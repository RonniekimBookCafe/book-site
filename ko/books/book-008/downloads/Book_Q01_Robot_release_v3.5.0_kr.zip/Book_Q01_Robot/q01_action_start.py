# -*- coding: utf-8 -*-
"""
q01_action_start.py  |  QUAD-01 시작 파일 · 액션 동작
배포 버전 3.4.3 (v3.4.2 ACTION 화면 순서 개선)  |  바닥에 선 로봇(Book-QUAD-01-ACTION)의 Microcontroller에 연결해 실행합니다.

숫자 키를 누르면 정해진 동작을 한 번 실행합니다.
    Level 1 소통 및 준비      1 서서 인사 · 2 앉아서 손 흔들기 · 3 다리 스트레칭
    Level 2 역동적 퍼포먼스   4 팔굽혀펴기 · 5 앞발 번갈아 흔들기 · 6 수영 동작
    Level 3 고난도 아크로바틱 7 플란체 푸쉬업 · 8 물구나무서기 · 9 탭 댄스
    0                         기본 자세

좌표계: X축 앞 · Y축 왼쪽 · Z축 위 (원점은 각 다리의 엉덩이 관절)
동작의 자세(발끝 좌표)는 Q01_Lib/action/q01lib_actions.py에 있습니다.

콘솔 LOG는 영어로 나옵니다([시간] [분류] 내용). 읽는 법은 README 12장에 있습니다.
"""

# --- 준비 코드: 이 부분은 바꾸지 않습니다 ------------------------------------
# 스크립트를 실행할 때마다 Q01_Lib 라이브러리를 새로 읽어 옵니다. 라이브러리
# 파일을 고쳤을 때 고친 내용이 바로 반영되게 하기 위해서입니다. 파일을 지우는
# 것이 아니라, RoboCo가 기억해 둔 이전 내용만 비웁니다.
import sys as _sys

_sys.dont_write_bytecode = True  # 실행할 때 임시 파일(__pycache__ 폴더)을 만들지 않음

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.action.q01lib_action_app import ActionApp


# ========================================
# 1. CONTROL PARAMETERS  (먼저 바꿔 볼 값)
# ========================================
# --- 부드러운 이동 ---
SMOOTH_STEPS = 30            # 한 자세에서 다음 자세로 옮길 때 나누는 단계 수
FAST_DELAY = 0.01            # 단계 사이 쉬는 시간(초) - 빠른 이동 (기본값)
SLOW_DELAY = 0.02            # 단계 사이 쉬는 시간(초) - 느린 이동
VERY_SLOW_DELAY = 0.03       # 단계 사이 쉬는 시간(초) - 매우 느린 이동 (물구나무 자세)

# --- 서보 속도 ---
DEFAULT_RPM = 30             # 관절 서보 회전 속도 (ServoMotor.max_rpm)
FAST_RPM = 300               # 플란체 푸쉬업 · 물구나무서기에서 쓰는 빠른 회전 속도

# --- 기본 자세와 휴식 자세 ---
STAND_HEIGHT = 78            # 기본 자세(0번 키)의 몸체 높이. 네 발끝 = [0, 0, -STAND_HEIGHT]
REST_POSITION = [55, 0, -78] # 1~5번 등 일부 동작의 중간 휴식 자세 (완료 후 Stand 복귀)

# --- 손 흔들기 (1번 · 2번) : FR 엉덩이 X축 관절(Port 11)의 논리 각도 ---
SERVO_NEUTRAL = 92           # 흔들기 시작·끝 각도 (도)
SERVO_UP = 120               # 위쪽 끝 각도 (도)
SERVO_DOWN = 60              # 아래쪽 끝 각도 (도)
HAND_WAVES = 2               # 중립 → 위 → 아래 → 중립을 반복하는 횟수

# --- 동작별 반복 횟수와 시간 ---
STRETCH_REPEAT = 4           # 3번 다리 스트레칭: 좌우 반복 횟수
PUSH_UP_COUNT = 4            # 4번 팔굽혀펴기: 반복 횟수
PAW_WAVE_REPEAT = 3          # 5번 앞발 번갈아 흔들기: 반복 횟수
PAW_WAVE_DELAY = 0.001       # 5번 앞발 번갈아 흔들기: 단계 사이 쉬는 시간(초)
SWIM_REPEAT = 3              # 6번 수영 동작: 앞뒤로 젓는 횟수
PLANCHE_HOLD_SEC = 2         # 7번 · 8번: 플란체 자세를 유지하는 시간(초)
HAND_STAND_HOLD_SEC = 3      # 8번: 물구나무 자세를 유지하는 시간(초)

# --- 6번 수영 (v3.4.0 방식) ---
SWIM_Z = -50                 # 앞발 수영 높이
SWIM_RADIUS = 80             # 앞발 원호 반지름
SWIM_ANGLE_DEG = 40          # 앞발 원호 각도
SWIM_HIND = [-85, 10, -95]   # 뒷발 준비 위치
SWIM_KICK = [-65, 10, -92]   # 뒷발 발차기 위치
SWIM_KICKS = 2               # 앞발 젓기 한 번당 발차기 횟수
SWIM_STROKE_SEC = 0.8        # 팔 한 방향 이동 시간 (초)
SWIM_STROKES = None          # None이면 SWIM_REPEAT 유지 (v3.4.1 호환)
STEP_LIFT = 15              # 6번 복귀 시 발 높이
STEP_SEC = 0.5              # 6번 한 다리 복귀 시간

# --- 9번 탭 댄스 (v3.4.0 방식) ---
TAP_LIFT = 15               # 발 드는 높이
TAP_BEATS = 8               # 두 단계 템포의 각각 박자 수
TAP_BEAT_SEC = 0.3          # 기본 박자 길이 (초)

# --- 액션 로봇 Text Screen 표시 시간 ---
WELCOME_SEC = 1.0           # 시작: 첫 줄 로봇 모델명 / 두 번째 줄 WELCOME (초)
DONE_SEC = 1.5              # 실행 완료 표시 후 메인 화면으로 자동 복귀 (초)

# --- 키 읽기 ---
LOOP_SLEEP_SEC = 0.1         # 키를 한 번 읽은 뒤 쉬는 시간(초)
QUEUE_KEYS = True            # True: 동작 중에 누른 키를 끝난 뒤 차례로 실행 · False: 버림

# --- 콘솔 LOG ---
LOG_COLOR = True             # 콘솔 LOG에 색을 입힘. 콘솔에 <color=...> 글자가 그대로 보이면 False


# ========================================
# 2. KEYS  (키 배정)
# ========================================
ACTION_KEYS = {              # 누르면 한 번 실행
    "1": "hello",            # 서서 인사
    "2": "sit_and_wave",     # 앉아서 손 흔들기
    "3": "leg_stretch",      # 다리 스트레칭
    "4": "push_ups",         # 팔굽혀펴기
    "5": "front_paw_wave",   # 앞발 번갈아 흔들기
    "6": "swim",             # 수영 동작
    "7": "planche_push_ups", # 플란체 푸쉬업
    "8": "handstand",        # 물구나무서기
    "9": "tap_dance",       # 탭 댄스 (v3.4.0)
    "0": "stand",            # 기본 자세
}


# ========================================
# 3. RUN  (한 번 준비하고, 계속 반복)
# ========================================
def main():
    from scriptruntime import Runtime
    Runtime.require_force_close(False)  # Space: 게임 기본 즉시 종료, 별도 대기 프로세스 없음
    app = ActionApp(globals())   # 준비: 위의 값과 키 배정을 로봇에 전달하고 기본 자세로
    app.run()                    # 반복: 키 읽기 → 동작 실행


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""
Q01_Lib/leg1_joint  |  다리 테스트 1 · 관절 테스트 (q01_leg1_joint_start.py · Book-QUAD-01-LEG1)

    q01lib_leg1_joint.py   JointTest: 관절 서보에 각도를 직접 보냄 (Port · 관절 이름 · 회전 방향 · 좌우 반대)

키를 읽는 반복 부분과 로봇은 leg_common 폴더를 함께 씁니다.
"""

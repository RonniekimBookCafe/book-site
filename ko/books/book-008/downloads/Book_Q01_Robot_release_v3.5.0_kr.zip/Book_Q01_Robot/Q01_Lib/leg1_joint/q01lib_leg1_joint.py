# -*- coding: utf-8 -*-
"""
q01lib_leg1_joint.py  |  QUAD-01 교육용 라이브러리 · 다리 테스트 1 · 관절 테스트

시작 파일 q01_leg1_joint_start.py · 로봇 Book-QUAD-01-LEG1

발끝 좌표(IK)를 쓰지 않고 관절 서보 하나하나에 논리 각도를 직접 보냅니다.
어느 Port가 어느 관절인지, 각도를 바꾸면 다리가 어느 쪽으로 도는지, 왼쪽과
오른쪽 다리의 각도가 왜 반대인지를 확인합니다. 값과 키는 시작 파일에 있습니다.

    [관절 직접 조작] W · S / A · D / E · Q   고른 다리의 HY / HX / KN을 JOINT_JOG_DEG씩
                     K               고른 다리의 관절 세 개를 90도로
                     U · O · J · L   다리 고르기 (공통, q01lib_leg_app.py)
    [자동 테스트]    1 · 2 · 3 · 4   다리 하나의 관절 세 개를 차례로 돌림 (FL · HL · HR · FR)
                     5               네 다리의 엉덩이 X축 관절(HX)을 함께 벌렸다 돌아옴
                     6               네 다리의 HX → KN → HY를 차례로 천천히 돌리는 포즈 변화
                     0               관절 영점 자세 (모든 관절 논리 90도)

[관절 이름]
이 책은 관절을 "도는 축"으로 부릅니다(core/q01lib_ports.py).

    HX 엉덩이 X축 : x축(앞) 둘레로 돎 → 다리가 몸 바깥·안쪽으로 벌어지고 모임
    HY 엉덩이 Y축 : y축(왼쪽) 둘레로 돎 → 다리가 앞뒤로 흔들림
    KN 무릎        : y축과 나란한 축으로 돎 → 다리가 굽고 펴짐

[관절 직접 조작의 방향]
같은 키를 IK 테스트(q01_leg2_ik_start.py)에서 누르면 발끝 좌표가 같은 쪽으로 움직입니다.
W 앞 · S 뒤 · A 왼쪽 · D 오른쪽 · E 위(무릎 굽힘) · Q 아래(무릎 폄).
JOG_KEYS에는 왼쪽 다리(FL · HL) 기준으로 각도를 바꾸는 방향(+1 · -1)을 적습니다.
오른쪽 다리(HR · FR)는 HY와 KN 서보가 왼쪽 다리와 마주 보게 달려 있으므로
방향을 반대로 보냅니다. HX는 좌우 다리 모두 같은 방향입니다(core/q01lib_motion.py의
좌우 다리 방향 보정 표와 같음).

[로봇 화면]
    관절 · 다리 FL              고른 다리 (관절 제한에 닿으면 " · HX 제한")
    ------------------
    입력 HX 84  HY 137  KN 102  코드가 보낸 논리 각도 (0~180, 90이 중립)
    모터 HX 6  HY -47  KN -12   spin_to_degrees()에 보낸 물리 각도 (+90~-90)
    Port HX 4  HY 3  KN 2       그 다리의 관절 Port
    발끝 x 13  y 10  z -97      세 관절 각도로 계산한 발끝 좌표 (FK)
    ------------------
    WS HY  AD HX  EQ KN         관절 직접 조작 키
화면 모양(8줄)과 색은 leg_common/q01lib_leg_screen.py가 정합니다.
자동 테스트 중에는 테스트마다 줄 수가 일정한 화면 하나가 나옵니다.
    1 ~ 4  테스트 이름 · 관절과 Port · 입력과 모터 각도 · 발끝 좌표 (모르면 "-") · 멈춤 키
    5 6 0  테스트 이름 · 지금 돌리는 관절과 각도 · 멈춤 키

[콘솔 LOG]  (영어, 형식은 core/q01lib_log.py)
서보에 각도를 보낼 때마다 [JOINT] 한 줄(관절 · Port · 논리 각도 바뀜 · 모터 각도)을 남깁니다.
그 다리의 관절 세 개의 각도를 모두 알면 FK로 계산한 발끝 좌표를 [STATE] 한 줄 더 남깁니다.

    [ 41.0] [INPUT]     W    HY forward
    [ 41.0] [JOINT]     FL_HY port=3   in=147 -> 137 deg  motor=-47 deg
    [ 41.0] [STATE]     FL foot (FK)  x=  13.0  y=  10.2  z= -97.3
"""

from ..core import q01lib_ports as ports
from ..core.q01lib_ik import restrict_angle
from ..core.q01lib_key_events import key_label
from ..leg_common.q01lib_leg_robot import PORT_NAMES
from ..leg_common import q01lib_leg_screen as scr
from ..core import q01lib_log as L    # 콘솔 LOG 출력 (L.event · L.more · L.key …)

JOINTS = ("HX", "HY", "KN")

# 관절 종류별 Port (FL · HL · HR · FR 순서)
JOINT_PORTS = {joint: [ports.LEG_JOINT_PORTS[leg][i] for leg in range(4)]
               for i, joint in enumerate(JOINTS)}

# JOG_KEYS의 (관절, 방향)을 사람이 읽는 말로
JOG_WORDS = {("HY", -1): "앞으로", ("HY", 1): "뒤로",
             ("HX", -1): "왼쪽으로", ("HX", 1): "오른쪽으로",
             ("KN", 1): "굽힘", ("KN", -1): "폄"}

# 같은 말의 콘솔용 영어
JOG_WORDS_EN = {("HY", -1): "forward", ("HY", 1): "back",
                ("HX", -1): "left", ("HX", 1): "right",
                ("KN", 1): "bend", ("KN", -1): "extend"}

# 화면 제목 (한 줄을 한글 10자 안팎으로)
SCREEN_TITLES = {
    "spread": "네 다리 HX 벌리기",
    "sweep": "네 다리 포즈 변화",
    "zero": "관절 영점 자세",
}


def mirror(leg, angle):
    """왼쪽 다리 기준 각도를 그 다리의 각도로 바꿉니다.

    오른쪽 다리(HR·FR)는 서보가 왼쪽 다리와 마주 보게 달려 있어서, 같은 방향으로
    돌리려면 180 - 각도를 보냅니다.
    """
    return angle if leg in ports.LEFT_LEGS else 180 - angle


class JointTest:
    """다리 테스트 1 · 관절 테스트."""

    TITLE = "관절 테스트"
    HEADER = "QUAD-01 LEG TEST 1  JOINT   (Book-QUAD-01-LEG1)"
    LOG_CATEGORIES = ()   # 공통 분류 밖에 이 테스트가 콘솔에 쓰는 분류 (열 맞추기)
    SHORT = "관절"
    START_FILE = "q01_leg1_joint_start.py"
    USES_LEG_SELECT = True
    VALUE_NAMES = ("KEY_REPEAT_SEC", "LEFT_TEST_ANGLES", "TEST_ORDER", "JOINT_STEP_SEC", "ZERO_GROUP_SEC",
                   "SPREAD_LEFT_ANGLE", "SPREAD_HOLD_SEC", "SPREAD_RETURN_SEC",
                   "SWEEP_HX_DEG", "SWEEP_KN_DEG", "SWEEP_HY_DEG", "SWEEP_STEP_SEC",
                   "SWEEP_PAUSE_SEC", "SWEEP_END_PAUSE_SEC", "SWEEP_RESET_GROUP_SEC", "JOINT_JOG_DEG",
                   "LEG_TEST_KEYS", "SPREAD_KEY", "SWEEP_KEY", "ZERO_KEY", "JOG_KEYS", "LEG_ZERO_KEY")

    def __init__(self, robot, settings):
        self.robot = robot
        self.s = settings
        self.note = None            # 대기 화면 첫 줄에 붙이는 알림 (관절 제한)
        for key, (joint, sign) in settings["JOG_KEYS"].items():
            if (joint, sign) not in JOG_WORDS:
                raise ValueError(f"JOG_KEYS '{key}': joint must be HX, HY or KN, direction 1 or -1")

    # ------------------------------------------------------------
    # 키 · 화면 · 콘솔 안내
    # ------------------------------------------------------------
    def actions(self):
        """(키, 콘솔에 남길 설명, 실행할 함수, 걸린 시간을 남길지) 목록."""
        s = self.s
        items = []
        for key, name in s["LEG_TEST_KEYS"].items():
            leg = ports.LEG_NAMES.index(name)
            items.append((key, f"{name} joint test", lambda leg=leg: self.test_leg(leg), True))
        items.append((s["SPREAD_KEY"], "spread HX (4 legs)", self.spread, True))
        items.append((s["SWEEP_KEY"], "pose sweep (4 legs)", self.sweep, True))
        items.append((s["ZERO_KEY"], "zero pose (all joints 90 deg)", self.zero_pose, True))
        for key, (joint, sign) in s["JOG_KEYS"].items():
            items.append((key, f"{joint} {JOG_WORDS_EN[(joint, sign)]}",
                          lambda joint=joint, sign=sign: self.jog(joint, sign), False))
        items.append((s["LEG_ZERO_KEY"], "selected leg to 90 deg", self.zero_leg, False))
        return items

    def repeat_keys(self):
        """누르고 있으면 KEY_REPEAT_SEC마다 다시 실행하는 키."""
        return list(self.s["JOG_KEYS"])

    def _jog_pairs(self):
        """화면 · 콘솔용: 관절마다 (+쪽 키, -쪽 키). 예: {"HY": ("W", "S"), ...}"""
        keys = {}
        for key, (joint, sign) in self.s["JOG_KEYS"].items():
            keys[(joint, sign)] = key_label(key)
        return {joint: (keys.get((joint, a), "?"), keys.get((joint, -a), "?"))
                for joint, a in (("HY", -1), ("HX", -1), ("KN", 1))}

    def guide(self):
        """콘솔 키 안내 (영어)."""
        s = self.s
        jog = {j: L.key("/".join(pair)) for j, pair in self._jog_pairs().items()}
        k = {name: L.key(key_label(s[name])) for name in ("LEG_ZERO_KEY", "SPREAD_KEY", "SWEEP_KEY", "ZERO_KEY")}
        legs = "  ".join(f"{L.key(key_label(key))} {n}" for key, n in s["LEG_TEST_KEYS"].items())
        return [
            f" Jog    {jog['HY']} HY fwd/back   {jog['HX']} HX left/right   {jog['KN']} KN bend/ext",
            f"        {s['JOINT_JOG_DEG']} deg per key   {k['LEG_ZERO_KEY']} selected leg to 90 deg",
            f" Test   {legs}   (KN, HY, HX of one leg)",
            f"        {k['SPREAD_KEY']} spread HX   {k['SWEEP_KEY']} pose sweep   {k['ZERO_KEY']} zero pose",
        ]

    def jog_footer(self):
        """키 안내 줄: 관절 직접 조작 키 (예: "WS HY  AD HX  EQ KN")."""
        jog = self._jog_pairs()
        return scr.keys_line([(jog[j][0] + jog[j][1], j) for j in ("HY", "HX", "KN")])

    def idle_page(self):
        """대기 화면: 제목(고른 다리) / 입력 각도 · 모터 각도 · Port · FK 발끝 / 관절 직접 조작 키."""
        body = [self.robot.servo_text(prefix="입력 "),
                self.robot.motor_text(),
                self.robot.port_text(),
                self.robot.foot_text()]
        title = f"관절 · 다리 {self.robot.leg_name}"
        if self.note:
            title = f"{title} · {scr.paint(self.note, 'warn')}"
        return title, body, self.jog_footer()

    def help_lines(self, leg_keys):
        """F1 키 안내 화면 (이 테스트의 키). leg_keys: 다리 고르기 키 (예: "U O J L")."""
        s = self.s
        jog = self._jog_pairs()
        tests = " ".join(key_label(k) for k in s["LEG_TEST_KEYS"])
        return [scr.keys_line([(leg_keys, "다리"), (key_label(s["LEG_ZERO_KEY"]), "90도")]),
                scr.keys_line([(jog[j][0] + jog[j][1], j) for j in ("HY", "HX", "KN")]),
                scr.keys_line([(tests, "다리 테스트")]),
                scr.keys_line([(key_label(s["SPREAD_KEY"]), "벌리기"), (key_label(s["SWEEP_KEY"]), "포즈"),
                               (key_label(s["ZERO_KEY"]), "영점")])]

    def enter(self):
        """시작할 때: 로봇은 움직이지 않습니다. 각도를 보낸 적 없는 관절은 화면에 - 로 나옵니다."""
        self.note = None

    def before_action(self):
        """키 하나를 실행하기 전에: 지난 알림을 지웁니다."""
        self.note = None

    # ------------------------------------------------------------
    # 관절 직접 조작
    # ------------------------------------------------------------
    def jog(self, joint, sign):
        """고른 다리의 관절 하나를 JOINT_JOG_DEG만큼 돌립니다."""
        leg = self.robot.leg
        port = ports.LEG_JOINT_PORTS[leg][JOINTS.index(joint)]
        if leg not in ports.LEFT_LEGS and joint != "HX":
            sign = -sign                # 오른쪽 다리의 HY · KN은 왼쪽 다리와 반대 방향
        now = self.robot.angles.get(port)
        if now is None:
            L.event("STATE", f"{PORT_NAMES[port]}: no angle sent yet, starting from 90 deg")
            now = 90
        target = restrict_angle(now + sign * self.s["JOINT_JOG_DEG"])
        limited = target in (ports.LOGICAL_MIN_DEG, ports.LOGICAL_MAX_DEG)
        self.note = f"{joint} 제한" if limited else None
        if target == now:
            L.event("WARN", f"{PORT_NAMES[port]} at {now} deg, limit "
                            f"{ports.LOGICAL_MIN_DEG}-{ports.LOGICAL_MAX_DEG} deg")
        else:
            self.robot.send_joint(port, target)
            self.robot.log_foot(leg)

    def motion_angle(self, logical):
        """논리 각도 → 모터(물리) 각도 (core/q01lib_servo.py convert_angle)."""
        return self.robot.motion.servo.convert_angle(logical)

    def zero_leg(self):
        """고른 다리의 관절 세 개를 90도에 둡니다."""
        leg = self.robot.leg
        for port in ports.LEG_JOINT_PORTS[leg]:
            self.robot.send_joint(port, 90)
        self.robot.log_foot(leg)

    # ------------------------------------------------------------
    # 자동 테스트
    # ------------------------------------------------------------
    def zero_pose(self, group_sec=None):
        """관절 종류별로 네 다리를 논리 90도(물리 0도)에 둡니다. KN → HY → HX 순서."""
        if group_sec is None:
            group_sec = self.s["ZERO_GROUP_SEC"]
        self.robot.show_running(SCREEN_TITLES["zero"], "KN · HY · HX 차례로 90도", "진행 중")
        L.event("TASK", "zero pose: all joints to 90 deg (KN, HY, HX)")
        for i, joint in enumerate(("KN", "HY", "HX"), 1):
            joint_ports = JOINT_PORTS[joint]
            L.event("TASK", f"step {i}: {joint}  ports {' '.join(map(str, joint_ports))}")
            for port in joint_ports:
                self.robot.send_joint(port, 90)
            self.robot.show_running(SCREEN_TITLES["zero"], "KN · HY · HX 차례로 90도",
                                    f"{joint} {scr.paint(90, 'angle')}도 · Port {' '.join(map(str, joint_ports))}")
            self.robot.wait(group_sec)
        for leg in range(4):
            self.robot.log_foot(leg)
        L.event("TASK", "zero pose done")

    def test_leg(self, leg):
        """다리 하나의 관절을 TEST_ORDER 순서로, 관절마다 각도 목록을 차례로 보냅니다."""
        name = ports.LEG_NAMES[leg]
        L.event("TASK", f"{name} joint test: {' -> '.join(self.s['TEST_ORDER'])}")
        hx, hy, kn = ports.LEG_JOINT_PORTS[leg]
        joint_port = {"HX": hx, "HY": hy, "KN": kn}
        for joint in self.s["TEST_ORDER"]:
            port = joint_port[joint]
            for angle in self.s["LEFT_TEST_ANGLES"][joint]:
                sent = mirror(leg, angle)
                self.robot.send_joint(port, sent)
                self.robot.log_foot(leg)
                self.robot.show_running(f"{name} 관절 테스트", f"{PORT_NAMES[port]}  Port {port}",
                                        f"입력 {scr.paint(sent, 'angle')}도 · 모터 {self.motion_angle(sent)}도",
                                        self.robot.foot_text(leg))   # 각도를 모르는 관절이 있으면 "-"
                self.robot.wait(self.s["JOINT_STEP_SEC"])

    def spread(self):
        """네 다리의 HX를 함께 벌린 뒤(왼쪽 SPREAD_LEFT_ANGLE, 오른쪽은 대칭) 90도로 되돌립니다."""
        self.robot.show_running(SCREEN_TITLES["spread"], "진행 중")
        L.event("TASK", "spread HX on 4 legs, then back to 90 deg")
        for leg, port in enumerate(JOINT_PORTS["HX"]):
            self.robot.send_joint(port, mirror(leg, self.s["SPREAD_LEFT_ANGLE"]))
        left = self.s["SPREAD_LEFT_ANGLE"]
        self.robot.show_running(SCREEN_TITLES["spread"],
                                f"HX 왼쪽 {scr.paint(left, 'angle')} · 오른쪽 {scr.paint(180 - left, 'angle')}")
        self.robot.wait(self.s["SPREAD_HOLD_SEC"])
        for port in JOINT_PORTS["HX"]:
            self.robot.send_joint(port, 90)
        self.robot.wait(self.s["SPREAD_RETURN_SEC"])

    def sweep(self):
        """네 다리의 HX → KN → HY를 1도씩 천천히 돌린 뒤 관절 영점 자세로 돌아옵니다.

        1도마다 서보 12번을 보내므로 콘솔에는 관절마다 시작·끝 각도만 남깁니다.
        """
        self.robot.show_running(SCREEN_TITLES["sweep"], "HX · KN · HY 1도씩 차례로", "진행 중")
        L.event("TASK", "pose sweep: HX, KN, HY 1 deg at a time")
        for joint, degrees in (("HX", self.s["SWEEP_HX_DEG"]),
                               ("KN", self.s["SWEEP_KN_DEG"]),
                               ("HY", self.s["SWEEP_HY_DEG"])):
            L.event("TASK", f"{joint}  left 90 -> {90 - (degrees - 1)} deg   "
                            f"right 90 -> {90 + (degrees - 1)} deg")
            for i in range(degrees):
                for leg, port in enumerate(JOINT_PORTS[joint]):
                    self.robot.send_joint(port, mirror(leg, 90 - i), log_line=False)
                self.robot.show_running(SCREEN_TITLES["sweep"], "HX · KN · HY 1도씩 차례로",
                                        f"{joint} 왼쪽 {scr.paint(90 - i, 'angle')} · "
                                        f"오른쪽 {scr.paint(90 + i, 'angle')}")
                self.robot.wait(self.s["SWEEP_STEP_SEC"])
            pause = self.s["SWEEP_END_PAUSE_SEC"] if joint == "HY" else self.s["SWEEP_PAUSE_SEC"]
            self.robot.wait(pause)
        for leg in range(4):
            self.robot.log_foot(leg)
        self.zero_pose(self.s["SWEEP_RESET_GROUP_SEC"])

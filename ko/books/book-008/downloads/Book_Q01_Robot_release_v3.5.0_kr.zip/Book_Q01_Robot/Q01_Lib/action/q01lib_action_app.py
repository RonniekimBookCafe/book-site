# -*- coding: utf-8 -*-
"""Book-QUAD-01-ACTION only, version 3.4.3.

TextScreen Port 0 display sequence:
    WELCOME (robot name / WELCOME)
    -> MAIN (waiting / key choices)
    -> RUNNING (key / action)
    -> DONE (key / action)
    -> MAIN.

TextScreen.color colors the whole text, not individual words. The prominent
status and key information are prioritized by text position and state palette.
No ACTION movement method or non-ACTION module is modified in this release.
"""
import time
from color import Color
from ..core import q01lib_log as L
from ..core.q01lib_log import log_traceback
from ..core.q01lib_keys import key_stream
from ..core.q01lib_key_events import key_label
from ..core.q01lib_motion import LegMotion
from ..core.q01lib_screen import StatusScreen
from ..core.q01lib_servo import setup_canonical_servos
from .q01lib_actions import Actions, ACTION_NAMES, LOG_NAMES, LEVELS

DEFAULTS = {
    "SMOOTH_STEPS": 30,
    "FAST_DELAY": 0.01, "SLOW_DELAY": 0.02, "VERY_SLOW_DELAY": 0.03,
    "DEFAULT_RPM": 30, "FAST_RPM": 300,
    "STAND_HEIGHT": 78, "REST_POSITION": [55, 0, -78],
    "SERVO_NEUTRAL": 92, "SERVO_UP": 120, "SERVO_DOWN": 60,
    "HAND_WAVES": 2, "STRETCH_REPEAT": 4, "PUSH_UP_COUNT": 4,
    "PAW_WAVE_REPEAT": 3, "PAW_WAVE_DELAY": 0.001,
    "SWIM_REPEAT": 3, "SWIM_STROKES": None, "SWIM_Z": -50,
    "SWIM_RADIUS": 80, "SWIM_ANGLE_DEG": 40,
    "SWIM_HIND": [-85, 10, -95], "SWIM_KICK": [-65, 10, -92],
    "SWIM_KICKS": 2, "SWIM_STROKE_SEC": 0.8,
    "STEP_LIFT": 15, "STEP_SEC": 0.5,
    "PLANCHE_HOLD_SEC": 2, "HAND_STAND_HOLD_SEC": 3,
    "TAP_LIFT": 15, "TAP_BEATS": 8, "TAP_BEAT_SEC": 0.3,
    "LOOP_SLEEP_SEC": 0.1, "QUEUE_KEYS": True, "LOG_COLOR": True,
    "WELCOME_SEC": 1.0, "DONE_SEC": 1.5,  # non-blocking screen hold durations
    "ACTION_KEYS": {
        "1":"hello", "2":"sit_and_wave", "3":"leg_stretch",
        "4":"push_ups", "5":"front_paw_wave", "6":"swim",
        "7":"planche_push_ups", "8":"handstand", "9":"tap_dance", "0":"stand",
    },
}

# ACTION TextScreen(Port 0) only. Entire screen uses one color per state.
# Dark background (game model) -> high-contrast text colors.
SCREEN_COLORS = {
    "welcome": Color(0.86, 0.93, 1.00),   # ice white / welcome
    "idle":    Color(0.43, 0.96, 1.00),   # cyan / main, 1~9 selection
    "running": Color(1.00, 0.85, 0.27),   # amber / active action
    "done":    Color(0.55, 1.00, 0.75),   # mint / finished action
    "error":   Color(1.00, 0.45, 0.43),   # coral / failure
}

_WELCOME_LINES = ("Book-QUAD-01-ACTION", "WELCOME")
_IDLE_LINES = ("Q01 | 대기 중", "1~9 키 선택")


# 이 프로그램이 콘솔에 쓰는 분류 (분류 칸 폭을 이 가운데 가장 긴 이름에 맞춤)
LOG_CATEGORIES = ("INPUT", "STATE", "ACTION", "WARN", "ERROR")


def print_instructions(action_keys, queue_keys):
    """시작 안내를 콘솔에 출력합니다 (키는 시작 파일의 ACTION_KEYS에서 만듦)."""
    lines = [" Frame  x forward   y left   z up   (origin: hip joint)"]
    for level in sorted({LEVELS[n] for n in action_keys.values()}, key=lambda v: (v == 0, v)):
        label = f"L{level}" if level else "Base"
        lines += L.key_lines(label, [(key_label(k), LOG_NAMES[n])
                                     for k, n in action_keys.items() if LEVELS[n] == level])
    lines.append(" One key, one action. Keys pressed during an action "
                 + ("wait." if queue_keys else "are ignored."))
    L.banner("QUAD-01 ACTION   (Book-QUAD-01-ACTION)", lines)


def key_message(key, name):
    """키를 눌렀을 때 콘솔에 남기는 문장 (영어 이름 + 메서드 이름)."""
    return f"{L.key(key_label(key), 4)} {LOG_NAMES[name]:<16} ({name})"


class ActionApp:
    """액션 동작 실습의 메인 루프."""

    def __init__(self, script_values: dict):
        """script_values: 시작 파일의 globals().
        준비하다 오류가 나면(시작 파일의 값 · 키 배정 · Port) 콘솔에 영어로 알리고, run()은 바로 끝납니다.
        """
        self.ready = False
        try:
            self._setup(script_values)
            self.ready = True
        except Exception as e:
            L.setup_failed(e, "q01_action_start.py")

    def _screen_state(self, state, key="", name=""):
        """Write two explicit lines and apply one RoboCo-supported text color.

        Display order: welcome -> idle -> running -> done -> idle.
        A second action cannot preempt the done display (see update()).
        """
        if state == "welcome":
            top, bottom = _WELCOME_LINES
        elif state == "idle":
            top, bottom = _IDLE_LINES
        elif state == "running":
            top, bottom = "KEY {} | 실행 중".format(key), ACTION_NAMES[name]
        elif state == "done":
            top, bottom = "KEY {} | 완료".format(key), ACTION_NAMES[name]
        elif state == "error":
            top, bottom = "KEY {} | 오류".format(key), ACTION_NAMES.get(name, "동작 확인")
        else:
            raise ValueError("unknown screen state " + str(state))
        self.screen.screen.color = SCREEN_COLORS[state]
        self.screen.show_lines(top, bottom)
        self.screen_state = state


    def _setup(self, script_values: dict):
        s = dict(DEFAULTS)
        for name, value in script_values.items():
            if name in DEFAULTS:
                s[name] = value
        L.configure(LOG_CATEGORIES, s["LOG_COLOR"])

        for key, name in s["ACTION_KEYS"].items():
            if name not in ACTION_NAMES:
                raise ValueError(f"ACTION_KEYS '{key}': unknown action '{name}'. "
                                 f"Use one of: {', '.join(ACTION_NAMES)}")

        # A non-blocking welcome/complete hold; action motors are never delayed.
        for key in ("WELCOME_SEC", "DONE_SEC"):
            try:
                s[key] = float(s[key])
            except (TypeError, ValueError):
                raise ValueError("{} must be a non-negative number".format(key))
            if not 0 <= s[key] <= 60:
                raise ValueError("{} must be in 0..60 seconds".format(key))

        self.s = s
        print_instructions(s["ACTION_KEYS"], s["QUEUE_KEYS"])
        # ACTION-only Text Screen (Port 0); never change shared screen module.
        self.screen = StatusScreen(centered=True, enforce_contrast=False)  # ACTION status colors stay as v3.4.6
        self.screen_until = 0.0
        self._screen_state("welcome")
        setup_canonical_servos()  # 12DOF initial robot spec (v3.4.1)
        self.motion = LegMotion(servo_rpm=s["DEFAULT_RPM"])
        self.actions = Actions(self.motion, s)

        # 키마다 사건 흐름을 하나씩 만들어 둠: (키, 동작 이름, 콘솔 문장, 흐름)
        self.bindings = [(key, name, key_message(key, name), key_stream(key))
                         for key, name in s["ACTION_KEYS"].items()]

        # 시작할 때 기본 자세로
        self.actions.stand()
        L.event("STATE", f"stand pose  height={s['STAND_HEIGHT']:g} mm")

        # Welcome remains visible after robot stand initialization; no blocking
        # sleep in setup so RoboCo Space can terminate the run loop promptly.
        self.screen_until = time.monotonic() + s["WELCOME_SEC"]

    def update(self):
        """Run a non-blocking welcome/done state timer before handling keys.

        WELCOME -> MAIN -> RUNNING -> DONE -> MAIN.
        During WELCOME, presses are ignored to guarantee the first MAIN screen.
        During DONE, QUEUE_KEYS=True preserves stream events until MAIN,
        QUEUE_KEYS=False discards them without starting a new action.
        """
        queue = self.s["QUEUE_KEYS"]
        if self.screen_state == "welcome":
            if time.monotonic() < self.screen_until:
                self.discard_pending(silent=True)
                time.sleep(self.s["LOOP_SLEEP_SEC"])
                return
            self.discard_pending(silent=True)
            self._screen_state("idle")
            # Show MAIN before reading keys on the next update.
            time.sleep(self.s["LOOP_SLEEP_SEC"])
            return

        if self.screen_state == "done":
            if time.monotonic() < self.screen_until:
                if not queue:
                    self.discard_pending(silent=True)
                time.sleep(self.s["LOOP_SLEEP_SEC"])
                return
            if not queue:
                self.discard_pending(silent=True)
            self._screen_state("idle")
            # Keep MAIN in a real frame even when another key was queued.
            time.sleep(self.s["LOOP_SLEEP_SEC"])
            return

        for key, name, message, stream in self.bindings:
            performed = False
            for event in stream:
                if event:
                    self.perform(name, message)
                    performed = True
                    if not queue:
                        break
            if performed and not queue:
                # 동작 중에 누른 키를 버리고, 다음 반복에서 새로 읽음
                self.discard_pending()
                break
        time.sleep(self.s["LOOP_SLEEP_SEC"])

    def perform(self, name, message):
        """One active action. Normal completion returns to stand (v3.4.1)."""
        L.event("INPUT", message)
        key = next(k for k, n in self.s["ACTION_KEYS"].items() if n == name)
        self._screen_state("running", key, name)
        start = time.time()
        try:
            getattr(self.actions, name)()
            if name != "stand":
                self.actions.stand()  # return after successful movement
        except KeyboardInterrupt:
            raise  # RoboCo Space: no extra movement or color animation
        except Exception:
            self._screen_state("error", key, name)
            raise
        L.event("ACTION", f"{LOG_NAMES[name]}  done in {time.time() - start:.1f} s")
        self._screen_state("done", key, name)
        # Display-only hold is polled by update(); there is no blocking sleep.
        # After DONE_SEC, MAIN is restored without requiring an additional key.
        self.screen_until = time.monotonic() + self.s["DONE_SEC"]

    def discard_pending(self, silent=False):
        """Discard stale keyboard events (only needed during welcome / no-queue)."""
        dropped = 0
        for _key, _name, _message, stream in self.bindings:
            for event in stream:
                if event:
                    dropped += 1
        if dropped and not silent:
            L.event("INPUT", f"ignored {dropped} key{'s' if dropped > 1 else ''} pressed during the action")

    def run(self):
        """이벤트 루프. Space 종료 시 추가 복귀 동작 없이 중단합니다."""
        if not self.ready:
            return
        L.event("STATE", "ready")
        try:
            from scriptruntime import Runtime
            while not Runtime.quitting():
                self.update()
        except KeyboardInterrupt:
            pass  # RoboCo Space: 별도 종료 대기·자세 이동 없음
        except Exception as e:
            L.event("ERROR", f"unexpected error: {e}")
            log_traceback()
        finally:
            L.event("STATE", "end")  # 종료 중 서보 제어·sleep은 수행하지 않음

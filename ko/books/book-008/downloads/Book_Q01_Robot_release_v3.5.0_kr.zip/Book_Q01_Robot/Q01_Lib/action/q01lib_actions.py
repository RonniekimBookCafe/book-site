# -*- coding: utf-8 -*-
"""QUAD-01 ACTION: 1-5,7-8 v3.9.7 원형 · 6/9 v3.4.0 이식.

현재 키맵에 연결되지 않은 과거 back_flip/IMU 전용 제어는 이 ACTION 모듈에서 제거합니다.
다른 QUAD-01 로봇의 보행·다리·균형 코드는 독립적으로 보존됩니다.
"""
import math
import time
from ..core import q01lib_ports as ports
from ..core.q01lib_ik import is_valid_point, coordinate_to_angle
from ..walk.q01lib_gait import swing_pair

# 현재 키 0~9만 표시합니다 (과거의 Back Flip 제거).
ACTION_NAMES = {
    "stand": "기본 자세", "hello": "서서 인사", "sit_and_wave": "앉아서 손 흔들기",
    "leg_stretch": "다리 스트레칭", "push_ups": "팔굽혀펴기",
    "front_paw_wave": "앞발 번갈아 흔들기", "swim": "수영 동작",
    "planche_push_ups": "플란체 푸쉬업", "handstand": "물구나무서기",
    "tap_dance": "탭 댄스",
}
LOG_NAMES = {
    "stand": "stand", "hello": "hello", "sit_and_wave": "sit and wave",
    "leg_stretch": "leg stretch", "push_ups": "push-ups",
    "front_paw_wave": "front paw wave", "swim": "swim",
    "planche_push_ups": "planche push-ups", "handstand": "handstand",
    "tap_dance": "tap dance",
}
LEVELS = {
    "stand": 0, "hello": 1, "sit_and_wave": 1, "leg_stretch": 1,
    "push_ups": 2, "front_paw_wave": 2, "swim": 2,
    "planche_push_ups": 3, "handstand": 3, "tap_dance": 3,
}

class Actions:
    """Nine active ACTION movement methods only."""

    def __init__(self, motion, settings):
        """settings: ACTION Reader Script parameters."""
        self.motion = motion
        self.servo = motion.servo
        self.s = settings

    def _smooth_move_to(self, target_positions, steps=None, delay=None, rpm=None):
        """네 다리를 목표 좌표까지 부드럽게 옮깁니다.

        1. 다리마다 지금 좌표와 목표 좌표의 차이를 steps로 나눠 한 단계의 이동량을 구함
        2. 한 단계씩 이동량을 더하고 서보에 보냄
        3. 단계마다 delay초 쉼

        :param target_positions: 목표 좌표 [[x, y, z] × 4] (FL, HL, HR, FR)
        :param steps: 단계 수 (생략하면 SMOOTH_STEPS)
        :param delay: 단계 사이 쉬는 시간(초) (생략하면 FAST_DELAY)
        :param rpm: 서보 속도 (생략하면 DEFAULT_RPM)
        """
        if steps is None:
            steps = self.s["SMOOTH_STEPS"]
        if delay is None:
            delay = self.s["FAST_DELAY"]
        if rpm is None:
            rpm = self.s["DEFAULT_RPM"]

        points = self.motion.points
        increments = []
        for i in range(4):
            dx = (target_positions[i][0] - points[i][0]) / steps
            dy = (target_positions[i][1] - points[i][1]) / steps
            dz = (target_positions[i][2] - points[i][2]) / steps
            increments.append([dx, dy, dz])

        for _ in range(steps):
            for i in range(4):
                points[i][0] += increments[i][0]
                points[i][1] += increments[i][1]
                points[i][2] += increments[i][2]
            self.motion.run(rpm)
            time.sleep(delay)

    def _move_single_leg(self, leg_index, target_position, steps=None, delay=None, rpm=None):
        """다리 하나만 목표 좌표까지 부드럽게 옮깁니다. 나머지 세 다리는 그 자리에 둡니다.

        :param leg_index: 다리 번호 (0 FL, 1 HL, 2 HR, 3 FR)
        :param target_position: 목표 좌표 [x, y, z]
        """
        if steps is None:
            steps = self.s["SMOOTH_STEPS"]
        if delay is None:
            delay = self.s["FAST_DELAY"]
        if rpm is None:
            rpm = self.s["DEFAULT_RPM"]

        point = self.motion.points[leg_index]
        increments = [(target_position[j] - point[j]) / steps for j in range(3)]

        for _ in range(steps):
            for j in range(3):
                point[j] += increments[j]
            self.motion.run(rpm)
            time.sleep(delay)

    def _wave_servo(self, port, start_angle, end_angle, delay=None, rpm=None):
        """서보 하나를 start_angle에서 end_angle까지 1도씩 돌립니다(끝 각도 포함).

        발끝 좌표(IK)를 거치지 않고 관절 하나의 논리 각도(0~180도)를 직접 보냅니다.

        :param port: 서보 Port
        :param start_angle, end_angle: 논리 각도 (도)
        :param delay: 1도마다 쉬는 시간(초) (생략하면 FAST_DELAY)
        :param rpm: 서보 속도 (생략하면 DEFAULT_RPM)
        """
        if delay is None:
            delay = self.s["FAST_DELAY"]
        if rpm is None:
            rpm = self.s["DEFAULT_RPM"]

        step = 1 if end_angle > start_angle else -1
        for angle in range(start_angle, end_angle + step, step):
            self.servo.set_servo_angle(port, angle, rpm)
            time.sleep(delay)

    def _wave_hand(self):
        """FR 엉덩이 X축 관절을 중립 → 위 → 아래 → 중립으로 HAND_WAVES번 흔듭니다."""
        port = ports.FR_HX
        neutral = self.s["SERVO_NEUTRAL"]
        up = self.s["SERVO_UP"]
        down = self.s["SERVO_DOWN"]
        for _ in range(self.s["HAND_WAVES"]):
            self._wave_servo(port, neutral, up)
            self._wave_servo(port, up, down)
            self._wave_servo(port, down, neutral)

    def _return_to_rest(self, delay=None):
        """네 다리를 휴식 자세(REST_POSITION)로 옮깁니다."""
        rest_positions = [list(self.s["REST_POSITION"]) for _ in range(4)]
        self._smooth_move_to(rest_positions, delay=delay or self.s["SLOW_DELAY"])

    def _snap_to(self, positions, rpm):
        """목표 좌표를 한 단계로 보냅니다. 서보는 rpm 속도로 목표까지 단번에 돕니다.

        :param positions: 다리별 목표 좌표 {다리 번호: [x, y, z]}. 빠진 다리는 그 자리에 둠
        """
        for leg, target in positions.items():
            self.motion.points[leg] = list(target)
        self.motion.run(rpm)

    def stand(self):
        """네 다리를 기본 서 있는 자세(발끝 z = -STAND_HEIGHT)로 옮깁니다."""
        stand = [0, 0, -self.s["STAND_HEIGHT"]]
        target_positions = [list(stand) for _ in range(4)]
        self._smooth_move_to(target_positions)

    def hello(self):
        """서서 인사 (시작).

        1. 인사 준비 자세 : FL 발끝을 몸 안쪽(-y)으로, 뒷다리를 조금 앞으로
        2. 손 들기        : FR 발끝을 앞 위쪽으로
        3. 손 흔들기      : FR 엉덩이 X축 관절을 직접 돌림 (HAND_WAVES번)
        4. 복귀           : 네 다리를 z = -100으로
        """
        greeting_pose = [
            [0, -30, -99],
            [10, 0, -99],
            [10, 0, -99],
            [0, 0, -99],
        ]
        self._smooth_move_to(greeting_pose, delay=self.s["SLOW_DELAY"])

        self._move_single_leg(3, [80, 0, -23])

        self._wave_hand()

        final_pose = [[0, 0, -100] for _ in range(4)]
        self._smooth_move_to(final_pose, delay=self.s["SLOW_DELAY"])

    def sit_and_wave(self):
        """앉아서 손 흔들기 (친근감 표현).

        1. 앉은 자세  : 뒷다리를 앞으로 당겨 굽히고, 앞다리는 펴서 몸 앞쪽을 높임
        2. 손 들기    : FR 발끝을 앞 위쪽으로
        3. 손 흔들기  : FR 엉덩이 X축 관절을 직접 돌림 (HAND_WAVES번)
        4. 휴식 자세로
        """
        sitting_pose = [
            [-20, -40, -120],
            [50, 0, -105],
            [50, 0, -105],
            [0, 0, -120],
        ]
        self._smooth_move_to(sitting_pose, delay=self.s["SLOW_DELAY"])

        self._move_single_leg(3, [80, 0, -23])

        self._wave_hand()

        self._return_to_rest()

    def leg_stretch(self):
        """다리 스트레칭 (유연성).

        1. 준비 자세 : 앞다리를 굽히고 뒷다리를 뒤로 뻗음
        2. 스트레칭  : 앞다리를 앞으로 뻗고 뒷다리를 세움
        3. 좌우 반복 : 앞다리와 뒷다리를 서로 반대쪽 y로 옮김 (STRETCH_REPEAT번)
        4. 휴식 자세로
        """
        start_pose = [
            [0, 0, -50],
            [-100, 0, -23],
            [-100, 0, -23],
            [0, 0, -50],
        ]
        self._smooth_move_to(start_pose)

        stretch_pose = [
            [80, 0, -80],
            [-30, 0, -120],
            [-30, 0, -120],
            [80, 0, -80],
        ]
        self._smooth_move_to(stretch_pose, delay=self.s["SLOW_DELAY"])

        left_pose = [
            [80, -30, -80],
            [-30, 30, -120],
            [-30, 30, -120],
            [80, -30, -80],
        ]
        right_pose = [
            [80, 30, -80],
            [-30, -30, -120],
            [-30, -30, -120],
            [80, 30, -80],
        ]
        for _ in range(self.s["STRETCH_REPEAT"]):
            self._smooth_move_to(left_pose, delay=self.s["SLOW_DELAY"])
            self._smooth_move_to(right_pose, delay=self.s["SLOW_DELAY"])

        self._return_to_rest()

    def push_ups(self):
        """팔굽혀펴기 (기초 근력).

        1. 준비 자세 : 앞다리를 굽히고 뒷다리를 뒤로 뻗음
        2. 반복      : 앞다리(FL·FR) 발끝 z를 -50 → -119 → -50으로 1씩 바꿈 (PUSH_UP_COUNT번)
        3. 휴식 자세로
        """
        start_pose = [
            [0, 0, -50],
            [-100, 0, -23],
            [-100, 0, -23],
            [0, 0, -50],
        ]
        self._smooth_move_to(start_pose)

        rpm = self.s["DEFAULT_RPM"]
        delay = self.s["FAST_DELAY"]
        points = self.motion.points
        for _ in range(self.s["PUSH_UP_COUNT"]):
            # 몸통 올리기 (앞다리를 폄)
            for height in range(50, 120):
                points[0][2] = -height
                points[3][2] = -height
                self.motion.run(rpm)
                time.sleep(delay)
            # 몸통 내리기 (앞다리를 굽힘)
            for height in range(120, 50, -1):
                points[0][2] = -height
                points[3][2] = -height
                self.motion.run(rpm)
                time.sleep(delay)

        self._return_to_rest()

    def front_paw_wave(self):
        """앞발 번갈아 흔들기 (동적 균형).

        1. 준비 자세 : 뒷다리를 앞으로 당겨 굽히고, 앞다리는 펴서 몸 앞쪽을 높임
        2. 반복      : FR을 앞 위로 뻗었다 되돌림 → FL을 앞 위로 뻗었다 되돌림 (PAW_WAVE_REPEAT번)
        3. 휴식 자세로
        """
        start_pose = [
            [-20, -20, -120],
            [50, 0, -105],
            [50, 0, -105],
            [-20, 20, -120],
        ]
        self._smooth_move_to(start_pose, delay=self.s["SLOW_DELAY"])

        paw_delay = self.s["PAW_WAVE_DELAY"]
        for _ in range(self.s["PAW_WAVE_REPEAT"]):
            # 오른쪽 앞발(FR) 앞으로 → 되돌림
            self._move_single_leg(3, [100, 10, -40], delay=paw_delay)
            self._move_single_leg(3, [-20, 20, -120], delay=paw_delay)
            # 왼쪽 앞발(FL) 앞으로 → 되돌림
            self._move_single_leg(0, [100, -10, -40], delay=paw_delay)
            self._move_single_leg(0, [-20, -20, -120], delay=paw_delay)

        self._return_to_rest(delay=self.s["SLOW_DELAY"])

    # ----------------------------------------------------------------
    # v3.4.0 action-only helpers. No other robot calls them.
    # ----------------------------------------------------------------
    def _v340_move(self, targets, sec, rpm=None):
        """Smooth cosine blend in 0.02 second intervals. None means hold leg."""
        rpm = self.s["DEFAULT_RPM"] if rpm is None else rpm
        points = self.motion.points
        start = [pt[:] for pt in points]
        goal = [start[i] if pos is None else list(pos) for i, pos in enumerate(targets)]
        steps = max(1, round(sec / 0.02))
        for step in range(1, steps + 1):
            k = (1.0 - math.cos(math.pi * step / steps)) / 2.0
            for leg in range(4):
                for axis in range(3):
                    points[leg][axis] = start[leg][axis] + (goal[leg][axis] - start[leg][axis]) * k
            self.motion.run(rpm)
            time.sleep(0.02)

    def _v340_in_range(self, leg, point):
        """IK point and joint-range guard inherited from v3.4.0."""
        if not is_valid_point(point):
            return False
        try:
            angle = self.motion.to_servo_angles(leg, coordinate_to_angle(*point))
        except ValueError:
            return False
        return all(ports.LOGICAL_MIN_DEG < v < ports.LOGICAL_MAX_DEG for v in angle)

    def _v340_step_to(self, targets):
        """Restore feet one at a time, FL/FR/HL/HR."""
        for leg in (0, 3, 1, 2):
            first = self.motion.points[leg][:]
            goal = list(targets[leg])
            if max(abs(a-b) for a,b in zip(first, goal)) < 1.0:
                continue
            lift = self.s["STEP_LIFT"]
            while True:
                midpoint = [(first[0]+goal[0])/2.0, goal[1],
                            max(first[2],goal[2])+lift]
                if lift <= 0 or self._v340_in_range(leg, midpoint):
                    break
                lift -= 5
            for pt in (midpoint,goal):
                targets_for_all = [None] * 4
                targets_for_all[leg] = pt
                self._v340_move(targets_for_all, self.s["STEP_SEC"]/2.0)

    def _v340_stand_by_steps(self):
        """Equalize foot heights and step into stand after swim."""
        height = self.s["STAND_HEIGHT"]
        levels = []
        for leg, pt in enumerate(self.motion.points):
            new = [pt[0],pt[1],-height]
            levels.append(new if self._v340_in_range(leg,new) else None)
        self._v340_move(levels,0.6)
        self._v340_step_to([[0,0,-height] for _ in range(4)])

    def swim(self):
        """Key6: v3.4.0 front arc + out-of-phase hind kick + careful return."""
        s = self.s
        z = s["SWIM_Z"]
        def both(point):
            x,y,zz = point
            return [[x,y,zz],[x,y,zz],[x,-y,zz],[x,-y,zz]]
        def arm(phi_deg):
            phi=math.radians(phi_deg)
            return [s["SWIM_RADIUS"]*math.sin(phi),
                    s["SWIM_RADIUS"]*math.cos(phi)+ports.LINK_HIP,z]
        def kick(k):
            a,b=s["SWIM_HIND"],s["SWIM_KICK"]
            hl=[a[i]+(b[i]-a[i])*k for i in range(3)]
            hr=[a[i]+(b[i]-a[i])*(1-k) for i in range(3)]
            return hl,[hr[0],-hr[1],hr[2]]
        top=s["SWIM_ANGLE_DEG"]
        hind=both(s["SWIM_HIND"])
        self._v340_step_to([self.motion.points[0],hind[1],hind[2],self.motion.points[3]])
        front=both(arm(top))
        self._v340_move([front[0],None,None,front[3]],1.0)
        steps=max(4,round(s["SWIM_STROKE_SEC"]/0.02))
        repeats=s["SWIM_REPEAT"] if s["SWIM_STROKES"] is None else s["SWIM_STROKES"]
        for _ in range(repeats):
            for sign in (-1,1):
                for step in range(1,steps+1):
                    k=(1.0-math.cos(math.pi*step/steps))/2.0
                    phi=-sign*top+sign*2*top*k
                    front_left=arm(phi)
                    kick_k=(1.0-math.cos(2.0*math.pi*s["SWIM_KICKS"]*step/steps))/2.0
                    hl,hr=kick(kick_k)
                    front_right=[front_left[0],-front_left[1],front_left[2]]
                    self._snap_to({i:p for i,p in enumerate((front_left,hl,hr,front_right))},s["DEFAULT_RPM"])
                    time.sleep(0.02)
        tuck=both([0,30,z])
        self._v340_move([tuck[0],None,None,tuck[3]],0.6)
        self._v340_stand_by_steps()

    def tap_dance(self):
        """Key9: v3.4.0 alternating trot diagonal foot lift, two tempos."""
        s=self.s
        self.stand()
        base=[[0,0,-s["STAND_HEIGHT"]] for _ in range(4)]
        height=s["STAND_HEIGHT"]
        for beat_sec in (s["TAP_BEAT_SEC"],s["TAP_BEAT_SEC"]/2.0):
            steps=max(4,round(2.0*beat_sec/0.02))
            for _ in range(max(1,s["TAP_BEATS"]//2)):
                for step in range(1,steps+1):
                    angle=360.0*step/steps
                    _,z1,_,z2=swing_pair(angle,0,s["TAP_LIFT"],height)
                    lift={0:z1+height,2:z1+height,1:z2+height,3:z2+height}
                    feet=[[pt[0],pt[1],pt[2]+lift[i]] for i,pt in enumerate(base)]
                    self._snap_to({i:pt for i,pt in enumerate(feet)},s["DEFAULT_RPM"])
                    time.sleep(0.02)
        self.stand()

    def planche_push_ups(self):
        """플란체 푸쉬업 (고출력 토크).

        서보 속도를 FAST_RPM으로 높여 몸무게를 앞다리에 싣습니다.

        1. 준비 자세   : 앞다리를 뒤로 당김
        2. 플란체 자세 : 뒷다리를 뒤로 수평에 가깝게 뻗음 (z = 0), PLANCHE_HOLD_SEC 유지
        3. 앞다리 펴기 : 앞다리를 앞으로 뻗음
        4. 기본 자세로
        """
        fast = self.s["FAST_RPM"]

        start_pose = [
            [-60, 0, -90],
            [0, 0, -100],
            [0, 0, -100],
            [-60, 0, -90],
        ]
        self._smooth_move_to(start_pose, rpm=fast)
        time.sleep(0.5)

        planche_pose = [
            [-60, 0, -90],
            [-105, 0, 0],
            [-105, 0, 0],
            [-60, 0, -90],
        ]
        self._smooth_move_to(planche_pose, rpm=fast)
        time.sleep(self.s["PLANCHE_HOLD_SEC"])

        extended_pose = [
            [90, 0, -10],
            [0, 0, -90],
            [0, 0, -90],
            [90, 0, -10],
        ]
        self._smooth_move_to(extended_pose, rpm=fast, delay=self.s["SLOW_DELAY"])
        time.sleep(0.5)

        self.stand()

    def handstand(self):
        """물구나무서기 (최종 피날레).

        1. 준비 자세     : 앞다리를 뒤로 당김
        2. 플란체 자세   : 뒷다리를 뒤로 뻗음 (z = 0), PLANCHE_HOLD_SEC 유지
        3. 물구나무 자세 : 앞다리를 수직으로 세움 (뒷다리는 그대로), HAND_STAND_HOLD_SEC 유지
        4. 다리 접기     : 네 다리를 몸 쪽으로 접음
        5. 기본 자세로
        """
        fast = self.s["FAST_RPM"]

        start_pose = [
            [-60, 0, -90],
            [0, 0, -100],
            [0, 0, -100],
            [-60, 0, -90],
        ]
        self._smooth_move_to(start_pose, rpm=fast)
        time.sleep(0.5)

        planche_pose = [
            [-60, 0, -90],
            [-105, 0, 0],
            [-105, 0, 0],
            [-60, 0, -90],
        ]
        self._smooth_move_to(planche_pose, rpm=fast)
        time.sleep(self.s["PLANCHE_HOLD_SEC"])

        handstand_pose = [
            [0, 0, -90],
            self.motion.points[1][:],
            self.motion.points[2][:],
            [0, 0, -90],
        ]
        self._smooth_move_to(handstand_pose, rpm=fast, delay=self.s["VERY_SLOW_DELAY"])
        time.sleep(self.s["HAND_STAND_HOLD_SEC"])

        folded_pose = [
            [-20, 0, -50],
            [-40, 0, -20],
            [-40, 0, -20],
            [-20, 0, -50],
        ]
        self._smooth_move_to(folded_pose, rpm=fast)
        time.sleep(1.5)

        self.stand()


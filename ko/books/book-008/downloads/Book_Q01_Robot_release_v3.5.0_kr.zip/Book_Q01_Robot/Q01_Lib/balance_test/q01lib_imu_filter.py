# -*- coding: utf-8 -*-
"""
q01lib_imu_filter.py  |  QUAD-01 교육용 라이브러리 · IMU 값 필터 (칼만 · 이동 평균)

IMU 값은 로봇이 가만히 있어도 조금씩 흔들립니다. 균형 제어가 이 흔들림까지 따라가면
다리가 떨리므로, 값을 부드럽게 만든 뒤 PID에 넘깁니다. 필터는 두 가지입니다.

    칼만 필터 (SimpleKalmanFilter)
        새 값과 이전 추정값을 칼만 이득 K(0~1)로 섞습니다.
        추정값 = 이전 추정값 + K × (새 값 - 이전 추정값)
        K가 1에 가까우면 새 값을 더 믿고, 0에 가까우면 이전 추정값을 더 믿습니다.
    이동 평균 필터 (MovingAverageFilter)
        최근 window_size개 값의 평균. 크면 부드럽지만 늦게 따라갑니다.

IMUFilter는 roll · pitch · yaw 세 값에 두 필터를 모드(FILTER_MODES)에 따라 씁니다.
칼만 필터는 값이 오래 그대로이면 K가 작아져 새 값을 늦게 따라갑니다. 시험대를 빠르게 기울이면
"없음" · "이동 평균"과 반응 빠르기를 비교해 봅니다(균형 테스트의 필터 키).
필터를 지운 뒤에는 칼만 추정값을 0이 아니라 첫 값에서 시작합니다(처음 값이 0으로 끌려가지 않게).
이 파일은 RoboCo API를 쓰지 않는 순수 계산입니다.
"""

# 필터 모드: 이름 → (칼만 사용, 이동 평균 사용). 균형 테스트의 필터 키는 이 순서로 바뀝니다.
FILTER_MODES = {
    "없음": (False, False),
    "칼만": (True, False),
    "이동 평균": (False, True),
    "칼만 + 이동 평균": (True, True),
}

# 콘솔에 쓰는 필터 이름 (영어)
FILTER_NAMES_EN = {"없음": "none", "칼만": "kalman", "이동 평균": "moving_avg", "칼만 + 이동 평균": "kalman+avg"}

# 칼만 필터 값: (측정 오차, 추정 오차, 프로세스 분산)
KALMAN_ROLL_PITCH = (1.0, 1.0, 0.01)
KALMAN_YAW = (2.0, 2.0, 0.01)
MOVING_AVERAGE_WINDOW = 5
ZERO_THRESHOLD = 0.01        # 이보다 작은 값(도)은 0으로


class MovingAverageFilter:
    """최근 window_size개 값의 평균."""

    def __init__(self, window_size=MOVING_AVERAGE_WINDOW):
        self.window_size = window_size
        self.values = []

    def update(self, value):
        self.values.append(value)
        if len(self.values) > self.window_size:
            self.values.pop(0)
        return sum(self.values) / len(self.values)


class SimpleKalmanFilter:
    """1차원 칼만 필터 (간단한 형태)."""

    def __init__(self, mea_e, est_e, q):
        """
        :param mea_e: 측정 오차 (클수록 새 값을 덜 믿음)
        :param est_e: 처음 추정 오차
        :param q: 프로세스 분산 (값이 실제로 바뀌는 정도)
        """
        self.mea_e = mea_e
        self.est_e = est_e
        self.q = q
        self.last_estimate = 0.0

    def update(self, measurement):
        gain = self.est_e / (self.est_e + self.mea_e)
        estimate = self.last_estimate + gain * (measurement - self.last_estimate)
        self.est_e = (1.0 - gain) * self.est_e + abs(self.last_estimate - estimate) * self.q
        self.last_estimate = estimate
        return estimate


class IMUFilter:
    """roll · pitch · yaw 세 값에 필터를 씁니다."""

    def __init__(self, mode="칼만"):
        mode = {en: ko for ko, en in FILTER_NAMES_EN.items()}.get(mode, mode)   # 영어 이름도 받음
        if mode not in FILTER_MODES:
            raise ValueError(f"FILTER_MODE: unknown filter. Use one of {', '.join(FILTER_NAMES_EN.values())}")
        self.mode = mode
        self.reset()

    def reset(self):
        """필터에 쌓인 값을 지웁니다 (영점을 다시 맞춘 뒤 · 모드를 바꾼 뒤 · 다리를 크게 옮긴 뒤).
        다음에 들어오는 값을 칼만 필터의 처음 추정값으로 씁니다."""
        self.kalman = [SimpleKalmanFilter(*KALMAN_ROLL_PITCH), SimpleKalmanFilter(*KALMAN_ROLL_PITCH),
                       SimpleKalmanFilter(*KALMAN_YAW)]
        self.average = [MovingAverageFilter() for _ in range(3)]
        self.fresh = True       # 다음 값으로 칼만 추정값을 시작 (0에서 천천히 따라오지 않게)

    def next_mode(self):
        """다음 필터 모드로 바꿉니다 (없음 → 칼만 → 이동 평균 → 칼만 + 이동 평균 → 없음)."""
        names = list(FILTER_MODES)
        self.mode = names[(names.index(self.mode) + 1) % len(names)]
        self.reset()
        return self.mode

    def update(self, values):
        """(roll, pitch, yaw) → 필터를 거친 (roll, pitch, yaw)."""
        use_kalman, use_average = FILTER_MODES[self.mode]
        if self.fresh:
            for kalman, value in zip(self.kalman, values):
                kalman.last_estimate = value
            self.fresh = False
        out = []
        for i, value in enumerate(values):
            if use_kalman:
                value = self.kalman[i].update(value)
            if use_average:
                value = self.average[i].update(value)
            out.append(0.0 if abs(value) < ZERO_THRESHOLD else value)
        return tuple(out)

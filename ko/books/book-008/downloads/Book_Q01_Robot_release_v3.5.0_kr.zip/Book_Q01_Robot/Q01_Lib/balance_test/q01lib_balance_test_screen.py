# -*- coding: utf-8 -*-
"""
q01lib_balance_test_screen.py  |  QUAD-01 교육용 라이브러리 · 균형 테스트의 로봇 화면

균형 테스트(q01_balance_test_start.py · Book-QUAD-01-BALANCE)만 쓰는 로봇 화면입니다.
Text Screen(Port 0) Reference를 이 파일의 BalanceTestScreen이 만들고, 화면 설정과 글자를
모두 여기서 정합니다. 다른 실습의 화면 파일은 쓰지 않고, 다른 실습도 이 화면을 쓰지 않습니다.

[화면 한 장의 모양]  다른 실습(다리 테스트 · 복합 테스트)과 같은 틀, 늘 SCREEN_LINES(10)줄
    제목                       주황. 지금 상태 (균형 OFF · 테스트 3/8 · 연속 흔들기 · 키 이름)
    ----------------------     구분선
    본문 6줄                   화면마다 다름 (모자라면 빈 줄)
    ----------------------     구분선
    키                         지금 쓸 수 있는 키 (F1 키 안내 · F2 처음으로 · F3 모두 멈춤 등)

[화면 네 가지]
    시작 화면   스크립트를 시작하고 첫 화면이 나오기 전까지 (시험대 평평 · 기본 자세 · IMU 영점, 약 2초)
    메인 화면   늘 보이는 화면. 본문: Roll · Pitch · Yaw · 시험대 · PID · 다음 단계(또는 알림)
    보조 화면   키를 누르면 POPUP_SEC(2초) 동안: 무엇이 바뀌었는지 · 왜 필요한지 · 관련 키.
                그 뒤 저절로 메인 화면으로 돌아감 (q01lib_balance_test.py의 popup)
    키 안내     F1. 다른 키를 누를 때까지

메인 화면 예 (균형 ON, 시험대 roll -15):

    균형 테스트 · 균형 ON
    ----------------------
    Roll    +0.4° ----●---- 보정  +9.6      로봇 IMU 값(도) · 막대 · 보정 각도(균형 ON) 또는 명령 각도
    Pitch   -0.2° ----●---- 보정  +0.1
    Yaw     +0.0° ----●----
    시험대  R -15  P +0  Y +0  속도 x2.0    시험대 각도 · 시험대 속도 배수 (시험대 IMU를 받으면 괄호에)
    PID  KP 0.5 · KI 1.5 · KD 0.02 · 칼만   지금 PID 값 · IMU 필터
    다음: 2 균형 테스트                      다음 단계(초록), 또는 알림(빨강)
    ----------------------
    F1 키 안내 · F2 처음으로 · F3 모두 멈춤

막대는 -SCALE ~ +SCALE(도)을 BAR_LENGTH칸으로 그립니다(9칸이면 한 칸 2.5도). 값이 범위
밖이면 점은 끝에 머물고 숫자는 실제 값을 씁니다.

[화면 설정]
    정렬      왼쪽 · 가운데 (Roll · Pitch · Yaw 막대의 열을 맞추기 위해 왼쪽)
    글자 크기  auto_size 켬 (화면 폭이나 높이 가운데 먼저 닿는 쪽까지 크게, AUTO_SIZE_MAX까지)
    줄바꿈    끔
모든 화면을 SCREEN_LINES줄로 써서 화면을 바꿔도 글자 크기가 크게 바뀌지 않게 합니다.
"""

import math
import time

from controllables import TextScreen

from ..core import q01lib_ports as ports
from ..core.q01lib_screen import DEFAULT_TEXT_COLOR, ensure_readable_text

# ------------------------------------------------------------
# 화면 설정
# ------------------------------------------------------------
SCALE = 10                   # 막대가 그리는 범위 (-SCALE ~ +SCALE 도)
BAR_LENGTH = 9               # 막대 칸 수 (홀수). 9칸이면 한 칸 = 2.5도
BAR_CHAR = "-"               # 막대 선 글자 (영문과 폭이 같은 글자)
BODY_LINES = 6               # 본문 줄 수 (모자라면 빈 줄로 채움)
SCREEN_LINES = BODY_LINES + 4  # 화면 줄 수: 제목 · 구분선 · 본문 · 구분선 · 키 (모든 화면이 같은 줄 수)
RULE_CHAR = "-"              # 구분선 글자
RULE_WIDTH = 22              # 구분선 길이(글자 수). 본문의 가장 긴 줄보다 짧게 (글자 크기에 영향 없음)
AUTO_SIZE_MAX = 200          # 글자 크기 자동 맞춤의 최대 크기
HELP_GROUP_COLS = 8          # 키 안내 화면에서 묶음 이름(자동 · 시험대 · 균형 · 공통)이 차지하는 칸 (한글 2칸)
REFRESH_SEC = 0.2            # 화면을 다시 쓰는 간격(초). IMU 값이 이 간격으로 바뀜

SCREEN_COLOR = True          # False이면 색 태그 없이 씀 (화면에 <color= 가 그대로 보일 때)
COLORS = {
    "state": "#FF8A34",      # 제목 (균형 ON · OFF · 테스트 진행 · 멈춤 · 키 이름). QUAD-01 Mechanical Orange
    "rule": "#6B7280",       # 구분선
    "label": "yellow",       # Roll · Pitch · Yaw 이름과 막대의 점
    "value": "#FFFFFF",      # IMU 값
    "out": "#20D6D9",        # 보정 · 명령 각도, 다리 높이 변화
    "alert": "red",          # 알림 (범위 밖 · IMU 없음)
    "hint": "#7CD992",       # 다음 단계 안내
    "platform": "#FFD91A",   # 시험대 각도
    "key": "#FFFFFF",        # 키 이름 (굵게)
    "text": "#B0B7C3",       # 키 설명 · PID · 필터
}


def tag(text, color_name):
    """text에 색 태그를 붙입니다. color_name은 COLORS의 이름이나 색 이름."""
    if not SCREEN_COLOR:
        return text
    if color_name == "key":
        return f"<b><color={COLORS['key']}>{text}</color></b>"
    return f"<color={COLORS.get(color_name, color_name)}>{text}</color>"


def pad_cols(text, cols):
    """글자 폭(한글 2칸 · 영문 1칸)으로 cols칸이 되게 뒤에 빈칸을 붙입니다. 키 안내 화면의 묶음 이름 줄 맞춤용."""
    width = sum(2 if ord(ch) > 127 else 1 for ch in text)
    return text + " " * max(1, cols - width)


def keys_text(items, sep=" · "):
    """[(키, 설명), ...] → "F1 키 안내 · 1 방향" (키는 흰색, 설명은 회색)."""
    return sep.join(f"{tag(k, 'key')} {tag(d, 'text')}" for k, d in items)


def signed(value, width=0):
    """부호를 붙인 소수 한 자리. 예: +4.8, -0.2, +0.0"""
    return f"{round(value, 1) + 0.0:+{width}.1f}"


def cell(value, count=BAR_LENGTH):
    """값(-SCALE ~ +SCALE) → 칸 번호 0 ~ count-1. 0.5칸은 + · - 모두 바깥으로."""
    half = (count - 1) // 2
    t = value / SCALE * half
    steps = int(math.floor(abs(t) + 0.5))
    return min(count - 1, max(0, half + (steps if t >= 0 else -steps)))


def bar(value):
    """막대. 예: "----●----"."""
    cells = [BAR_CHAR] * BAR_LENGTH
    cells[cell(value)] = tag("●", "label")
    return "".join(cells)


def angle_line(label, value, extra_name="", extra_value=None):
    """Roll · Pitch · Yaw 한 줄. 예: "Roll    +4.8° ----●---- 보정  -3.1"."""
    line = f"{tag(f'{label:<6}', 'label')}{tag(signed(value, 6), 'value')}° {bar(value)}"
    if extra_value is not None:
        line += f" {tag(extra_name, 'text')} {tag(signed(extra_value, 5), 'out')}"
    return line


def platform_line(pose, speed, platform_imu=None):
    """시험대 각도와 속도 한 줄. 예: "시험대  R -15  P +0  Y +0  속도 x1.5", 시험대 IMU를 받았으면 "(IMU -14.8 +0.1)"."""
    roll, pitch, yaw = (round(v) + 0 for v in pose)
    line = (f"{tag('시험대', 'text')}  {tag(f'R {roll:+d}  P {pitch:+d}  Y {yaw:+d}', 'platform')}"
            f"  {tag('속도', 'text')} {tag(speed, 'platform')}")
    if platform_imu is not None:
        line += f" {tag(f'(IMU {platform_imu[0]:+.1f} {platform_imu[1]:+.1f})', 'text')}"
    return line


def pid_line(kp, ki, kd, filter_mode):
    """PID 값과 필터 한 줄. 예: "PID  KP 0.5 · KI 1.5 · KD 0.02 · 칼만"."""
    return tag(f"PID  KP {kp:g} · KI {ki:g} · KD {kd:g} · {filter_mode}", "text")


def rule():
    """구분선 한 줄."""
    return tag(RULE_CHAR * RULE_WIDTH, "rule")


def page(title, body, footer, body_lines=BODY_LINES):
    """화면 한 장(SCREEN_LINES줄): 제목 · 구분선 · 본문 body_lines줄 · 구분선 · 키.
    시험대 화면(q01lib_platform_app.py)도 이 틀을 씀 (본문 줄 수만 다름).

    :param title: 제목 글자 (주황으로 칠함)
    :param body: 본문 줄 목록 (색 태그 포함 가능). BODY_LINES보다 많으면 뒤를 버림
    :param footer: 키 줄 (keys_text로 만든 글자)
    """
    body = list(body)[:body_lines]
    body += [""] * (body_lines - len(body))
    return "\n".join([tag(title, "state"), rule(), *body, rule(), footer])


def balance_text(state, imu, extra_name, extras, platform, pid, info, footer=""):
    """메인 화면 글자 (page 모양).

    :param state: 제목 글자 (예: "균형 테스트 · 균형 ON")
    :param imu: (roll, pitch, yaw) 도, 또는 IMU를 읽을 수 없을 때 None
    :param extra_name: 오른쪽 값의 이름 ("보정" · "명령")
    :param extras: (roll, pitch, yaw)의 오른쪽 값. 쓰지 않는 값은 None
    :param platform: 시험대 각도 줄 (platform_line)
    :param pid: (KP, KI, KD, 필터 이름)
    :param info: 다음 단계 · 알림 줄 (색 태그 포함)
    :param footer: 키 줄
    """
    lines = []
    if imu is None:
        lines += [tag("IMU를 읽을 수 없음", "alert"), "", ""]
    else:
        for name, value, extra in zip(("Roll", "Pitch", "Yaw"), imu, extras):
            lines.append(angle_line(name, value, extra_name, extra))
    lines += [platform, pid_line(*pid), info]
    return page(state, lines, footer)


def help_text(lines, footer):
    """F1 키 안내 화면 (메인 화면과 같은 줄 수)."""
    return page("키 안내", lines, footer)


def popup_text(title, lines, footer):
    """보조 화면: 키를 누른 뒤 잠깐 보이는 설명 (메인 화면과 같은 줄 수).
    lines는 (글자, 색 이름) 또는 글자. 색 이름이 없으면 회색 설명."""
    body = [tag(*line) if isinstance(line, tuple) else tag(line, "text") for line in lines]
    return page(title, body, footer)


def start_text():
    """시작 화면 (스크립트를 시작한 뒤 첫 메인 화면이 나오기 전까지)."""
    return page("QUAD-01 균형 테스트 · 시작", [
        tag("준비하는 중입니다", "value"),
        tag("1. 시험대를 평평하게", "text"),
        tag("2. 로봇 기본 자세", "text"),
        tag("3. IMU 영점 (약 2초)", "text"),
        tag("로봇 · 시험대를 건드리지 않습니다", "hint"),
    ], tag("잠시 기다리면 메인 화면이 나옵니다", "text"))


# ------------------------------------------------------------
# 로봇 화면 (Text Screen Reference)
# ------------------------------------------------------------
class BalanceTestScreen:
    """균형 테스트의 로봇 화면. Text Screen Reference를 한 번 만들고 계속 씁니다."""

    def __init__(self):
        self.screen = TextScreen(ports.PORT_TEXT_SCREEN)
        self.screen.color = DEFAULT_TEXT_COLOR  # Background is black; labels use their own rich-text colors.
        self.screen.wrapping = False
        self.screen.auto_size = True
        self.screen.auto_size_max = AUTO_SIZE_MAX
        self.screen.horizontal_alignment = TextScreen.HorizontalAlignment.LEFT
        self.screen.vertical_alignment = TextScreen.VerticalAlignment.MIDDLE
        self.text = ""
        self.sent_at = 0.0

    def show(self, text):
        """화면에 글자를 씁니다."""
        self.screen.text = ensure_readable_text(text)
        self.text = text
        self.sent_at = time.time()

    def due(self):
        """마지막으로 쓴 지 REFRESH_SEC가 지났으면 True."""
        return time.time() - self.sent_at >= REFRESH_SEC

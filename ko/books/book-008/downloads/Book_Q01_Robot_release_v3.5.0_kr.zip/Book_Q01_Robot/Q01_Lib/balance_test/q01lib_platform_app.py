# -*- coding: utf-8 -*-
"""
q01lib_platform_app.py  |  QUAD-01 교육용 라이브러리 · 기울기 시험대 (q01_balance_test_platform_start.py)

Book-QUAD-01-BALANCE의 시험대 3axis-Microcontroller에서 실행합니다. 시험대는 로봇이 균형을 잡는지 보기
위한 보조 장치이므로, 이 프로그램은 시험대를 기울이기만 하고 콘솔에는 알림(WARN · ERROR)만 씁니다.
시험대 각도와 결과는 로봇의 콘솔과 화면에 나옵니다(q01lib_balance_test.py).

시험대 각도를 정하는 방법은 두 가지이며, 메시지가 한 번이라도 오면 그 뒤로는 메시지만 따릅니다.

    1. 메시지 (연결했을 때)  로봇이 "P roll pitch yaw speed"를 보냄 → 그 속도 · 각도로 기울임
       로봇 Microcontroller의 비어 있는 Port에 이 시험대 Microcontroller를 배정해야 함 (README 11.1)
    2. 같은 키 (연결하지 않았을 때)  로봇과 같은 키(W S A D Q E · 1 2 3 5 6 7 8 · F2 F3)를 이 스크립트도
       읽고, 로봇과 같은 규칙(q01lib_platform_program.py)으로 같은 각도를 정함

    시험대 각도 → 시험대 서보 5개 (q01lib_platform.py) → 시험대가 기울어짐

[시험대 속도]  시험대 서보 5개의 max_rpm = 기준 속도 × 시험대 속도 배수
    기준 속도: 시험대 시작 파일 SERVO_RPM, None이면 시작할 때 읽은 부품 설정 값
    시험대 속도 배수: 로봇 시작 파일 PLATFORM_SPEED (실행 중에는 로봇의 6 · 7). 메시지에 함께 옴
    시험대 키 · 5 · F2 · 1 · 2 · 3의 시험대 움직임이 모두 이 한 속도

[시험대 IMU]  시험대 Microcontroller Port 5. 제어에 쓰지 않음
시험대 화면(Port 6)에 시험대가 실제로 기운 각도를 보여 줍니다. 시험대 Microcontroller의 비어 있는 Port에 로봇
Microcontroller를 배정하면 REPORT_SEC마다 "I roll pitch yaw"로 로봇에 보내, 로봇 화면에도 나옵니다.

[정해 둔 방식]
- 시험대 키는 로봇 시작 파일에서 정합니다. 시험대는 로봇의 테스트를 따라갑니다
- 시험대 IMU는 rotation_axis()를 읽어 쿼터니언으로 영점을 잡습니다(core/q01lib_imu.py)
- 키 안내 화면(Port 7)은 그 Port에 Text Screen이 있을 때만 씁니다
- 시험대는 로봇의 테스트 순서(1 방향 확인 · 2 균형 테스트 · 3 비교 · 8 연속 흔들기)를 따릅니다

사용하는 RoboCo 공식 API
- Runtime.message_stream() · MicroController(port).message(text)   q01lib_platform_link.py
- Input.stream(key)   core/q01lib_key_events.py (연결하지 않았을 때)
- TextScreen · Port.assigned · Port.port_type   시험대 화면 · 키 안내 화면
"""

import time

from ports import Port
from controllables import TextScreen, MicroController

from ..core import q01lib_log as L    # 콘솔 LOG 출력 (L.event · L.more · L.key …)
from ..core.q01lib_log import log_traceback
from ..core.q01lib_key_events import KeyEvents
from ..core.q01lib_imu import BodyIMU, STILL_TIMEOUT_SEC
from ..core.q01lib_screen import StatusScreen
from .q01lib_platform import (PlatformAxes, AXES, PLATFORM_IMU_PORT, PLATFORM_SCREEN_PORT,
                              PLATFORM_GUIDE_SCREEN_PORT, SERVO_RPM_MAX)
from .q01lib_platform_program import (DEFAULTS as PROGRAM, LEVEL, DIRECTION_KO, PlatformPose, PlatformSpeed,
                                   ScenarioRun, scenario, speed_text)
from .q01lib_platform_link import Inbox, find_mcu_port, pose_message
from .q01lib_balance_test_screen import page, tag, keys_text

START_FILE = "q01_balance_test_platform_start.py"

# 시작 파일에서 바꿀 수 있는 값과 기본값
DEFAULTS = {
    "TILT_LIMIT_DEG": 15,
    "SERVO_RPM": None,
    "ROLL_SERVO_SIGN": 1,
    "PITCH_SERVO_SIGN": 1,
    "YAW_SERVO_SIGN": -1,
    "USE_IMU": True,
    "IMU_ROLL_SIGN": 1,
    "IMU_PITCH_SIGN": 1,
    "IMU_YAW_SIGN": 1,
    "IMU_SWAP_ROLL_PITCH": False,
    "ZERO_SETTLE_SEC": 1.0,
    "CALIBRATION_SAMPLES": 20,
    "IMU_STILL_DEG": 0.2,
    "ROBOT_MCU_PORT": None,
    "REPORT_SEC": 0.5,
    "LOOP_SLEEP_SEC": 0.02,
    "SCREEN_INTERVAL_SEC": 0.2,
    "PLATFORM_LOG": False,
    "LOG_COLOR": True,
}

LOG_CATEGORIES = ("PARAMETER", "STATE", "ACTION", "WARN", "ERROR")
ZERO_SPREAD_WARN_DEG = 1.0
SCENARIO_KO = {"check": "방향 확인", "test": "균형 테스트", "compare": "비교", "sway": "연속 흔들기"}
SCREEN_BODY_LINES = 3        # 시험대 화면 본문 줄 수 (Roll · Pitch · Yaw)
GUIDE_BODY_LINES = 5         # 안내 화면 본문 줄 수


def _deg(value):
    """정수 각도는 부호를 붙여 3칸. 예: +15, -15, +0"""
    return f"{round(value) + 0:+3d}"


class PlatformApp:
    """시험대 Microcontroller의 메인 루프: 메시지 또는 같은 키 → 시험대 기울이기 · 시험대 화면 · 시험대 IMU 보고."""

    def __init__(self, script_values: dict):
        """script_values: 시작 파일의 globals().
        준비하다 오류가 나면(시작 파일의 값 · Port) 콘솔에 영어로 알리고, run()은 바로 끝납니다.
        """
        self.ready = False
        try:
            self._setup(script_values)
            self.ready = True
        except Exception as e:
            L.setup_failed(e, START_FILE)

    def log(self, category, text):
        """시험대의 콘솔 줄: WARN · ERROR만. PLATFORM_LOG = True이면 모두 ("platform"으로 시작)."""
        if self.s["PLATFORM_LOG"] or category in ("WARN", "ERROR"):
            L.event(category, f"platform {text}")

    def _setup(self, script_values: dict):
        s = dict(DEFAULTS)
        for name, value in script_values.items():
            if name in DEFAULTS:
                s[name] = value
        self.s = s
        L.configure(LOG_CATEGORIES, s["LOG_COLOR"])
        # 0. 시험대 화면 (Port 6): 부품 기본 글자("T") 대신 시작 화면을 먼저 씀
        self.screen = StatusScreen(port=PLATFORM_SCREEN_PORT, wrap=False)
        self.screen.show(page("기울기 시험대 · 시작", [
            tag("준비하는 중입니다", "value"),
            tag("1. 시험대 평평 → 2. 시험대 IMU 영점", "text"),
            tag("시험대를 건드리지 않습니다", "hint"),
        ], tag("로봇 시작 파일도 함께 실행합니다", "text"), SCREEN_BODY_LINES))
        unknown = [name for name in script_values if name.isupper() and name not in DEFAULTS]
        if unknown:                                                  # 모르는 이름(철자 틀림 등)은 알림
            L.event("WARN", "unknown names in the start file (check spelling)")
            for name in unknown:
                L.more(name)

        # 1. 시험대 서보: 서보 속도 = 기준 속도(부품 설정 또는 SERVO_RPM) × 시험대 속도 배수, 평평하게 (0, 0, 0)
        if s["SERVO_RPM"] is not None and not 0 < s["SERVO_RPM"] <= SERVO_RPM_MAX:
            raise ValueError(f"SERVO_RPM {s['SERVO_RPM']}: use None or a value above 0 and up to {SERVO_RPM_MAX}")
        self.axes = PlatformAxes(s["TILT_LIMIT_DEG"], s["ROLL_SERVO_SIGN"], s["PITCH_SERVO_SIGN"],
                                 s["YAW_SERVO_SIGN"], s["SERVO_RPM"])
        if self.axes.read_error is not None:
            self.log("WARN", "cannot read the servo speed: part setting kept")
            L.more(str(self.axes.read_error))
        self.speed = PlatformSpeed(PROGRAM["PLATFORM_SPEED"], PROGRAM["PLATFORM_SPEED_STEP"])
        self.apply_speed()
        self.axes.set(0, 0, 0)

        # 2. 키 안내 화면 (Port 7, 없으면 시험대 Microcontroller의 다른 Text Screen, 있을 때만)
        self.show_guide_screen()

        # 3. 메시지: 받는 흐름 · 시험대 IMU를 돌려보낼 로봇 Microcontroller (배정했을 때만)
        self.inbox = Inbox()
        robot_port = find_mcu_port(s["ROBOT_MCU_PORT"])
        self.robot_mcu = MicroController(robot_port) if robot_port is not None else None
        self.linked = False             # 메시지를 한 번이라도 받으면 True: 그 뒤로 키를 읽지 않음
        self.last_report = 0.0

        # 4. 같은 키 (메시지가 없을 때): 로봇과 같은 규칙 · 기본값
        prog = PROGRAM
        self.prog = prog
        self.target = PlatformPose(prog["PLATFORM_STEP_DEG"], prog["PLATFORM_LIMIT_DEG"])
        self.key_actions = {}
        for key, (axis, direction) in prog["PLATFORM_KEYS"].items():
            self.key_actions[key] = ("step", axis, direction)
        self.key_actions[prog["PLATFORM_SLOWER_KEY"]] = ("speed", -1)
        self.key_actions[prog["PLATFORM_FASTER_KEY"]] = ("speed", 1)
        self.key_actions[prog["CHECK_KEY"]] = ("run", "check")
        self.key_actions[prog["TEST_KEY"]] = ("run", "test")
        self.key_actions[prog["COMPARE_KEY"]] = ("run", "compare")
        self.key_actions[prog["LEVEL_KEY"]] = ("level",)
        self.key_actions[prog["STAND_KEY"]] = ("level",)
        self.key_actions[prog["STOP_KEY"]] = ("stop",)
        self.key_actions[prog["SWAY_KEY"]] = ("sway",)
        self.keys = KeyEvents(list(self.key_actions))
        self.run_state = None           # 진행 중인 테스트 (ScenarioRun)
        self.sway = None                # 연속 흔들기 (ScenarioRun, loop=True). 키를 모두 읽음
        self.sway_index = None
        self.run_index = None

        # 5. 시험대 IMU (Port 5): 시험대가 평평해진 뒤 영점
        self.imu = None
        self.measured = None
        if s["USE_IMU"]:
            try:
                self.imu = BodyIMU(PLATFORM_IMU_PORT, roll_sign=s["IMU_ROLL_SIGN"],
                                   pitch_sign=s["IMU_PITCH_SIGN"], yaw_sign=s["IMU_YAW_SIGN"],
                                   swap_roll_pitch=s["IMU_SWAP_ROLL_PITCH"])
                time.sleep(s["ZERO_SETTLE_SEC"])
                zero = self.imu.calibrate(s["CALIBRATION_SAMPLES"], still_deg=s["IMU_STILL_DEG"])
                self.log("STATE", f"zero {L.angles_text(zero)}")
                if not self.imu.settled:
                    self.log("WARN", f"IMU not still after {STILL_TIMEOUT_SEC:g} s "
                                     f"(IMU_STILL_DEG={s['IMU_STILL_DEG']:g})")
                elif self.imu.spread > ZERO_SPREAD_WARN_DEG:
                    self.log("WARN", f"IMU moved {self.imu.spread:.1f} deg while zeroing")
                self.measured = (0.0, 0.0, 0.0)
            except Exception as e:
                self.imu = None
                self.log("WARN", f"no IMU on port {PLATFORM_IMU_PORT} (the platform still tilts)")
                L.more(str(e))
        self.last_screen = 0.0
        self.log("STATE", "ready  robot MCU port: "
                          f"{robot_port if robot_port is not None else 'none'}")

    # ------------------------------------------------------------
    # 화면
    # ------------------------------------------------------------
    def _guide_port(self):
        """안내 화면의 Port: PLATFORM_GUIDE_SCREEN_PORT(7)에 Text Screen이 있으면 그것, 없으면 시험대 화면(6)
        밖의 다른 Text Screen. 없으면 None."""
        candidates = [PLATFORM_GUIDE_SCREEN_PORT] + [p for p in self._ports() if p != PLATFORM_GUIDE_SCREEN_PORT]
        for port in candidates:
            if port == PLATFORM_SCREEN_PORT:
                continue
            try:
                if Port.assigned(port) and Port.port_type(port) is TextScreen:
                    return port
            except Exception:
                pass
        return None

    @staticmethod
    def _ports():
        try:
            return list(Port.ports())
        except Exception:
            return []

    def show_guide_screen(self):
        """안내 화면 (한국어): 제목 · 구분선 · 시험대 키 · 테스트 키 · 구분선 · 키를 누구가 읽는지."""
        port = self._guide_port()
        if port is None:
            return
        guide = StatusScreen(port=port, wrap=False)
        keys = PROGRAM["PLATFORM_KEYS"]

        def pair(axis):
            plus = next((k for k, (a, d) in keys.items() if a == axis and d > 0), "?").upper()
            minus = next((k for k, (a, d) in keys.items() if a == axis and d < 0), "?").upper()
            return (f"{tag(f'{plus}/{minus}', 'key')}  {tag(axis, 'label')} "
                    f"{tag(DIRECTION_KO[(axis, 1)] + ' / ' + DIRECTION_KO[(axis, -1)], 'text')}")
        p = PROGRAM
        body = [pair("pitch"), pair("roll"), pair("yaw"),
                keys_text([(p["LEVEL_KEY"], "평평"), (f"{p['PLATFORM_SLOWER_KEY']}/{p['PLATFORM_FASTER_KEY']}", "속도"),
                           (p["SWAY_KEY"], "연속 흔들기")], "   "),
                keys_text([(p["CHECK_KEY"], "방향 확인"), (p["TEST_KEY"], "균형 테스트"),
                           (p["COMPARE_KEY"], "비교")], "   ")]
        guide.show(page("기울기 시험대 · 키 안내", body,
                        tag("키는 로봇이 읽음 · ", "text") + keys_text([("F2", "처음으로"), ("F3", "모두 멈춤")]),
                        GUIDE_BODY_LINES))
        self.log("STATE", f"guide screen on port {port}")

    def update_screen(self, now):
        """시험대 화면: 제목(따르는 방법) · 구분선 · Roll · Pitch · Yaw (목표 · IMU) · 구분선 · 속도."""
        if now - self.last_screen < self.s["SCREEN_INTERVAL_SEC"]:
            return
        self.last_screen = now
        a = self.axes.angles
        if self.imu is not None:
            self.measured = self.imu.read()
        body = []
        for i, axis in enumerate(AXES):
            imu = tag("IMU 없음", "text") if self.measured is None else \
                tag(f"IMU {self.measured[i]:+5.1f}°", "out")
            body.append(f"{tag(f'{axis.capitalize():<6}', 'label')}{tag(_deg(a[axis]) + '°', 'value')}   {imu}")
        if self.linked:
            mode = "로봇 메시지"
        elif self.sway is not None:
            mode = f"키 · {SCENARIO_KO['sway']}"
        elif self.run_state is not None:
            mode = f"키 · {SCENARIO_KO[self.run_state.name]}"
        else:
            mode = "키"
        rpms = self.axes.rpm
        rpm = "" if rpms is None else f"  (서보 {rpms[0]:.1f} rpm)"
        footer = f"{tag('속도', 'text')} {tag(speed_text(self.speed.value), 'platform')}{tag(rpm, 'text')}"
        self.screen.show(page(f"기울기 시험대 · 따름: {mode}", body, footer, SCREEN_BODY_LINES))

    # ------------------------------------------------------------
    # 시험대 각도
    # ------------------------------------------------------------
    def apply_speed(self):
        """시험대 서보 5개의 속도 = 기준 속도 × 시험대 속도 배수. 기준을 모르면 바꾸지 않음."""
        self.axes.set_speed(self.axes.speeds(ratio=self.speed.value))
        if self.axes.rpm is not None:
            self.log("PARAMETER", f"speed {speed_text(self.speed.value)}  "
                                  f"servo rpm {self.axes.base_rpm[0]:.1f} -> {self.axes.rpm[0]:.1f}")

    def apply(self, pose):
        """시험대를 pose로 기울입니다 (바뀌었을 때만 서보에 보냄)."""
        if self.target.set(pose):
            self._send_servos()

    def _send_servos(self):
        roll, pitch, yaw = self.axes.set(*self.target.pose)
        self.log("ACTION", f"cmd  roll={_deg(roll)}  pitch={_deg(pitch)}  yaw={_deg(yaw)} deg")

    def read_messages(self):
        """로봇이 보낸 "P roll pitch yaw speed"를 따릅니다. 처음 받으면 연결 상태로 바뀜."""
        for kind, pose, speed in self.inbox.read():
            if kind != "P":
                continue
            if not self.linked:
                self.linked = True
                self.run_state = None
                self.sway = None
                self.log("STATE", "robot link: following robot messages")
            if speed is not None and self.speed.set(speed):
                self.apply_speed()
            self.apply(pose)

    def read_keys(self, now):
        """연결하지 않았을 때: 로봇과 같은 키를 같은 규칙으로 처리합니다.
        테스트(1 · 2 · 3) 중에는 로봇처럼 F2 · F3만 읽고, 다른 키는 테스트가 끝난 뒤 처리합니다.
        연속 흔들기(8) 중에는 키를 모두 읽습니다: 8 · 5 · F2 · F3 · 시험대 키 · 1 2 3이 흔들기를 멈춤."""
        if self.run_state is not None:
            keys = self.keys.take([self.prog["STAND_KEY"], self.prog["STOP_KEY"]])
        else:
            keys = self.keys.pressed()
        for key in keys:
            action = self.key_actions[key]
            if action[0] == "stop":
                self.run_state = None
                self.sway = None
            elif action[0] == "level":
                self.run_state = None
                self.sway = None
                self.apply(LEVEL)
            elif action[0] == "run":
                self.sway = None
                self.run_state = ScenarioRun(action[1], scenario(action[1], self.prog), now)
                self.run_index = None
            elif action[0] == "sway":
                if self.sway is not None:
                    self.sway = None
                    self.apply(LEVEL)
                else:
                    self.sway = ScenarioRun("sway", scenario("sway", self.prog), now, loop=True)
                    self.sway_index = None
            elif action[0] == "step":
                self.sway = None
                if self.target.step_axis(action[1], action[2]):
                    self._send_servos()
            elif action[0] == "speed":
                if self.speed.change(action[1]):
                    self.apply_speed()
        if self.sway is not None:
            i, seg = self.sway.at(now)
            if i != self.sway_index:
                self.sway_index = i
                self.apply(seg.pose)
        if self.run_state is not None:
            i, seg = self.run_state.at(now)
            if i is None:
                self.run_state = None
                self.apply(LEVEL)
            elif i != self.run_index:
                self.run_index = i
                self.apply(seg.pose)

    def report(self, now):
        """로봇 Microcontroller를 배정했으면 시험대 IMU 값을 REPORT_SEC마다 보냅니다."""
        if self.robot_mcu is None or self.measured is None or now - self.last_report < self.s["REPORT_SEC"]:
            return
        self.last_report = now
        try:
            self.robot_mcu.message(pose_message("I", self.measured))
        except Exception as e:
            self.robot_mcu = None
            self.log("WARN", f"cannot send to the robot MCU ({e})")

    # ------------------------------------------------------------
    # 반복
    # ------------------------------------------------------------
    def update(self):
        now = time.time()
        self.read_messages()
        if self.linked:
            self.keys.clear()           # 연결되면 키는 로봇만 처리
        else:
            self.read_keys(now)
        self.update_screen(now)
        self.report(now)
        time.sleep(self.s["LOOP_SLEEP_SEC"])

    def run(self):
        """update()를 계속 반복합니다. RoboCo에서 스크립트를 멈추면 바로 끝납니다."""
        if not self.ready:
            return
        try:
            from scriptruntime import Runtime
            while not Runtime.quitting():
                self.update()
        except KeyboardInterrupt:
            pass  # RoboCo Space 즉시 종료, 추가 시험대 복귀 없음
        except Exception as e:
            L.event("ERROR", f"platform: unexpected error: {e}")
            log_traceback()
            try:
                self.axes.set(0, 0, 0)
            except Exception:
                pass

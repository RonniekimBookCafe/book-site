# -*- coding: utf-8 -*-
"""
Q01_Lib/balance_test  |  균형 테스트 · 시험대 · IMU · PID (q01_balance_test_start.py · Book-QUAD-01-BALANCE)

    q01lib_balance_test.py          BalanceTest: 시험대 키 · 1 방향 확인 · 2 균형 테스트 · 3 비교 · PID 균형 모드
    q01lib_balance_test_screen.py   BalanceTestScreen: 이 테스트만 쓰는 로봇 화면 (Roll · Pitch · Yaw · 보정 · 시험대 · PID)
    q01lib_imu_filter.py            IMUFilter: IMU 값 필터 (칼만 · 이동 평균, 계산만)
    q01lib_pid.py                   PID 제어기 (계산만)
    q01lib_platform_program.py      시험대를 움직이는 규칙 (시험대 키 · 테스트 순서). 로봇 · 시험대가 함께 씀 (계산만)
    q01lib_platform_link.py         PlatformLink: Microcontroller 두 개 사이의 메시지

    시험대 (q01_balance_test_platform_start.py · 시험대의 3axis-Microcontroller)
    q01lib_platform.py              PlatformAxes: 시험대의 서보 5개 (roll 2 · pitch 2 · yaw 1)와 시험대 Port 대응표
    q01lib_platform_app.py          PlatformApp: 로봇 메시지(또는 같은 키)를 따라 시험대 기울이기 · 시험대 화면 · 알림만 콘솔

Book-QUAD-01-BALANCE에는 Microcontroller가 두 개 있고, 시작 파일도 두 개입니다.
    로봇 Microcontroller     q01_balance_test_start.py            BalanceTest (모든 키 · 로봇 IMU Port 1 → PID · 판정)
    시험대 3axis-Microcontroller q01_balance_test_platform_start.py PlatformApp (시험대 서보 · 시험대 화면)
로봇 Microcontroller의 Port에 시험대 Microcontroller를 배정하면 로봇이 시험대 각도를 메시지로 보냅니다.
배정하지 않으면 시험대가 같은 키를 읽어 같은 규칙으로 따라옵니다 (README 11.1).

로봇 쪽은 키를 읽는 반복 부분과 서보 · 기본 자세에 leg_common 폴더를, IMU 읽기에
core/q01lib_imu.py를, 몸체 기울기 → 네 발끝 계산에 body_pose 폴더를 함께 씁니다.
"""

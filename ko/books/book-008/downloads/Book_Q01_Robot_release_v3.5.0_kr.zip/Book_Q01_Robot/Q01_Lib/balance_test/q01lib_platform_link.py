# -*- coding: utf-8 -*-
"""
q01lib_platform_link.py  |  QUAD-01 교육용 라이브러리 · Microcontroller 두 개 사이의 메시지

Book-QUAD-01-BALANCE의 로봇 Microcontroller와 시험대 3axis-Microcontroller는 각자 자기 Port만 봅니다.
RoboCo는 Microcontroller끼리 글자 메시지를 보내는 공식 API를 제공합니다.

    보내는 쪽   MicroController(port).message("글자")
                port = 보내는 Microcontroller의 Port 가운데 받는 Microcontroller를 배정한 번호
    받는 쪽     Runtime.message_stream()  → 받은 글자를 차례로 돌려주는 흐름
                ("몇 밀리초 안에 도착", RoboCo API 문서)

메시지를 보내려면 로봇 파일에서 로봇 Microcontroller의 비어 있는 Port에 시험대 3axis-Microcontroller를
배정합니다(README 11.1). 반대로 시험대 Microcontroller의 비어 있는 Port에 로봇 Microcontroller를 배정하면
시험대가 시험대 IMU 값을 로봇에 돌려보냅니다. 배정하지 않으면 메시지 없이 같은 키를 두 스크립트가 각자
읽습니다(q01lib_platform_program.py).

[메시지 형식]  ASCII 한 줄
    로봇 → 시험대  "P <roll> <pitch> <yaw> <speed>"  시험대 목표 각도(도)와 시험대 속도 배수(PLATFORM_SPEED).
                바뀔 때마다, 그리고 HEARTBEAT_SEC마다 다시 보냄
    시험대 → 로봇  "I <roll> <pitch> <yaw>"  시험대 IMU로 잰 시험대 기울기(도)
같은 목표 각도를 여러 번 받아도 결과가 같으므로(몇 도씩 더하는 명령이 아님) 다시 보내도 됩니다.

사용하는 RoboCo 공식 API
- MicroController(port).message(text)     controllables.py
- Runtime.message_stream()                scriptruntime.py
- Port.ports() · Port.port_type(port)     ports.py: 배정된 Port와 그 부품의 종류
"""

import time

from ports import Port
from controllables import MicroController
from scriptruntime import Runtime

HEARTBEAT_SEC = 1.0          # 시험대 목표 각도를 다시 보내는 간격(초). 시험대 스크립트가 늦게 시작해도 따라옴


def find_mcu_port(port=None):
    """다른 Microcontroller가 배정된 Port. port를 주면 그 Port만 확인. 없으면 None."""
    candidates = [port] if port is not None else Port.ports()
    for p in candidates:
        try:
            if Port.port_type(p) is MicroController:
                return p
        except Exception:
            pass
    return None


def pose_message(kind, pose, speed=None):
    """("P", (10, 0, 0), 1.5) → "P 10.0 0.0 0.0 1.50". speed가 None이면 각도만."""
    text = f"{kind} " + " ".join(f"{round(float(v), 1) + 0.0:.1f}" for v in pose)
    return text if speed is None else f"{text} {float(speed):.2f}"


def parse_message(text):
    """"P 10.0 0.0 0.0 1.50" → ("P", (10.0, 0.0, 0.0), 1.5). 속도가 없으면 세 번째 값이 None.
    형식이 다르면 (None, None, None)."""
    parts = str(text).split()
    if len(parts) not in (4, 5) or parts[0] not in ("P", "I"):
        return None, None, None
    try:
        values = [float(v) for v in parts[1:]]
    except ValueError:
        return None, None, None
    return parts[0], tuple(values[:3]), (values[3] if len(values) == 4 else None)


class Inbox:
    """Runtime.message_stream()을 읽는 클래스. 흐름을 만들 수 없으면 아무것도 받지 않음."""

    def __init__(self):
        try:
            self.stream = Runtime.message_stream()
        except Exception:
            self.stream = None

    def read(self):
        """지난번 뒤에 받은 (종류, 각도, 속도) 목록."""
        if self.stream is None:
            return []
        out = []
        for text in self.stream:
            kind, pose, speed = parse_message(text)
            if kind:
                out.append((kind, pose, speed))
        return out


class PlatformLink:
    """로봇 쪽: 시험대 Microcontroller에 시험대 목표 각도를 보내고, 시험대 IMU 값을 받습니다."""

    def __init__(self, port=None):
        self.port = find_mcu_port(port)
        self.mcu = MicroController(self.port) if self.port is not None else None
        self.inbox = Inbox()
        self.pose = None             # 마지막으로 보낸 목표 각도
        self.speed = None            # 마지막으로 보낸 시험대 속도 배수
        self.sent_at = 0.0
        self.platform_imu = None     # 시험대가 보내온 시험대 IMU (roll, pitch, yaw), 받은 적 없으면 None
        self.imu_at = 0.0
        self.error = None

    @property
    def linked(self):
        return self.mcu is not None and self.error is None

    def send(self, pose, speed, force=False):
        """시험대 목표 각도와 속도 배수를 보냅니다. 같은 값은 HEARTBEAT_SEC마다만 다시 보냄."""
        now = time.time()
        pose = tuple(float(v) for v in pose)
        if not self.linked:
            self.pose, self.speed = pose, speed
            return
        if force or pose != self.pose or speed != self.speed or now - self.sent_at >= HEARTBEAT_SEC:
            try:
                self.mcu.message(pose_message("P", pose, speed))
            except Exception as e:
                self.error = e
                return
            self.pose, self.speed = pose, speed
            self.sent_at = now

    def poll(self):
        """받은 메시지를 읽어 시험대 IMU 값을 갱신하고, 목표 각도를 주기적으로 다시 보냅니다."""
        for kind, pose, _ in self.inbox.read():
            if kind == "I":
                self.platform_imu = pose
                self.imu_at = time.time()
        if self.pose is not None:
            self.send(self.pose, self.speed)

    def platform_imu_fresh(self, max_age=2.0):
        """최근 max_age초 안에 받은 시험대 IMU 값, 없으면 None."""
        if self.platform_imu is None or time.time() - self.imu_at > max_age:
            return None
        return self.platform_imu

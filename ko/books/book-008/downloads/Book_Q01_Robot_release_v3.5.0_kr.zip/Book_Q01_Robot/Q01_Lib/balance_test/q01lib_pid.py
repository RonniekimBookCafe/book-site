# -*- coding: utf-8 -*-
"""
q01lib_pid.py  |  QUAD-01 교육용 라이브러리 · PID 제어기

목표값과 측정값의 차이(오차)로 보정값을 계산합니다.

    오차 e = 목표값 - 측정값                      (균형 제어에서 목표값은 0도)
    P = KP × e                                    지금 오차에 비례
    I = KI × (e를 시간에 따라 더한 값)             남아 있는 오차를 없앰
    D = KD × (e가 바뀌는 빠르기)                   빠른 변화를 누그러뜨림
    보정값 = P + I + D   (±output_limit 안으로 제한)

[균형 제어에서 I가 하는 일]
시험대가 기울어 몸체가 θ만큼 기울면, 로봇은 다리 높이를 바꿔 몸체를 -θ만큼
되돌려야 합니다. 몸체가 수평이 되면 오차가 0이 되어 P는 0이 되지만,
그동안 쌓인 I가 -θ만큼의 보정값을 계속 유지합니다. 그래서 P만으로는 기울기가
조금 남고, I를 더하면 수평에 가까워집니다.

I가 너무 크게 쌓이지 않도록(windup) I 항은 ±output_limit 안으로 제한합니다.

[실행 중에 값을 바꿀 때]  set_gains()
KP · KD는 다음 계산부터 바로 새 값을 씁니다. KI는 지금 I 항(KI × 쌓인 값)이 그대로 이어지도록
쌓인 값을 다시 맞춥니다. 그래서 KI를 바꾼 순간 보정 각도가 튀지 않고, 그 뒤 쌓이는 빠르기만
달라집니다. KI = 0이면 쌓인 값을 지우고 더 쌓지 않습니다(I 항 0). 그러면 P만 남아 시험대가
기울어 있는 동안 몸체 기울기가 다 지워지지 않고 남습니다.
이 파일은 RoboCo API를 쓰지 않는 순수 계산입니다.
"""


class PID:
    """PID 제어기 하나 (roll용 · pitch용을 따로 만들어 씁니다)."""

    def __init__(self, kp, ki, kd, output_limit):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.output_limit = output_limit
        self.reset()

    def reset(self):
        """쌓인 I와 이전 오차를 지웁니다."""
        self.integral = 0.0
        self.last_error = None
        self.p = self.i = self.d = 0.0     # 마지막으로 계산한 P · I · D 항 (LOG용)

    def set_gains(self, kp=None, ki=None, kd=None):
        """실행 중에 값을 바꿉니다. KI를 바꿔도 지금 I 항은 이어짐(쌓인 값을 비율로 맞춤)."""
        if kp is not None:
            self.kp = kp
        if kd is not None:
            self.kd = kd
        if ki is not None:
            if ki == 0 or self.ki == 0:
                self.integral = 0.0
            else:
                self.integral *= self.ki / ki
            self.ki = ki

    def update(self, measured, dt, target=0.0):
        """측정값으로 보정값을 계산합니다.

        :param measured: 측정값 (예: 지금 roll, 도)
        :param dt: 지난번 계산 뒤 흐른 시간(초)
        :param target: 목표값 (기본 0)
        :return: 보정값 (P + I + D)
        """
        error = target - measured
        limit = self.output_limit

        self.p = self.kp * error

        if self.ki == 0:
            self.integral = 0.0             # KI = 0: I 항을 쓰지 않음 (쌓지도 않음)
        else:
            self.integral += error * dt
        self.i = self.ki * self.integral
        if self.i > limit or self.i < -limit:          # I 항 제한 (windup 방지)
            self.i = max(-limit, min(limit, self.i))
            self.integral = self.i / self.ki

        if self.last_error is None or dt <= 0:
            self.d = 0.0
        else:
            self.d = self.kd * (error - self.last_error) / dt
        self.last_error = error

        output = self.p + self.i + self.d
        return max(-limit, min(limit, output))

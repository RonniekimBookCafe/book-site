# -*- coding: utf-8 -*-
"""
q01lib_balance_test.py  |  QUAD-01 교육용 라이브러리 · 균형 테스트 (시험대 · IMU · PID)

시작 파일 q01_balance_test_start.py · 로봇 Book-QUAD-01-BALANCE

로봇은 기울기 시험대 위에 서 있습니다. 이 실습의 목적은 시험대가 기울 때 로봇이 몸체를 수평으로
유지하는지 보는 것입니다. 시험대는 그 확인을 돕는 보조 장치이므로, 모든 키와 콘솔은 로봇 쪽에 모읍니다.

    로봇 키 (W S A D Q E · 1 2 3 5)  ->  시험대 각도 (q01lib_platform_program.py)
      ->  시험대 Microcontroller에 메시지 (q01lib_platform_link.py, 연결했을 때)  ->  시험대가 기울어짐
    IMU (Port 1)  ->  필터  ->  PID 두 개 (roll · pitch, 목표 0도)  ->  보정 각도
      ->  몸체 자세 (roll · pitch)  ->  네 발끝 좌표 (body_pose)  ->  IK  ->  서보 12개

[처음 하는 순서]  콘솔 · 로봇 화면이 다음 단계를 알려 줌 (next: ...)
    1  방향 확인    시험대를 ±CHECK_DEG 기울여 로봇 IMU가 시험대와 같은 쪽으로 재는지(시험대 서보 방향),
                   시험대를 평평하게 두고 몸체를 기울여 IMU가 명령과 같은 쪽으로 재는지(로봇 IMU 방향)
    2  균형 테스트  균형 ON. 시험대가 TEST_POSES대로 기우는 동안 몸체 기울기의 최대 · 끝 · 수평이 될 때까지의
                   시간을 자세마다 재고 표로 정리
    3  비교 테스트  같은 시험대 움직임을 균형 OFF → ON으로 두 번. 자세마다 몸체 기울기를 나란히 비교
    U J · I K · O L로 PID를 바꾼 뒤 2를 다시 누르면 같은 조건에서 결과를 비교할 수 있습니다.
    직접 해 보기: 4 균형 ON · OFF, W S A D Q E 시험대 기울이기, 5 시험대 평평하게

[좌표와 부호]  Spot과 같은 몸체 좌표계. 회전의 + 방향은 오른손 법칙 (README 14)
    roll  +  x(앞)축 둘레: 오른쪽이 내려감
    pitch +  y(왼쪽)축 둘레: 머리(앞)가 내려감
    yaw   +  z(위)축 둘레: 위에서 볼 때 왼쪽(반시계)으로 돎
시험대가 roll +10이면 로봇도 함께 roll +10 기울고(IMU roll +10), PID가 보정 roll -10을 내어
몸체를 시험대에 대해 반대로 기울이면 몸체가 수평(IMU 0)이 됩니다.

[콘솔]  다른 실습과 같은 영어 형식 (core/q01lib_log.py). 시험대의 줄은 시험대 스크립트가 쓰지 않고
로봇이 시험대 각도를 함께 씁니다.
    [  5.0] [SENSOR]    platform +10  +0  body  +0.4  +0.0  corr  -9.6  +0.0
시험대 roll · pitch, 로봇 IMU roll · pitch, 보정 roll · pitch (도).

[F2 · F3]
    F2  처음으로: 테스트를 멈추고 시험대를 평평하게, 균형 OFF, 기본 자세, IMU 영점
    F3  모두 멈춤: 테스트를 멈추고 시험대와 로봇을 그 자리에 둠 (시험대 스크립트도 같은 키로 멈춤)
"""

import math
import time

from ..core import q01lib_ports as ports
from ..core.q01lib_key_events import key_label
from ..leg_common.q01lib_leg_check import check_point
from ..core import q01lib_log as L    # 콘솔 LOG 출력 (L.event · L.more · L.key …)
from ..core.q01lib_imu import BodyIMU, STILL_TIMEOUT_SEC
from .q01lib_pid import PID
from ..body_pose.q01lib_body_pose import body_pose_feet, zero_pose
from .q01lib_imu_filter import IMUFilter, FILTER_NAMES_EN
from .q01lib_balance_test_screen import (BalanceTestScreen, balance_text, help_text, keys_text, platform_line, tag,
                                         pad_cols, popup_text, start_text, HELP_GROUP_COLS)
from .q01lib_platform_program import (AXES, LEVEL, DIRECTION_EN, PlatformPose, PlatformSpeed, ScenarioRun, scenario,
                                   settings_from, check_platform_keys, changed_from_defaults, pose_text,
                                   speed_text, PLATFORM_SPEED_MIN, PLATFORM_SPEED_MAX)
from .q01lib_platform_link import PlatformLink

GAIN_NAMES = ("KP", "KI", "KD")
GAIN_LEVEL_NAMES = {"KP": "KP_LEVELS", "KI": "KI_LEVELS", "KD": "KD_LEVELS"}
# PID 키 보조 화면의 설명: (항 이름, 곱하는 것, 크게 하면, 작게 하면)
GAIN_INFO = {
    "KP": ("P", "지금 기울기", "크게: 빨리 수평 · 너무 크면 떨림", "작게: 느리게 수평 · 0이면 I만 일함"),
    "KI": ("I", "쌓인 기울기", "크게: 지나쳐서 출렁임 (흔들림)", "0: 시험대가 기운 만큼 몸체에 남음"),
    "KD": ("D", "기울기 변화 빠르기", "조금: 빠른 흔들림이 줄어듦", "크게: IMU 잡음까지 키워 떨림"),
}
SIGN_NAMES = {"roll": "ROLL_SIGN", "pitch": "PITCH_SIGN", "yaw": "YAW_SIGN"}
SERVO_SIGN_NAMES = {"roll": "ROLL_SERVO_SIGN", "pitch": "PITCH_SERVO_SIGN", "yaw": "YAW_SERVO_SIGN"}
IMU_SETTLE_SEC = 0.5         # 기본 자세로 선 뒤 최소로 기다리는 시간(초). 그 뒤 IMU가 멈출 때까지 기다림
MAX_DT_SEC = 0.1             # PID 한 번에 쓰는 시간 간격의 최댓값 (키 동작으로 멈췄다 다시 시작할 때)
IMU_TEST_SAMPLES = 10        # 몸체 방향 확인에서 한 자세의 IMU를 읽어 평균하는 횟수
IMU_TEST_SAMPLE_SEC = 0.02   # 그 간격(초)
MEASURE_SEC = 0.5            # 시험대 자세마다 끝의 이 시간(초) 동안의 IMU 평균을 "끝" 값으로 씀
CHECK_LEVEL_SEC = 1.0        # 방향 확인에서 시험대가 평평해진 뒤 몸체를 기울이기 전에 기다리는 시간(초)
NOTE_REPEAT_SEC = 3.0        # 같은 알림(보정 최대 · 관절 한계)을 콘솔에 다시 남기기까지 기다리는 시간(초)
LOG_CHANGE_DEG = 0.5         # 시험대가 그대로일 때 IMU · 보정이 이만큼(도) 바뀌어야 콘솔에 남김
ZERO_SPREAD_WARN_DEG = 1.0   # 영점을 잡는 동안 IMU가 이보다 많이 움직이면 콘솔에 알림(도)
GUIDE_LABEL_COLS = 8         # 콘솔 키 안내의 묶음 이름 칸 (Step · Platform · Gain · Mode · Now · Log)
ZERO_TILT_WARN_DEG = 15.0    # 영점의 roll · pitch가 이보다 크면 콘솔에 알림(도). 시험대 · 로봇이 기울어 있었을 수 있음
                             # (180도 근처는 센서를 뒤집어 단 것이므로 알리지 않음)


def check_levels(name, levels):
    """KP_LEVELS 등: 0 이상의 숫자를 작은 것부터. 두 개 이상."""
    try:
        values = [float(v) for v in levels]
    except (TypeError, ValueError):
        raise ValueError(f"{name}: use a list of numbers, e.g. [0, 0.5, 1, 2]")
    if len(values) < 2 or any(v < 0 for v in values) or values != sorted(set(values)):
        raise ValueError(f"{name}: use 2 or more numbers >= 0, small to large")
    return values


def next_level(levels, value, sign):
    """지금 값에서 한 단계 위(sign +1) · 아래(-1)의 값. 끝이면 None.
    지금 값이 단계 사이에 있으면(시작 파일에 0.6처럼 적음) 가장 가까운 위 · 아래 단계로."""
    if sign > 0:
        bigger = [v for v in levels if v > value + 1e-9]
        return bigger[0] if bigger else None
    smaller = [v for v in levels if v < value - 1e-9]
    return smaller[-1] if smaller else None


def level_text(levels, value):
    """단계 목록에서 지금 값을 [ ]로. 예: "0 0.25 [0.5] 1 2 4 8"."""
    return " ".join(f"[{v:g}]" if abs(v - value) < 1e-9 else f"{v:g}" for v in levels)


def tilt_of(roll, pitch):
    """몸체 기울기의 크기(도): roll · pitch를 합친 값."""
    return math.hypot(roll, pitch)


class BalanceTest:
    """균형 테스트 (Book-QUAD-01-BALANCE)."""

    TITLE = "균형 테스트"
    SHORT = "균형"
    HEADER = "QUAD-01 BALANCE TEST  tilt platform + IMU + PID"
    LOG_CATEGORIES = ("PARAMETER", "SENSOR", "ACTION", "METRIC")   # 공통 분류 밖에 이 테스트가 콘솔에 쓰는 분류 (열 맞추기)
    START_FILE = "q01_balance_test_start.py"
    USES_LEG_SELECT = False
    COMMON_DESC = {"STAND_KEY": "reset", "STOP_KEY": "stop all"}       # F2 · F3 콘솔 이름
    STAND_KO = "처음으로"                                               # F2 화면 이름
    SHOWS_START = True                                                  # 시작 화면을 이 파일이 씀 (start_text)
    VALUE_NAMES = ("KEY_REPEAT_SEC", "BODY_LENGTH", "BODY_WIDTH", "FEET_FORWARD",
                   "KP", "KI", "KD", "KP_LEVELS", "KI_LEVELS", "KD_LEVELS", "MAX_CORRECTION_DEG",
                   "BALANCE_AT_START", "FILTER_MODE", "CALIBRATION_SAMPLES", "IMU_STILL_DEG", "LOG_INTERVAL_SEC",
                   "ROLL_SIGN", "PITCH_SIGN", "YAW_SIGN", "SWAP_ROLL_PITCH",
                   "PLATFORM_MCU_PORT", "PLATFORM_STEP_DEG", "PLATFORM_LIMIT_DEG",
                   "PLATFORM_SPEED", "PLATFORM_SPEED_STEP",
                   "CHECK_DEG", "CHECK_HOLD_SEC", "CHECK_MOVE_STEPS",
                   "TEST_POSES", "TEST_HOLD_SEC", "SWAY_HOLD_SEC", "LEVEL_OK_DEG", "SETTLE_DEG", "LOG_DETAIL",
                   "POPUP_SEC",
                   "PLATFORM_KEYS", "GAIN_KEYS", "CHECK_KEY", "TEST_KEY", "COMPARE_KEY", "BALANCE_KEY", "LEVEL_KEY",
                   "PLATFORM_SLOWER_KEY", "PLATFORM_FASTER_KEY", "SWAY_KEY")

    def __init__(self, robot, settings):
        self.robot = robot
        self.motion = robot.motion
        self.s = settings
        for key, (name, sign) in settings["GAIN_KEYS"].items():
            if name not in GAIN_NAMES or sign not in (1, -1):
                raise ValueError(f"GAIN_KEYS '{key}': name must be KP, KI or KD, direction 1 or -1")
        self.screen = BalanceTestScreen()       # 이 테스트만 쓰는 로봇 화면 (Text Screen, Port 0)
        self.screen.show(start_text())          # 시작 화면: 부품 기본 글자("T") 대신 준비 중임을 보여 줌
        check_platform_keys(settings["PLATFORM_KEYS"])
        self.prog = settings_from(settings)              # 시험대 움직임 값 (시험대 스크립트와 같은 규칙)
        self.gains = {name: float(settings[name]) for name in GAIN_NAMES}
        self.levels = {name: check_levels(GAIN_LEVEL_NAMES[name], settings[GAIN_LEVEL_NAMES[name]])
                       for name in GAIN_NAMES}           # PID 키 한 번에 한 단계씩 (KP_LEVELS 등)
        if not settings["POPUP_SEC"] >= 0:
            raise ValueError(f"POPUP_SEC {settings['POPUP_SEC']}: use 0 or more (0 = no help screen on keys)")
        limit = settings["MAX_CORRECTION_DEG"]
        self.roll_pid = PID(self.gains["KP"], self.gains["KI"], self.gains["KD"], limit)
        self.pitch_pid = PID(self.gains["KP"], self.gains["KI"], self.gains["KD"], limit)
        self.filter = IMUFilter(settings["FILTER_MODE"])
        self.platform = PlatformPose(self.prog["PLATFORM_STEP_DEG"], self.prog["PLATFORM_LIMIT_DEG"])
        speed, step = self.prog["PLATFORM_SPEED"], self.prog["PLATFORM_SPEED_STEP"]
        if not PLATFORM_SPEED_MIN <= speed <= PLATFORM_SPEED_MAX:
            raise ValueError(f"PLATFORM_SPEED {speed}: use {PLATFORM_SPEED_MIN:g} ~ {PLATFORM_SPEED_MAX:g} "
                             f"(1.0 = servo part speed)")
        if not step > 0:
            raise ValueError(f"PLATFORM_SPEED_STEP {step}: use a value above 0")
        self.speed = PlatformSpeed(speed, step)      # 시험대 속도 배수 (6 · 7로 바꿈, 시험대에 메시지로 보냄)
        try:
            self.link = PlatformLink(settings["PLATFORM_MCU_PORT"])
            self.link_error = None
        except Exception as e:
            self.link = None
            self.link_error = e

        self.imu = None
        self.imu_error = None
        try:
            self.imu = BodyIMU(ports.PORT_INERTIAL_SENSOR, roll_sign=settings["ROLL_SIGN"],
                               pitch_sign=settings["PITCH_SIGN"], yaw_sign=settings["YAW_SIGN"],
                               swap_roll_pitch=settings["SWAP_ROLL_PITCH"])
        except Exception as e:
            self.imu_error = e              # 시작 안내 뒤에 콘솔에 알림 (enter)

        self.balance_on = False
        self.angles = (0.0, 0.0, 0.0)       # 마지막으로 읽은 IMU (필터를 거친 값)
        self.corrections = (0.0, 0.0)       # 마지막 보정 각도 (roll, pitch)
        self.legs = None                    # 다리 높이 변화 (앞, 뒤, 왼쪽, 오른쪽)
        self.command = None                 # 몸체 방향 확인에서 지금 명령한 몸체 자세 (roll, pitch, yaw)
        self.running = None                 # 진행 중인 테스트 이름 (화면 상태 줄)
        self.note = None                    # 화면 안내 줄에 쓰는 알림 (한국어)
        self.note_logged = {}                # 콘솔 알림 → 마지막으로 남긴 시각 (같은 알림을 NOTE_REPEAT_SEC 안에 되풀이하지 않음)
        self.hint = None                    # 화면 안내 줄의 다음 단계 (한국어)
        self.help_shown = False
        self.key_time = time.time()
        self.last_time = time.time()
        self.last_log = 0.0
        self.logged = None                  # 마지막으로 콘솔에 남긴 (시험대, (IMU roll pitch, 보정 roll pitch))
        self.popup = None                   # 보조 화면 (글자, 사라지는 시각). 키를 누르면 POPUP_SEC 동안
        self.sway = None                    # 연속 흔들기 (ScenarioRun, loop=True). 꺼져 있으면 None
        self.sway_index = None              # 연속 흔들기의 지금 구간 번호
        self.sway_seg = None                # 지금 구간 (시험대 자세)
        self.sway_rows = []                 # 지금 구간의 IMU 기록 (구간 안의 시각, roll, pitch, yaw)
        self.sway_seg_start = 0.0
        self.sway_gain_text = ""            # 지금 구간을 시작할 때의 PID 값 (콘솔 sway 줄, 도중에 바뀌면 *)
        self.sway_last = None               # 지난 구간 결과 (자세 이름, 최대 기울기, 끝 기울기)

    # ------------------------------------------------------------
    # 키 · 콘솔 안내
    # ------------------------------------------------------------
    def actions(self):
        """(키, 콘솔 설명, 함수, 걸린 시간을 남길지) 목록. 왼손 → 오른손 → 사용자 지정 키 순서."""
        items = []
        for key, (axis, direction) in self.s["PLATFORM_KEYS"].items():
            items.append((key, f"platform {axis} {DIRECTION_EN[(axis, direction)]}",
                          lambda a=axis, d=direction: self.platform_step(a, d), False))
        for key, (name, sign) in self.s["GAIN_KEYS"].items():
            items.append((key, f"{name} {'+' if sign > 0 else '-'}",
                          lambda name=name, sign=sign: self.change_gain(name, sign), False))
        items += [(self.s["CHECK_KEY"], "direction check", self.direction_check, True),
                  (self.s["TEST_KEY"], "balance test", self.balance_test, True),
                  (self.s["COMPARE_KEY"], "compare OFF vs ON", self.compare_test, True),
                  (self.s["BALANCE_KEY"], "balance on/off", self.toggle_balance, False),
                  (self.s["LEVEL_KEY"], "platform level", self.platform_level, False),
                  (self.s["PLATFORM_SLOWER_KEY"], "platform slower", lambda: self.platform_speed(-1), False),
                  (self.s["PLATFORM_FASTER_KEY"], "platform faster", lambda: self.platform_speed(1), False),
                  (self.s["SWAY_KEY"], "sway on/off", self.toggle_sway, False)]
        return items

    def repeat_keys(self):
        """누르고 있으면 KEY_REPEAT_SEC마다 다시 실행하는 키 (PID 값 바꾸기). 기본 KEY_REPEAT_SEC = 0이면
        누를 때 한 단계만. 시험대 키는 반복하지 않습니다(시험대 스크립트가 같은 키를 읽을 때 걸음 수가
        어긋나지 않게)."""
        return list(self.s["GAIN_KEYS"])

    def _key(self, name):
        """시작 파일의 키 이름(예: "TEST_KEY") → 화면에 쓰는 키 글자 (예: "2")."""
        return key_label(self.s[name])

    def _gain_keys(self):
        """PID 이름마다 [(키, 방향), ...]. 시작 파일 GAIN_KEYS에 적은 순서."""
        keys = {}
        for key, (name, sign) in self.s["GAIN_KEYS"].items():
            keys.setdefault(name, []).append((key_label(key), sign))
        return keys

    def _platform_keys(self):
        """축마다 "D/A roll +/-" (+ 키 먼저, 키 이름에 키 색)."""
        parts = []
        for axis in AXES:
            keys = sorted(((d, key_label(k)) for k, (a, d) in self.s["PLATFORM_KEYS"].items() if a == axis),
                          reverse=True)
            if keys:
                parts.append(f"{L.key('/'.join(k for _, k in keys))} {axis} "
                             f"{'/'.join('+' if d > 0 else '-' for d, _ in keys)}")
        return "   ".join(parts)

    def _gain_pairs(self):
        """화면 키 줄용 [("U/J", "KP"), ("I/K", "KI"), ("O/L", "KD")]."""
        return [("/".join(k for k, _ in keys), name) for name, keys in self._gain_keys().items()]

    def _pair_text(self, axis):
        """화면용 시험대 키 두 개 "+키/-키". 예: "W/S"."""
        keys = sorted(((d, key_label(k)) for k, (a, d) in self.s["PLATFORM_KEYS"].items() if a == axis),
                      reverse=True)
        return "/".join(k for _, k in keys)

    def _link_text(self):
        if self.link is not None and self.link.linked:
            return f"platform link: MCU port {self.link.port}"
        return "platform link: none (same keys)"

    def _console_key(self, name):
        """시작 파일의 키 이름(예: "TEST_KEY") → 콘솔용 키 글자 (키 색)."""
        return L.key(self._key(name))

    def _gain_key_text(self):
        """PID 키 묶음 "U/J I/K O/L" (콘솔용, 키 색)."""
        return L.keys("/".join(k for k, _ in keys) for keys in self._gain_keys().values())

    def common_guide(self):
        """콘솔 시작 안내의 첫 줄 (F1 · F2 · F3)."""
        k = self._console_key
        return f" {k('HELP_KEY')} help   {k('STAND_KEY')} reset   {k('STOP_KEY')} stop all   quit: stop the script"

    def guide(self):
        """콘솔 키 안내 (영어). 묶음 이름 칸은 GUIDE_LABEL_COLS (Platform이 들어가는 폭)."""
        k = self._console_key

        def row(label, text):
            return f" {label:<{GUIDE_LABEL_COLS}} {text}"
        gain_keys = "   ".join(f"{L.key('/'.join(key for key, _ in keys))} {name}"
                               for name, keys in self._gain_keys().items())
        return [row("Step", f"{k('CHECK_KEY')} direction check   {k('TEST_KEY')} balance test"),
                row("", f"{k('COMPARE_KEY')} compare: same platform moves, balance OFF then ON"),
                row("", f"{k('SWAY_KEY')} sway: platform keeps tilting, PID keys work live"),
                row("Platform", self._platform_keys()),
                row("", f"{k('LEVEL_KEY')} level   {self.prog['PLATFORM_STEP_DEG']:g} deg per key, "
                        f"limit +-{self.prog['PLATFORM_LIMIT_DEG']:g}"),
                row("", f"{k('PLATFORM_SLOWER_KEY')}/{k('PLATFORM_FASTER_KEY')} speed -/+"
                        f"{self.speed.step:g}   (x1.0 = servo part speed)"),
                row("Gain", f"{gain_keys}   (one level per key)"),
                *[row("", f"{name} {level_text(self.levels[name], self.gains[name])}") for name in GAIN_NAMES],
                row("Mode", f"{k('BALANCE_KEY')} balance on/off   {self._link_text()}"),
                row("Now", self._gain_text()),
                row("", f"platform speed {speed_text(self.speed.value)}"),
                row("Log", "body = robot IMU   corr = PID correction (deg)")]

    def _gain_text(self):
        g = self.gains
        return (f"KP={g['KP']:g}  KI={g['KI']:g}  KD={g['KD']:g}  "
                f"filter={FILTER_NAMES_EN[self.filter.mode]}")

    def _gain_short(self):
        """콘솔 한 줄 끝에 붙이는 짧은 PID 값. 예: "P0.5 I1.5 D0.02", 균형 OFF이면 "balance OFF"."""
        g = self.gains
        return f"P{g['KP']:g} I{g['KI']:g} D{g['KD']:g}" if self.balance_on else "balance OFF"

    def _set_note(self, ko=None, en=None):
        """화면 알림(한국어)과 콘솔 알림(영어). 콘솔은 같은 알림을 NOTE_REPEAT_SEC에 한 번만 남깁니다."""
        self.note = ko
        if not en:
            return
        now = time.time()
        if now - self.note_logged.get(en, -NOTE_REPEAT_SEC) >= NOTE_REPEAT_SEC:
            L.event("WARN", en)
            self.note_logged[en] = now

    def _next(self, en, ko):
        """다음 단계 안내: 콘솔 한 줄 · 화면 안내 줄."""
        L.event("STATE", f"next: {en}")
        self.hint = ko

    # ------------------------------------------------------------
    # 로봇 화면
    # ------------------------------------------------------------
    def _pid(self):
        return (self.gains["KP"], self.gains["KI"], self.gains["KD"], self.filter.mode)

    def _platform_line(self):
        imu = self.link.platform_imu_fresh() if self.link is not None else None
        return platform_line(self.platform.pose, speed_text(self.speed.value), imu)

    def _info(self):
        """메인 화면 본문 마지막 줄: 알림(빨강) · 다음 단계(초록) · 연속 흔들기의 지난 자세 결과."""
        if self.note:
            return tag(self.note, "alert")
        if self.sway is not None and self.sway_last is not None:
            label, mx, end = self.sway_last
            return tag(f"지난 {label}: 최대 {mx:.1f}° · 끝 {end:.1f}°", "hint")
        if self.hint:
            return tag(self.hint, "hint")
        return ""

    def _keys(self, *pairs):
        """[(시작 파일 키 이름 또는 키 글자, 설명), ...] → 화면 키 줄."""
        return keys_text([(self._key(k) if k in self.s else k, desc) for k, desc in pairs])

    def _popup_active(self):
        return self.popup is not None and time.time() < self.popup[1]

    def _popup(self, title, lines, *keys):
        """보조 화면을 POPUP_SEC 동안 보여 줍니다 (그 뒤 메인 화면으로). keys: 화면 맨 아래 키 줄."""
        if self.s["POPUP_SEC"] <= 0:
            return
        self.popup = (popup_text(title, lines, self._keys(*keys)), time.time() + self.s["POPUP_SEC"])
        self.help_shown = False
        self.screen.show(self.popup[0])

    def _main_title(self):
        balance = "균형 ON" if self.balance_on else "균형 OFF"
        if self.sway is not None and self.sway_seg is not None:
            pose = "평평" if self.sway_seg.label == "level" else self.sway_seg.label
            return f"연속 흔들기 · {balance} · {pose}"
        if self.robot.interrupted:
            return f"균형 테스트 · 멈춤 · {balance}"
        return f"균형 테스트 · {balance}"

    def _main_footer(self):
        if self.sway is not None:
            pid = " ".join("/".join(k for k, _ in keys) for keys in self._gain_keys().values())
            return self._keys(("SWAY_KEY", "멈춤"), (pid, "PID"), ("BALANCE_KEY", "균형"))
        return self._keys(("HELP_KEY", "키 안내"), ("STAND_KEY", "처음으로"), ("STOP_KEY", "모두 멈춤"))

    def show_idle(self):
        """메인 화면 (키를 하나 실행할 때마다 · REFRESH_SEC마다). 보조 화면이 떠 있으면 그것을."""
        self.help_shown = False
        if self._popup_active():
            self.screen.show(self.popup[0])
            return
        self.popup = None
        imu = self.angles if self.imu is not None else None
        extras = (self.corrections[0], self.corrections[1], None) if self.balance_on else (None, None, None)
        self.screen.show(balance_text(self._main_title(), imu, "보정", extras, self._platform_line(),
                                      self._pid(), self._info(), self._main_footer()))

    def show_running(self, state):
        """테스트 중 화면. 몸체 방향 확인이면 명령한 몸체 자세를, 균형 ON이면 보정을 오른쪽에.
        테스트를 시작한 키의 보조 화면이 떠 있으면 POPUP_SEC 동안 그것을."""
        if self._popup_active():
            self.screen.show(self.popup[0])
            return
        footer = self._keys(("STOP_KEY", "멈춤"), ("STAND_KEY", "처음으로"))
        info = tag(self.note, "alert") if self.note else ""
        if self.command is not None:
            name, extras = "명령", self.command
        elif self.balance_on:
            name, extras = "보정", (self.corrections[0], self.corrections[1], None)
        else:
            name, extras = "", (None, None, None)
        self.screen.show(balance_text(state, self.angles, name, extras, self._platform_line(), self._pid(),
                                      info, footer))

    def show_help_screen(self):
        """F1 키 안내 화면: 묶음 이름(노랑) · 키(흰색 굵게) · 설명(회색). 메인 화면과 같은 줄 수."""
        k = self._key

        def pair(name):
            """시험대 키 두 개를 "+키/-키"로. 예: "W/S"."""
            keys = sorted(((d, key_label(key)) for key, (a, d) in self.s["PLATFORM_KEYS"].items() if a == name),
                          reverse=True)
            return "/".join(key for _, key in keys)

        gains = self._gain_keys()
        rows = [
            ("자동", [(k("CHECK_KEY"), "방향 확인"), (k("TEST_KEY"), "균형 테스트")]),
            ("", [(k("COMPARE_KEY"), "비교 OFF → ON"), (k("SWAY_KEY"), "연속 흔들기")]),
            ("시험대", [(pair("pitch"), "앞뒤"), (pair("roll"), "좌우"), (pair("yaw"), "회전")]),
            ("", [(k("LEVEL_KEY"), "평평"),
                  (f"{k('PLATFORM_SLOWER_KEY')}/{k('PLATFORM_FASTER_KEY')}",
                   f"속도 (지금 {speed_text(self.speed.value)})")]),
            ("균형", [(k("BALANCE_KEY"), "ON/OFF")]),
            ("PID", [("/".join(key for key, _ in gains[name]), name) for name in GAIN_NAMES if name in gains]),
        ]
        lines = [tag(pad_cols(group, HELP_GROUP_COLS), "label") + keys_text(items, "   ") for group, items in rows]
        self.help_shown = True
        self.popup = None
        self.screen.show(help_text(lines, self._keys(("STAND_KEY", "처음으로"), ("STOP_KEY", "모두 멈춤"),
                                                     ("다른 키", "돌아감"))))

    # ------------------------------------------------------------
    # 다리 테스트 프로그램이 부르는 곳
    # ------------------------------------------------------------
    def enter(self):
        """시작할 때: 시험대를 평평하게, 기본 자세, IMU 영점. 시험대 연결 상태를 알림."""
        if self.imu_error is not None:
            self._imu_failed(self.imu_error)
        self._report_link()
        self._platform_to(LEVEL, force=True)
        self.robot.stand()
        self.on_stand()
        self.calibrate()
        if self.s["BALANCE_AT_START"]:
            self.set_balance(True)
        if self.imu is not None:
                self._next(f"press {self._console_key('CHECK_KEY')} (direction check)",
                           f"다음: {self._key('CHECK_KEY')} 방향 확인")

    def _report_link(self):
        """시험대 Microcontroller와 메시지로 연결되었는지 콘솔에 알립니다."""
        if self.link is not None and self.link.linked:
            L.event("STATE", f"platform link: MCU port {self.link.port}, robot sends angles")
            return
        if self.link_error is not None:
            L.event("WARN", f"platform link not available ({self.link_error})")
        L.event("STATE", "platform link: none, platform script reads keys")
        L.more("to link: README 11.1 (platform MCU on a robot port)")
        changed = changed_from_defaults(self.prog)
        if changed:
            L.event("WARN", "not linked: the platform uses default values for")
            for line in L.wrap(" ".join(changed), 50):
                L.more(line)

    def on_stand(self):
        """기본 자세로 옮긴 뒤: 균형 모드를 끄고 보정값을 지웁니다."""
        if self.balance_on:
            L.event("STATE", "balance OFF")
        self.balance_on = False
        self.corrections = (0.0, 0.0)
        self.legs = None
        self.command = None
        self.roll_pid.reset()
        self.pitch_pid.reset()
        self.filter.reset()

    def reset(self):
        """F2 처음으로: 시험대 평평 · 균형 OFF · 기본 자세 · IMU 영점."""
        self.prepare()
        self.calibrate()

    def prepare(self):
        """시험대 평평 · 균형 OFF · 기본 자세. F3으로 멈춘 뒤 테스트를 다시 시작할 때 (영점은 그대로)."""
        self.running = None
        self._end_sway()
        self._platform_to(LEVEL, force=True)
        L.event("ACTION", "platform level")
        self.robot.stand()
        self.on_stand()

    def _start_time(self):
        """테스트를 시작한 시각. 시험대를 연결했으면 지금, 연결하지 않았으면 키를 처리하기 시작한 시각
        (시험대 스크립트도 같은 키를 그때부터 세므로 두 쪽의 시험대 순서가 맞음)."""
        if self.link is not None and self.link.linked:
            return time.time()
        return self.key_time

    def stop_idle(self):
        """F3을 눌렀지만 진행 중인 자동 테스트(1 · 2 · 3)가 없을 때. 연속 흔들기 중이면 멈추고
        시험대는 그 자세에 둠."""
        if self.sway is not None:
            self._end_sway()
            self._platform_to(self.platform.pose, force=True)
            L.event("STATE", f"platform held at {pose_text(self.platform.pose)}, "
                             f"balance {'ON' if self.balance_on else 'OFF'}")
            return
        L.event("STATE", f"nothing running; platform held at {pose_text(self.platform.pose)}")

    def before_action(self):
        """키 하나를 실행하기 전에: 지난 알림을 지우고 키를 처리하기 시작한 시각을 기억합니다.
        시험대를 연결하지 않았으면 테스트는 이 시각부터 시험대 순서를 셉니다(먼저 기본 자세로 서는 시간이
        있어도 같은 키를 읽은 시험대 스크립트와 맞음)."""
        self.note = None
        self.popup = None
        self.key_time = time.time()

    def after_stop(self):
        """테스트를 F3 · F2로 멈춘 뒤: 시험대는 그 자리, 다리는 멈춘 자세."""
        self.running = None
        self.robot.sync_from_motion()
        self.command = None
        self.filter.reset()
        self._platform_to(self.platform.pose, force=True)
        L.event("STATE", f"platform held at {pose_text(self.platform.pose)}, "
                         f"balance {'ON' if self.balance_on else 'OFF'}")

    def on_loop(self):
        """키를 한 번 읽을 때마다: IMU 읽기 → (균형 모드면) PID → 다리, 시험대 연결, 콘솔 · 화면."""
        now = time.time()
        if self.sway is not None:
            self._sway_step(now)
        self._control_step(now)
        if self.sway is not None and self.sway_seg is not None:
            self.sway_rows.append((now - self.sway_seg_start,) + tuple(self.angles))
        interval = self.s["LOG_INTERVAL_SEC"]
        if interval and now - self.last_log >= interval:
            self.last_log = now
            self.log_state()
        if not self.help_shown and self.screen.due():
            self.show_idle()

    def _control_step(self, now):
        """IMU → (균형 ON이면) PID · 다리. 시험대에 목표 각도를 다시 보내고 시험대 IMU를 받음."""
        dt = min(MAX_DT_SEC, max(0.0, now - self.last_time))
        self.last_time = now
        angles = self.read_imu()
        if angles is not None:
            self.angles = angles
            if self.balance_on:
                self.balance_step(angles, dt)
        if self.link is not None:
            self.link.poll()

    # ------------------------------------------------------------
    # 시험대
    # ------------------------------------------------------------
    def _platform_to(self, pose, force=False):
        """시험대 목표 각도를 정하고 (연결되어 있으면) 시험대 속도 배수와 함께 시험대에 보냅니다."""
        self.platform.set(pose)
        if self.link is not None:
            self.link.send(self.platform.pose, self.speed.value, force=force)

    def platform_step(self, axis, direction):
        """시험대 키: 한 축을 PLATFORM_STEP_DEG도. 연속 흔들기 중이면 멈추고 지금 자세에서 한 걸음."""
        self._end_sway()
        if not self.platform.step_axis(axis, direction):
            L.event("STATE", f"platform {axis} at limit {self.platform.pose[AXES.index(axis)]:+.0f} deg")
            return
        self._platform_to(self.platform.pose)
        p = self.platform.pose
        L.event("ACTION", f"platform roll={p[0]:+.0f}  pitch={p[1]:+.0f}  yaw={p[2]:+.0f} deg")
        self.logged = None

    def platform_level(self):
        """5: 시험대 평평. 연속 흔들기 중이면 멈춤."""
        self._end_sway()
        self._platform_to(LEVEL)
        L.event("ACTION", "platform level")
        self.logged = None
        self._popup("시험대 평평", [
            "시험대를 (0, 0, 0)도로 되돌림",
            "왜: 기울인 뒤 처음 자세에서 다시 시작",
            "균형 ON: 몸체가 반대로 기울었다가",
            "        다시 수평을 찾는 모습이 보임",
            ("시험대 키 한 번에 "
             f"{self.prog['PLATFORM_STEP_DEG']:g}도 · 한계 ±{self.prog['PLATFORM_LIMIT_DEG']:g}도", "platform"),
        ], (self._pair_text("pitch"), "앞뒤"), (self._pair_text("roll"), "좌우"), (self._pair_text("yaw"), "회전"))

    def platform_speed(self, sign):
        """6 · 7: 시험대 속도 배수를 PLATFORM_SPEED_STEP만큼. 시험대 키 · 테스트의 시험대 움직임이 모두 이 속도."""
        old = self.speed.value
        changed = self.speed.change(sign)
        if not changed:
            limit = "min" if sign < 0 else "max"
            L.event("STATE", f"platform speed at {limit} {speed_text(old)}")
        else:
            self._platform_to(self.platform.pose, force=True)
            L.event("PARAMETER", f"platform speed {speed_text(old)} -> {speed_text(self.speed.value)}")
        new = speed_text(self.speed.value)
        title = f"시험대 속도 {speed_text(old)} → {new}" if changed else \
            f"시험대 속도 {new} ({'가장 느림' if sign < 0 else '가장 빠름'})"
        self._popup(title, [
            "서보 속도 = 부품 설정 속도 × 배수",
            "빠르게: 몸체가 갑자기 기욺 → 최대 큼",
            "느리게: PID가 따라가기 쉬움 → 최대 작음",
            (f"한 번에 {self.speed.step:g} · 범위 {speed_text(PLATFORM_SPEED_MIN)} ~ {speed_text(PLATFORM_SPEED_MAX)}", "platform"),
            "시험대 키 · 1 2 3 · 8이 모두 이 속도",
            ("2 균형 테스트의 최대 기울기로 비교", "hint"),
        ], ("PLATFORM_SLOWER_KEY", "느리게"), ("PLATFORM_FASTER_KEY", "빠르게"), ("TEST_KEY", "균형 테스트"))

    # ------------------------------------------------------------
    # IMU
    # ------------------------------------------------------------
    def _imu_failed(self, error):
        L.event("WARN", f"no IMU on port {ports.PORT_INERTIAL_SENSOR}: balance and tests off")
        L.more(str(error))
        self.imu = None
        self.balance_on = False
        self.note = f"IMU 없음 (Port {ports.PORT_INERTIAL_SENSOR})"

    def _need_imu(self):
        if self.imu is None:
            self.note = f"IMU 없음 (Port {ports.PORT_INERTIAL_SENSOR})"
            L.event("WARN", "no IMU: cannot run this")
            return False
        return True

    def read_imu(self):
        """IMU (roll, pitch, yaw) 도, 필터를 거친 값. 읽을 수 없으면 None."""
        if self.imu is None:
            return None
        try:
            return self.filter.update(self.imu.read())
        except Exception as e:
            self._imu_failed(e)
            return None

    def read_imu_average(self):
        """필터 없이 IMU_TEST_SAMPLES번 읽은 평균."""
        total = [0.0, 0.0, 0.0]
        for _ in range(IMU_TEST_SAMPLES):
            for i, value in enumerate(self.imu.read()):
                total[i] += value
            time.sleep(IMU_TEST_SAMPLE_SEC)
        return tuple(t / IMU_TEST_SAMPLES for t in total)

    def calibrate(self):
        """지금 기울기를 IMU 영점(0도)으로 잡습니다. 시험대가 평평하고 로봇이 기본 자세일 때."""
        if self.imu is None:
            return
        time.sleep(IMU_SETTLE_SEC)
        L.event("STATE", "IMU zero: keep the robot and the platform still")
        try:
            zero = self.imu.calibrate(self.s["CALIBRATION_SAMPLES"], still_deg=self.s["IMU_STILL_DEG"])
        except Exception as e:
            self._imu_failed(e)
            return
        self.filter.reset()
        self.angles = (0.0, 0.0, 0.0)
        self.logged = None
        L.event("SENSOR", f"zero  {L.angles_text(zero)}")
        L.more(f"still after {self.imu.wait_sec:.1f} s  spread={self.imu.spread:.2f} deg")
        again = f"press {self._console_key('STAND_KEY')} (reset) again"
        if not self.imu.settled:
            L.event("WARN", f"IMU not still after {STILL_TIMEOUT_SEC:g} s "
                            f"(IMU_STILL_DEG={self.s['IMU_STILL_DEG']:g})")
            L.more(f"keep the robot still and {again}")
        elif self.imu.spread > ZERO_SPREAD_WARN_DEG:
            L.event("WARN", f"IMU moved {self.imu.spread:.1f} deg while zeroing")
            L.more(f"keep the robot still and {again}")
        if any(ZERO_TILT_WARN_DEG < abs(v) < 180.0 - ZERO_TILT_WARN_DEG for v in zero[:2]):
            L.event("WARN", "large tilt at zero: is the platform level?")
            L.more(f"level the platform and {again}")

    # ------------------------------------------------------------
    # PID 균형
    # ------------------------------------------------------------
    def toggle_balance(self):
        """4: 균형 ON / OFF. 연속 흔들기 중이면 시험대는 계속 흔들림 (ON · OFF 차이를 바로 봄)."""
        self.set_balance(not self.balance_on)
        p = self.platform.pose
        now = f"지금 시험대 R {p[0]:+.0f} · P {p[1]:+.0f} · Y {p[2]:+.0f}"
        if self.balance_on:
            self._popup("균형 OFF → ON", [
                "IMU → PID → 다리 높이 → 몸체 수평",
                "목표: 몸체 roll 0도 · pitch 0도",
                "보정: 시험대와 반대로 몸체를 기울임",
                "왜: 켜고 끄며 차이를 바로 봄",
                (now, "platform"),
                ("시험대 키로 기울여 확인 · 8 연속 흔들기", "hint"),
            ], ("BALANCE_KEY", "OFF"), (self._pair_text("roll"), "시험대"), ("SWAY_KEY", "흔들기"))
        elif self.imu is not None:
            self._popup("균형 ON → OFF", [
                "PID를 멈추고 기본 자세로",
                "몸체가 시험대와 함께 기욺",
                "Roll · Pitch 값 = 시험대 기울기",
                "왜: 균형 제어가 없을 때와 비교",
                (now, "platform"),
                ("다시 ON: 몸체가 수평으로 돌아옴", "hint"),
            ], ("BALANCE_KEY", "ON"), (self._pair_text("roll"), "시험대"), ("SWAY_KEY", "흔들기"))

    def set_balance(self, on):
        """균형 모드 ON / OFF. OFF이면 기본 자세로 옮깁니다."""
        if on and not self._need_imu():
            return
        if on:
            self.roll_pid.reset()
            self.pitch_pid.reset()
            self.filter.reset()
            self.balance_on = True
            self.last_time = time.time()
            self.note_logged = {}
            L.event("STATE", "balance ON  target roll=0 pitch=0 deg")
            L.event("PARAMETER", self._gain_text())
        else:
            self.balance_on = False
            L.event("STATE", "balance OFF -> stand pose")
            self.robot.stand()
            self.on_stand()
        self.logged = None

    def change_gain(self, name, sign):
        """PID 값 하나를 KP_LEVELS 등의 한 단계 위 · 아래로 바꿉니다. roll · pitch 두 PID에 바로 적용
        (균형 ON · 연속 흔들기 중에도 다음 계산부터 새 값). 단계가 크게 벌어져 있어 효과가 눈에 보임."""
        levels = self.levels[name]
        old = self.gains[name]
        new = next_level(levels, old, sign)
        if new is None:
            L.event("STATE", f"{name} at {'max' if sign > 0 else 'min'} {old:g}")
            new = old
        else:
            self.gains[name] = new
            for pid in (self.roll_pid, self.pitch_pid):
                pid.set_gains(**{name.lower(): new})
            L.event("PARAMETER", f"{name} {old:g} -> {new:g}  (level {levels.index(new) + 1}/{len(levels)})")
        self._gain_popup(name, old, new, sign)

    def _gain_popup(self, name, old, new, sign):
        """PID 키의 보조 화면: 무엇이 바뀌었는지 · 그 값이 하는 일 · 크게 · 작게 하면 · 지금 상태 · 관련 키."""
        letter, formula, big, small = GAIN_INFO[name]
        if new != old:
            title = f"{name} {old:g} → {new:g}"
        else:
            title = f"{name} {new:g} ({'가장 큼' if sign > 0 else '가장 작음'})"
        if not self.balance_on:
            state = ("균형 OFF: 4로 켜야 효과가 보임", "alert")
        else:
            state = (f"지금 보정 roll {self.corrections[0]:+.1f} · pitch {self.corrections[1]:+.1f}", "out")
        tip = ("콘솔 sway 줄의 최대 · 끝으로 비교", "hint") if self.sway is not None else \
            ("8 연속 흔들기: 멈추지 않고 비교", "hint")
        up, down = (next((k for k, s in self._gain_keys().get(name, []) if s == d), "?") for d in (1, -1))
        self._popup(title, [
            f"{letter} = {name} × {formula}",
            big,
            small,
            (f"단계 {level_text(self.levels[name], new)}", "platform"),
            state,
            tip,
        ], (up, "올림"), (down, "내림"), ("BALANCE_KEY", "균형"), ("SWAY_KEY", "흔들기"))

    # ------------------------------------------------------------
    # 8  연속 흔들기 (시험대가 TEST_POSES를 계속 되풀이, 키를 모두 읽음)
    # ------------------------------------------------------------
    def toggle_sway(self):
        """8: 연속 흔들기 켜기 · 끄기. 켜면 균형 ON, 시험대가 TEST_POSES를 SWAY_HOLD_SEC씩 계속 되풀이합니다.
        1 · 2 · 3과 달리 키를 기다리는 반복(on_loop) 안에서 진행하므로 PID 키 · 4 · 6 · 7이 바로 반영됩니다.
        끄면 시험대를 평평하게 합니다."""
        if self.sway is not None:
            self._end_sway()
            self._platform_to(LEVEL)
            L.event("ACTION", "platform level")
            self._popup("8 연속 흔들기 OFF", [
                "시험대를 평평하게",
                "PID 값은 바꾼 그대로 남음",
                (f"지금 KP {self.gains['KP']:g} · KI {self.gains['KI']:g} · KD {self.gains['KD']:g}", "platform"),
                "좋은 값은 시작 파일 KP · KI · KD에",
                ("2 균형 테스트로 같은 조건에서 재기", "hint"),
            ], ("SWAY_KEY", "다시 켜기"), ("TEST_KEY", "균형 테스트"))
            return
        if not self._need_imu():
            return
        if self.robot.interrupted:
            L.event("STATE", "moving to stand pose before sway")
            self.prepare()
        t0 = self._start_time()
        if not self.balance_on:
            self.set_balance(True)
        self.sway = ScenarioRun("sway", scenario("sway", self.prog), t0, loop=True)
        self.sway_index = None
        self.sway_seg = None
        self.sway_last = None
        hold = self.prog["SWAY_HOLD_SEC"]
        n = len(self.prog["TEST_POSES"])
        L.event("TASK", f"sway: {n} platform poses, {hold:g} s each, repeating")
        L.more("per pose: max/end tilt and PID (* = changed)")
        L.more(f"PID keys work live. Stop: {L.keys([self._key(k) for k in ('SWAY_KEY', 'STOP_KEY', 'STAND_KEY')])}")
        self._popup("8 연속 흔들기 ON", [
            f"시험대가 {n}자세를 {hold:g}초씩 계속 반복",
            "균형 ON · PID 키가 바로 반영됨",
            "왜: 멈추지 않고 값을 바꿔 차이를 봄",
            "화면 맨 아래 줄: 지난 자세 최대 · 끝",
            ("콘솔 [METRIC] sway: 자세마다 결과", "hint"),
            ("멈춤: 8 · F3 · F2 · 5 · 시험대 키", "text"),
        ], *self._gain_pairs(), ("SWAY_KEY", "멈춤"))

    def _sway_step(self, now):
        """연속 흔들기 한 번: 구간이 바뀌면 지난 구간 결과를 콘솔에 남기고 시험대에 다음 자세를 보냄."""
        i, seg = self.sway.at(now)
        if i == self.sway_index:
            return
        if self.sway_seg is not None:
            self._sway_report()
        self.sway_index = i
        self.sway_seg = seg
        self.sway_rows = []
        self.sway_seg_start = now
        self.sway_gain_text = self._gain_short()
        self._platform_to(seg.pose)
        self.logged = None

    def _sway_report(self):
        """지난 구간: 최대 · 끝 기울기 한 줄 (그때의 PID 값과 함께). 화면 맨 아래 줄에도."""
        stats = self._segment_stats(self.sway_rows, self.prog["SWAY_HOLD_SEC"])
        if stats is None:
            return
        mx, end = stats[0], stats[1]
        label = self.sway_seg.label
        self.sway_last = ("평평" if label == "level" else label, mx, end)
        gains = self.sway_gain_text if self.sway_gain_text == self._gain_short() else f"{self.sway_gain_text} *"
        L.event("METRIC", f"sway {label:<9} max {mx:4.1f} end {end:4.1f}  {gains}")

    def _end_sway(self):
        """연속 흔들기를 끕니다 (켜져 있을 때만 콘솔에 한 줄). 시험대는 지금 자세 그대로."""
        if self.sway is None:
            return
        self.sway = None
        self.sway_seg = None
        self.sway_last = None
        L.event("TASK", "sway stopped")

    def pose_feet(self, roll=0.0, pitch=0.0, yaw=0.0):
        """몸체 자세(도) → 네 발끝 좌표와 문제 (갈 수 없으면 (화면용 한국어, 콘솔용 영어), 갈 수 있으면 None).
        기본 자세처럼 발끝을 FEET_FORWARD만큼 앞에 둡니다 (몸체를 그만큼 뒤로 옮긴 것과 같음)."""
        pose = zero_pose()
        pose["x"] = -self.s["FEET_FORWARD"]
        pose["roll"], pose["pitch"], pose["yaw"] = roll, pitch, yaw
        feet = body_pose_feet(pose, self.s["BODY_HEIGHT"], self.s["BODY_LENGTH"], self.s["BODY_WIDTH"])
        for leg, point in enumerate(feet):
            r = check_point(self.motion, leg, point)
            name = ports.LEG_NAMES[leg]
            if not r["ok"]:
                return feet, (f"{name} 갈 수 없음", f"{name} foot {r['reason']}")
            if r["limited"]:
                return feet, (f"{name} {'·'.join(r['limited'])} 제한",
                              f"{name} {' '.join(r['limited'])} at 0/180 deg limit")
        return feet, None

    def balance_step(self, angles, dt):
        """IMU 값 한 번으로 보정 각도를 계산하고 다리에 보냅니다."""
        roll, pitch, _ = angles
        saved = (self.roll_pid.integral, self.pitch_pid.integral)
        roll_c = self.roll_pid.update(roll, dt)
        pitch_c = self.pitch_pid.update(pitch, dt)
        feet, problem = self.pose_feet(roll_c, pitch_c)
        if problem:
            # 갈 수 없는 자세: 다리를 지금 자세에 두고, 이번에 쌓은 I도 되돌림 (I가 계속 커지지 않게)
            self.roll_pid.integral, self.pitch_pid.integral = saved
            self._set_note(f"{problem[0]} · 보정 멈춤", f"{problem[1]}: correction held")
            return
        limit = self.s["MAX_CORRECTION_DEG"]
        at_limit = [name for name, c in (("roll", roll_c), ("pitch", pitch_c)) if abs(c) >= limit - 1e-6]
        if at_limit:
            self._set_note(f"{' · '.join(at_limit)} 보정 최대 {limit}도",
                           f"{'+'.join(at_limit)} correction at max {limit:g} deg")
        else:
            self._set_note()
        for leg in range(4):
            self.motion.points[leg] = list(feet[leg])
        self.motion.run()
        self.robot.sync_from_motion()
        self.corrections = (roll_c, pitch_c)
        self.legs = self.leg_changes(feet)

    def leg_changes(self, feet):
        """다리 높이 변화 (앞, 뒤, 왼쪽, 오른쪽). 엉덩이에서 발끝까지 높이 - 기본 높이, +는 다리가 길어짐."""
        h = self.s["BODY_HEIGHT"]
        length = [-feet[leg][2] - h for leg in range(4)]

        def mean(legs):
            return sum(length[leg] for leg in legs) / len(legs)
        return (mean(ports.FRONT_LEGS), mean(ports.HIND_LEGS), mean(ports.LEFT_LEGS), mean(ports.RIGHT_LEGS))

    def _state_text(self):
        """콘솔 한 줄: 시험대 roll pitch · 몸체(IMU) roll pitch · (균형 ON이면) 보정 roll pitch."""
        p = self.platform.pose
        a = self.angles
        text = f"platform {p[0]:+3.0f} {p[1]:+3.0f}  body {L.signed(a[0])} {L.signed(a[1])}"
        if self.balance_on:
            text += f"  corr {L.signed(self.corrections[0])} {L.signed(self.corrections[1])}"
        return text

    def log_state(self):
        """콘솔 한 줄 (LOG_INTERVAL_SEC마다 확인): 시험대가 바뀌었거나 IMU · 보정이 LOG_CHANGE_DEG 넘게
        바뀌었을 때만. 시험대와 몸체가 가만히 있으면 콘솔이 조용합니다."""
        if self.imu is None:
            return
        values = tuple(self.angles[:2]) + (tuple(self.corrections) if self.balance_on else (0.0, 0.0))
        if self.logged is not None and self.logged[0] == self.platform.pose \
                and max(abs(a - b) for a, b in zip(values, self.logged[1])) < LOG_CHANGE_DEG:
            return
        self.logged = (self.platform.pose, values)
        L.event("SENSOR", self._state_text())
        if not self.balance_on:
            return
        if not self.s["LOG_DETAIL"]:
            return
        for axis, pid in (("roll", self.roll_pid), ("pitch", self.pitch_pid)):
            L.more(f"PID {axis:<5} P={L.signed(pid.p)}  I={L.signed(pid.i)}  D={L.signed(pid.d)}")
        if self.legs is not None:
            f, b, left, right = self.legs
            L.more(f"legs  front={L.signed(f)} hind={L.signed(b)} left={L.signed(left)} right={L.signed(right)}")

    # ------------------------------------------------------------
    # 테스트를 진행하는 반복 (시험대 순서를 따라가며 균형 제어 · 측정)
    # ------------------------------------------------------------
    def _segment_stats(self, rows, hold):
        """한 구간의 측정: (최대 기울기, 끝 기울기, 끝 (roll, pitch, yaw), 수평이 된 시각 또는 None)."""
        if not rows:
            return None
        tilts = [(t, tilt_of(r, p)) for t, r, p, _ in rows]
        end_rows = [row for row in rows if row[0] >= hold - MEASURE_SEC] or rows[-1:]
        end = tuple(sum(row[k] for row in end_rows) / len(end_rows) for k in (1, 2, 3))
        over = [t for t, tilt in tilts if tilt > self.s["SETTLE_DEG"]]
        if not over:
            settle = 0.0
        else:
            # 마지막으로 SETTLE_DEG를 넘은 뒤 처음 읽은 시각. 끝까지 넘으면 None
            after = [t for t, _ in tilts if t > max(over)]
            settle = after[0] if after else None
        return max(v for _, v in tilts), tilt_of(end[0], end[1]), end, settle

    # ------------------------------------------------------------
    # 1  방향 확인
    # ------------------------------------------------------------
    def direction_check(self):
        """시험대를 ±CHECK_DEG 기울여 로봇 IMU가 같은 쪽으로 재는지 보고(시험대 서보 방향),
        시험대를 평평하게 둔 채 몸체를 ±CHECK_DEG 기울여 IMU가 명령과 같은 쪽인지 봅니다(로봇 IMU 방향)."""
        if not self._need_imu():
            return
        self._end_sway()
        t0 = self._start_time()
        deg = self.prog["CHECK_DEG"]
        hold = self.prog["CHECK_HOLD_SEC"]
        self._popup(f"1 방향 확인 · 약 {round(hold * 10.5 + 2)}초", [
            f"시험대 ±{deg:g}도: 로봇 IMU가 같은 쪽인가",
            f"몸체 ±{deg:g}도: IMU가 명령과 같은 쪽인가",
            "왜: 부호가 반대면 균형이 더 기울게 함",
            "균형 OFF로 진행 (시험대만 · 몸체만)",
            ("결과: 콘솔 direction check result", "hint"),
            ("세 축 OK → 다음은 2 균형 테스트", "text"),
        ], ("STOP_KEY", "멈춤"), ("STAND_KEY", "처음으로"))
        if self.balance_on:
            self.set_balance(False)
        self.running = "check"
        run = ScenarioRun("check", scenario("check", self.prog), t0)
        L.event("TASK", f"direction check 1/2: platform +-{deg:g} deg, balance OFF")
        L.event("METRIC", f"{'platform':<12}  {'imu roll':>9}  {'pitch':>5}  {'yaw':>5}  {'diff':>5}")
        segs = run.segments

        def on_segment(i, seg):
            if i > 0:
                self._check_line(segs[i - 1], samples_ref.get(i - 1), hold, platform_results)

        platform_results = {}
        samples_ref = {}
        samples = self._run_collect(run, on_segment, "방향 확인", samples_ref)
        last = len(segs) - 2
        self._check_line(segs[last], samples.get(last), hold, platform_results)

        self.robot.wait(CHECK_LEVEL_SEC)
        L.event("TASK", f"direction check 2/2: body +-{deg:g} deg, platform level")
        L.event("METRIC", f"{'body':<12}  {'imu roll':>9}  {'pitch':>5}  {'yaw':>5}  {'diff':>5}")
        body_results = self._body_check(deg)
        self.running = None
        self._check_result(platform_results, body_results, deg)

    def _run_collect(self, run, on_segment, label, store):
        """run(ScenarioRun)이 끝날 때까지: 구간이 바뀌면 시험대에 보내고 on_segment(i, 구간),
        반복마다 IMU · PID를 돌리고 store[구간 번호]에 (구간 안의 시각, roll, pitch, yaw)를 쌓음.
        F3 · F2를 누르면 robot.check_stop()이 TestStopped를 일으켜 그 자리에서 멈춤."""
        samples = store
        index = None
        while True:
            now = time.time()
            i, seg = run.at(now)
            if i is None:
                break
            if i != index:
                index = i
                self._platform_to(seg.pose)
                on_segment(i, seg)
            self._control_step(now)
            samples.setdefault(i, []).append((now - run.t0 - seg.start,) + tuple(self.angles))
            if self.screen.due():
                self.show_running(self._progress(run, i, seg, label))
            self.robot.check_stop()
            time.sleep(self.s["LOOP_SLEEP_SEC"])
        self._platform_to(LEVEL)
        return samples

    @staticmethod
    def _progress(run, i, seg, label):
        """화면 상태 줄. 예: "균형 테스트 3/8 · 시험대 roll -10", "비교 ON 2/8 · 시험대 평평"."""
        if seg.phase in ("lead", "gap"):
            return f"{label} 준비 · 시험대 평평"
        same = [s for s in run.segments if s.phase == seg.phase]
        done = sum(1 for s in run.segments[:i + 1] if s.phase == seg.phase)
        phase = f" {seg.phase.upper()}" if seg.phase in ("off", "on") and run.name == "compare" else ""
        pose = "평평" if seg.label == "level" else seg.label
        return f"{label}{phase} {done}/{len(same)} · 시험대 {pose}"

    def _check_line(self, seg, rows, hold, results):
        """시험대 방향 확인 한 자세: 끝 IMU 평균을 콘솔 한 줄로, results에 저장."""
        stats = self._segment_stats(rows or [], hold)
        if stats is None:
            return
        end = stats[2]
        axis = next(a for a, v in zip(AXES, seg.pose) if v != 0)
        i = AXES.index(axis)
        sign = 1 if seg.pose[i] > 0 else -1
        results[(axis, sign)] = end
        L.more(f"{seg.label:<12}  {L.signed(end[0], 9)}  {L.signed(end[1])}  {L.signed(end[2])}  "
               f"{L.signed(end[i] - seg.pose[i])}")

    def _body_check(self, deg):
        """시험대를 평평하게 둔 채 몸체를 roll · pitch · yaw ±deg로 기울여 IMU를 읽습니다."""
        s = self.s
        level_feet, _ = self.pose_feet()
        results = {}
        for axis in AXES:
            for sign in (1, -1):
                target = {a: 0.0 for a in AXES}
                target[axis] = sign * deg
                feet, problem = self.pose_feet(**target)
                label = f"{axis} {sign * deg:+g}"
                if problem:
                    L.more(f"{label:<12}  skipped: {problem[1]}")
                    continue
                self.command = tuple(target[a] for a in AXES)
                self.show_running(f"방향 확인 · 몸체 {label}")
                self.motion.move_to([list(p) for p in feet], s["CHECK_MOVE_STEPS"])
                self.robot.sync_from_motion()
                self.robot.wait(self.prog["CHECK_HOLD_SEC"] / 2)
                measured = self.read_imu_average()
                results[(axis, sign)] = measured
                diff = measured[AXES.index(axis)] - target[axis]
                L.more(f"{label:<12}  {L.signed(measured[0], 9)}  {L.signed(measured[1])}  "
                       f"{L.signed(measured[2])}  {L.signed(diff)}")
                self.angles = measured
                self.show_running(f"방향 확인 · 몸체 {label}")
                self.command = (0.0, 0.0, 0.0)
                self.motion.move_to([list(p) for p in level_feet], s["CHECK_MOVE_STEPS"])
                self.robot.sync_from_motion()
                self.robot.wait(self.prog["CHECK_HOLD_SEC"] / 4)
        self.command = None
        self.robot.stand()
        self.filter.reset()
        return results

    @staticmethod
    def judge(axis, results, deg):
        """한 축의 + · - 결과: "OK" · "REVERSED" · "OTHER" · "NONE" · "UNCLEAR" · "SKIP"와 값 글자."""
        i = AXES.index(axis)
        got = [(sign, results[(axis, sign)]) for sign in (1, -1) if (axis, sign) in results]
        if not got:
            return "SKIP", ""
        own = [sign * m[i] for sign, m in got]                     # 명령과 같은 쪽이면 +
        other = [max(abs(m[j]) for j in range(3) if j != i) for _, m in got]
        half = deg / 2
        values = " / ".join(L.signed(m[i], 0) for _, m in got)
        if all(abs(m[i]) < half for _, m in got) and all(o >= half for o in other):
            return "OTHER", values
        if all(v >= half for v in own):
            return "OK", values
        if all(v <= -half for v in own):
            return "REVERSED", values
        if all(abs(m[i]) < half for _, m in got):
            return "NONE", values
        return "UNCLEAR", values

    def _check_result(self, platform_results, body_results, deg):
        """시험대 · 몸체 결과를 합쳐 축마다 무엇을 고칠지 콘솔에 정리합니다."""
        L.event("METRIC", "direction check result  (platform servo / robot IMU)")
        all_ok = True
        for axis in AXES:
            platform, pv = self.judge(axis, platform_results, deg)
            body, bv = self.judge(axis, body_results, deg)
            sign_name = SIGN_NAMES[axis]
            servo_name = SERVO_SIGN_NAMES[axis]
            fix = []
            if body == "OK" and platform == "OK":
                text = "OK"
            elif body == "OTHER":
                text, fix = "robot IMU axes swapped", ["SWAP_ROLL_PITCH = True (this file)"]
            elif body == "NONE":
                text, fix = "robot IMU did not change", [f"check IMU port 1, then {self._console_key('STAND_KEY')} reset"]
            elif platform == "NONE":
                text, fix = "platform did not move", ["platform script running? (README 11.1)"]
            elif platform == "OTHER":
                text, fix = "platform moved another axis", ["check platform servo ports (README 8.1)"]
            elif body == "OK" and platform == "REVERSED":
                text, fix = "platform servo reversed", [f"platform start file {servo_name} = -1"]
            elif body == "REVERSED" and platform == "REVERSED":
                text, fix = "robot IMU reversed", [f"{sign_name} = -1 (this file)"]
            elif body == "REVERSED" and platform == "OK":
                text, fix = "robot IMU and platform servo reversed", [f"{sign_name} = -1 (this file)",
                                                                   f"platform start file {servo_name} = -1"]
            elif "SKIP" in (body, platform):
                text = "not checked (pose unreachable)"
            else:
                text = f"unclear: run {self._console_key('CHECK_KEY')} again"
            if text != "OK":
                all_ok = False
            L.more(f"{axis:<6}{text}")
            for line in fix:
                L.more(f"      -> {line}")
            L.more(f"      platform {pv or '-'}   body {bv or '-'}")
        if all_ok:
            self._next(f"press {self._console_key('TEST_KEY')} (balance test)",
                       f"다음: {self._key('TEST_KEY')} 균형 테스트")
        else:
            self._next("fix the values above, run again, then press "
                       f"{self._console_key('CHECK_KEY')}", f"방향을 고친 뒤 다시 {self._key('CHECK_KEY')}")

    # ------------------------------------------------------------
    # 2  균형 테스트 · 3  비교 테스트
    # ------------------------------------------------------------
    def balance_test(self):
        """균형 ON. 시험대가 TEST_POSES대로 기우는 동안 자세마다 몸체 기울기를 잽니다."""
        if not self._need_imu():
            return
        self._end_sway()
        t0 = self._start_time()
        self.running = "test"
        n = len(self.prog["TEST_POSES"])
        hold_sec = self.prog["TEST_HOLD_SEC"]
        g = self.gains
        self._popup(f"2 균형 테스트 · 약 {round(1 + n * hold_sec)}초", [
            f"균형 ON · 시험대 {n}자세를 {hold_sec:g}초씩",
            "자세마다 최대 · 끝 · 수평이 된 시각",
            "왜: PID를 바꾼 뒤 같은 조건에서 비교",
            (f"지금 KP {g['KP']:g} · KI {g['KI']:g} · KD {g['KD']:g}", "platform"),
            ("결과: 콘솔 표 · balance test n/8 OK", "hint"),
            ("값을 바꾸고 다시 2 → 표를 나란히", "text"),
        ], ("STOP_KEY", "멈춤"), ("STAND_KEY", "처음으로"))
        run = ScenarioRun("test", scenario("test", self.prog), t0)
        if not self.balance_on:
            self.set_balance(True)
        hold = self.prog["TEST_HOLD_SEC"]
        L.event("TASK", f"balance test: {len(self.prog['TEST_POSES'])} platform poses, "
                        f"{hold:g} s each")
        L.event("METRIC", f"{'#':>2} {'platform':<14} {'max':>5} {'end':>5} {'settle':>7}  result")
        segs = run.segments
        results = []
        store = {}

        def report(i):
            seg = segs[i]
            if seg.phase != "on":
                return
            stats = self._segment_stats(store.get(i, []), hold)
            if stats is None:
                return
            results.append((seg, stats))
            self._result_line(len(results), seg, stats)

        def on_segment(i, seg):
            if i > 0:
                report(i - 1)

        self._run_collect(run, on_segment, "균형 테스트", store)
        report(len(segs) - 2)
        self.running = None
        self._test_summary(results)
        self._next(f"press {self._console_key('COMPARE_KEY')} (compare), or change PID and press "
                   f"{self._console_key('TEST_KEY')}",
                   f"다음: {self._key('COMPARE_KEY')} 비교 · PID 바꾸고 {self._key('TEST_KEY')}")

    def _result_line(self, n, seg, stats):
        mx, end, _, settle = stats
        ok = "OK" if end <= self.s["LEVEL_OK_DEG"] else "TILTED"
        st = "-" if settle is None else f"{settle:.1f} s"
        L.more(f"{n:>2} {seg.label:<14} {mx:5.1f} {end:5.1f} {st:>7}  {ok}")

    def _test_summary(self, results):
        if not results:
            return
        n_ok = sum(1 for _, st in results if st[1] <= self.s["LEVEL_OK_DEG"])
        worst = max(st[0] for _, st in results)
        mean_end = sum(st[1] for _, st in results) / len(results)
        settles = [st[3] for _, st in results if st[3] is not None]
        L.event("METRIC", f"balance test {n_ok}/{len(results)} OK  "
                          f"(end tilt <= {self.s['LEVEL_OK_DEG']:g} deg)")
        L.more(f"worst max {worst:.1f} deg   mean end {mean_end:.1f} deg")
        if settles:
            L.more(f"mean settle {sum(settles) / len(settles):.1f} s  "
                   f"(tilt <= {self.s['SETTLE_DEG']:g} deg)")
        L.more(self._gain_text())

    def compare_test(self):
        """같은 시험대 움직임을 균형 OFF → ON으로 두 번. 자세마다 끝 기울기를 비교합니다."""
        if not self._need_imu():
            return
        self._end_sway()
        t0 = self._start_time()
        self.running = "compare"
        n = len(self.prog["TEST_POSES"])
        hold_sec = self.prog["TEST_HOLD_SEC"]
        self._popup(f"3 비교 · 약 {round(1 + 2 * n * hold_sec + 2)}초", [
            "같은 시험대 움직임을 두 번",
            "먼저 균형 OFF → 다음 균형 ON",
            "OFF: 몸체가 시험대와 같이 기욺",
            "ON: PID가 몸체를 수평으로 되돌림",
            "왜: 균형 제어가 지운 기울기를 숫자로",
            ("결과: 콘솔 mean OFF → ON", "hint"),
        ], ("STOP_KEY", "멈춤"), ("STAND_KEY", "처음으로"))
        run = ScenarioRun("compare", scenario("compare", self.prog), t0)
        if self.balance_on:
            self.set_balance(False)
        hold = self.prog["TEST_HOLD_SEC"]
        L.event("TASK", "compare: same platform poses, balance OFF then ON")
        segs = run.segments
        ends = {"off": [], "on": []}
        store = {}

        def report(i):
            seg = segs[i]
            if seg.phase not in ends:
                return
            stats = self._segment_stats(store.get(i, []), hold)
            if stats is not None:
                ends[seg.phase].append((seg, stats))

        def on_segment(i, seg):
            if i > 0:
                report(i - 1)
            if seg.phase in ("lead", "off") and self.balance_on:
                self.set_balance(False)
            elif seg.phase in ("gap", "on") and not self.balance_on:
                L.event("TASK", "compare: balance ON pass")
                self.set_balance(True)

        self._run_collect(run, on_segment, "비교", store)
        report(len(segs) - 2)
        self.running = None
        L.event("METRIC", "compare: body tilt at the end of each pose (deg)")
        L.more(f"{'platform':<14} {'OFF':>6} {'ON':>6}  less tilt")
        off_sum = on_sum = 0.0
        for (seg, off), (_, on) in zip(ends["off"], ends["on"]):
            off_sum += off[1]
            on_sum += on[1]
            less = f"{(1 - on[1] / off[1]) * 100:5.0f}%" if off[1] >= 1.0 else "    -"
            L.more(f"{seg.label:<14} {off[1]:6.1f} {on[1]:6.1f}  {less}")
        count = len(ends["on"])
        if count:
            L.more(f"mean OFF {off_sum / count:.1f} deg -> ON {on_sum / count:.1f} deg")
        L.more(self._gain_text())
        self._next(f"change PID ({self._gain_key_text()}) and press {self._console_key('TEST_KEY')}",
                   f"다음: PID 바꾸고 {self._key('TEST_KEY')}")

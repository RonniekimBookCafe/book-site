# -*- coding: utf-8 -*-
"""
q01lib_platform.py  |  QUAD-01 교육용 라이브러리 · 기울기 시험대의 Port와 서보 (시험대 Microcontroller)

Book-QUAD-01-BALANCE에는 Microcontroller가 두 개 있습니다. 이 파일은 그 가운데 시험대의
3axis-Microcontroller에 달린 부품만 다룹니다. 로봇의 Port(core/q01lib_ports.py)와는 따로
번호가 매겨집니다.

    시험대 3axis-Microcontroller의 Port
    Port 0 · 1   Roll Servo Motor 1 · 2      시험대를 좌우로 기울임 (두 서보는 서로 반대 방향)
    Port 2 · 3   Pitch Servo Motor 1 · 2     시험대를 앞뒤로 기울임 (두 서보는 서로 반대 방향)
    Port 4       Yaw Servo Motor 1           시험대를 위에서 볼 때 돌림
    Port 5       3axis-Inertial Sensor 1     시험대 IMU (시험대가 실제로 기운 각도 확인)
    Port 6       3axis-Text Screen 1         시험대 화면 (명령 · IMU · 모드)
    Port 7       (있을 때만) 키 안내 화면

[각도와 부호]  로봇과 같은 몸체 좌표계(Spot)로 씁니다.
    roll  +  시험대의 오른쪽이 내려감  pitch +  시험대의 앞쪽이 내려감  yaw +  위에서 볼 때 왼쪽(반시계)으로 돎
서보에 보내는 각도 = 부호(ROLL_SERVO_SIGN 등) × 시험대 각도입니다. 기본 부호는 Book-QUAD-01-BALANCE
시험대의 서보 방향에 맞춘 값입니다.
    roll   서보 1 = +roll · 서보 2 = -roll          (ROLL_SERVO_SIGN = 1)
    pitch  서보 1 = -pitch · 서보 2 = +pitch        (PITCH_SERVO_SIGN = 1)
    yaw    서보 = -yaw (서보의 + 각도는 오른쪽 회전)  (YAW_SERVO_SIGN = -1)
부호가 실제 시험대의 방향과 맞는지는 로봇의 1 방향 확인이 로봇 IMU로 판정합니다(README 11.3).

사용하는 RoboCo 공식 API
- ServoMotor(port): Reference는 여기서 한 번만 만들고 계속 씀
- ServoMotor.spin_to_degrees(angle): 서보를 그 각도(도)로 돌림
- ServoMotor.max_rpm: 서보 회전 속도. 시작할 때 부품 설정 값을 읽어 기준 속도로 두고(SERVO_RPM이 None일 때),
  기준 × SPEED_RATIO를 한 번 넣음. 모든 시험대 움직임이 같은 속도 (q01lib_platform_app.py)
"""

from controllables import ServoMotor

PLATFORM_ROLL_SERVO_PORTS = (0, 1)
PLATFORM_PITCH_SERVO_PORTS = (2, 3)
PLATFORM_YAW_SERVO_PORT = 4
PLATFORM_IMU_PORT = 5
PLATFORM_SCREEN_PORT = 6
PLATFORM_GUIDE_SCREEN_PORT = 7

AXES = ("roll", "pitch", "yaw")
SERVO_RPM_MAX = 1000         # ServoMotor.max_rpm의 최대


class PlatformAxes:
    """시험대의 서보 5개를 roll · pitch · yaw 세 각도로 움직이는 클래스."""

    def __init__(self, limit_deg, roll_sign=1, pitch_sign=1, yaw_sign=-1, servo_rpm=None):
        """
        :param limit_deg: 시험대 각도의 한계(도). 명령은 ±limit_deg 안으로 제한
        :param roll_sign, pitch_sign, yaw_sign: 시험대 각도 → 서보 각도 부호 (1 또는 -1)
        :param servo_rpm: 기준 서보 속도(rpm). None이면 부품 설정 값을 읽어 기준으로 씀
        """
        self.limit = limit_deg
        self.signs = {"roll": roll_sign, "pitch": pitch_sign, "yaw": yaw_sign}
        self.roll_servos = tuple(ServoMotor(port) for port in PLATFORM_ROLL_SERVO_PORTS)
        self.pitch_servos = tuple(ServoMotor(port) for port in PLATFORM_PITCH_SERVO_PORTS)
        self.yaw_servo = ServoMotor(PLATFORM_YAW_SERVO_PORT)
        self.servos = self.roll_servos + self.pitch_servos + (self.yaw_servo,)
        self.read_error = None
        if servo_rpm is not None:
            self.base_rpm = [float(servo_rpm)] * len(self.servos)
        else:
            try:
                self.base_rpm = [float(servo.max_rpm) for servo in self.servos]
            except Exception as e:          # 읽을 수 없으면 속도를 바꾸지 않음 (부품 설정 그대로)
                self.base_rpm = None
                self.read_error = e
        self.rpm = None                     # 지금 서보에 넣은 속도 (서보 5개), 넣은 적 없으면 None
        self.angles = {"roll": 0.0, "pitch": 0.0, "yaw": 0.0}

    def speeds(self, ratio=1.0):
        """서보 5개의 속도(rpm) = 기준 속도 × ratio (최대 1000). 기준을 모르면 None."""
        if self.base_rpm is None:
            return None
        return [min(SERVO_RPM_MAX, r * ratio) for r in self.base_rpm]

    def set_speed(self, rpms):
        """서보 5개의 속도를 바꿉니다 (지금과 같으면 그대로). rpms가 None이면 바꾸지 않음."""
        if rpms is None or rpms == self.rpm:
            return
        for servo, rpm in zip(self.servos, rpms):
            servo.max_rpm = rpm
        self.rpm = list(rpms)

    def clamp(self, angle):
        return max(-self.limit, min(self.limit, angle))

    def set(self, roll, pitch, yaw):
        """시험대를 (roll, pitch, yaw)도로 기울입니다. 한계 안으로 제한한 각도를 돌려줍니다."""
        roll, pitch, yaw = self.clamp(roll), self.clamp(pitch), self.clamp(yaw)
        a = self.signs["roll"] * roll
        self.roll_servos[0].spin_to_degrees(a)
        self.roll_servos[1].spin_to_degrees(-a)
        a = self.signs["pitch"] * pitch
        self.pitch_servos[0].spin_to_degrees(-a)
        self.pitch_servos[1].spin_to_degrees(a)
        self.yaw_servo.spin_to_degrees(self.signs["yaw"] * yaw)
        self.angles = {"roll": roll, "pitch": pitch, "yaw": yaw}
        return roll, pitch, yaw

# -*- coding: utf-8 -*-
"""
q01lib_platform_program.py  |  QUAD-01 교육용 라이브러리 · 시험대를 움직이는 순서 (로봇 · 시험대가 함께 씀)

Book-QUAD-01-BALANCE의 시험대는 로봇이 균형을 잡는지 보기 위한 보조 장치입니다. 시험대를 언제
얼마나 기울일지는 이 파일 하나가 정하고, 두 Microcontroller의 스크립트가 함께 씁니다.

    로봇 스크립트 (q01_balance_test_start.py)            시험대 스크립트 (q01_balance_test_platform_start.py)
      키 → 이 파일로 시험대 각도를 정함                     시험대 각도를 받아 서보 5개로 기울임
      → 시험대 Microcontroller에 메시지로 보냄 ──(연결)──→  (메시지가 오면 메시지만 따름)
      → 같은 각도를 콘솔 · 화면 · 판정에 씀                 (메시지가 없으면 같은 키를 직접 읽어
                                                          이 파일로 같은 각도를 정함)

두 스크립트가 같은 규칙으로 같은 키를 읽으면, 메시지를 주고받지 않아도 시험대 각도가 같아집니다.
메시지로 연결하는 방법은 README 11.1에 있습니다.

[시험대 키]  로봇 시작 파일의 PLATFORM_KEYS (왼손)
    W · S   pitch + · -   앞쪽이 내려감 · 앞쪽이 올라감
    A · D   roll  - · +   왼쪽이 내려감 · 오른쪽이 내려감
    Q · E   yaw   + · -   왼쪽(반시계)으로 돎 · 오른쪽으로 돎
    5       시험대 평평하게
    6 · 7   시험대 속도 - · + (PLATFORM_SPEED_STEP씩, PLATFORM_SPEED_MIN ~ PLATFORM_SPEED_MAX)
    8       연속 흔들기 켜기 · 끄기 (TEST_POSES를 SWAY_HOLD_SEC씩 계속 되풀이)

[시험대 속도]  시험대 서보 속도 = 시험대 서보 부품 설정 속도 × PLATFORM_SPEED (1.0이면 부품 설정 속도)
    시험대 키 · 5 · F2 · 1 · 2 · 3 · 8의 시험대 움직임이 모두 이 한 속도입니다. 시험대 스크립트가 부품 속도를 읽어 곱함

[테스트 순서]  키를 누른 때부터 시간으로 정함 (scenario)
    1 방향 확인   roll +CHECK · roll -CHECK · pitch + · pitch - · yaw + · yaw -  (자세마다 CHECK_HOLD_SEC)
                 → 평평. 그 뒤 로봇이 시험대를 평평하게 둔 채 몸체를 기울임
    2 균형 테스트 평평 LEAD_SEC → TEST_POSES를 TEST_HOLD_SEC씩 → 평평
    3 비교 테스트 평평 LEAD_SEC → TEST_POSES (균형 OFF) → 평평 GAP_SEC → TEST_POSES (균형 ON) → 평평
    8 연속 흔들기 TEST_POSES를 SWAY_HOLD_SEC씩 끝없이 되풀이 (8 · F3 · F2 · 5 · 시험대 키 · 1 2 3으로 멈춤)
                 테스트와 달리 다른 키를 모두 읽으므로, 흔들리는 동안 PID 값을 바꾸며 차이를 봄

[좌표와 부호]  로봇과 같은 Spot 몸체 좌표계. 회전의 + 방향은 오른손 법칙
    roll  +  x(앞)축 둘레: 시험대의 오른쪽이 내려감
    pitch +  y(왼쪽)축 둘레: 시험대의 앞쪽이 내려감
    yaw   +  z(위)축 둘레: 위에서 볼 때 왼쪽(반시계)으로 돎

이 파일은 RoboCo API를 쓰지 않습니다.
"""

AXES = ("roll", "pitch", "yaw")
LEVEL = (0.0, 0.0, 0.0)

LEAD_SEC = 1.0               # 테스트를 시작하기 전 시험대를 평평하게 두는 시간(초). 로봇이 균형 모드를 켜고 자리 잡음
GAP_SEC = 2.0                # 비교 테스트에서 균형 OFF와 ON 사이에 시험대를 평평하게 두는 시간(초)

# 로봇 시작 파일에서 바꿀 수 있는 값의 기본값. 시험대 스크립트는 메시지 연결이 없을 때 이 값을 씀
DEFAULTS = {
    "PLATFORM_STEP_DEG": 15,
    "PLATFORM_LIMIT_DEG": 15,
    "CHECK_DEG": 15,
    "CHECK_HOLD_SEC": 2.0,
    "TEST_POSES": [(15, 0, 0), (0, 0, 0), (-15, 0, 0), (0, 0, 0),
                   (0, 15, 0), (0, 0, 0), (0, -15, 0), (0, 0, 0)],
    "TEST_HOLD_SEC": 3.0,
    "SWAY_HOLD_SEC": 2.0,
    "PLATFORM_KEYS": {"w": ("pitch", 1), "s": ("pitch", -1), "a": ("roll", -1),
                   "d": ("roll", 1), "q": ("yaw", 1), "e": ("yaw", -1)},
    "CHECK_KEY": "1",
    "TEST_KEY": "2",
    "COMPARE_KEY": "3",
    "LEVEL_KEY": "5",
    "SWAY_KEY": "8",
    "PLATFORM_SPEED": 2.0,
    "PLATFORM_SPEED_STEP": 0.2,
    "PLATFORM_SLOWER_KEY": "6",
    "PLATFORM_FASTER_KEY": "7",
    "STAND_KEY": "f2",
    "STOP_KEY": "f3",
}

PLATFORM_SPEED_MIN = 0.4     # 시험대 속도 배수의 한계 (부품 설정 속도의 0.4배 ~ 4배)
PLATFORM_SPEED_MAX = 4.0

# 키 방향 → 콘솔 이름 (영어) · 화면 이름 (한국어)
DIRECTION_EN = {
    ("roll", 1): "right down", ("roll", -1): "left down",
    ("pitch", 1): "front down", ("pitch", -1): "front up",
    ("yaw", 1): "turn left", ("yaw", -1): "turn right",
}
DIRECTION_KO = {
    ("roll", 1): "오른쪽이 내려감", ("roll", -1): "왼쪽이 내려감",
    ("pitch", 1): "앞쪽이 내려감", ("pitch", -1): "앞쪽이 올라감",
    ("yaw", 1): "왼쪽으로 돎", ("yaw", -1): "오른쪽으로 돎",
}


def settings_from(values):
    """DEFAULTS에 values(시작 파일의 값)를 덮어쓴 dict."""
    s = dict(DEFAULTS)
    for name in DEFAULTS:
        if name in values:
            s[name] = values[name]
    return s


def check_platform_keys(platform_keys):
    """PLATFORM_KEYS 확인: 키 → (축, 방향 1 · -1)."""
    for key, item in platform_keys.items():
        if not (isinstance(item, (tuple, list)) and len(item) == 2
                and item[0] in AXES and item[1] in (1, -1)):
            raise ValueError(f"PLATFORM_KEYS '{key}': use (\"roll\" | \"pitch\" | \"yaw\", 1 | -1)")


def changed_from_defaults(s):
    """기본값과 다른 값 이름 목록 (메시지 연결이 없을 때 시험대는 기본값을 쓰므로 알림에 씀)."""
    return [name for name in DEFAULTS if s.get(name) != DEFAULTS[name]]


def pose_text(pose):
    """(roll, pitch, yaw) → "roll +10" · "level" · "roll +10 pitch -5" (콘솔용 영어)."""
    parts = [f"{axis} {round(v):+d}" for axis, v in zip(AXES, pose) if round(v) != 0]
    return " ".join(parts) if parts else "level"


class PlatformPose:
    """시험대의 지금 각도 (roll, pitch, yaw). 키 한 번에 PLATFORM_STEP_DEG도씩, ±PLATFORM_LIMIT_DEG 안으로."""

    def __init__(self, step_deg, limit_deg):
        self.step = step_deg
        self.limit = limit_deg
        self.pose = LEVEL

    def clamp(self, value):
        return max(-self.limit, min(self.limit, value))

    def set(self, pose):
        """시험대 각도를 정합니다 (한계 안으로). 바뀌었으면 True."""
        new = tuple(float(self.clamp(v)) for v in pose)
        changed = new != self.pose
        self.pose = new
        return changed

    def step_axis(self, axis, direction):
        """한 축을 한 걸음. 한계에 닿아 바뀌지 않으면 False."""
        pose = list(self.pose)
        i = AXES.index(axis)
        pose[i] = self.clamp(pose[i] + direction * self.step)
        return self.set(pose)


class PlatformSpeed:
    """시험대 속도 배수 (부품 설정 속도 × value). 키 한 번에 step씩, PLATFORM_SPEED_MIN ~ PLATFORM_SPEED_MAX."""

    def __init__(self, value, step):
        self.step = step
        self.value = self.clamp(value)

    @staticmethod
    def clamp(value):
        return round(max(PLATFORM_SPEED_MIN, min(PLATFORM_SPEED_MAX, float(value))), 2)

    def set(self, value):
        """속도 배수를 정합니다 (한계 안으로). 바뀌었으면 True."""
        new = self.clamp(value)
        changed = new != self.value
        self.value = new
        return changed

    def change(self, sign):
        """한 걸음 느리게(-1) · 빠르게(+1). 한계에 닿아 바뀌지 않으면 False."""
        return self.set(self.value + sign * self.step)


def speed_text(value):
    """속도 배수 → "x1.5"."""
    return f"x{value:.1f}" if abs(value * 10 - round(value * 10)) < 1e-6 else f"x{value:.2f}"


class Segment:
    """시험대가 한 자세를 유지하는 구간. start · end는 테스트를 시작한 때부터의 초."""

    def __init__(self, start, end, pose, phase):
        self.start = start
        self.end = end
        self.pose = tuple(float(v) for v in pose)
        self.phase = phase           # "check" · "lead" · "off" · "gap" · "on" · "end"
        self.label = pose_text(self.pose)


def scenario(name, s):
    """테스트 이름("check" · "test" · "compare" · "sway")의 구간 목록. 마지막 구간은 평평(end).
    "sway"는 TEST_POSES를 SWAY_HOLD_SEC씩 한 바퀴. ScenarioRun(loop=True)이 끝없이 되풀이함."""
    segments = []
    t = 0.0

    def add(pose, hold, phase):
        nonlocal t
        segments.append(Segment(t, t + hold, pose, phase))
        t += hold

    if name == "check":
        deg = s["CHECK_DEG"]
        for i, axis in enumerate(AXES):
            for sign in (1, -1):
                pose = [0.0, 0.0, 0.0]
                pose[i] = sign * deg
                add(pose, s["CHECK_HOLD_SEC"], "check")
    elif name == "test":
        add(LEVEL, LEAD_SEC, "lead")
        for pose in s["TEST_POSES"]:
            add(pose, s["TEST_HOLD_SEC"], "on")
    elif name == "sway":
        for pose in s["TEST_POSES"]:
            add(pose, s["SWAY_HOLD_SEC"], "sway")
    elif name == "compare":
        add(LEVEL, LEAD_SEC, "lead")
        for pose in s["TEST_POSES"]:
            add(pose, s["TEST_HOLD_SEC"], "off")
        add(LEVEL, GAP_SEC, "gap")
        for pose in s["TEST_POSES"]:
            add(pose, s["TEST_HOLD_SEC"], "on")
    else:
        raise ValueError(f"unknown scenario {name}")
    segments.append(Segment(t, t, LEVEL, "end"))
    return segments


class ScenarioRun:
    """시작 시각 t0부터 진행하는 테스트. at(now)는 (구간 번호, 구간), 끝났으면 (None, None).
    loop=True이면 끝나지 않고 처음 구간부터 되풀이합니다(연속 흔들기). 구간 번호는 바퀴마다 이어서 셈."""

    def __init__(self, name, segments, t0, loop=False):
        self.name = name
        self.segments = segments
        self.t0 = t0
        self.loop = loop
        self.period = segments[-1].start
        self.end_time = t0 + self.period

    def at(self, now):
        t = now - self.t0
        if self.loop and self.period > 0:
            lap, t = divmod(max(0.0, t), self.period)
            for i, seg in enumerate(self.segments[:-1]):
                if t < seg.end:
                    return int(lap) * (len(self.segments) - 1) + i, seg
            return int(lap + 1) * (len(self.segments) - 1), self.segments[0]
        for i, seg in enumerate(self.segments[:-1]):
            if t < seg.end:
                return i, seg
        return None, None

    def done(self, now):
        return not self.loop and now >= self.end_time

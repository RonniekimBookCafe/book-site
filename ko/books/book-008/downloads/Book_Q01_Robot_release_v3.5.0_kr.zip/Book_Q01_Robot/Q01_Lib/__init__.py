# -*- coding: utf-8 -*-
"""
Q01_Lib  |  QUAD-01 교육용 라이브러리

실습마다 쓰는 파일을 하위 폴더로 나누었습니다. 모든 실습이 core 폴더를
함께 쓰고, 나머지 폴더는 해당 실습의 시작 파일에서만 씁니다.

    core           로봇 기본: Port 대응표 · 서보 · 역기구학(IK) · 발끝 좌표 → 관절 · IMU · 키 · LOG · 화면
    walk           키보드 보행 (W·S·A·D·Q·E · X·Z)            → q01_walk_start.py
    auto           자동 테스트 (1·2·3)                         → q01_walk_start.py
    leg1_joint     다리 테스트 1 · 관절 테스트                 → q01_leg1_joint_start.py
    leg2_ik        다리 테스트 2 · IK 테스트                   → q01_leg2_ik_start.py
    leg3_combined  다리 테스트 3 · 복합 테스트                 → q01_leg3_combined_start.py
    body_pose      몸체 자세 테스트 (x y z · roll pitch yaw)   → q01_body_pose_start.py
    balance_test   균형 테스트 (IMU · PID, 기울기 시험대)       → q01_balance_test_start.py
                   시험대의 Microcontroller (시험대 기울이기 · 시험대 IMU)  → q01_balance_test_platform_start.py
    leg_common     다리 테스트 세 가지 · 몸체 자세 · 균형 테스트가 함께 씀 (키 읽기 · 공통 키 · 로봇 · 화면)
    action         인사 · 손 흔들기 · 스트레칭 · 팔굽혀펴기 · 수영 · 물구나무 등 9가지 동작 → q01_action_start.py

이 파일이 있어야 Q01_Lib 폴더를 라이브러리로 불러올 수 있습니다.
코드는 들어 있지 않으며, 바꾸거나 지우지 않습니다.
"""

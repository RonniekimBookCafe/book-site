# -*- coding: utf-8 -*-
"""
q01lib_leg_app.py  |  QUAD-01 교육용 라이브러리 · 다리 테스트 프로그램 (다섯 시작 파일이 함께 씀)

다리 테스트 세 가지 · 몸체 자세 테스트 · 균형 테스트는 시작 파일과 로봇이 따로 있고, 키를 읽어
동작을 실행하는 반복 부분은 이 파일 하나를 함께 씁니다.

    시작 파일                      로봇                            테스트 클래스
    q01_leg1_joint_start.py        Book-QUAD-01-LEG1               leg1_joint/q01lib_leg1_joint.py         JointTest
    q01_leg2_ik_start.py           Book-QUAD-01-LEG2               leg2_ik/q01lib_leg2_ik.py               IKTest
    q01_leg3_combined_start.py     Book-QUAD-01-LEG3               leg3_combined/q01lib_leg3_combined.py   CombinedTest
    q01_body_pose_start.py         Book-QUAD-01-ROLL_PITCH_YAW     body_pose/q01lib_body_pose_test.py      BodyPoseTest
    q01_balance_test_start.py      Book-QUAD-01-BALANCE            balance_test/q01lib_balance_test.py     BalanceTest

시작 파일은 LegTestApp(globals(), 테스트 클래스)로 이 프로그램을 만듭니다.

[다섯 테스트가 같은 키]
    F1  키 안내 (콘솔 · 로봇 화면)
    F2  네 다리 기본 자세. 자동 테스트 중이면 멈춘 뒤 기본 자세
    F3  자동 테스트 멈춤. 다리는 멈춘 자리에 둠
    U · O · J · L   다리 고르기 (관절 · IK 테스트만). 위에서 본 다리 배치와 같은 모양
                        U FL    O FR
                        J HL    L HR

[한 번 반복할 때]
    KeyEvents.pressed()로 눌린 키 목록을 받음 (Input.stream)
      -> 공통 키이면 이 파일에서 실행 (키 안내 · 기본 자세 · 다리 고르기)
      -> 테스트의 키이면 테스트 클래스의 함수를 실행 (actions())
      -> 로봇 화면을 테스트의 대기 화면(idle_page())으로 다시 씀 (화면 모양: q01lib_leg_screen.py)
         몸체 자세 · 균형 테스트는 자기 화면 파일(body_pose/q01lib_body_pose_screen.py ·
         balance_test/q01lib_balance_test_screen.py)에 씀:
         대기 화면 show_idle() · 키 안내 show_help_screen() · 반복마다 on_loop()

[자동 테스트 멈추기]
자동으로 이어지는 테스트(관절 테스트의 숫자 키, IK 테스트의 원 그리기, 복합 테스트의
숫자 키, 몸체 자세 테스트의 1, 균형 테스트의 1 · 2 · 3)가 진행되는 동안 F3을 누르면 그 자리에서
멈추고, F2를 누르면 멈춘 뒤 기본 자세로 옮깁니다(균형 테스트의 F2는 시험대 평평 · 기본 자세 · IMU 영점). 테스트는 기다리는 시간마다(LegTestRobot.wait) 이 두 키만 확인하고,
다른 키는 끝난 뒤에 읽습니다. 멈춘 뒤에는 테스트 중에 쌓인 키를 버립니다.

[멈춘 뒤 다시 시작하기]
F3으로 멈추면 다리는 멈춘 자세 그대로 있습니다. 화면과 콘솔에서 멈춘 자리의 값을 볼 수
있고, 관절 · 발끝을 한 걸음씩 움직이는 키(W · S · A · D · E · Q · K)는 그 자세에서 이어서
움직입니다. 자동 테스트는 기본 자세를 기준으로 짜여 있으므로(시작할 때의 자세로 돌아오며
끝남), 멈춘 뒤 자동 테스트 키를 누르면 먼저 기본 자세로 옮긴 다음 시작합니다. F2를 누르면
그때 바로 기본 자세로 옮깁니다.

[끝내기]
RoboCo에서 스크립트를 멈추면 바로 끝납니다. 종료 키는 따로 두지 않고, 끝낼 때
다리를 다른 자세로 옮기지도 않습니다. 로봇은 거치대에 매달려 있어 넘어지지 않습니다.
"""

import time

from ..core import q01lib_ports as ports
from ..core.q01lib_key_events import KeyEvents, key_label
from ..core.q01lib_log import log_traceback
from ..core.q01lib_welcome import (show_welcome, checked_duration,
                                    DEFAULT_WELCOME_SEC, DEFAULT_START_SCREEN_SEC)
from .q01lib_leg_robot import LegTestRobot, TestStopped
from . import q01lib_leg_screen as scr
from ..core import q01lib_log as L    # 콘솔 LOG 출력 (L.event · L.more · L.key …)

# 모든 시작 파일에 있어야 하는 값과 키 이름
COMMON_NAMES = ("SERVO_RPM", "BODY_HEIGHT", "LOOP_SLEEP_SEC", "HELP_KEY", "STAND_KEY", "STOP_KEY")
# 다리를 고르는 테스트(관절 · IK)의 시작 파일에 더 있어야 하는 이름
LEG_SELECT_NAMES = ("START_LEG", "LEG_SELECT_KEYS")
# 적지 않아도 되는 이름 (적지 않으면 기본값)
OPTIONAL_NAMES = ("LOG_COLOR", "WELCOME_SEC", "START_SCREEN_SEC")
# 다섯 테스트가 함께 콘솔에 쓰는 분류 (테스트마다 LOG_CATEGORIES를 더해 열을 맞춤)
COMMON_LOG_CATEGORIES = ("INPUT", "STATE", "JOINT", "TASK", "WARN", "ERROR")


def check_names(values, names, file_name):
    """값 이름을 확인합니다. 모르는 이름(철자 틀림 등)은 콘솔 알림으로, 빠진 이름은 오류로."""
    unknown = [name for name in values if name not in names and name not in OPTIONAL_NAMES]
    if unknown:
        L.event("WARN", "unknown names in the start file (check spelling)")
        for name in unknown:
            L.more(name)
    missing = [n for n in names if n not in values]
    if missing:
        raise ValueError(f"{file_name}: missing {', '.join(missing)} (check spelling)")


# 이 다섯 로봇 모델에 Welcome을 적용합니다. 별도 시험대 MCU에는 적용하지 않습니다.
WELCOME_MODELS = {
    "q01_leg1_joint_start.py": "Book-QUAD-01-LEG1",
    "q01_leg2_ik_start.py": "Book-QUAD-01-LEG2",
    "q01_leg3_combined_start.py": "Book-QUAD-01-LEG3",
    "q01_body_pose_start.py": "Book-QUAD-01-ROLL_PITCH_YAW",
    "q01_balance_test_start.py": "Book-QUAD-01-BALANCE",
}


class LegTestApp:
    """다리 테스트 프로그램의 메인 루프. test_class는 JointTest · IKTest · CombinedTest · BodyPoseTest · BalanceTest 가운데 하나."""

    def __init__(self, script_values: dict, test_class):
        """script_values: 시작 파일의 globals(), test_class: 테스트 클래스.
        준비하다 오류가 나면(시작 파일의 값 · 키 배정 · Port) 콘솔에 영어로 알리고, run()은 바로 끝납니다.
        """
        self.ready = False
        try:
            self._setup(script_values, test_class)
            self.ready = True
        except Exception as e:
            L.setup_failed(e, test_class.START_FILE)

    def _setup(self, script_values: dict, test_class):
        values = {name: value for name, value in script_values.items() if name.isupper()}
        L.configure(COMMON_LOG_CATEGORIES + test_class.LOG_CATEGORIES, values.get("LOG_COLOR"))
        names = COMMON_NAMES + (LEG_SELECT_NAMES if test_class.USES_LEG_SELECT else ()) + test_class.VALUE_NAMES
        check_names(values, names, test_class.START_FILE)
        self.s = values
        self.robot = LegTestRobot(values)
        model_name = WELCOME_MODELS.get(test_class.START_FILE)
        if model_name:
            show_welcome(self.robot.screen, model_name,
                         values.get("WELCOME_SEC", DEFAULT_WELCOME_SEC))
        if not getattr(test_class, "SHOWS_START", False):
            # 시작 화면: 부품 기본 글자("T") 대신 준비 중임을 보여 줌 (균형 테스트는 자기 화면 파일에서)
            self.robot.show_page(f"{test_class.TITLE} · 시작",
                                 [scr.paint("준비하는 중입니다", "hint"), "기본 자세로 옮깁니다"],
                                 scr.paint("잠시 기다립니다", "hint"))
        self.test = test_class(self.robot, values)
        # 첫 안내 페이지는 IK/복합 테스트의 메인 페이지에 곧바로 덮이지 않게 유지.
        # BALANCE는 자기 화면(start_text)을 생성하므로 동일한 지연만 적용합니다.
        # 시간은 테스트 수학/모터 속도가 아니라 화면 전환에만 영향을 줍니다.
        if model_name:
            intro_sec = checked_duration(values.get("START_SCREEN_SEC", DEFAULT_START_SCREEN_SEC),
                                         "START_SCREEN_SEC")
            if intro_sec:
                time.sleep(intro_sec)

        if len({values["HELP_KEY"], values["STAND_KEY"], values["STOP_KEY"]}) < 3:
            raise ValueError("HELP_KEY, STAND_KEY and STOP_KEY share a key: "
                             "give each key one action")

        # 키 → (설명, 실행할 함수, 걸린 시간을 남길지). 테스트가 COMMON_DESC로 F2 · F3 이름을 바꿀 수 있음
        desc = getattr(test_class, "COMMON_DESC", {})
        common = {values["HELP_KEY"]: ("help", self.show_help, False),
                  values["STAND_KEY"]: (desc.get("STAND_KEY", "stand pose"), self.stand, False),
                  values["STOP_KEY"]: (desc.get("STOP_KEY", "stop test"), self.stop_idle, False)}
        leg_select = {}
        if test_class.USES_LEG_SELECT:
            leg_select = {key: (f"select leg {name}", lambda name=name: self.select_leg(name), False)
                          for key, name in values["LEG_SELECT_KEYS"].items()}
            for name in values["LEG_SELECT_KEYS"].values():
                if name not in ports.LEG_NAMES:
                    raise ValueError(f"LEG_SELECT_KEYS '{name}': use one of FL, HL, HR, FR")
        test_keys = [(key, (desc, func, timed)) for key, desc, func, timed in self.test.actions()]

        # 키 하나에 동작 하나: 같은 키를 두 번 배정했으면 시작할 때 알려 줌
        self.table = {}
        entries = ([(k, v, "common keys") for k, v in common.items()] +
                   [(k, v, "LEG_SELECT_KEYS") for k, v in leg_select.items()] +
                   [(k, v, "test keys") for k, v in test_keys])
        owner = {}
        for key, item, group in entries:
            if key in self.table:
                raise ValueError(f"key {key_label(key)} is used twice: {owner[key]} ({self.table[key][0]}) "
                                 f"and {group} ({item[0]}). Give each key one action")
            self.table[key] = item
            owner[key] = group

        # 읽는 순서: 테스트의 키 → 다리 고르기 → F1 · F2 · F3
        all_keys = [k for k, _ in test_keys] + list(leg_select) + list(common)
        self.keys = KeyEvents(all_keys, self.test.repeat_keys(), values.get("KEY_REPEAT_SEC", 0))

        self._help_on_screen = False
        self.stop_keys = [values["STOP_KEY"], values["STAND_KEY"]]
        self.robot.stop_check = self._stop_pressed
        stand_ko = getattr(test_class, "STAND_KO", "기본 자세")
        self.robot.running_footer = scr.keys_line([(key_label(values["STOP_KEY"]), "멈춤"),
                                                   (key_label(values["STAND_KEY"]), stand_ko)], " · ")

        self.print_guide()
        self.robot.check_servo_spec()
        self.test.enter()
        self.keys.clear()
        self.show_idle()

    # ------------------------------------------------------------
    # 콘솔 · 화면 안내
    # ------------------------------------------------------------
    def print_guide(self):
        """콘솔 시작 안내 · F1 키 안내 (영어, core/q01lib_log.py의 형식)."""
        s = self.s
        test = self.test
        if hasattr(test, "common_guide"):
            lines = [test.common_guide()]
        else:
            lines = [f" {L.key(key_label(s['HELP_KEY']))} help   {L.key(key_label(s['STAND_KEY']))} stand   "
                     f"{L.key(key_label(s['STOP_KEY']))} stop test   quit: stop the script"]
        if test.USES_LEG_SELECT:
            legs = "  ".join(f"{L.key(key_label(k))} {name}" for k, name in s["LEG_SELECT_KEYS"].items())
            lines.append(f" Leg    {legs}   (now {self.robot.leg_name})")
        lines += test.guide()
        L.banner(test.HEADER, lines)

    def show_idle(self):
        """대기 화면. 자기 화면을 가진 테스트(몸체 자세 · 균형)는 그 화면에, 아니면 8줄 화면(idle_page)."""
        if hasattr(self.test, "show_idle"):
            self.test.show_idle()
        else:
            self.robot.show_page(*self.test.idle_page())

    def show_help(self):
        """F1: 이 테스트의 키를 콘솔과 로봇 화면에 다시 보여 줍니다."""
        s = self.s
        self.print_guide()
        leg_keys = " ".join(key_label(k) for k in s.get("LEG_SELECT_KEYS", {}))
        if hasattr(self.test, "show_help_screen"):
            self.test.show_help_screen()
        else:
            footer = scr.keys_line([(key_label(s["STAND_KEY"]), "기본 자세"), (key_label(s["STOP_KEY"]), "멈춤")],
                                   " · ")
            self.robot.show_page(f"{self.test.SHORT} 키 안내", self.test.help_lines(leg_keys), footer)
        self._help_on_screen = True

    # ------------------------------------------------------------
    # 공통 동작
    # ------------------------------------------------------------
    def stand(self):
        """F2. 테스트에 reset()이 있으면 그것을(균형 테스트: 시험대 평평 · 기본 자세 · IMU 영점)."""
        if hasattr(self.test, "reset"):
            self.test.reset()
            return
        self.robot.stand()
        if hasattr(self.test, "on_stand"):
            self.test.on_stand()

    def stop_idle(self):
        """F3을 눌렀지만 진행 중인 자동 테스트가 없을 때."""
        if hasattr(self.test, "stop_idle"):
            self.test.stop_idle()
            return
        L.event("STATE", "no auto test running")

    def _stop_pressed(self):
        """자동 테스트 중에 부름: 멈춤 키(F3)나 기본 자세 키(F2)가 눌렸으면 그 키."""
        pressed = self.keys.take(self.stop_keys)
        if self.s["STAND_KEY"] in pressed:
            return self.s["STAND_KEY"]
        return pressed[0] if pressed else None

    def after_stop(self, key, start):
        """자동 테스트를 멈춘 뒤: 쌓인 키를 버리고, F2였으면 기본 자세로 옮김."""
        L.event("TASK", f"stopped by {L.key(key_label(key))} after {time.time() - start:.1f} s")
        self.keys.clear()
        if hasattr(self.test, "after_stop"):
            self.test.after_stop()
        if key == self.s["STAND_KEY"]:
            self.stand()
        else:
            self.robot.interrupted = True
            stand_desc = getattr(self.test, "COMMON_DESC", {}).get("STAND_KEY", "stand")
            L.event("STATE", f"legs held; next test starts from stand "
                             f"({L.key(key_label(self.s['STAND_KEY']))}: {stand_desc})")

    def select_leg(self, name):
        self.robot.leg = ports.LEG_NAMES.index(name)
        if hasattr(self.test, "on_leg_selected"):
            self.test.on_leg_selected()

    # ------------------------------------------------------------
    # 메인 루프
    # ------------------------------------------------------------
    def handle(self, key):
        """키 하나를 실행합니다."""
        desc, func, timed = self.table[key]
        L.event("INPUT", f"{L.key(key_label(key), 4)} {desc}")
        if hasattr(self.test, "before_action"):
            self.test.before_action()
        self._help_on_screen = False
        start = time.time()
        try:
            if timed and self.robot.interrupted:
                L.event("STATE", "moving to stand pose before the test")
                if hasattr(self.test, "prepare"):
                    self.test.prepare()     # 균형 테스트: 시험대 평평 · 기본 자세 (영점은 다시 잡지 않음)
                else:
                    self.stand()
            func()
            if timed:
                L.event("TASK", f"done in {time.time() - start:.1f} s")
        except TestStopped as stop:
            self.after_stop(stop.key, start)
        if not self._help_on_screen:
            self.show_idle()

    def update(self):
        for key in self.keys.pressed():
            self.handle(key)
        if hasattr(self.test, "on_loop"):
            self.test.on_loop()
        time.sleep(self.s["LOOP_SLEEP_SEC"])

    def run(self):
        """update()를 계속 반복합니다. RoboCo에서 스크립트를 멈추면 바로 끝납니다."""
        if not self.ready:
            return
        L.event("STATE", "ready")
        try:
            if getattr(self.test, "START_FILE", "") == "q01_balance_test_start.py":
                # BALANCE 전용: 게임 종료 신호를 받으면 복귀·정리 동작 없이 종료합니다.
                from scriptruntime import Runtime
                while not Runtime.quitting():
                    self.update()
            else:
                while True:
                    self.update()
        except KeyboardInterrupt:
            pass                    # RoboCo Space: 다리를 옮기지 않고 바로 끝냄
        except Exception as e:
            L.event("ERROR", f"unexpected error: {e}")
            log_traceback()

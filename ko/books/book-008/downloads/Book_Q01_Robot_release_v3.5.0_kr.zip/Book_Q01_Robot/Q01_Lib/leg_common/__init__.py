# -*- coding: utf-8 -*-
"""
Q01_Lib/leg_common  |  다리 테스트 세 가지 · 몸체 자세 테스트 · 균형 테스트가 함께 쓰는 코드

    q01lib_leg_app.py     다리 테스트 프로그램. 키 읽기 · 공통 키(F1 키 안내 · F2 기본 자세 ·
                          F3 테스트 멈춤 · U O J L 다리 고르기) · 자동 테스트 멈추기
    q01lib_leg_robot.py   테스트 로봇 (화면 · 서보 · 마지막 각도 · 고른 다리)
    q01lib_leg_screen.py  로봇 화면의 모양(8줄)과 색 설정 (다리 테스트 세 가지)
    q01lib_leg_check.py   확인 계산 (IK · FK · 관절 제한)

    시작 파일                      로봇                 테스트 폴더
    q01_leg1_joint_start.py        Book-QUAD-01-LEG1    leg1_joint     관절 테스트 (각도 → 관절)
    q01_leg2_ik_start.py           Book-QUAD-01-LEG2    leg2_ik        IK 테스트 (발끝 좌표 → 각도)
    q01_leg3_combined_start.py     Book-QUAD-01-LEG3    leg3_combined  복합 테스트 (좌표 목록 → 결과)
    q01_body_pose_start.py         Book-QUAD-01-ROLL_PITCH_YAW
                                                        body_pose      몸체 자세 (x y z · roll pitch yaw)
    q01_balance_test_start.py      Book-QUAD-01-BALANCE balance_test   균형 테스트 (IMU · PID)

다리 테스트 세 가지는 IMU(Inertial Sensor, Port 1)를 쓰지 않습니다. 몸체 자세 테스트는
기울기 확인에, 균형 테스트는 균형 제어에 IMU를 씁니다.
콘솔 LOG 형식(영어, [시간] [분류] 내용)은 모든 실습이 함께 쓰는 core/q01lib_log.py에 있습니다.
테스트 클래스의 LOG_CATEGORIES로 그 테스트의 콘솔 열을 맞춥니다.
"""

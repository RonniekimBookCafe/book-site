# -*- coding: utf-8 -*-
"""
q01lib_leg_check.py  |  QUAD-01 교육용 라이브러리 · 다리 좌표와 관절 각도 확인

다리 테스트 세 가지(관절 · IK · 복합) · 몸체 자세 테스트 · 균형 테스트가 함께 쓰는 계산입니다.
서보는 움직이지 않고 값만 계산합니다.

    check_point()     발끝 좌표 → 도달 범위 → IK 각도 → 서보 각도 → 0~180도 제한 → FK 오차
    servo_to_ik()     서보 논리 각도 → IK 각도 (좌우 다리 방향 보정을 거꾸로)
    foot_from_servo() 서보 논리 각도 → 발끝 좌표 (FK)

[두 방향의 계산]
    IK  발끝 좌표 (x, y, z) → 관절 각도 (a, b, c)   core/q01lib_ik.coordinate_to_angle()
    FK  관절 각도 (a, b, c) → 발끝 좌표 (x, y, z)   core/q01lib_ik.angle_to_coordinate()

IK로 구한 각도를 FK에 다시 넣으면 처음 좌표로 돌아와야 합니다. 두 좌표의
거리(FK 오차)가 각도를 정수로 반올림한 만큼(약 1 이내)이면 IK가 맞게 계산한
것입니다. 관절이 0도나 180도 제한에 닿으면 서보가 그 각도에서 멈추므로,
발끝은 목표 좌표에 닿지 않습니다.
"""

import math

from ..core import q01lib_ports as ports
from ..core.q01lib_ik import coordinate_to_angle, angle_to_coordinate, is_valid_point

JOINT_NAMES = ("HX", "HY", "KN")


def servo_to_ik(leg, servo):
    """서보 논리 각도 [HX, HY, KN]를 IK 각도 (a, b, c)로 바꿉니다.

    core/q01lib_motion.LegMotion.to_servo_angles()의 반대 계산입니다(보정각 포함).

        왼쪽 다리   a = HX    b = 90 - HY    c = KN
        오른쪽 다리 a = HX    b = HY - 90    c = 180 - KN
    """
    hx, hy, kn = servo
    cal = ports.CALIBRATION_ANGLES[leg]
    if leg in ports.LEFT_LEGS:
        return hx - cal[0], (90 - hy) - cal[1], kn - cal[2]
    return hx - cal[0], (hy - 90) - cal[1], (180 - kn) - cal[2]


def foot_from_servo(leg, servo):
    """서보 논리 각도 [HX, HY, KN]에서 발끝 좌표 (x, y, z)를 계산합니다(FK)."""
    return angle_to_coordinate(*servo_to_ik(leg, servo))


def check_point(motion, leg, point):
    """발끝 좌표 하나를 확인합니다. 서보는 움직이지 않습니다.

    :param motion: core/q01lib_motion.LegMotion (좌우 보정에 씀)
    :param leg: 다리 번호 (0 FL, 1 HL, 2 HR, 3 FR)
    :param point: 발끝 좌표 [x, y, z]
    :return: dict
        ok       서보에 보낼 수 있으면 True (도달 범위 안, IK 계산 가능)
        reason   보낼 수 없는 이유, 콘솔용 영어 (ok가 True이면 None)
        reach    엉덩이에서 발끝까지 거리
        ik       IK 각도 (a, b, c)
        servo    서보 논리 각도 [HX, HY, KN] (0~180도로 제한한 값)
        limited  0도나 180도 제한에 닿은 관절 이름 목록 (예: ["HY"])
        fk       서보 각도로 다시 계산한 발끝 좌표
        error    목표와 FK 좌표의 거리
    """
    result = {"ok": False, "reason": None, "reach": math.sqrt(sum(v * v for v in point)),
              "ik": None, "servo": None, "limited": [], "fk": None, "error": None}
    if not is_valid_point(point):
        result["reason"] = f"reach {result['reach']:.1f} outside {ports.REACH_MIN}-{ports.REACH_MAX}"
        return result
    try:
        ik = coordinate_to_angle(*point)
    except ValueError:
        result["reason"] = "no IK solution for the leg lengths"
        return result
    servo = motion.to_servo_angles(leg, ik)
    fk = foot_from_servo(leg, servo)
    result.update(ok=True, ik=ik, servo=servo, fk=fk,
                  limited=[n for n, v in zip(JOINT_NAMES, servo)
                           if v <= ports.LOGICAL_MIN_DEG or v >= ports.LOGICAL_MAX_DEG],
                  error=math.sqrt(sum((f - t) ** 2 for f, t in zip(fk, point))))
    return result


def side_word(leg, dy):
    """다리마다 y 방향이 몸 바깥쪽인지 안쪽인지 알려 줍니다.

    왼쪽 다리(FL·HL)는 +y(왼쪽)가 몸 바깥쪽, 오른쪽 다리(HR·FR)는 +y가 몸 안쪽입니다.
    """
    if dy == 0:
        return ""
    outward = (dy > 0) == (leg in ports.LEFT_LEGS)
    return "몸 바깥쪽" if outward else "몸 안쪽"


def side_word_en(leg, dy):
    """side_word()의 콘솔용 영어: "out"(몸 바깥쪽) · "in"(몸 안쪽)."""
    if dy == 0:
        return ""
    return "out" if (dy > 0) == (leg in ports.LEFT_LEGS) else "in"

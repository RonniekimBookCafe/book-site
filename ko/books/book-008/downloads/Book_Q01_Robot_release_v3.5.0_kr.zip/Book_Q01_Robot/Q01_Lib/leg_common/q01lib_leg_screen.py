# -*- coding: utf-8 -*-
"""
q01lib_leg_screen.py  |  QUAD-01 교육용 라이브러리 · 다리 테스트 로봇 화면의 모양과 색

세 다리 테스트(관절 · IK · 복합)와 몸체 자세 테스트는 Text Screen(Port 0)을 쓰므로, 화면의
줄 배치와 색을 이 파일 한곳에서 정합니다. 화면 설정을 바꿀 때는 아래 1절만 고칩니다.

[화면 한 장의 모양]  늘 8줄
    제목                      테스트 이름 · 고른 다리 (COLORS["title"])
    ------------------        구분선
    본문 1                    값 네 줄 (줄이 모자라면 빈 줄로 채움)
    본문 2
    본문 3
    본문 4
    ------------------        구분선
    키 안내                   대기 중에는 쓸 수 있는 키, 자동 테스트 중에는 F3 멈춤 · F2 기본 자세

줄 수가 늘 같으므로 대기 화면 · 자동 테스트 화면 · 키 안내 화면을 오가도 글자 크기와
줄 위치가 거의 바뀌지 않습니다. 구분선은 고정 길이(RULE_WIDTH)이고 가장 긴 줄보다 짧아서
글자 크기(auto_size)에 영향을 주지 않습니다.

[색]
값 가운데 먼저 봐야 할 것에만 색을 씁니다. 색만으로 뜻을 나누지 않고 글자(예: "HY 제한")를
함께 씁니다(흑백 화면 캡처에서도 읽힘).

    coord   발끝 좌표 x · y · z의 숫자            청록
    angle   보낸 서보 각도(입력 각도)의 숫자       노랑
    ok      FK 오차가 작음 (IK가 맞게 계산)        초록
    warn    관절 제한 · 갈 수 없는 좌표            빨강
    key     키 이름 (F3 · W · 1 …)                흰색 굵게
    title / rule / hint   제목 · 구분선 · 키 설명

색은 Text Screen 글자 안에 <color=#RRGGBB> 태그를 넣어 바꿉니다. RoboCo 공식 API 문서에는
글자 전체 색(TextScreen.color)만 나와 있고 글자 일부의 색 태그는 나와 있지 않습니다. 화면
글자 엔진(TextMeshPro)의 기능이며, 게임 화면에서 색으로 나옵니다. 화면에
"<color=" 같은 글자가 그대로 보이면 SCREEN_COLOR를 False로 바꿉니다. 그러면 태그 없이 글자만 씁니다.

사용하는 RoboCo 공식 API
- TextScreen.text (core/q01lib_screen.py의 StatusScreen.show_lines를 거침)
"""

# ========================================
# 1. 화면 설정 (다리 테스트 · 몸체 자세 테스트가 함께 씀)
# ========================================
SCREEN_COLOR = True          # 값에 색을 씀. 화면에 태그 글자가 보이면 False
COLORS = {
    "title": "#FF8A34",      # 제목 (QUAD-01 강조색 Mechanical Orange)
    "coord": "#20D6D9",      # 발끝 좌표 숫자
    "angle": "#FFD91A",      # 서보 각도 숫자
    "ok": "#4ADE80",         # FK 오차 정상
    "warn": "#FF5A52",       # 관절 제한 · 갈 수 없음
    "key": "#FFFFFF",        # 키 이름 (굵게)
    "rule": "#6B7280",       # 구분선
    "hint": "#B0B7C3",       # 키 설명
}
RULE_CHAR = "-"              # 구분선 글자
RULE_WIDTH = 18              # 구분선 길이(글자 수). 가장 짧은 화면의 가장 긴 줄보다 짧게
BODY_LINES = 4               # 본문 줄 수 (모자라면 빈 줄로 채움)


# ========================================
# 2. 글자 만들기
# ========================================
def paint(text, kind):
    """text에 kind(COLORS의 이름) 색을 입힙니다. SCREEN_COLOR가 False이면 글자만."""
    text = str(text)
    if not SCREEN_COLOR:
        return text
    if kind == "key":
        return f"<b><color={COLORS['key']}>{text}</color></b>"
    return f"<color={COLORS[kind]}>{text}</color>"


def value(v, kind):
    """값 하나. 값을 모르면(None · "-") 색 없이 "-"."""
    if v is None or v == "-":
        return "-"
    if kind is None:
        return str(v)
    return paint(v, kind)


def joints(values, kind="angle", prefix=""):
    """관절 세 개의 값 한 줄. 예: "HX 84  HY 147  KN 102" (숫자에 색)."""
    hx, hy, kn = values
    return f"{prefix}HX {value(hx, kind)}  HY {value(hy, kind)}  KN {value(kn, kind)}"


def xyz(x, y, z, prefix=""):
    """발끝 좌표 한 줄. 예: "x 30  y 10  z -70" (숫자에 색)."""
    return f"{prefix}x {value(x, 'coord')}  y {value(y, 'coord')}  z {value(z, 'coord')}"


def keys_line(pairs, sep="  "):
    """키 안내 한 줄. pairs = [("F3", "멈춤"), ("F2", "기본 자세")] → "F3 멈춤 · F2 기본 자세"."""
    return sep.join(f"{paint(k, 'key')} {paint(desc, 'hint')}" for k, desc in pairs)


def rule():
    """구분선 한 줄."""
    return paint(RULE_CHAR * RULE_WIDTH, "rule")


def page(title, body, footer):
    """화면 한 장(8줄): 제목 · 구분선 · 본문 BODY_LINES줄 · 구분선 · 키 안내."""
    body = list(body)
    body += [""] * (BODY_LINES - len(body))
    return [paint(title, "title"), rule(), *body, rule(), footer]

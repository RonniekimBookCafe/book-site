# -*- coding: utf-8 -*-
"""
q01lib_leg_robot.py  |  QUAD-01 교육용 라이브러리 · 다리 테스트가 함께 쓰는 로봇

세 다리 테스트(관절 · IK · 복합) · 몸체 자세 테스트 · 균형 테스트는 로봇과 시작 파일이 따로 있지만,
로봇의 화면 · 서보 · 마지막 각도 · 고른 다리를 다루는 코드는 이 클래스 하나를 함께 씁니다.
다리 테스트 로봇은 공중에 매달려 있고, 몸체 자세 테스트 로봇은 바닥에, 균형 테스트 로봇은 기울기 시험대에 섭니다.

    screen   로봇 화면 (Text Screen, Port 0). 가운데 정렬, 코드가 정한 줄만 씀. 처음 쓸 때 만듦
             (몸체 자세 · 균형 테스트는 자기 화면 파일 body_pose/q01lib_body_pose_screen.py ·
              balance_test/q01lib_balance_test_screen.py를 쓰고 이 화면은 만들지 않음)
    motion   발끝 좌표 → 관절 서보 (core/q01lib_motion.LegMotion). IK · 복합 · 몸체 자세 · 균형 테스트와 기본 자세가 씀
    angles   Port별로 마지막에 보낸 논리 각도. 관절 테스트가 직접 보낸 각도와 motion으로
             보낸 각도를 모두 기억함 (화면 표시 · FK 계산 · 관절 직접 조작)
    leg      고른 다리 (0 FL · 1 HL · 2 HR · 3 FR). 관절 · IK 테스트가 씀

프로그램을 시작할 때 관절 서보 12개의 최대 토크와 가속 시간을 한 번 읽어 서보 사양
(core/q01lib_ports.py 7절)과 같은지 콘솔에 남깁니다. 이 두 값은 로봇 파일의 값을
그대로 쓰고 코드에서 바꾸지 않습니다.

관절 서보에 각도를 보내는 길은 두 가지입니다.
    send_joint()   Port 하나에 논리 각도를 직접 보냄 (관절 테스트)
    motion.run()   네 다리의 발끝 좌표를 IK로 풀어 서보 12개에 보냄 (IK · 복합 테스트, 기본 자세)
                   → 보낸 뒤 sync_from_motion()으로 angles를 맞춤

[자동 테스트 멈추기]
자동으로 이어지는 테스트는 기다리는 시간을 wait()로 보냅니다. wait()는 STOP_CHECK_SEC마다
check_stop()을 불러 멈춤 키(F3)와 기본 자세 키(F2)가 눌렸는지 봅니다. 눌렸으면
TestStopped를 일으켜 테스트를 그 자리에서 끝냅니다. 테스트를 끝낸 뒤 할 일(그 자리에
멈춤 · 기본 자세)은 다리 테스트 프로그램(q01lib_leg_app.py)이 정합니다. F3으로 멈춘
자세이면 interrupted가 True가 되고, 다음 자동 테스트는 기본 자세로 옮긴 뒤 시작합니다.
"""

import time

from controllables import ServoMotor

from ..core import q01lib_ports as ports
from ..core.q01lib_servo import setup_canonical_servos
from ..core.q01lib_motion import LegMotion
from ..core.q01lib_screen import StatusScreen
from .q01lib_leg_check import foot_from_servo
from . import q01lib_leg_screen as scr
from ..core import q01lib_log as L    # 콘솔 LOG 출력 (L.event · L.more · L.key …)

STAND_STEPS = 30                 # 기본 자세로 옮길 때 나누는 단계 수
STOP_CHECK_SEC = 0.05            # 자동 테스트 중 멈춤 키를 확인하는 간격(초)


class TestStopped(Exception):
    """자동 테스트를 중간에 멈췄을 때 일어나는 예외. key는 멈춘 키 (F3 멈춤 · F2 기본 자세)."""

    def __init__(self, key):
        super().__init__(key)
        self.key = key

# Port 번호 → 관절 이름 (예: 3 → "FL_HY")
PORT_NAMES = {}
for _leg, _name in enumerate(ports.LEG_NAMES):
    for _joint, _port in zip(("HX", "HY", "KN"), ports.LEG_JOINT_PORTS[_leg]):
        PORT_NAMES[_port] = f"{_name}_{_joint}"


def joint_list_text(joints):
    """관절 이름 목록을 짧게: 네 다리의 같은 관절이 모두 있으면 "HX HY on FL HL HR FR"."""
    legs = [n for n in ports.LEG_NAMES if any(j.startswith(n + "_") for j in joints)]
    kinds = [k for k in ("HX", "HY", "KN") if any(j.endswith("_" + k) for j in joints)]
    if len(joints) == len(legs) * len(kinds):
        return f"{' '.join(kinds)} on {' '.join(legs)}"
    return " ".join(joints)


class LegTestRobot:
    """다리 테스트 로봇 (Book-QUAD-01-LEG1 · LEG2 · LEG3 · ROLL_PITCH_YAW)."""

    def __init__(self, settings):
        self.s = settings
        setup_canonical_servos()  # shared 12DOF motor contract
        start_leg = settings.get("START_LEG", ports.LEG_NAMES[0])     # 복합 테스트는 다리를 고르지 않음
        if start_leg not in ports.LEG_NAMES:
            raise ValueError(f"START_LEG '{start_leg}': use one of FL, HL, HR, FR")
        self.rpm = settings["SERVO_RPM"]
        if not 0 < self.rpm <= ports.SERVO_RPM_MAX:
            raise ValueError(f"SERVO_RPM {self.rpm}: use a value above 0 and up to {ports.SERVO_RPM_MAX}")
        self.height = settings["BODY_HEIGHT"]
        self.feet_forward = settings.get("FEET_FORWARD", 0)    # 기본 자세에서 발끝을 엉덩이보다 앞에 두는 거리 (균형 테스트만 씀)
        self._screen = None         # 로봇 화면. 처음 쓸 때 만듦 (screen)
        self.motion = LegMotion(body_height=self.height, servo_rpm=self.rpm)
        self.angles = {}
        self.leg = ports.LEG_NAMES.index(start_leg)
        self.stop_check = None      # 멈춤 키가 눌렸으면 그 키를 돌려주는 함수 (다리 테스트 프로그램이 넣음)
        self.running_footer = ""    # 자동 테스트 중 화면 마지막 줄 (예: "F3 멈춤 · F2 기본 자세")
        self.interrupted = False    # F3으로 자동 테스트를 멈춘 자세이면 True. 기본 자세로 옮기면 False

    # ------------------------------------------------------------
    # 자동 테스트 멈추기
    # ------------------------------------------------------------
    def check_stop(self):
        """멈춤 키가 눌렸으면 TestStopped를 일으킵니다."""
        if self.stop_check is not None:
            key = self.stop_check()
            if key:
                raise TestStopped(key)

    def wait(self, seconds):
        """seconds초 기다립니다. STOP_CHECK_SEC마다 멈춤 키를 확인합니다."""
        remaining = seconds
        while remaining > 0:
            step = min(STOP_CHECK_SEC, remaining)
            time.sleep(step)
            remaining -= step
            self.check_stop()
        if seconds <= 0:
            self.check_stop()

    @property
    def screen(self):
        """로봇 화면 (StatusScreen, 가운데 정렬). 처음 쓸 때 Reference를 만들고 계속 씁니다."""
        if self._screen is None:
            self._screen = StatusScreen(centered=True)
        return self._screen

    def show_page(self, title, body, footer):
        """로봇 화면 한 장 (8줄: 제목 · 구분선 · 본문 네 줄 · 구분선 · 키 안내, q01lib_leg_screen.py)."""
        self.screen.show_lines(*scr.page(title, body, footer))

    def show_running(self, title, *body):
        """자동 테스트 중 화면: 키 안내 줄에 멈춤 키 (F3 멈춤 · F2 기본 자세)."""
        self.show_page(title, body, self.running_footer)

    def check_servo_spec(self):
        """관절 서보 12개의 최대 토크 · 가속 시간이 서보 사양과 같은지 콘솔에 남깁니다."""
        try:
            values = {port: {name: getattr(ServoMotor(port), name)
                             for name in ("max_torque", "acceleration_time")}
                      for port in ports.SERVO_ORDER}
        except Exception as e:
            L.event("WARN", f"cannot read servo settings ({e})")
            return
        L.event("STATE", f"servo action rpm={self.rpm:g}  default={ports.SERVO_RPM_DEFAULT:g}  "
                         f"accel={ports.SERVO_ACCELERATION_TIME:g} s")
        for port, value in values.items():
            expected = {"max_torque": ports.SERVO_MAX_TORQUE_BY_PORT[port],
                        "acceleration_time": ports.SERVO_ACCELERATION_TIME}
            for name, target in expected.items():
                if abs(value[name] - target) > 0.01 * max(1.0, abs(target)):
                    L.event("WARN", f"{ports.SERVO_PART_NAMES[port]} {name}={value[name]:g}, "
                                    f"expected {target:g}")

    # ------------------------------------------------------------
    # 고른 다리
    # ------------------------------------------------------------
    @property
    def leg_name(self):
        return ports.LEG_NAMES[self.leg]

    def leg_servo(self, leg=None):
        """다리 하나의 [HX, HY, KN] 논리 각도. 아직 보낸 적 없는 관절은 None."""
        leg = self.leg if leg is None else leg
        return [self.angles.get(p) for p in ports.LEG_JOINT_PORTS[leg]]

    def servo_text(self, leg=None, prefix=""):
        """화면에 쓰는 서보(입력) 각도 한 줄 (예: "HX 84  HY 147  KN 102", 숫자는 노랑)."""
        return scr.joints(self.leg_servo(leg), "angle", prefix)

    def motor_text(self, leg=None):
        """화면에 쓰는 모터(물리) 각도 한 줄 (예: "모터 HX -6  HY -57  KN -12")."""
        values = [None if v is None else self.motion.servo.convert_angle(v) for v in self.leg_servo(leg)]
        return scr.joints(values, None, "모터 ")

    def port_text(self, leg=None):
        """화면에 쓰는 Port 번호 한 줄 (예: "Port HX 4  HY 3  KN 2")."""
        return scr.joints(ports.LEG_JOINT_PORTS[self.leg if leg is None else leg], None, "Port ")

    def foot_text(self, leg=None):
        """화면에 쓰는 FK 발끝 좌표 한 줄 (숫자는 청록). 관절 세 개의 각도를 모두 알아야 계산합니다."""
        leg = self.leg if leg is None else leg
        servo = self.leg_servo(leg)
        if None in servo:
            return scr.xyz(None, None, None, "발끝 ")
        x, y, z = (round(v) + 0 for v in foot_from_servo(leg, servo))
        return scr.xyz(x, y, z, "발끝 ")

    # ------------------------------------------------------------
    # 서보에 각도 보내기
    # ------------------------------------------------------------
    def send_joint(self, port, logical_angle, log_line=True):
        """Port 서보 하나에 논리 각도를 보내고, 필요하면 콘솔에 남깁니다."""
        old = self.angles.get(port)
        self.motion.servo.set_servo_angle(port, logical_angle, self.rpm)
        self.angles[port] = logical_angle
        if log_line:
            physical = self.motion.servo.convert_angle(logical_angle)
            before = "" if old is None else f"{old:3} -> "
            L.event("JOINT", f"{PORT_NAMES[port]:<5} port={port:<2}  in={before}{logical_angle:3} deg  "
                             f"motor={physical:3} deg")

    def log_foot(self, leg):
        """그 다리 관절 세 개의 각도를 모두 알면 FK로 계산한 발끝 좌표를 남깁니다."""
        servo = self.leg_servo(leg)
        if None in servo:
            return
        x, y, z = (v + 0.0 for v in foot_from_servo(leg, servo))
        L.event("STATE", f"{ports.LEG_NAMES[leg]} foot (FK)  {L.xyz_text(x, y, z)}")

    def sync_from_motion(self):
        """motion이 마지막으로 보낸 서보 각도를 angles에 옮겨 적습니다."""
        for leg in range(4):
            for axis, port in enumerate(ports.LEG_JOINT_PORTS[leg]):
                self.angles[port] = self.motion.angles[leg][axis]

    # ------------------------------------------------------------
    # 자세
    # ------------------------------------------------------------
    def stand_positions(self):
        """기본 자세의 발끝 좌표 (FL, HL, HR, FR)."""
        x = self.feet_forward
        y = ports.FOOT_Y_OFFSET
        h = self.height
        return [[x, y, -h], [x, y, -h], [x, -y, -h], [x, -y, -h]]

    def stand(self):
        """네 다리를 기본 자세로 옮깁니다."""
        self.motion.move_to(self.stand_positions(), STAND_STEPS)
        self.sync_from_motion()
        self.interrupted = False
        L.event("STATE", "stand pose")

# -*- coding: utf-8 -*-
"""
q01lib_gait.py  |  QUAD-01 교육용 라이브러리 · 보행 궤적 (발끝이 그리는 길)

걸음 한 주기 동안 발끝이 그리는 길(궤적)을 계산합니다. 이 파일의 함수는
위상 각도(angle) 하나를 받아, 그 순간 두 다리 그룹의 발끝 좌표를
돌려줍니다. 서보를 직접 움직이지 않는 순수 계산입니다.

    위상 각도 angle (반복할 때마다 GAIT_SPEED만큼 증가 또는 감소)
      -> 궤적 함수 (이 파일)        cos·sin으로 발끝 좌표 계산
      -> LegMotion.change_coordinates()  두 그룹의 좌표를 네 다리에 배분
      -> IK -> 관절 서보

[트롯(trot) 보행]
대각선 두 다리를 한 그룹으로 묶어 같은 궤적으로 움직이고, 두 그룹은
180도 어긋난 위상으로 움직입니다. 한 그룹이 발을 드는 동안 다른 그룹이
땅을 밀어 몸을 옮깁니다.

    그룹 1 : FL · HR   위상 angle
    그룹 2 : HL · FR   위상 angle + 180도

[좌표]
발끝 좌표는 다리 좌표계(x 앞 · y 왼쪽 · z 위, 원점은 엉덩이 관절)입니다.
서 있을 때 발끝의 z는 -몸체 높이(예: -99)입니다.

    전진·후진(W·S)   : x로 앞뒤, z로 발 들기
    제자리 회전(A·D) : x와 y를 같은 값으로 움직여 yaw 방향으로 돎, z로 발 들기
    측면 이동(Q·E)   : y로 좌우, z로 발 들기

[발을 드는 구간만 높이가 바뀝니다]
z = -(진폭 × sin(위상) + 몸체 높이) 로 계산한 뒤, -몸체 높이보다 낮은
값(땅 아래로 파고드는 쪽)은 -몸체 높이로 자릅니다. 그래서 발끝은 반원
모양으로 들렸다가, 나머지 반 주기에는 땅에 닿은 채 앞뒤 또는 좌우로
밀립니다.
"""

import math


def swing_pair(angle, amp_main, amp_lift, height):
    """두 그룹의 (주 이동 축 좌표, z 좌표)를 계산합니다.

    전진·후진·제자리 회전에서는 주 이동 축이 x(앞뒤),
    측면 이동에서는 y(좌우)입니다.

    :param angle: 위상 각도(도)
    :param amp_main: 주 이동 축의 진폭 (보폭의 절반)
    :param amp_lift: 발을 드는 높이 진폭
    :param height: 몸체 높이 (서 있을 때 발끝 z = -height)
    :return: (그룹 1 주축, 그룹 1 z, 그룹 2 주축, 그룹 2 z)
    """
    M1 = amp_main * math.cos(angle * math.pi / 180)
    Z1 = -(amp_lift * math.sin(angle * math.pi / 180) + height)
    M2 = amp_main * math.cos((angle + 180) * math.pi / 180)
    Z2 = -(amp_lift * math.sin((angle + 180) * math.pi / 180) + height)

    # 발끝이 땅(z = -height)보다 아래로 내려가지 않게
    Z1 = max(Z1, -height)
    Z2 = max(Z2, -height)
    return M1, Z1, M2, Z2


def diagonal_pair(angle, amp_x, amp_y, height, amp_lift=8):
    """대각선 이동(자동 모드 3)의 두 그룹 좌표를 계산합니다.

    amp_x 부호: + 앞쪽 / - 뒤쪽,  amp_y 부호: + 왼쪽 / - 오른쪽
    :return: (X1, Y1, Z1, X2, Y2, Z2)
    """
    X1 = amp_x * math.cos(angle * math.pi / 180)
    Y1 = amp_y * math.cos(angle * math.pi / 180)
    Z1 = -(amp_lift * math.sin(angle * math.pi / 180) + height)
    X2 = amp_x * math.cos((angle + 180) * math.pi / 180)
    Y2 = amp_y * math.cos((angle + 180) * math.pi / 180)
    Z2 = -(amp_lift * math.sin((angle + 180) * math.pi / 180) + height)

    # 발끝이 땅보다 아래로 내려가지 않게
    Z1 = max(Z1, -height)
    Z2 = max(Z2, -height)
    return X1, Y1, Z1, X2, Y2, Z2


def zigzag_pair(angle, amp_turn_y, height, turn_factor=0.8):
    """전진하면서 회전(자동 모드 3 지그재그)의 두 그룹 좌표를 계산합니다.

    그룹 1만 x(앞뒤) 진폭을 키워 한쪽으로 휘어 가게 합니다.
    amp_turn_y 부호: + 왼쪽으로 휨 / - 오른쪽으로 휨
    :return: (X1, Y1, Z1, X2, Y2, Z2)
    """
    # 기본 전진 움직임
    forward_x = 15 * math.cos(angle * math.pi / 180)
    forward_z = -(8 * math.sin(angle * math.pi / 180) + height)

    X1 = forward_x + 8 * math.cos(angle * math.pi / 180) * turn_factor
    Y1 = amp_turn_y * math.cos(angle * math.pi / 180) * turn_factor
    Z1 = forward_z
    X2 = 15 * math.cos((angle + 180) * math.pi / 180)
    Y2 = amp_turn_y * math.cos((angle + 180) * math.pi / 180) * turn_factor
    Z2 = -(8 * math.sin((angle + 180) * math.pi / 180) + height)

    # 발끝이 땅보다 아래로 내려가지 않게
    Z1 = max(Z1, -height)
    Z2 = max(Z2, -height)
    return X1, Y1, Z1, X2, Y2, Z2


class Phase:
    """보행 위상 각도를 한 걸음씩 진행하고, 한 주기가 끝나면 처음으로 되돌립니다.

    reverse=False : speed만큼 증가, high를 넘으면 low로   (예: 전진 90 → 450 → 90)
    reverse=True  : speed만큼 감소, low보다 작아지면 high로 (예: 후진 450 → 90 → 450)
    """

    def __init__(self, start, speed, low, high, reverse=False):
        self.angle = start
        self.speed = speed
        self.low = low
        self.high = high
        self.reverse = reverse

    def advance(self):
        if not self.reverse:
            self.angle += self.speed
            if self.angle > self.high:
                self.angle = self.low
        else:
            self.angle -= self.speed
            if self.angle < self.low:
                self.angle = self.high

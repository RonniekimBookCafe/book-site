# -*- coding: utf-8 -*-
"""
q01lib_robot.py  |  QUAD-01 교육용 라이브러리 · QuadRobot (4족 로봇 전체)

q01lib_app.py와 자동 모드(auto/q01lib_auto.py)는 이 QuadRobot 클래스 하나만
가져다 씁니다. ServoMotor를 직접 다루지 않아도 되고, 필요할 때는 이
파일을 열어 명령이 어디로 이어지는지 따라갈 수 있습니다.

    시작 파일 (q01_walk_start.py)
      -> q01lib_app.py   (키를 읽고 robot.forward() 등을 부름)
        -> QuadRobot     (이 파일: 보행 반복, 자세)
          -> q01lib_gait.py    발끝 궤적 (cos · sin)
          -> LegMotion         발끝 좌표 → IK → 좌우 보정 (core/q01lib_motion.py)
            -> ServoController 논리 각도 → 물리 각도 (core/q01lib_servo.py)
              -> RoboCo Python API (ServoMotor.spin_to_degrees)
                -> Port 2~13
                  -> 다리의 실제 움직임

[보행 동작의 공통 순서]
W·S·A·D·Q·E 동작은 모두 같은 반복 구조를 씁니다(_walk).

    반복 시작
      -> 끝낼 조건 확인 (키를 뗐는가 / 자동 모드의 시간이 끝났는가)
      -> 위상 각도로 발끝 궤적 계산 (q01lib_gait)
      -> 두 그룹의 좌표를 네 다리에 배분하고 서보 전송 (LegMotion)
      -> 위상 각도 한 걸음 진행 (키별 *_GAIT_SPEED)
    반복 끝
      -> 직접 조종(키)이었다면 기본 자세로 복귀
"""

import time

from ..core import q01lib_ports as ports
from ..core.q01lib_keys import is_down
from ..core.q01lib_motion import LegMotion
from .q01lib_gait import swing_pair, Phase
from ..core import q01lib_log as L    # 콘솔 LOG 출력 (L.event · L.more · L.key …)

# 이완 자세의 발끝 좌표 [x, y, z] (네 다리 같음)
RELAX_POSITION = [55, 0, -78]

# 자세를 옮길 때 나누는 단계 수
DEFAULT_POSITION_STEPS = 30     # 기본 자세로 복귀
STOP_STEPS = 50                 # 정지 자세
RELAX_STEPS = 50                # 이완 자세

# 몸체 높이를 바꿀 때 발끝 높이를 다시 계산하는 빈도(초당 횟수)
HEIGHT_UPDATE_HZ = 20


class QuadRobot:
    """QUAD-01 4족 로봇 전체를 다루는 클래스."""

    def __init__(self,
                 servo_rpm=30,
                 body_height=99,
                 gait_speed=2.5,
                 forward_gait_speed=3.6,
                 backward_gait_speed=4.5,
                 turn_gait_speed=3.75,
                 side_gait_speed=4.0,
                 forward_stride=(20, 10),
                 backward_stride=(12, 6),
                 turn_stride=(6, 8),
                 side_stride=(15, 5)):
        """인자의 뜻은 시작 파일의 CONTROL PARAMETERS 설명과 같습니다.

        *_gait_speed는 키로 직접 조종할 때의 위상 속도(도)이고, gait_speed는
        자동 모드에서 속도를 따로 정하지 않은 동작에 씁니다.
        *_stride는 (주 이동 축 진폭, 발 드는 높이 진폭)입니다.
        주 이동 축은 전진·후진 x, 회전 x와 y, 측면 이동 y이고, 발 드는 높이는 z입니다.
        """
        # 발끝 좌표 → 관절 서보
        self.motion = LegMotion(body_height=body_height, servo_rpm=servo_rpm)

        self.rpm = servo_rpm             # 서보 회전 속도
        self.base_height = body_height   # 기본 자세 높이 (기준값, 발끝 z = -base_height)
        self.height = body_height        # 지금 보행에 쓰는 몸체 높이 (발끝 z = -height, 자동 모드 2가 바꿈)

        # 보행 위상 속도 (한 번 반복할 때 위상이 나아가는 각도)
        self.gait_speed = gait_speed                   # 자동 모드 기본값
        self.forward_gait_speed = forward_gait_speed   # W 전진 (키로 직접 조종)
        self.backward_gait_speed = backward_gait_speed # S 후진
        self.turn_gait_speed = turn_gait_speed         # A·D 회전
        self.side_gait_speed = side_gait_speed         # Q·E 측면 이동

        # 보폭 (키로 직접 조종할 때와, 자동 모드에서 보폭을 정하지 않은 동작에 씀)
        self.forward_stride = forward_stride
        self.backward_stride = backward_stride
        self.turn_stride = turn_stride
        self.side_stride = side_stride

        self.leg_names = ports.LEG_NAMES  # ["FL", "HL", "HR", "FR"]

        # 자동 모드가 실행 중인가 (auto/q01lib_auto.py가 켜고 끔)
        self.auto_mode_active = False

        # 시작할 때 기본 자세로
        self.default_position()

    # ------------------------------------------------------------
    # 자세
    # ------------------------------------------------------------
    def default_positions(self):
        """기본 자세의 발끝 좌표 [x, y, z] (FL, HL, HR, FR)."""
        h = self.base_height
        y = ports.FOOT_Y_OFFSET
        return [
            [0, y, -h],    # 왼쪽 앞 다리(FL)
            [0, y, -h],    # 왼쪽 뒤 다리(HL)
            [0, -y, -h],   # 오른쪽 뒤 다리(HR)
            [0, -y, -h],   # 오른쪽 앞 다리(FR)
        ]

    def default_position(self):
        """모든 다리를 기본 자세로 부드럽게 옮깁니다(30단계).
        로봇이 안정적으로 서 있는 기본 상태입니다.
        """
        self.motion.move_to(self.default_positions(), DEFAULT_POSITION_STEPS, self.rpm)

    def stop(self):
        """X 키: 안정된 정지 자세로 부드럽게 옮깁니다(50단계).
        네 발끝을 조금 앞쪽(x = 10)에 두고, 지금 몸체 높이를 유지합니다.
        """
        h = self.height
        y = ports.FOOT_Y_OFFSET
        target_positions = [
            [10, y, -h],    # 왼쪽 앞 다리(FL)
            [10, y, -h],    # 왼쪽 뒤 다리(HL)
            [10, -y, -h],   # 오른쪽 뒤 다리(HR)
            [10, -y, -h],   # 오른쪽 앞 다리(FR)
        ]
        self.motion.move_to(target_positions, STOP_STEPS)
        L.event("STATE", f"stop pose  feet x=+10  height={h:g} mm")

    def relax(self):
        """Z 키: 몸체를 낮춘 이완 자세로 부드럽게 옮깁니다(50단계).
        네 다리를 같은 좌표(RELAX_POSITION)로 보냅니다.
        """
        relax_positions = [list(RELAX_POSITION) for _ in range(4)]
        self.motion.move_to(relax_positions, RELAX_STEPS)
        L.event("STATE", "relax pose")

    def smooth_height_transition(self, target_height, duration):
        """몸체 높이를 duration초 동안 target_height로 천천히 바꿉니다(자동 모드 2).

        초당 HEIGHT_UPDATE_HZ번 네 발끝의 z(= -몸체 높이)를 조금씩 바꿉니다.
        자동 모드가 중지되면 그 자리에서 멈춥니다.
        """
        start_height = self.height
        start_time = time.time()
        steps = int(duration * HEIGHT_UPDATE_HZ)

        for step in range(steps + 1):
            if not self.auto_mode_active:
                return

            elapsed_time = time.time() - start_time
            if elapsed_time >= duration:
                break

            # 선형 보간
            progress = step / steps
            current_height = start_height + (target_height - start_height) * progress

            self.height = current_height
            for i in range(4):
                self.motion.points[i][2] = -current_height

            self.motion.run()
            time.sleep(0.05)  # 20Hz 업데이트

        # 최종 높이 설정
        self.height = target_height
        for i in range(4):
            self.motion.points[i][2] = -target_height
        self.motion.run()

    # ------------------------------------------------------------
    # 보행 반복 (모든 보행 동작이 함께 씀)
    # ------------------------------------------------------------
    def _speed(self, speed, auto_mode, manual_speed):
        """위상 속도를 고릅니다.

        speed를 주면 그 값, 주지 않으면 키로 직접 조종할 때는 키별 속도(manual_speed),
        자동 모드에서는 GAIT_SPEED를 씁니다.
        """
        if speed is not None:
            return speed
        return self.gait_speed if auto_mode else manual_speed

    def _walk(self, hold_key, duration, auto_mode, phase, step_fn):
        """보행 한 동작을 반복합니다.

        :param hold_key: 직접 조종일 때 이 키를 누르고 있는 동안 반복
        :param duration: 자동 모드일 때 반복할 시간(초)
        :param auto_mode: True면 자동 모드(시간으로 끝냄), False면 키로 끝냄
        :param phase: 위상 각도 진행 규칙 (q01lib_gait.Phase)
        :param step_fn: 위상 각도를 받아 발끝 좌표를 계산하고 다리를 움직이는 함수
        """
        start_time = time.time() if duration else None

        while True:
            # 끝낼 조건
            if auto_mode and duration:
                if time.time() - start_time >= duration:
                    break
                if not self.auto_mode_active:
                    break
            elif not auto_mode:
                if not is_down(hold_key):
                    break

            step_fn(phase.angle)
            phase.advance()

        # 직접 조종이었다면 기본 자세로 정리
        if not auto_mode:
            self.default_position()

    # ------------------------------------------------------------
    # 보행 동작 (W·S·A·D·Q·E)
    # ------------------------------------------------------------
    def forward(self, duration=None, auto_mode=False, speed=None,
                stride_x=None, lift_z=None, hold_key="w"):
        """W 키: 앞으로(+x) 걷습니다. 위상 90 → 450도로 진행합니다.

        speed    : 위상 속도. 생략하면 FORWARD_GAIT_SPEED (자동 모드는 GAIT_SPEED)
        stride_x : x(앞뒤) 진폭,  lift_z : 발을 드는 z 진폭
        """
        speed = self._speed(speed, auto_mode, self.forward_gait_speed)
        sx = self.forward_stride[0] if stride_x is None else stride_x
        lz = self.forward_stride[1] if lift_z is None else lift_z

        def step(angle):
            X1, Z1, X2, Z2 = swing_pair(angle, sx, lz, self.height)
            self.motion.change_coordinates("forward", X1, 0, Z1, X2, 0, Z2)

        self._walk(hold_key, duration, auto_mode, Phase(90, speed, 90, 450), step)

    def backward(self, duration=None, auto_mode=False, speed=None,
                 stride_x=None, lift_z=None, hold_key="s"):
        """S 키: 뒤로(-x) 걷습니다. 위상을 450 → 90도로 거꾸로 진행합니다.

        speed    : 위상 속도. 생략하면 BACKWARD_GAIT_SPEED (자동 모드는 GAIT_SPEED)
        stride_x : x(앞뒤) 진폭,  lift_z : 발을 드는 z 진폭
        """
        speed = self._speed(speed, auto_mode, self.backward_gait_speed)
        sx = self.backward_stride[0] if stride_x is None else stride_x
        lz = self.backward_stride[1] if lift_z is None else lift_z

        def step(angle):
            X1, Z1, X2, Z2 = swing_pair(angle, sx, lz, self.height)
            self.motion.change_coordinates("backward", X1, 0, Z1, X2, 0, Z2)

        self._walk(hold_key, duration, auto_mode, Phase(450, speed, 90, 450, reverse=True), step)

    def _turn(self, move_order, start_angle, duration, auto_mode, speed, hold_key):
        """제자리 회전(yaw) 공통. 발끝이 x와 y로 같은 값만큼 움직여 몸이 z축을 중심으로 돕니다.

        start_angle : 위상 시작 각도 (왼쪽 0도, 오른쪽 180도)
        speed       : 위상 속도. 생략하면 TURN_GAIT_SPEED (자동 모드는 GAIT_SPEED)
        """
        speed = self._speed(speed, auto_mode, self.turn_gait_speed)
        sxy, lz = self.turn_stride

        def step(angle):
            X1, Z1, X2, Z2 = swing_pair(angle, sxy, lz, self.height)
            # y 좌표는 x 좌표와 같게 (회전 효과)
            self.motion.change_coordinates(move_order, X1, X1, Z1, X2, X2, Z2)

        self._walk(hold_key, duration, auto_mode, Phase(start_angle, speed, 0, 360), step)

    def turn_left(self, duration=None, auto_mode=False, speed=None, hold_key="a"):
        """A 키: 제자리에서 왼쪽으로 돕니다(위에서 볼 때 반시계, +yaw). 위상 0도에서 시작합니다."""
        self._turn("turn_left", 0, duration, auto_mode, speed, hold_key)

    def turn_right(self, duration=None, auto_mode=False, speed=None, hold_key="d"):
        """D 키: 제자리에서 오른쪽으로 돕니다(위에서 볼 때 시계, -yaw).

        왼쪽 회전을 좌우로 뒤집은(거울) 동작입니다. 좌우를 뒤집으면 대각선 짝이
        서로 바뀌므로(FL·HR ↔ FR·HL), 위상을 180도 옮겨 180도에서 시작합니다.
        그래서 시작할 때 발끝 자세와 먼저 드는 다리가 왼쪽 회전과 좌우 대칭이 됩니다.
        """
        self._turn("turn_right", 180, duration, auto_mode, speed, hold_key)

    def step_left(self, duration=None, auto_mode=False, speed=None, hold_key="q"):
        """Q 키: 왼쪽(+y) 옆으로 걷습니다. 발끝이 y(좌우)로 움직이고 x는 0입니다."""
        speed = self._speed(speed, auto_mode, self.side_gait_speed)
        sy, lz = self.side_stride

        def step(angle):
            Y1, Z1, Y2, Z2 = swing_pair(angle, sy, lz, self.height)
            self.motion.change_coordinates("step_left", 0, Y1, Z1, 0, Y2, Z2)

        self._walk(hold_key, duration, auto_mode, Phase(90, speed, 90, 450), step)

    def step_right(self, duration=None, auto_mode=False, speed=None, hold_key="e"):
        """E 키: 오른쪽(-y) 옆으로 걷습니다. 왼쪽 이동의 위상을 거꾸로 진행합니다."""
        speed = self._speed(speed, auto_mode, self.side_gait_speed)
        sy, lz = self.side_stride

        def step(angle):
            Y1, Z1, Y2, Z2 = swing_pair(angle, sy, lz, self.height)
            self.motion.change_coordinates("step_right", 0, Y1, Z1, 0, Y2, Z2)

        self._walk(hold_key, duration, auto_mode, Phase(450, speed, 90, 450, reverse=True), step)

# -*- coding: utf-8 -*-
"""
Q01_Lib/walk  |  키보드 보행 (q01_walk_start.py)

W·S·A·D·Q·E 보행과 X·Z 자세, 키를 읽어 동작을 고르는 메인 루프입니다.
"""

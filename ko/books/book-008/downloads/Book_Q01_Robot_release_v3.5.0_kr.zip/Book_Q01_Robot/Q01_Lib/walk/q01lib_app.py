# -*- coding: utf-8 -*-
"""
q01lib_app.py  |  QUAD-01 교육용 라이브러리 · 시작 파일과 로봇 연결

시작 파일(q01_walk_start.py)의 값과 키 배정을 받아 로봇을 준비하고, 메인
루프에서 매번 키를 읽어 동작을 실행합니다.

    보행 키   W·S·A·D·Q·E  누르고 있는 동안 걷기 (떼면 기본 자세)
    자세 키   X·Z          정지 자세 · 이완 자세
    자동 모드 1·2·3        정해진 순서의 동작을 이어서 실행
    종료      0            이완 자세로 옮긴 뒤 스크립트 종료

한 번 반복할 때 키를 읽는 순서
    1. 보행 키   : 눌린 키가 있으면 그 보행을 실행 (키를 뗄 때까지 반복)
    2. 자세 키   : 1이 없을 때만. 쿨다운 시간 안에는 다시 실행하지 않음
    3. 자동 모드 : 1·2가 없을 때만. 쿨다운 시간 안에는 다시 실행하지 않음
    4. 종료 키   : 언제나 확인
    5. 대기 표시 : 1~3이 없었을 때 Text Screen에 대기 문구

콘솔 LOG(영어, 형식은 core/q01lib_log.py)와 Text Screen(Port 0, 한국어)에 쓰는
문구는 이 파일과 auto/q01lib_auto.py, q01lib_robot.py, core/q01lib_motion.py에
적혀 있습니다.

    [  0.0] [PARAMETER] height=99 mm  servo rpm=30          시작할 때 값
    [  2.1] [INPUT]     W    forward                         누른 키
    [  4.5] [ACTION]    forward  2.4 s -> default pose       키를 뗀 뒤 걸은 시간
    [  6.0] [TASK]      auto 1  basic moves  start           자동 모드 (auto)

시작 파일에 적지 않은 값은 아래 DEFAULTS의 값을 씁니다. DEFAULTS에 있는
이름을 시작 파일에 한 줄 적으면 그 값으로 바뀝니다.
"""

import time

from ..core import q01lib_log as L    # 콘솔 LOG 출력 (L.event · L.more · L.key …)
from ..core.q01lib_log import log_traceback
from ..core.q01lib_servo import setup_canonical_servos
from ..core.q01lib_keys import is_down
from ..core.q01lib_key_events import key_label
from .q01lib_robot import QuadRobot
from ..auto.q01lib_auto import AutoModes
from ..core.q01lib_screen import StatusScreen
from ..core.q01lib_welcome import show_welcome, DEFAULT_WELCOME_SEC

# 시작 파일에서 바꿀 수 있는 값과 기본값
DEFAULTS = {
    # 서보와 자세
    "SERVO_RPM": 30,                 # 관절 서보 회전 속도 (ServoMotor.max_rpm)
    "BODY_HEIGHT": 99,               # 기본 자세의 몸체 높이 (발끝 z = -BODY_HEIGHT)
    # 보행 위상 속도 (한 번 반복할 때 보행 위상이 나아가는 각도, 도)
    "FORWARD_GAIT_SPEED": 3.6,       # W 전진
    "BACKWARD_GAIT_SPEED": 4.5,      # S 후진
    "TURN_GAIT_SPEED": 3.75,         # A·D yaw 회전
    "SIDE_GAIT_SPEED": 4.0,          # Q·E 측면 이동
    "GAIT_SPEED": 2.5,               # 자동 모드에서 속도를 정하지 않은 동작
    # 보폭
    "FORWARD_STRIDE": (20, 10),      # W 전진 (x 진폭, 발 드는 z 진폭)
    "BACKWARD_STRIDE": (12, 6),      # S 후진 (x 진폭, 발 드는 z 진폭)
    "TURN_STRIDE": (6, 8),           # A·D yaw 회전 (x·y 진폭, 발 드는 z 진폭)
    "SIDE_STRIDE": (15, 5),          # Q·E 측면 이동 (y 진폭, 발 드는 z 진폭)
    # 키
    "ACTION_COOLDOWN_SEC": 0.5,      # 자세 키·자동 모드 키를 다시 받기까지의 시간(초)
    "WALK_KEYS": {"w": "forward", "s": "backward", "a": "turn_left",
                  "d": "turn_right", "q": "step_left", "e": "step_right"},
    "POSE_KEYS": {"x": "stop", "z": "relax"},
    "AUTO_KEYS": {"1": 1, "2": 2, "3": 3},
    "QUIT_KEY": "0",
    # 콘솔
    "LOG_COLOR": True,               # 콘솔 LOG 색 (콘솔에 <color=...>가 그대로 보이면 False)
    "WELCOME_SEC": DEFAULT_WELCOME_SEC,  # Book-QUAD-01-WALK 시작 화면 유지 시간(초)
}

# 이 프로그램이 콘솔에 쓰는 분류 (분류 칸 폭을 이 가운데 가장 긴 이름에 맞춤)
LOG_CATEGORIES = ("INPUT", "PARAMETER", "STATE", "ACTION", "TASK", "WARN", "ERROR")

# 콘솔에 쓰는 동작 이름 (영어)
WALK_NAMES = {
    "forward": "forward", "backward": "backward",
    "turn_left": "turn left", "turn_right": "turn right",
    "step_left": "side left", "step_right": "side right",
}
POSE_NAMES = {"stop": "stop pose", "relax": "relax pose"}
AUTO_NAMES = {1: "basic moves", 2: "height test", 3: "complex pattern"}

# 동작별 Text Screen 문구
_ACTION_MESSAGES = {
    "forward": "앞으로 이동 중...",
    "backward": "뒤로 이동 중...",
    "turn_left": "왼쪽 회전 중...",
    "turn_right": "오른쪽 회전 중...",
    "step_left": "왼쪽 측면 이동 중...",
    "step_right": "오른쪽 측면 이동 중...",
    "stop": "정지 - 기본 자세로 이동",
    "relax": "모든 모터 이완",
}
_AUTO_MESSAGES = {
    1: "자동 모드 1: 기본 이동 패턴",
    2: "자동 모드 2: 높이별 주행",
    3: "자동 모드 3: 복합 패턴",
}
_START_TEXT = "QUAD-01 보행 시작 · 기본 자세로 옮기는 중..."
_IDLE_TEXT = "대기 중... (키를 눌러 로봇을 조작하세요)"
_AUTO_RUNNING_TEXT = "자동 모드 실행 중... (아무 키나 눌러서 중지)"
_QUIT_TEXT = "프로그램을 종료합니다..."

_WALK_ACTIONS = ("forward", "backward", "turn_left", "turn_right", "step_left", "step_right")
_POSE_ACTIONS = ("stop", "relax")


def print_instructions(s):
    """시작 안내를 콘솔에 출력합니다 (키는 시작 파일의 키 배정에서 만듦)."""
    lines = (L.key_lines("Walk", [(key_label(k), WALK_NAMES[n]) for k, n in s["WALK_KEYS"].items()])
             + L.key_lines("Pose", [(key_label(k), POSE_NAMES[n]) for k, n in s["POSE_KEYS"].items()])
             + L.key_lines("Auto", [(key_label(k), AUTO_NAMES[m]) for k, m in s["AUTO_KEYS"].items()])
             + L.key_lines("Quit", [(key_label(s["QUIT_KEY"]), "relax and quit")]))
    lines.append(" Hold a walk key to walk; release it to stop.")
    L.banner("QUAD-01 WALK   (Book-QUAD-01-WALK)", lines)


def print_parameters(s):
    """시작할 때의 값 (먼저 바꿔 볼 값)을 콘솔에 남깁니다."""
    def pair(v):
        return f"{v[0]:g}/{v[1]:g}"
    L.event("PARAMETER", f"height={s['BODY_HEIGHT']:g} mm  servo rpm={s['SERVO_RPM']:g}")
    L.more(f"speed   fwd {s['FORWARD_GAIT_SPEED']:g}  back {s['BACKWARD_GAIT_SPEED']:g}  "
           f"turn {s['TURN_GAIT_SPEED']:g}  side {s['SIDE_GAIT_SPEED']:g}")
    L.more(f"stride  fwd {pair(s['FORWARD_STRIDE'])}  back {pair(s['BACKWARD_STRIDE'])}  "
           f"turn {pair(s['TURN_STRIDE'])}  side {pair(s['SIDE_STRIDE'])}")


class RobotApp:
    """시작 파일의 값으로 로봇을 준비하고, 메인 루프를 한 번씩 진행하는 클래스."""

    def __init__(self, script_values: dict):
        """script_values: 시작 파일의 globals(). 대문자 이름의 값만 읽습니다.
        준비하다 오류가 나면(시작 파일의 값 · 키 배정 · Port) 콘솔에 영어로 알리고, run()은 바로 끝납니다.
        """
        self.ready = False
        try:
            self._setup(script_values)
            self.ready = True
        except Exception as e:
            L.setup_failed(e, "q01_walk_start.py")

    def _setup(self, script_values: dict):
        s = dict(DEFAULTS)
        for name, value in script_values.items():
            if name in DEFAULTS:
                s[name] = value

        # 0. 콘솔 준비 · 키 배정 확인 · 사용 방법 출력
        L.configure(LOG_CATEGORIES, s["LOG_COLOR"])
        walk_map = self._checked(s["WALK_KEYS"], _WALK_ACTIONS, "WALK_KEYS")
        pose_map = self._checked(s["POSE_KEYS"], _POSE_ACTIONS, "POSE_KEYS")
        auto_map = self._checked(s["AUTO_KEYS"], tuple(_AUTO_MESSAGES), "AUTO_KEYS")
        print_instructions(s)
        print_parameters(s)

        # 1. 화면 준비 (Text Screen, Port 0): 부품 기본 글자("T") 대신 시작 문구를 먼저 씀
        self.screen = StatusScreen()
        show_welcome(self.screen, "Book-QUAD-01-WALK", s["WELCOME_SEC"])
        self.screen.show(_START_TEXT)

        # 2. 로봇 준비 (기본 자세로 이동)
        setup_canonical_servos()  # shared 12DOF contract
        self.robot = QuadRobot(servo_rpm=s["SERVO_RPM"],
                               body_height=s["BODY_HEIGHT"],
                               gait_speed=s["GAIT_SPEED"],
                               forward_gait_speed=s["FORWARD_GAIT_SPEED"],
                               backward_gait_speed=s["BACKWARD_GAIT_SPEED"],
                               turn_gait_speed=s["TURN_GAIT_SPEED"],
                               side_gait_speed=s["SIDE_GAIT_SPEED"],
                               forward_stride=s["FORWARD_STRIDE"],
                               backward_stride=s["BACKWARD_STRIDE"],
                               turn_stride=s["TURN_STRIDE"],
                               side_stride=s["SIDE_STRIDE"])
        self.auto = AutoModes(self.robot)
        L.event("STATE", f"default pose  height={s['BODY_HEIGHT']:g} mm")

        # 3. 키 배정: (키, 실행할 함수, 화면 문구, 콘솔 이름)
        self.walk_keys = [(key, getattr(self.robot, name), _ACTION_MESSAGES[name], WALK_NAMES[name])
                          for key, name in walk_map]
        self.pose_keys = [(key, getattr(self.robot, name), _ACTION_MESSAGES[name], POSE_NAMES[name])
                          for key, name in pose_map]
        self.auto_keys = [(key, mode, _AUTO_MESSAGES[mode], f"auto {mode}  {AUTO_NAMES[mode]}")
                          for key, mode in auto_map]
        self.quit_key = s["QUIT_KEY"]
        self.action_cooldown = s["ACTION_COOLDOWN_SEC"]

        # 실행 중에 바뀌는 상태 값
        self.current_key = None          # 마지막으로 실행한 보행 키
        self.last_action_time = 0        # 자세 키·자동 모드를 마지막으로 실행한 시각
        self._quit = False               # 종료 키를 눌렀는가


    @staticmethod
    def _checked(mapping: dict, allowed: tuple, label: str) -> list:
        """키 배정의 동작 이름이 쓸 수 있는 이름인지 확인합니다."""
        for key, name in mapping.items():
            if name not in allowed:
                raise ValueError(f"{label} '{key}': unknown action '{name}'. "
                                 f"Use one of: {', '.join(map(str, allowed))}")
        return list(mapping.items())

    # ------------------------------------------------------------
    # 반복: 메인 루프
    # ------------------------------------------------------------
    def running(self) -> bool:
        """종료 키를 누르기 전까지 True."""
        return not self._quit

    def update(self):
        """메인 루프에서 매번 부릅니다. 키를 한 번 읽고 동작을 실행합니다."""
        action_occurred = False

        # 1. 보행 키 (누르고 있는 동안 반복)
        for key, action, message, name in self.walk_keys:
            if is_down(key):
                self._stop_auto_mode_if_active()
                self.screen.show(message)
                L.event("INPUT", f"{L.key(key_label(key), 4)} {name}")
                start = time.time()
                action(hold_key=key)
                L.event("ACTION", f"{name}  {time.time() - start:.1f} s -> default pose")
                self.current_key = key
                action_occurred = True
                break

        # 2. 자세 키 (보행 키가 없을 때만, 쿨다운 적용)
        if not action_occurred:
            for key, action, message, name in self.pose_keys:
                current_time = time.time()
                if is_down(key) and current_time - self.last_action_time > self.action_cooldown:
                    self._stop_auto_mode_if_active()
                    self.screen.show(message)
                    L.event("INPUT", f"{L.key(key_label(key), 4)} {name}")
                    action()
                    self.last_action_time = current_time
                    action_occurred = True
                    break

        # 3. 자동 모드 키 (다른 동작이 없을 때만, 쿨다운 적용)
        if not action_occurred:
            for key, mode, message, name in self.auto_keys:
                current_time = time.time()
                if is_down(key) and current_time - self.last_action_time > self.action_cooldown:
                    self.screen.show(message)
                    L.event("INPUT", f"{L.key(key_label(key), 4)} {name}")
                    self.auto.start(mode)
                    self.last_action_time = current_time
                    action_occurred = True
                    break

        # 4. 종료 키
        if is_down(self.quit_key):
            self.screen.show(_QUIT_TEXT)
            L.event("INPUT", f"{L.key(key_label(self.quit_key), 4)} quit")
            self.safe_shutdown()
            self._quit = True
            return

        # 5. 대기 상태
        if not action_occurred:
            if self.current_key and not is_down(self.current_key):
                self.current_key = None
            self._update_idle_status()

    def run(self):
        """종료 키를 누를 때까지 update()를 반복합니다.
        오류가 나도 이완 자세로 옮긴 뒤 끝냅니다.
        """
        if not self.ready:
            return
        L.event("STATE", "ready")
        try:
            while self.running():
                self.update()

        except KeyboardInterrupt:
            pass  # RoboCo Space: extra shutdown flow disabled

        except Exception as e:
            L.event("ERROR", f"unexpected error: {e}")
            log_traceback()
            self._shutdown_after_error()

        finally:
            L.event("STATE", "end")

    # ------------------------------------------------------------
    # 보조
    # ------------------------------------------------------------
    def _stop_auto_mode_if_active(self):
        """자동 모드가 켜져 있으면 중지합니다."""
        if self.robot.auto_mode_active:
            self.auto.stop()
            return True
        return False

    def _update_idle_status(self):
        """대기 중 Text Screen 문구."""
        if not self.robot.auto_mode_active:
            self.screen.show(_IDLE_TEXT)
        else:
            self.screen.show(_AUTO_RUNNING_TEXT)

    def _shutdown_after_error(self):
        """오류 · 중단 뒤의 종료. 종료 중에 다시 오류가 나도 영어로 남기고 끝냅니다."""
        try:
            self.safe_shutdown()
        except Exception as e:
            L.event("ERROR", f"shutdown failed: {e}")
            log_traceback()

    def safe_shutdown(self):
        """자동 모드를 끄고 이완 자세로 옮긴 뒤 끝냅니다."""
        L.event("STATE", "shutting down")
        if self.robot.auto_mode_active:
            self.auto.stop()
        self.robot.relax()

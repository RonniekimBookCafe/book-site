# -*- coding: utf-8 -*-
"""
q01lib_leg2_ik.py  |  QUAD-01 교육용 라이브러리 · 다리 테스트 2 · IK 테스트

시작 파일 q01_leg2_ik_start.py · 로봇 Book-QUAD-01-LEG2

고른 다리의 발끝 목표 좌표를 키로 조금씩 바꿉니다. 좌표가 바뀔 때마다
역기구학(IK)이 계산한 관절 각도와, 그 각도로 다시 계산한 발끝 좌표(FK)를
콘솔에 보여 줍니다(영어, 형식은 core/q01lib_log.py). 값과 키는 시작 파일에 있습니다.

    [  6.0] [INPUT]     W    foot x +
    [  6.0] [STATE]     FL foot target  x=  10.0  y=  10.0  z= -99.0
                        IK     a= 84  b= -51  c= 101
                        servo  HX= 84  HY=141  KN=101  (ports 4 3 2)
                        FK     x=   9.6  y=  10.3  z= -98.5

    발끝 목표 (x, y, z)
      -> core/q01lib_ik.coordinate_to_angle()   IK 각도 (a, b, c)
      -> LegMotion.to_servo_angles()            서보 논리 각도 (HX, HY, KN)
      -> LegMotion.move_to()                    서보 전송 → 다리가 움직임
      -> core/q01lib_ik.angle_to_coordinate()   FK로 다시 계산한 발끝 좌표 (확인용)

    W · S / A · D / E · Q   발끝 x / y / z를 STEP_MM씩 + · -
    I                       발끝이 큰 원(x-z 평면)을 한 바퀴 그림 (자동)
    K                       고른 다리만 기본 자세로
    U · O · J · L           다리 고르기 (공통, q01lib_leg_app.py)

나머지 세 다리는 그 자리에 둡니다. 시작할 때 네 다리를 먼저 기본 자세로 옮깁니다.

[원 그리기]
원의 중심(CIRCLE_CENTER_X · CIRCLE_CENTER_Z)과 반지름(CIRCLE_RADIUS)은 시작 파일에
있습니다. 기본값(중심 x 40 · z -80, 반지름 40)은 도달 범위(25~130) 안에서 관절이
0 · 180도 제한에 3도 넘게 다가가지 않고, 발끝이 엉덩이보다 40 넘게 아래에 있는 가장
큰 원입니다. 고른 다리의 발끝을 원의 앞쪽 끝으로 옮긴 뒤, 점 하나마다
CIRCLE_STEP_SEC씩 기다리며 원을 그리고, 끝나면 그 다리의 기본 자세 위치로 돌아옵니다.
원 위에 갈 수 없는 점이 하나라도 있으면 움직이지 않고 이유를 알려 줍니다.

로봇 화면(Text Screen, 8줄 · 모양과 색은 leg_common/q01lib_leg_screen.py). 원을 그리는
동안에도 같은 모양이고, 첫 줄 끝에 "원"이, 마지막 줄에 키 대신 "F3 멈춤 · F2 기본 자세"가
나옵니다.
    IK · 다리 FL
    ------------------
    목표 x 0  y 10  z -99       발끝 목표 좌표
    IK a 84  b -57  c 102       IK가 계산한 관절 각도
    서보 HX 84  HY 147  KN 102  좌우 보정 뒤 서보에 보낸 논리 각도
    거리 100  FK 오차 0.7       엉덩이~발끝 거리(25~130) · FK로 다시 계산한 좌표와의 차이
    ------------------
    WS x  AD y  EQ z
"""

import math

from ..core import q01lib_ports as ports
from ..core.q01lib_ik import coordinate_to_angle, angle_to_coordinate, is_valid_point
from ..core.q01lib_key_events import key_label
from ..leg_common import q01lib_leg_screen as scr
from ..core import q01lib_log as L    # 콘솔 LOG 출력 (L.event · L.more · L.key …)

AXES = ("x", "y", "z")


class IKTest:
    """다리 테스트 2 · IK 테스트."""

    TITLE = "IK 테스트"
    HEADER = "QUAD-01 LEG TEST 2  IK   (Book-QUAD-01-LEG2)"
    LOG_CATEGORIES = ()   # 공통 분류 밖에 이 테스트가 콘솔에 쓰는 분류 (열 맞추기)
    SHORT = "IK"
    START_FILE = "q01_leg2_ik_start.py"
    USES_LEG_SELECT = True
    VALUE_NAMES = ("KEY_REPEAT_SEC", "STEP_MM", "MOVE_STEPS",
                   "CIRCLE_CENTER_X", "CIRCLE_CENTER_Z", "CIRCLE_RADIUS", "CIRCLE_STEPS",
                   "CIRCLE_STEP_SEC", "CIRCLE_MOVE_STEPS",
                   "MOVE_KEYS", "CIRCLE_KEY", "LEG_RESET_KEY")

    def __init__(self, robot, settings):
        self.robot = robot
        self.motion = robot.motion
        self.s = settings
        self.last = None            # 고른 다리의 마지막 확인 결과 (화면 표시용, report()가 씀)

    # ------------------------------------------------------------
    # 키 · 화면 · 콘솔 안내
    # ------------------------------------------------------------
    def actions(self):
        """(키, 콘솔에 남길 설명, 실행할 함수, 걸린 시간을 남길지) 목록."""
        s = self.s
        items = []
        for key, direction in s["MOVE_KEYS"].items():
            items.append((key, f"foot {self._direction_text(direction)}",
                          lambda direction=direction: self.move_foot(direction), False))
        items.append((s["CIRCLE_KEY"], "draw a circle with the foot", self.circle, True))
        items.append((s["LEG_RESET_KEY"], "selected leg to stand pose", self.reset_leg, False))
        return items

    def repeat_keys(self):
        """누르고 있으면 KEY_REPEAT_SEC마다 다시 실행하는 키."""
        return list(self.s["MOVE_KEYS"])

    @staticmethod
    def _direction_text(direction):
        """(1, 0, 0) → "x +" """
        return " ".join(f"{axis} {'+' if d > 0 else '-'}" for axis, d in zip(AXES, direction) if d)

    def _move_pairs(self):
        """화면 · 콘솔용: 축마다 (+쪽 키, -쪽 키). 예: {"x": ("W", "S"), ...}"""
        keys = {}
        for key, direction in self.s["MOVE_KEYS"].items():
            for axis, d in zip(AXES, direction):
                if d:
                    keys[(axis, d > 0)] = key_label(key)
        return {axis: (keys.get((axis, True), "?"), keys.get((axis, False), "?")) for axis in AXES}

    def guide(self):
        """콘솔 키 안내 (영어)."""
        s = self.s
        mv = {axis: L.key("/".join(pair)) for axis, pair in self._move_pairs().items()}
        return [
            f" Foot   {mv['x']} x fwd/back   {mv['y']} y left/right   {mv['z']} z up/down",
            f"        {s['STEP_MM']} per key   {L.key(key_label(s['LEG_RESET_KEY']))} selected leg to stand",
            f" Test   {L.key(key_label(s['CIRCLE_KEY']))} circle (x-z, center x={s['CIRCLE_CENTER_X']} "
            f"z={s['CIRCLE_CENTER_Z']}, r={s['CIRCLE_RADIUS']})",
            " Frame  origin at hip  x fwd(+)  y left(+)  z up(+)",
        ]

    def value_lines(self):
        """화면 가운데 네 줄: 목표 좌표 · IK 각도 · 서보 각도 · 거리와 FK 오차 (또는 알림)."""
        x, y, z = self.motion.points[self.robot.leg]
        lines = [scr.xyz(round(x), round(y), round(z), "목표 ")]
        last = self.last
        if last is None or last["ik"] is None:
            lines += ["IK -", self.robot.servo_text(prefix="서보 "), scr.paint("갈 수 없는 좌표", "warn")]
            return lines
        a, b, c = last["ik"]
        lines += [f"IK a {a}  b {b}  c {c}",
                  scr.joints(last["servo"], "angle", "서보 ")]
        if last["problem"]:
            lines.append(f"거리 {last['reach']:.0f}  {scr.paint('관절 제한에 닿음', 'warn')}")
        else:
            error = f"{last['error']:.1f}"
            lines.append(f"거리 {last['reach']:.0f}  FK 오차 {scr.paint(error, 'ok')}")
        return lines

    def idle_page(self):
        """대기 화면: 제목(고른 다리) / 값 네 줄 / 발끝 이동 키."""
        mv = self._move_pairs()
        footer = scr.keys_line([(mv[a][0] + mv[a][1], a) for a in AXES])
        return f"IK · 다리 {self.robot.leg_name}", self.value_lines(), footer

    def help_lines(self, leg_keys):
        """F1 키 안내 화면 (이 테스트의 키). leg_keys: 다리 고르기 키 (예: "U O J L")."""
        s = self.s
        mv = self._move_pairs()
        return [scr.keys_line([(leg_keys, "다리")]),
                scr.keys_line([(mv["x"][0] + mv["x"][1], "앞뒤 x"), (mv["y"][0] + mv["y"][1], "좌우 y")]),
                scr.keys_line([(mv["z"][0] + mv["z"][1], "위아래 z"), (key_label(s["CIRCLE_KEY"]), "원")]),
                scr.keys_line([(key_label(s["LEG_RESET_KEY"]), "고른 다리 기본 자세")])]

    def enter(self):
        """시작할 때: 네 다리를 기본 자세로 옮기고 고른 다리의 값을 보여 줍니다."""
        self.robot.stand()
        self.report()

    def on_leg_selected(self):
        self.report()

    def on_stand(self):
        self.report()

    def after_stop(self):
        """원 그리기를 멈춘 뒤: 보낸 각도를 맞추고 지금 위치를 보여 줍니다."""
        self.robot.sync_from_motion()
        self.report()

    # ------------------------------------------------------------
    # IK 계산과 확인
    # ------------------------------------------------------------
    def solve(self, leg, point):
        """발끝 좌표 하나를 IK로 풀어 봅니다(서보는 움직이지 않음).

        :return: (IK 각도, 서보 논리 각도, 문제 설명). 문제가 없으면 설명은 None
        """
        if not is_valid_point(point):
            return None, None, f"reach outside {ports.REACH_MIN}-{ports.REACH_MAX}"
        try:
            ik = coordinate_to_angle(*point)
        except ValueError:
            return None, None, "no IK solution for the leg lengths"
        servo = self.motion.to_servo_angles(leg, ik)
        if any(v <= ports.LOGICAL_MIN_DEG or v >= ports.LOGICAL_MAX_DEG for v in servo):
            return ik, servo, f"joint at {ports.LOGICAL_MIN_DEG}-{ports.LOGICAL_MAX_DEG} deg limit"
        return ik, servo, None

    def report(self):
        """고른 다리의 발끝 목표 · IK 각도 · 서보 각도 · FK 확인값을 출력합니다.

        로봇 화면은 동작이 끝난 뒤 다리 테스트 프로그램(q01lib_leg_app.py)이 idle_page()로 씁니다.
        """
        leg = self.robot.leg
        name = self.robot.leg_name
        x, y, z = self.motion.points[leg]
        ik, servo, problem = self.solve(leg, [x, y, z])
        hx, hy, kn = ports.LEG_JOINT_PORTS[leg]
        L.event("STATE", f"{name} foot target  {L.xyz_text(x, y, z)}")
        if ik is None:
            L.event("WARN", problem)
            self.last = None
            return
        fx, fy, fz = angle_to_coordinate(*ik)
        L.more(f"IK     a={ik[0]:3}  b={ik[1]:4}  c={ik[2]:3}")
        L.more(f"servo  HX={servo[0]:3}  HY={servo[1]:3}  KN={servo[2]:3}  (ports {hx} {hy} {kn})")
        L.more(f"FK     {L.xyz_text(fx, fy, fz)}")
        if problem:
            L.event("WARN", problem)
        self.last = self.measure()

    def measure(self):
        """고른 다리의 지금 발끝 좌표를 확인한 값 (화면 표시용, 콘솔에는 남기지 않음)."""
        leg = self.robot.leg
        x, y, z = self.motion.points[leg]
        ik, servo, problem = self.solve(leg, [x, y, z])
        if ik is None:
            return None
        fx, fy, fz = angle_to_coordinate(*ik)
        return {"ik": ik, "servo": servo, "problem": problem,
                "reach": math.sqrt(x * x + y * y + z * z),
                "error": math.sqrt((fx - x) ** 2 + (fy - y) ** 2 + (fz - z) ** 2)}

    # ------------------------------------------------------------
    # 다리 움직이기
    # ------------------------------------------------------------
    def move_foot(self, direction):
        """고른 다리의 발끝을 direction × STEP_MM만큼 옮깁니다."""
        leg = self.robot.leg
        step = self.s["STEP_MM"]
        target = [c + d * step for c, d in zip(self.motion.points[leg], direction)]
        ik, servo, problem = self.solve(leg, target)
        if ik is None:
            L.event("WARN", f"{self.robot.leg_name} cannot reach ({target[0]:.0f}, {target[1]:.0f}, "
                            f"{target[2]:.0f}), foot kept")
            L.more(problem)
            return
        positions = [list(p) for p in self.motion.points]
        positions[leg] = target
        self.motion.move_to(positions, self.s["MOVE_STEPS"])
        self.robot.sync_from_motion()
        self.report()

    def circle(self):
        """고른 다리의 발끝이 x-z 평면에서 원을 한 바퀴 그립니다.

        원의 앞쪽 끝으로 옮김 → 점마다 CIRCLE_STEP_SEC씩 기다리며 한 바퀴 → 기본 자세 위치로.
        """
        s = self.s
        leg = self.robot.leg
        name = self.robot.leg_name
        y = self.robot.stand_positions()[leg][1]
        cx, cz, r, n = s["CIRCLE_CENTER_X"], s["CIRCLE_CENTER_Z"], s["CIRCLE_RADIUS"], s["CIRCLE_STEPS"]
        path = [[cx + r * math.cos(2 * math.pi * k / n), y,
                 cz + r * math.sin(2 * math.pi * k / n)] for k in range(n + 1)]
        ranges = [[180, 0], [180, 0], [180, 0]]
        for p in path:
            ik, servo, problem = self.solve(leg, p)
            if problem:
                L.event("WARN", f"{name} circle point ({p[0]:.0f}, {p[1]:.0f}, {p[2]:.0f}), circle skipped")
                L.more(problem)
                return
            for i, v in enumerate(servo):
                ranges[i] = [min(ranges[i][0], v), max(ranges[i][1], v)]
        L.event("TASK", f"{name} circle  x={cx} z={cz} r={r}  {n} points  ~{n * s['CIRCLE_STEP_SEC']:.1f} s")
        L.more(f"servo range  HX {ranges[0][0]}-{ranges[0][1]}  HY {ranges[1][0]}-{ranges[1][1]}  "
               f"KN {ranges[2][0]}-{ranges[2][1]}")
        self._glide(leg, path[0])
        for p in path[1:]:
            self._step_to(leg, p)
        self._glide(leg, self.robot.stand_positions()[leg])
        self.robot.sync_from_motion()
        self.report()

    def _glide(self, leg, target):
        """발끝을 target까지 CIRCLE_MOVE_STEPS 단계로 옮깁니다 (단계마다 CIRCLE_STEP_SEC)."""
        steps = max(1, self.s["CIRCLE_MOVE_STEPS"])
        start = list(self.motion.points[leg])
        for i in range(1, steps + 1):
            self._step_to(leg, [a + (b - a) * i / steps for a, b in zip(start, target)])

    def _step_to(self, leg, point):
        """발끝을 point로 옮기고 화면을 고친 뒤 CIRCLE_STEP_SEC 기다립니다 (멈춤 키 확인)."""
        self.motion.points[leg] = list(point)
        self.motion.run()
        self.robot.sync_from_motion()
        self.last = self.measure()
        # 대기 화면과 같은 8줄: 마지막 줄만 키 안내 대신 멈춤 키 안내
        self.robot.show_running(f"IK · 다리 {self.robot.leg_name} 원", *self.value_lines())
        self.robot.wait(self.s["CIRCLE_STEP_SEC"])

    def reset_leg(self):
        """고른 다리만 기본 자세의 발끝 좌표로 옮깁니다."""
        positions = [list(p) for p in self.motion.points]
        positions[self.robot.leg] = self.robot.stand_positions()[self.robot.leg]
        self.motion.move_to(positions, self.s["MOVE_STEPS"])
        self.robot.sync_from_motion()
        self.report()

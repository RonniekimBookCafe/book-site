# -*- coding: utf-8 -*-
"""
Q01_Lib/leg2_ik  |  다리 테스트 2 · IK 테스트 (q01_leg2_ik_start.py · Book-QUAD-01-LEG2)

    q01lib_leg2_ik.py   IKTest: 발끝 x · y · z 좌표를 키로 바꿈 (IK 각도 · FK 확인 · 도달 범위 · 관절 제한)

키를 읽는 반복 부분과 로봇은 leg_common 폴더를 함께 씁니다.
"""

# -*- coding: utf-8 -*-
"""
q01lib_leg3_combined_tests.py  |  QUAD-01 교육용 라이브러리 · 다리 테스트 3 · 복합 테스트의 좌표와 순서

발끝 좌표 목록을 차례로 보내며 역기구학(IK)이 맞게 계산하는지, 다리가 어디까지
닿는지, 네 다리를 조합해 움직일 때 다리 자세와 순서가 맞는지를 확인합니다.
로봇은 공중에 매달아 두므로 발이 바닥에 닿지 않습니다.

    [IK 검증 · FL]      1 기본 이동 · 2 극단 위치 · 3 유효 범위
    [IK 검증 · 네 다리]  4 네 다리 차례로 · 5 관절 제한
    [복합 동작]         6 다리 하나씩 들기 · 7 대각선 두 다리 · 8 3점 지지 자세 · 9 보행 순서
    (키는 시작 파일 q01_leg3_combined_start.py의 TEST_KEYS에서 바꿉니다)

[좌표계]
발끝 좌표는 보행과 같은 다리 좌표계입니다. 원점은 각 다리의 엉덩이 관절입니다.
    x : 앞 (+)     y : 왼쪽 (+)     z : 위 (+)
발끝은 엉덩이보다 아래에 있으므로 서 있을 때 z는 음수입니다(기본 자세 z = -99).
y는 다리마다 몸 바깥쪽 방향이 다릅니다. 왼쪽 다리(FL·HL)는 +y가 바깥쪽,
오른쪽 다리(HR·FR)는 -y가 바깥쪽입니다.

[한 좌표의 확인 결과]  콘솔은 영어 (형식은 core/q01lib_log.py)
    target    목표 발끝 좌표
    IK        coordinate_to_angle()이 계산한 (a, b, c)
    servo     좌우 보정 뒤 서보에 보낸 논리 각도 (HX, HY, KN)
    FK        서보 각도로 다시 계산한 발끝 좌표와 목표까지의 거리(err, 오차)
    limit     0도나 180도 제한에 닿은 관절. 이때 발끝은 목표에 닿지 않음

    [  3.5] [TASK]      FL fwd  x+30          [30, 10, -99]
                        IK     a= 84  b= -31  c=  94
                        servo  HX= 84  HY=121  KN= 94
                        FK     x=  29.6  y=  10.4  z= -99.1   err=0.6

여러 좌표를 한 번에 확인하는 테스트(4 · 5 · 6)는 좌표 하나를 한 줄로 씁니다.

    [271.1] [METRIC]    FL basic      target           HX  HY  KN  err limit
                        stand         [0, 10, -99]     84 147 102  0.7
                        fwd           [30, 10, -99]    84 121  94  0.6

케이스 이름은 로봇 화면용 한국어와 콘솔용 영어를 함께 적습니다.
"""

import time

from ..core import q01lib_ports as ports
from ..leg_common.q01lib_leg_check import check_point, side_word, side_word_en
from ..core import q01lib_log as L    # 콘솔 LOG 출력 (L.event · L.more · L.key …)

NAME_WIDTH = 13          # 한 줄 요약의 케이스 이름 칸
TARGET_WIDTH = 16        # 한 줄 요약의 좌표 칸


def default_y(leg):
    """다리별 기본 y 값 (왼쪽 +10, 오른쪽 -10)."""
    return ports.FOOT_Y_OFFSET if leg in ports.LEFT_LEGS else -ports.FOOT_Y_OFFSET


class LegCombinedTests:
    """IK 검증 테스트를 실행하는 클래스.

    motion은 core/q01lib_motion.py의 LegMotion입니다. 서보 속도는 settings의 SERVO_RPM입니다.
    """

    def __init__(self, motion, settings, on_case=None, wait=None, on_result=None, on_pose=None):
        """on_case: 확인하는 좌표·단계가 바뀔 때마다 그 이름으로 부르는 함수 (로봇 화면 표시용).
        wait: 기다리는 함수. 다리 테스트 프로그램은 멈춤 키를 확인하며 기다리는 LegTestRobot.wait를 넘김.
        on_result: 좌표 하나를 확인할 때마다 (다리, 좌표, check_point 결과)로 부르는 함수 (로봇 화면 표시용).
        on_pose: 네 다리를 함께 옮길 때마다 부르는 함수 (로봇 화면 표시용).
        """
        self.motion = motion
        self.s = settings
        self.rpm = settings["SERVO_RPM"]
        self.names = ports.LEG_NAMES
        self.on_case = on_case
        self.wait = wait if wait is not None else time.sleep
        self.on_result = on_result
        self.on_pose = on_pose

    def case(self, label, leg=None, pos=None):
        """지금 확인하는 좌표·단계의 이름(한국어)을 화면 쪽에 알립니다. 괄호 안 설명은 뺌.

        다리 하나의 좌표를 확인하는 단계는 leg · pos를 함께 넘깁니다. 화면은 옮기기 전에
        그 좌표의 확인 결과를 바로 보여 주므로, 단계가 바뀌어도 화면 모양이 그대로입니다.
        """
        if self.on_case is not None:
            self.on_case(label.split(" (")[0], leg, pos)

    def result(self, leg, pos, r):
        """좌표 하나의 확인 결과를 화면 쪽에 알립니다."""
        if self.on_result is not None:
            self.on_result(leg, pos, r)

    # ================================================================
    # 이동
    # ================================================================
    def stand_positions(self):
        h = self.s["BODY_HEIGHT"]
        return [[0, default_y(leg), -h] for leg in range(4)]

    def default_position(self):
        """네 다리를 기본 자세로 옮깁니다."""
        self.move_all(self.stand_positions(), show=False)
        L.event("STATE", "stand pose")

    def move_all(self, targets, show=True):
        """네 다리를 MOVE_ALL_STEPS 단계로 나눠 함께 옮깁니다(단계 사이 쉼 없음).

        show가 False이면 화면 쪽에 알리지 않습니다 (테스트 끝에 기본 자세로 돌아갈 때).
        """
        self.motion.move_to([list(t) for t in targets], self.s["MOVE_ALL_STEPS"], self.rpm)
        if show and self.on_pose is not None:
            self.on_pose()

    def move_one(self, leg, target):
        """다리 하나를 MOVE_SINGLE_STEPS 단계로 나눠 옮깁니다(단계마다 MOVE_SINGLE_DELAY 쉼)."""
        steps = self.s["MOVE_SINGLE_STEPS"]
        point = self.motion.points[leg]
        start = list(point)
        delta = [(t - c) / steps for t, c in zip(target, start)]
        for _ in range(steps):
            for j in range(3):
                point[j] += delta[j]
            self.motion.run(self.rpm)
            self.wait(self.s["MOVE_SINGLE_DELAY"])

    def snapshot(self):
        return [list(p) for p in self.motion.points]

    # ================================================================
    # 확인 결과 출력
    # ================================================================
    def report(self, leg, en, pos):
        """좌표 하나의 확인 결과를 여러 줄로 출력합니다. 서보에 보낼 수 있으면 True."""
        r = check_point(self.motion, leg, pos)
        self.result(leg, pos, r)
        L.event("TASK", f"{ports.LEG_NAMES[leg]} {en:<18} {self.fmt(pos)}")
        if not r["ok"]:
            L.event("WARN", f"invalid: {r['reason']}")
            return False
        a, b, c = r["ik"]
        hx, hy, kn = r["servo"]
        fx, fy, fz = r["fk"]
        L.more(f"IK     a={a:3}  b={b:4}  c={c:4}")
        L.more(f"servo  HX={hx:3}  HY={hy:3}  KN={kn:3}")
        L.more(f"FK     {L.xyz_text(fx, fy, fz)}   err={r['error']:.1f}")
        if r["limited"]:
            L.event("WARN", f"{' '.join(r['limited'])} at 0/180 deg limit: foot misses the target")
        return True

    @staticmethod
    def table_head(title):
        """한 줄 요약 표의 머리 줄."""
        L.event("METRIC", f"{title:<{NAME_WIDTH}} {'target':<{TARGET_WIDTH}} HX  HY  KN  err limit")

    def report_short(self, leg, en, pos):
        """한 줄 요약: 이름, 좌표, 서보 각도, FK 오차, 제한 (표의 한 줄)."""
        r = check_point(self.motion, leg, pos)
        self.result(leg, pos, r)
        head = f"{en:<{NAME_WIDTH}} {self.fmt(pos):<{TARGET_WIDTH}}"
        if not r["ok"]:
            L.more(f"{head}invalid  reach={r['reach']:.1f}")
            return False
        hx, hy, kn = r["servo"]
        L.more(f"{head}{hx:3} {hy:3} {kn:3} {r['error']:4.1f} {' '.join(r['limited'])}".rstrip())
        return True

    @staticmethod
    def fmt(pos):
        return "[" + ", ".join(f"{v:g}" if isinstance(v, (int, float)) else str(v) for v in pos) + "]"

    # ================================================================
    # 1 · 2 · 3  다리 하나 (FL)
    # ================================================================
    def fl_basic(self):
        """1. FL 다리 기본 위치 변화: 기본 자세에서 앞·뒤·위·아래·좌우로 옮겨 IK와 FK를 확인."""
        original = list(self.motion.points[0])
        cases = [
            ("기본 자세", "stand", [0, 10, -99]),
            ("앞으로 (x +30)", "fwd  x+30", [30, 10, -99]),
            ("뒤로 (x -30)", "back x-30", [-30, 10, -99]),
            ("위로 (z -70, 발을 듦)", "up   z-70", [0, 10, -70]),
            ("아래로 (z -120, 다리를 폄)", "down z-120", [0, 10, -120]),
            ("y +20 (몸 바깥쪽)", "y+20 out", [0, 30, -99]),
            ("y -20 (몸 안쪽)", "y-20 in", [0, -10, -99]),
        ]
        for name, en, pos in cases:
            self.case(f"FL {name}", 0, pos)
            self.move_one(0, pos)
            self.report(0, en, pos)
            self.wait(self.s["CASE_HOLD_SEC"])
        self.move_one(0, original)

    def fl_extreme(self):
        """2. FL 다리 극단 위치: 닿을 수 있는 끝 근처. 유효하지 않은 좌표는 보내지 않음."""
        original = list(self.motion.points[0])
        cases = [
            ("앞+위", "fwd+up", [50, 10, -70]),
            ("뒤+위", "back+up", [-50, 10, -70]),
            ("앞+아래", "fwd+down", [50, 10, -120]),
            ("위+바깥쪽", "up+outward", [0, 40, -50]),
            ("앞+위+바깥쪽", "fwd+up+outward", [40, 30, -60]),
        ]
        for name, en, pos in cases:
            self.case(f"FL {name}", 0, pos)
            if check_point(self.motion, 0, pos)["ok"]:
                self.move_one(0, pos)
            self.report(0, en, pos)
            self.wait(self.s["CASE_HOLD_SEC"])
        self.move_one(0, original)

    def fl_validity(self):
        """3. FL 다리 유효 범위: 도달 범위 검사(25~130)만 하고 서보는 움직이지 않음."""
        L.event("TASK", f"reach check only ({ports.REACH_MIN}-{ports.REACH_MAX}), servos not moved")
        original = list(self.motion.points[0])
        cases = [
            ("너무 높음", "too high", [0, 10, -20]),
            ("너무 낮음", "too low", [0, 10, -140]),
            ("너무 앞", "too far fwd", [100, 10, -99]),
            ("복합 초과", "mixed over", [70, 50, -70]),
        ]
        L.event("METRIC", f"{'case':<{NAME_WIDTH}} {'target':<{TARGET_WIDTH}} reach  result")
        for name, en, pos in cases:
            self.case(f"FL {name}", 0, pos)
            r = check_point(self.motion, 0, pos)
            self.result(0, pos, r)
            L.more(f"{en:<{NAME_WIDTH}} {self.fmt(pos):<{TARGET_WIDTH}}{r['reach']:5.1f}  "
                   f"{'valid' if r['ok'] else 'invalid'}")
            if r["ok"]:
                limit = " ".join(r["limited"]) or "none"
                L.event("WARN", f"unexpectedly valid: err={r['error']:.1f}  limit={limit}")
            self.wait(self.s["VALIDITY_HOLD_SEC"])
        self.move_one(0, original)

    # ================================================================
    # 4 · 6 · 7  종합
    # ================================================================
    def all_legs(self):
        """4. 네 다리를 차례로: 기본 위치 변화 → 극단 위치 → 유효 범위 → 원위치."""
        for leg, name in enumerate(self.names):
            original = list(self.motion.points[leg])
            self._basic(leg, name)
            self._extreme(leg, name)
            self._validity(leg, name)
            self.move_one(leg, original)
            L.event("STATE", f"{name} back to start")
            self.wait(self.s["LEG_GAP_SEC"])
        self.default_position()

    def _basic(self, leg, name):
        self.table_head(f"{name} basic")
        y = default_y(leg)
        cases = [
            ("기본", "stand", [0, y, -99]),
            ("앞", "fwd", [30, y, -99]),
            ("뒤", "back", [-30, y, -99]),
            ("위", "up", [0, y, -70]),
            ("아래", "down", [0, y, -120]),
            (f"y +20 ({side_word(leg, 1)})", f"y+20 {side_word_en(leg, 1)}", [0, y + 20, -99]),
            (f"y -20 ({side_word(leg, -1)})", f"y-20 {side_word_en(leg, -1)}", [0, y - 20, -99]),
        ]
        for case_name, en, pos in cases:
            self.case(f"{name} {case_name}", leg, pos)
            self.move_one(leg, pos)
            self.report_short(leg, en, pos)
            self.wait(self.s["STEP_HOLD_SEC"])

    def _extreme(self, leg, name):
        self.table_head(f"{name} extreme")
        y = default_y(leg)
        cases = [
            ("앞+위", "fwd+up", [50, y, -70]),
            ("뒤+위", "back+up", [-50, y, -70]),
            ("앞+아래", "fwd+down", [50, y, -120]),
            (f"위+y +30 ({side_word(leg, 1)})", f"up y+30 {side_word_en(leg, 1)}", [0, y + 30, -50]),
            (f"복합 y +20 ({side_word(leg, 1)})", f"mix y+20 {side_word_en(leg, 1)}", [40, y + 20, -60]),
        ]
        for case_name, en, pos in cases:
            self.case(f"{name} {case_name}", leg, pos)
            if check_point(self.motion, leg, pos)["ok"]:
                self.move_one(leg, pos)
            self.report_short(leg, en, pos)
            self.wait(self.s["STEP_HOLD_SEC"])

    def _validity(self, leg, name):
        L.event("METRIC", f"{name + ' reach':<{NAME_WIDTH}} {'target':<{TARGET_WIDTH}} reach  result")
        y = default_y(leg)
        cases = [
            ("너무 높음", "too high", [0, y, -20]),
            ("너무 낮음", "too low", [0, y, -140]),
            ("너무 앞", "too far fwd", [100, y, -99]),
            ("복합 초과", "mixed over", [70, y + 40, -70]),
        ]
        for case_name, en, pos in cases:
            self.case(f"{name} {case_name}", leg, pos)
            r = check_point(self.motion, leg, pos)
            self.result(leg, pos, r)
            L.more(f"{en:<{NAME_WIDTH}} {self.fmt(pos):<{TARGET_WIDTH}}{r['reach']:5.1f}  "
                   f"{'valid' if r['ok'] else 'invalid'}")
            self.wait(self.s["STEP_HOLD_SEC"])

    def lift_each(self):
        """6. 다리 하나씩: 들기 → 앞 → 뒤 → 복원. 나머지 세 다리는 기본 자세."""
        originals = self.snapshot()
        for leg, name in enumerate(self.names):
            self.table_head(f"{name} lift")
            y = default_y(leg)
            for label, en, pos in (("들기", "lift", [0, y, -70]), ("앞", "fwd", [30, y, -70]),
                                   ("뒤", "back", [-30, y, -70])):
                self.case(f"{name} {label}", leg, pos)
                self.move_one(leg, pos)
                self.report_short(leg, en, pos)
                self.wait(self.s["STEP_HOLD_SEC"])
            self.move_one(leg, originals[leg])
            L.event("STATE", f"{name} back to start")
            self.wait(self.s["STEP_HOLD_SEC"])

    def diagonal(self):
        """7. 대각선 두 다리(FL+HR, FR+HL)를 함께 들고 앞으로 옮긴 뒤 복원. 트롯 보행의 짝."""
        originals = self.snapshot()
        hold = self.s["STEP_HOLD_SEC"]
        for title, legs in (("FL + HR", (0, 2)), ("FR + HL", (3, 1))):
            self.case(title)
            target = [list(p) for p in originals]
            for leg in legs:
                target[leg] = [0, default_y(leg), -70]
            self.move_all(target)
            L.event("ACTION", f"{title}  lift (z=-70)")
            self.wait(hold)
            for leg in legs:
                target[leg] = [30, default_y(leg), -70]
            self.move_all(target)
            L.event("ACTION", f"{title}  forward (x=+30)")
            self.wait(hold)
            self.move_all(originals)
            L.event("ACTION", f"{title}  back to start")
            if title == "FL + HR":
                self.wait(hold)

    # ================================================================
    # 5 · 8 · 9  고급
    # ================================================================
    def joint_limits(self):
        """5. 관절 제한: 관절을 끝 쪽으로 보내는 좌표에서 어느 관절이 0~180도에 닿는지 확인."""
        originals = self.snapshot()
        for leg, name in enumerate(self.names):
            self.table_head(f"{name} limits")
            y = default_y(leg)
            cases = [
                ("HX 쪽 1 (y -30, z -130)", "HX y-30", [0, y - 30, -130]),
                ("HX 쪽 2 (y +30, z -130)", "HX y+30", [0, y + 30, -130]),
                ("다리 접기 (z -50)", "fold z-50", [0, y, -50]),
                ("다리 펴기 (z -130)", "extend z-130", [0, y, -130]),
                ("앞으로 뻗기 (x +50, z -90)", "fwd x+50", [50, y, -90]),
                ("뒤로 뻗기 (x -50, z -90)", "back x-50", [-50, y, -90]),
            ]
            for case_name, en, pos in cases:
                self.case(f"{name} {case_name}", leg, pos)
                if check_point(self.motion, leg, pos)["ok"]:
                    self.move_one(leg, pos)
                self.report_short(leg, en, pos)
                self.wait(self.s["STEP_HOLD_SEC"])
            self.move_one(leg, originals[leg])
            self.wait(self.s["STEP_HOLD_SEC"])

    def three_legs(self):
        """8. 3점 지지 자세: 다리를 하나씩 들고 나머지 세 다리는 기본 자세로 둠.

        공중에 매단 상태라 몸이 버티는지(안정성)는 볼 수 없습니다. 다리 하나를 든
        자세와 바뀌는 순서를 확인하고, 안정성은 보행 로봇으로 바닥에서 확인합니다.
        """
        originals = self.snapshot()
        for leg, name in enumerate(self.names):
            self.case(f"{name} 들기")
            target = [list(p) for p in originals]
            target[leg] = [0, default_y(leg), -70]
            self.move_all(target)
            L.event("ACTION", f"{name} lifted, 3 legs on stand pose")
            self.wait(self.s["THREE_LEG_HOLD_SEC"])
        self.move_all(originals)
        L.event("ACTION", "all legs back to start")

    def walk_sequence(self):
        """9. 보행 순서: 대각선 짝을 번갈아 들고 앞으로 놓은 뒤, 네 발을 함께 뒤로 옮김.

        바닥에서는 마지막 단계(네 발을 뒤로)가 몸을 앞으로 밀어 냅니다. 공중에서는
        몸이 움직이지 않으므로 다리 순서와 발끝 위치만 확인합니다.
        """
        originals = self.snapshot()
        h, lift, stride = self.s["BODY_HEIGHT"], self.s["WALK_LIFT_Z"], self.s["WALK_STEP_X"]
        hold = self.s["WALK_HOLD_SEC"]
        yl, yr = ports.FOOT_Y_OFFSET, -ports.FOOT_Y_OFFSET
        for cycle in range(self.s["WALK_CYCLES"]):
            L.event("TASK", f"cycle {cycle + 1}/{self.s['WALK_CYCLES']}")
            steps = [
                ("1. FL+HR 들기", "1 FL+HR lift", [[0, yl, lift], list(originals[1]), [0, yr, lift], list(originals[3])]),
                ("2. FL+HR 앞", "2 FL+HR forward",
                 [[stride, yl, lift], list(originals[1]), [stride, yr, lift], list(originals[3])]),
                ("3. FL+HR 내리기", "3 FL+HR down",
                 [[stride, yl, -h], list(originals[1]), [stride, yr, -h], list(originals[3])]),
                ("4. FR+HL 들기", "4 FR+HL lift", [[stride, yl, -h], [0, yl, lift], [stride, yr, -h], [0, yr, lift]]),
                ("5. FR+HL 앞", "5 FR+HL forward",
                 [[stride, yl, -h], [stride, yl, lift], [stride, yr, -h], [stride, yr, lift]]),
                ("6. FR+HL 내리기", "6 FR+HL down",
                 [[stride, yl, -h], [stride, yl, -h], [stride, yr, -h], [stride, yr, -h]]),
                ("7. 몸체 전진", "7 body forward (all feet back)",
                 [[0, yl, -h], [0, yl, -h], [0, yr, -h], [0, yr, -h]]),
            ]
            for label, en, target in steps:
                self.case(label)
                self.move_all(target)
                L.event("ACTION", en)
                self.wait(hold)
        self.move_all(originals)
        L.event("ACTION", "all legs back to start")

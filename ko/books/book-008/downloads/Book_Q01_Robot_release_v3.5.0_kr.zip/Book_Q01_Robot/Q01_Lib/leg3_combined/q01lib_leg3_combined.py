# -*- coding: utf-8 -*-
"""
q01lib_leg3_combined.py  |  QUAD-01 교육용 라이브러리 · 다리 테스트 3 · 복합 테스트

시작 파일 q01_leg3_combined_start.py · 로봇 Book-QUAD-01-LEG3

숫자 키를 누르면 정해진 발끝 좌표 목록을 차례로 보내며 IK · FK · 관절 제한을
확인하고, 네 다리를 조합한 동작(다리 하나씩 · 대각선 · 3점 지지 자세 · 보행 순서)을
실행합니다. 테스트 좌표와 순서는 q01lib_leg3_combined_tests.py에, 값과 키는
시작 파일에 있습니다.

    [IK 검증 · FL]      1 기본 이동 · 2 극단 위치 · 3 유효 범위
    [IK 검증 · 네 다리]  4 네 다리 차례로 · 5 관절 제한
    [복합 동작]         6 다리 하나씩 들기 · 7 대각선 두 다리 · 8 3점 지지 자세 · 9 보행 순서

시작할 때 네 다리를 먼저 기본 자세로 옮깁니다.

로봇 화면(Text Screen)은 테스트가 진행되는 동안 콘솔 LOG의 핵심 값을 함께 보여 줍니다.
화면 모양과 색은 세 다리 테스트가 함께 쓰는 leg_common/q01lib_leg_screen.py가 정합니다.

    좌표 하나를 확인할 때 (1 ~ 6)        네 다리를 함께 옮길 때 (7 · 8 · 9)
    개별 다리                            보행 시퀀스
    ------------------                   ------------------
    FL 앞                                2. FL+HR 앞
    FL x 30  y 10  z -70                 발끝 (x, z)
    HX 82  HY 129  KN 125                FL (30, -70)  FR (0, -99)
    FK 오차 0.5                          HL (0, -99)  HR (30, -70)
    ------------------                   ------------------
    F3 멈춤 · F2 기본 자세               F3 멈춤 · F2 기본 자세

좌표 숫자는 청록, 서보 각도 숫자는 노랑, FK 오차는 초록입니다. 관절이 제한에 닿으면
"FK 오차 21.8 · HY 제한", 도달 범위 밖이면 "거리 130 · 갈 수 없음"(서보 줄은
"HX -  HY -  KN -")이 빨강으로 나옵니다. 네 다리 줄은 위에서 본 다리 배치와 같은 순서입니다.
테스트가 진행되는 동안 화면은 늘 이 8줄 모양 하나입니다. 단계가 바뀌면 옮기기 전에 그
단계의 좌표와 확인 결과(또는 네 다리 발끝)를 바로 보여 줍니다.
"""

from ..core import q01lib_ports as ports
from ..core.q01lib_key_events import key_label
from ..core import q01lib_log as L    # 콘솔 LOG 출력 (L.event · L.more · L.key …)
from ..leg_common.q01lib_leg_check import check_point
from ..leg_common import q01lib_leg_screen as scr
from .q01lib_leg3_combined_tests import LegCombinedTests

# 테스트 이름: 화면에 쓰는 이름, F1 키 안내 화면에 쓰는 짧은 이름, 묶음, 콘솔에 쓰는 영어 이름
TESTS = {
    "fl_basic": ("FL 기본 이동", "기본", "IK 검증 · FL", "FL basic"),
    "fl_extreme": ("FL 극단 위치", "극단", "IK 검증 · FL", "FL extreme"),
    "fl_validity": ("FL 유효 범위", "유효", "IK 검증 · FL", "FL reach"),
    "all_legs": ("전체 다리", "전체", "IK 검증 · 네 다리", "all legs"),
    "joint_limits": ("각도 제한", "각도 제한", "IK 검증 · 네 다리", "joint limits"),
    "lift_each": ("개별 다리", "개별", "복합 동작", "lift each"),
    "diagonal": ("대각선 다리", "대각선", "복합 동작", "diagonal"),
    "three_legs": ("3점 지지 자세", "3점 지지", "복합 동작", "3-leg support"),
    "walk_sequence": ("보행 시퀀스", "보행", "복합 동작", "walk sequence"),
}
GROUPS = ("IK 검증 · FL", "IK 검증 · 네 다리", "복합 동작")
GROUP_EN = {"IK 검증 · FL": "IK FL", "IK 검증 · 네 다리": "IK 4 legs", "복합 동작": "Combined"}
GROUP_SHORT = {"IK 검증 · FL": "FL IK 검증", "IK 검증 · 네 다리": "네 다리 IK 검증",
               "복합 동작": "복합 동작"}


class CombinedTest:
    """다리 테스트 3 · 복합 테스트."""

    TITLE = "복합 테스트"
    HEADER = "QUAD-01 LEG TEST 3  COMBINED   (Book-QUAD-01-LEG3)"
    LOG_CATEGORIES = ("ACTION", "METRIC")   # 공통 분류 밖에 이 테스트가 콘솔에 쓰는 분류 (열 맞추기)
    SHORT = "복합"
    START_FILE = "q01_leg3_combined_start.py"
    USES_LEG_SELECT = False
    VALUE_NAMES = ("MOVE_ALL_STEPS", "MOVE_SINGLE_STEPS", "MOVE_SINGLE_DELAY", "CASE_HOLD_SEC",
                   "VALIDITY_HOLD_SEC", "STEP_HOLD_SEC", "LEG_GAP_SEC", "THREE_LEG_HOLD_SEC",
                   "WALK_CYCLES", "WALK_LIFT_Z", "WALK_STEP_X", "WALK_HOLD_SEC", "TEST_KEYS")

    def __init__(self, robot, settings):
        self.robot = robot
        self.s = settings
        for key, name in settings["TEST_KEYS"].items():
            if name not in TESTS:
                raise ValueError(f"TEST_KEYS '{key}': unknown test '{name}'. "
                                 f"Use one of: {', '.join(TESTS)}")
        self.title = ""
        self.label = ""
        self.tests = LegCombinedTests(robot.motion, settings, on_case=self.show_case, wait=robot.wait,
                                      on_result=self.show_result, on_pose=self.show_pose)

    # ------------------------------------------------------------
    # 키 · 화면 · 콘솔 안내
    # ------------------------------------------------------------
    def actions(self):
        """(키, 콘솔에 남길 설명, 실행할 함수, 걸린 시간을 남길지) 목록."""
        return [(key, TESTS[name][3], lambda name=name: self.perform(name), True)
                for key, name in self.s["TEST_KEYS"].items()]

    def repeat_keys(self):
        """누르고 있어도 다시 실행하는 키는 없습니다(자동 테스트만)."""
        return []

    def _keys_in(self, group):
        return [key_label(k) for k, n in self.s["TEST_KEYS"].items() if TESTS[n][2] == group]

    def guide(self):
        """콘솔 키 안내 (영어). 묶음마다 한 줄."""
        lines = []
        for group in GROUPS:
            items = [f"{L.key(key_label(k))} {TESTS[n][3]}"
                     for k, n in self.s["TEST_KEYS"].items() if TESTS[n][2] == group]
            label = GROUP_EN[group]
            while items:
                row = items.pop(0)
                while items and L.visible_len(row) + 3 + L.visible_len(items[0]) <= 48:
                    row += "   " + items.pop(0)
                lines.append(f" {label:<10} {row}")
                label = ""
        lines.append(" Frame      origin at hip  x fwd(+)  y left(+)  z up(+)")
        lines.append("            stand [0, +-10, -99]")
        return lines

    def idle_page(self):
        """대기 화면: 제목 / 숫자 키 묶음 / F1 키 안내 · F2 기본 자세."""
        body = []
        for group in GROUPS:
            keys = self._keys_in(group)
            if keys:
                body.append(scr.keys_line([(" ".join(keys), GROUP_SHORT[group])]))
        footer = scr.keys_line([(key_label(self.s["HELP_KEY"]), "키 안내"),
                                (key_label(self.s["STAND_KEY"]), "기본 자세")], " · ")
        return "복합 테스트", body, footer

    def help_lines(self, leg_keys=None):
        """F1 키 안내 화면 (이 테스트의 키). 묶음마다 한 줄, 길면 두 개씩 나눔."""
        lines = []
        for group in GROUPS:
            pairs = [(key_label(k), TESTS[n][1])
                     for k, n in self.s["TEST_KEYS"].items() if TESTS[n][2] == group]
            if not pairs:
                continue
            if len("  ".join(f"{k} {d}" for k, d in pairs)) <= 18:
                lines.append(scr.keys_line(pairs))
            else:
                for i in range(0, len(pairs), 2):
                    lines.append(scr.keys_line(pairs[i:i + 2]))
        return lines

    def enter(self):
        """시작할 때: 네 다리를 기본 자세로 옮깁니다."""
        self.tests.default_position()
        self.robot.sync_from_motion()

    # ------------------------------------------------------------
    # 테스트
    # ------------------------------------------------------------
    def after_stop(self):
        """테스트를 멈춘 뒤: 보낸 각도를 맞춥니다."""
        self.robot.sync_from_motion()

    def show_case(self, label, leg=None, pos=None):
        """단계가 바뀔 때의 로봇 화면.

        좌표 하나를 확인하는 단계(leg · pos가 있음)는 그 좌표의 확인 결과를, 네 다리를
        함께 옮기는 단계는 네 발끝을 같은 8줄 모양으로 바로 보여 줍니다. 단계 이름만 있는
        짧은 화면을 따로 두지 않아 테스트 동안 화면 모양이 바뀌지 않습니다.
        """
        self.label = label
        if pos is not None:
            self.show_result(leg, pos, check_point(self.robot.motion, leg, pos))
        else:
            self.show_pose()

    def show_result(self, leg, pos, r):
        """로봇 화면: 좌표 하나의 확인 결과 (좌표 · 서보 각도 · FK 오차 또는 제한)."""
        x, y, z = pos
        body = [self.label, scr.xyz(f"{x:g}", f"{y:g}", f"{z:g}", f"{ports.LEG_NAMES[leg]} ")]
        if not r["ok"]:
            body += [scr.joints((None, None, None)), f"거리 {r['reach']:.0f} · {scr.paint('갈 수 없음', 'warn')}"]
        else:
            body.append(scr.joints(r["servo"], "angle"))
            error = f"{r['error']:.1f}"
            if r["limited"]:
                body.append(f"FK 오차 {scr.paint(error, 'warn')} · "
                            f"{scr.paint('·'.join(r['limited']) + ' 제한', 'warn')}")
            else:
                body.append(f"FK 오차 {scr.paint(error, 'ok')}")
        self.robot.show_running(self.title, *body)

    def show_pose(self):
        """로봇 화면: 네 다리의 발끝 (x, z). 위에서 본 다리 배치 순서 (FL FR / HL HR)."""
        if not self.title:
            return
        p = {name: self.robot.motion.points[i] for i, name in enumerate(ports.LEG_NAMES)}

        def xz(name):
            return f"{name} ({scr.paint(round(p[name][0]), 'coord')}, {scr.paint(round(p[name][2]), 'coord')})"
        self.robot.show_running(self.title, self.label, "발끝 (x, z)",
                                f"{xz('FL')}  {xz('FR')}", f"{xz('HL')}  {xz('HR')}")

    def perform(self, name):
        self.title = TESTS[name][0]
        self.label = "진행 중"          # 첫 단계가 바로 화면을 씀 (단계 이름만 있는 화면을 따로 두지 않음)
        try:
            getattr(self.tests, name)()
        finally:
            self.title = ""
            self.robot.sync_from_motion()

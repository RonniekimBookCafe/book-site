# -*- coding: utf-8 -*-
"""
Q01_Lib/leg3_combined  |  다리 테스트 3 · 복합 테스트 (q01_leg3_combined_start.py · Book-QUAD-01-LEG3)

    q01lib_leg3_combined.py         CombinedTest: 숫자 키로 테스트를 고르고 화면에 보여 줌
    q01lib_leg3_combined_tests.py   테스트 좌표와 순서 (IK 검증 + 네 다리 조합 동작)

키를 읽는 반복 부분과 로봇은 leg_common 폴더를 함께 씁니다.
"""

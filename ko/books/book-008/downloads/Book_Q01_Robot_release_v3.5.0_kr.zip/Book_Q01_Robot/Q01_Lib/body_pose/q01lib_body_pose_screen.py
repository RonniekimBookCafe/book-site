# -*- coding: utf-8 -*-
"""
q01lib_body_pose_screen.py  |  QUAD-01 교육용 라이브러리 · 몸체 자세 테스트의 로봇 화면

몸체 자세 테스트(q01_body_pose_start.py · Book-QUAD-01-ROLL_PITCH_YAW)만 쓰는 로봇 화면입니다.
Text Screen(Port 0) Reference를 이 파일의 BodyPoseScreen이 만들고, 화면 설정과 글자를 모두
여기서 정합니다. 다리 테스트의 화면(leg_common/q01lib_leg_screen.py · core/q01lib_screen.py)은
쓰지 않고, 다리 테스트도 이 화면을 쓰지 않습니다.

화면은 Attitude Angle 화면입니다. pitch · yaw 격자와 막대 여섯 개, 맨 위 상태 상자, IMU 줄로
이루어집니다.

    +----------- Attitude Angle ------------+  제목 (상자 윗변)
      대기                                     상태 (주황)
      F1 키 안내 · 1 자동 테스트               안내: 키, 또는 갈 수 없는 자세(빨강)
    +20 ------------------------------------+  격자 윗변 = pitch +20
    |                        |              |
    |                        |              |
    |                        |              |
    |------------------------+-(5, 10)------|  pitch +10 (2줄 = 5)
    |                        |              |
    |                        |              |
    |                        |              |
    |0                       |              |  pitch 0
    |                        |              |
    |                        |              |
    |                        |              |
    |                        |              |
    |                        |              |
    |                        |              |
    |                        |              |
    -20 ----------------0   ----------------+  격자 아랫변 = pitch -20

    Roll    5 -----●--- Horizon   0 ----●----  왼쪽 회전 · 오른쪽 이동
    Pitch  10 ------●-- Side     -5 ---●-----  막대 = -20 ~ +20, 한 칸 = 5
    Yaw     5 -----●--- Height    0 ----●----  ● = 지금 값 (노랑)
      IMU roll 5 pitch 10 yaw 5                IMU로 잰 실제 기울기 (청록)

[칸 나누기]  키 한 번(5)이 언제나 같은 칸 수만큼 움직이도록 나눕니다.
    격자 세로 17줄 : -20 ~ +20을 16칸 → 2줄 = 5   (pitch 키 한 번 = 2줄)
    격자 가로 41칸 : -20 ~ +20을 40칸 → 5칸 = 5   (yaw 키 한 번 = 5칸)
    막대 9칸       : -20 ~ +20을 8칸  → 한 칸 = 5 (키 한 번 = 1칸)
값이 칸 사이에 오면 가장 가까운 칸으로 반올림하고, 딱 중간이면 + · - 모두 바깥쪽 칸으로 갑니다.

[격자가 보여 주는 값]  격자는 pitch(세로) · yaw(가로)입니다. roll은 몸체 앞뒤 축
둘레 회전이라 머리가 가리키는 방향(pitch · yaw)을 바꾸지 않으므로 격자에는 나오지 않고 Roll
막대에 나옵니다. x · y · z(몸체 이동)도 막대에만 나옵니다. GRID_X_AXIS를 "roll"로 바꾸면 격자
가로축이 roll이 되어(몸체 기울기 보기) J · L이 세로선을 움직이고, yaw는 막대에만 나옵니다.

[화면 설정]
    정렬      왼쪽 · 가운데 (글자를 칸에 맞춰 그리므로 왼쪽, 남는 위아래는 같게)
    글자 크기  auto_size 켬. 화면 폭이나 높이 가운데 먼저 닿는 쪽에 맞춰 가장 크게 (AUTO_SIZE_MAX까지)
    줄바꿈    끔 (긴 줄이 다음 줄로 넘어가 격자가 밀리지 않도록)
한 화면의 글자를 41칸 × 25줄로 맞춥니다. 이 비율(폭 : 줄 ≈ 1.6)이 Text Screen 글자 영역의 비율과
비슷해 폭과 높이가 함께 찹니다. 모든 줄을 41칸 안에 두고(막대 두 개를 한 줄에), 막대 선은 영문과
폭이 같은 "-"로 그립니다. "─"는 게임 글꼴에서 약 1.6칸이라 막대 줄이 격자보다 넓어져 글자가
작아지고 위아래 여백이 남습니다.
F1 키 안내 화면도 같은 칸 · 줄 수로 써서 글자 크기가 바뀌지 않게 합니다.

[다시 쓰기]  키를 누를 때마다 새로 쓰고, 키를 누르지 않아도 REFRESH_SEC마다 다시 씁니다
(IMU 값이 바뀌면 화면에 반영).
"""

import math
import time

from controllables import TextScreen

from ..core import q01lib_ports as ports
from ..core.q01lib_screen import DEFAULT_TEXT_COLOR, ensure_readable_text

# ------------------------------------------------------------
# 화면 설정
# ------------------------------------------------------------
SCALE = 20                   # 격자 · 막대가 그리는 범위 (-SCALE ~ +SCALE)
GRID_ROWS = 17               # 격자 세로 줄 수 (홀수). 17줄 = 2줄에 5
GRID_COLS = 41               # 격자 가로 칸 수 (홀수). 41칸 = 5칸에 5 (한 칸 = 1). 화면 폭도 이 값
BAR_LENGTH = 9               # 막대 칸 수 (홀수). 9칸 = 한 칸에 5
BAR_CHAR = "-"               # 막대 선 글자. 영문과 폭이 같은 글자 (─ 는 게임 글꼴에서 1.6칸이라 화면 폭을 넘김)
GRID_X_AXIS = "yaw"          # 격자 가로축: "yaw" (머리 방향 보기) 또는 "roll" (몸체 기울기 보기)
TITLE = "Attitude Angle"
SCREEN_LINES = GRID_ROWS + 8 # 화면 줄 수 = 상태 상자 3 + 격자 + 빈 줄 1 + 막대 3 + IMU 1 (키 안내 화면도 이 줄 수)

AUTO_SIZE_MAX = 200          # 글자 크기 자동 맞춤의 최대 크기 (화면에 꽉 차도록 크게)
REFRESH_SEC = 1.0            # 키를 누르지 않아도 화면을 다시 쓰는 간격(초)

SCREEN_COLOR = True          # False이면 색 태그 없이 씀 (화면에 <color= 가 그대로 보일 때)
COLORS = {
    "value": "yellow",       # 막대의 점과 이름
    "zero": "red",           # 격자 가운데 0축 +
    "state": "#FF8A34",      # 상태 (대기 · 자동 테스트 중 · 멈춤 · 키 안내)
    "alert": "red",          # 갈 수 없는 자세 · 범위 끝
    "key": "#FFFFFF",        # 키 이름
    "text": "#B0B7C3",       # 키 설명
    "imu": "#20D6D9",        # IMU로 잰 값
}


# ------------------------------------------------------------
# 글자 만들기
# ------------------------------------------------------------
def tag(text, color_name):
    """text에 색 태그를 붙입니다. color_name은 COLORS의 이름이나 색 이름."""
    if not SCREEN_COLOR:
        return text
    return f"<color={COLORS.get(color_name, color_name)}>{text}</color>"


def keys_text(items, sep=" · "):
    """[(키, 설명), ...] → "F1 키 안내 · 1 자동 테스트" (키는 흰색, 설명은 회색)."""
    return sep.join(f"{tag(k, 'key')} {tag(d, 'text')}" for k, d in items)


def cell(value, count):
    """값(-SCALE ~ +SCALE) → 칸 번호 0 ~ count-1 (-SCALE이 0, 0이 가운데).

    가운데에서 몇 칸인지를 반올림합니다. 0.5칸은 + · - 모두 바깥으로 (예: +2.5 → 1칸, -2.5 → -1칸).
    """
    half = (count - 1) // 2
    t = value / SCALE * half
    steps = int(math.floor(abs(t) + 0.5))
    return min(count - 1, max(0, half + (steps if t >= 0 else -steps)))


def value_to_col(value, width=GRID_COLS):
    """값 → 가로 칸 번호 (-SCALE이 왼쪽 끝, +SCALE이 오른쪽 끝)."""
    return cell(value, width)


def value_to_row(value, height=GRID_ROWS):
    """값 → 세로 줄 번호 (+SCALE이 맨 위, -SCALE이 맨 아래)."""
    return height - 1 - cell(value, height)


def number(value):
    """화면에 쓰는 숫자 (정수면 정수로, 아니면 소수 한 자리)."""
    return f"{value:g}" if float(value).is_integer() else f"{value:.1f}"


def slider(value, label, label_width):
    """막대 하나. 예: "Roll    5 -----●---" (이름 · 지금 값 · 막대)."""
    bar = [BAR_CHAR] * BAR_LENGTH
    bar[cell(value, BAR_LENGTH)] = tag("●", "value")
    return f"{tag(f'{label:<{label_width}}', 'value')}{number(value):>4} {''.join(bar)}"


# 막대 두 개를 한 줄에: 왼쪽 회전 (roll · pitch · yaw), 오른쪽 이동 (x · y · z)
SLIDER_ROWS = (
    (("roll", "Roll"), ("x", "Horizon")),
    (("pitch", "Pitch"), ("y", "Side")),
    (("yaw", "Yaw"), ("z", "Height")),
)
SLIDER_GAP = " "             # 왼쪽 막대와 오른쪽 막대 사이 (한 줄 = 화면 폭 41칸)


def slider_lines(pose):
    """막대 여섯 개를 세 줄로."""
    left_w = max(len(row[0][1]) for row in SLIDER_ROWS)
    right_w = max(len(row[1][1]) for row in SLIDER_ROWS)
    return [slider(pose[lk], ll, left_w) + SLIDER_GAP + slider(pose[rk], rl, right_w)
            for (lk, ll), (rk, rl) in SLIDER_ROWS]


def grid(pitch, x_value):
    """pitch(세로) · x_value(가로: yaw 또는 roll) 격자."""
    w, h = GRID_COLS, GRID_ROWS
    mid_c, mid_r = w // 2, h // 2
    row_p = value_to_row(pitch, h)
    col_x = value_to_col(x_value, w)
    g = [[" " for _ in range(w)] for _ in range(h)]

    # 테두리
    for c in range(w):
        g[0][c] = g[h - 1][c] = "-"
    for r in range(h):
        g[r][0] = g[r][w - 1] = "|"
    g[0][0] = g[0][w - 1] = g[h - 1][0] = g[h - 1][w - 1] = "+"

    # 지금 pitch(가로선) · 가로축 값(세로선)
    for c in range(1, w - 1):
        g[row_p][c] = "-"
    for r in range(1, h - 1):
        g[r][col_x] = "|"
    g[row_p][col_x] = "+"

    # 0축: 값이 0이면 가운데 선을 그림
    if pitch == 0:
        for c in range(1, w - 1):
            if g[mid_r][c] == " ":
                g[mid_r][c] = "-"
    if x_value == 0:
        for r in range(1, h - 1):
            if g[r][mid_c] == " ":
                g[r][mid_c] = "|"
    if pitch == 0 or x_value == 0:
        g[mid_r][mid_c] = tag("+", "zero")

    # 눈금: 왼쪽 pitch, 아래 가로축
    for v in (-SCALE, 0, SCALE):
        r = value_to_row(v, h)
        for i, ch in enumerate(f"{v:<3}"):
            g[r][1 + i] = ch
        c = value_to_col(v, w)
        for i, ch in enumerate(f"{v:<4}"):
            if c + i < w - 1:
                g[h - 1][c + i] = ch

    # 지금 값 (가로축 값, pitch). 위 · 아래 테두리 줄에는 쓰지 않음
    coord = f"({number(x_value)}, {number(pitch)})"
    if 0 < row_p < h - 1:
        start = min(col_x + 2, w - 1 - len(coord))
        for i, ch in enumerate(coord):
            g[row_p][start + i] = ch

    return "\n".join("".join(row) for row in g)


def box_top():
    """상태 상자 윗변 (가운데에 제목)."""
    inner = GRID_COLS - 2
    left = (inner - len(TITLE) - 2) // 2
    right = inner - len(TITLE) - 2 - left
    return "+" + "-" * left + f" {TITLE} " + "-" * right + "+"


def header(state, info=""):
    """상태 상자 (윗변 + 상태 줄 + 안내 줄). 아랫변은 격자 윗변이 대신합니다.

    한글은 게임 글꼴에서 영문 · 숫자와 폭이 달라 오른쪽 끝을 칸에 맞출 수 없으므로
    상태 · 안내 줄에는 양옆 | 를 긋지 않습니다.
    """
    return "\n".join([box_top(), f"  {tag(state, 'state')}", f"  {info}"])


def imu_line(imu):
    """IMU 줄. imu는 (roll, pitch, yaw) 도, 또는 IMU를 읽을 수 없을 때의 설명 글자."""
    if isinstance(imu, str):
        return "  " + tag(imu, "text")
    roll, pitch, yaw = (int(round(v)) + 0 for v in imu)
    return "  " + tag(f"IMU roll {roll} pitch {pitch} yaw {yaw}", "imu")


def _pad(lines):
    """화면 줄 수를 SCREEN_LINES로 맞춥니다 (글자 크기가 화면마다 바뀌지 않도록)."""
    return lines + [""] * max(0, SCREEN_LINES - len(lines))


def attitude_text(pose, state, info="", imu=None):
    """몸체 자세(dict) → 화면 글자: 상태 상자 + 격자 + 막대 여섯 개 (+ IMU 줄)."""
    lines = [header(state, info), grid(pose["pitch"], pose[GRID_X_AXIS]), ""] + slider_lines(pose)
    if imu is not None:
        lines.append(imu_line(imu))
    return "\n".join(_pad("\n".join(lines).split("\n")))


def help_text(state, info, lines):
    """키 안내 화면: 상태 상자 + 아랫변 + 키 안내 줄 (대기 화면과 같은 줄 수)."""
    body = [header(state, info), "+" + "-" * (GRID_COLS - 2) + "+"] + list(lines)
    return "\n".join(_pad("\n".join(body).split("\n")))


# ------------------------------------------------------------
# 로봇 화면 (Text Screen Reference)
# ------------------------------------------------------------
class BodyPoseScreen:
    """몸체 자세 테스트의 로봇 화면. Text Screen Reference를 한 번 만들고 계속 씁니다."""

    def __init__(self):
        self.screen = TextScreen(ports.PORT_TEXT_SCREEN)
        self.screen.color = DEFAULT_TEXT_COLOR  # Background is black; labels use their own rich-text colors.
        self.screen.wrapping = False
        self.screen.auto_size = True
        self.screen.auto_size_max = AUTO_SIZE_MAX
        self.screen.horizontal_alignment = TextScreen.HorizontalAlignment.LEFT
        self.screen.vertical_alignment = TextScreen.VerticalAlignment.MIDDLE
        self.text = ""
        self.sent_at = 0.0

    def show(self, text):
        """화면에 글자를 씁니다."""
        self.screen.text = ensure_readable_text(text)
        self.text = text
        self.sent_at = time.time()

    def due(self):
        """마지막으로 쓴 지 REFRESH_SEC가 지났으면 True."""
        return time.time() - self.sent_at >= REFRESH_SEC

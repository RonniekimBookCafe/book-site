# -*- coding: utf-8 -*-
"""
q01lib_body_pose.py  |  QUAD-01 교육용 라이브러리 · 몸체 자세 → 네 발끝 좌표

네 발을 바닥에 둔 채 몸체만 옮기고(x · y · z) 기울이면(roll · pitch · yaw), 엉덩이에서
본 발끝의 위치가 바뀝니다. 이 파일은 몸체 자세 여섯 값을 네 다리의 발끝 좌표로 바꿉니다.
바뀐 발끝 좌표는 역기구학(IK)으로 관절 각도가 됩니다(core/q01lib_motion.LegMotion).

    몸체 자세 (x, y, z, roll, pitch, yaw)
      -> body_pose_feet()          네 다리의 발끝 좌표 (다리 좌표계)
      -> LegMotion.run()           IK → 좌우 다리 방향 보정 → 서보 12개

[좌표계]  Spot과 같은 몸체 좌표계 (core/q01lib_ports.py)
    x 앞(+) · y 왼쪽(+) · z 위(+). 회전의 + 방향은 오른손 법칙
    roll  +  x축 둘레: 오른쪽이 내려가고 왼쪽이 올라감
    pitch +  y축 둘레: 앞(머리)이 내려가고 뒤가 올라감
    yaw   +  z축 둘레: 위에서 볼 때 왼쪽(반시계)으로 돎
    몸체 x · y · z : 기본 자세에서 몸체가 옮겨 간 거리 (z + = 몸체가 올라감)

[계산]
기본 자세에서 몸체 중심을 원점으로 잡으면 다리 i의 엉덩이 H와 발끝 F는

    H = (±L/2, ±W/2, 0)                  L 몸체 길이(앞뒤 엉덩이 사이) · W 몸체 폭(좌우 엉덩이 사이)
    F = H + (0, ±FOOT_Y_OFFSET, -높이)    앞다리 +L/2 · 뒷다리 -L/2, 왼쪽 + · 오른쪽 -

발은 바닥에 그대로 있고 몸체만 T = (x, y, z)만큼 옮겨 가 R만큼 돌면, 몸체에서 본
발끝은 R을 거꾸로 돌린 자리입니다. 엉덩이에서 본 발끝(다리 좌표계)은

    발끝 = Rᵀ · (F - T) - H          R = Rz(yaw) · Ry(pitch) · Rx(roll)

R은 yaw → pitch → roll 순서(z → y → x, 로봇에서 흔히 쓰는 roll · pitch · yaw 정의)입니다. IMU도
같은 순서로 각도를 꺼내므로(core/q01lib_imu.py) 여러 축을 함께 기울여도 명령한 roll · pitch · yaw와
IMU가 잰 값이 같은 뜻입니다. 한 축만 기울일 때는 순서와 관계없이 결과가 같습니다.

몸체를 오른쪽으로 기울이면(roll +) 오른쪽 엉덩이가 내려가 오른쪽 발끝이 엉덩이에 가까워지고
(z가 0에 가까워짐), 왼쪽 발끝은 멀어집니다. 몸체가 앞으로 가면(x +) 발끝은 엉덩이보다
뒤(x -)에 놓입니다.

이 계산은 RoboCo API를 쓰지 않으므로 RoboCo 밖의 Python에서도 실행할 수 있습니다.
"""

import math

from ..core import q01lib_ports as ports

POSE_AXES = ("x", "y", "z", "roll", "pitch", "yaw")


def rotation(roll, pitch, yaw):
    """몸체 회전 행렬 R = Rz(yaw) · Ry(pitch) · Rx(roll). 각도는 도."""
    r, p, y = (math.radians(v) for v in (roll, pitch, yaw))
    cr, sr, cp, sp, cy, sy = math.cos(r), math.sin(r), math.cos(p), math.sin(p), math.cos(y), math.sin(y)
    rx = [[1, 0, 0], [0, cr, -sr], [0, sr, cr]]
    ry = [[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]]
    rz = [[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]]
    return _matmul(_matmul(rz, ry), rx)


def _matmul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def hip_position(leg, body_length, body_width):
    """다리 leg의 엉덩이 위치 (몸체 중심 기준)."""
    front = 1 if leg in ports.FRONT_LEGS else -1
    left = 1 if leg in ports.LEFT_LEGS else -1
    return (front * body_length / 2, left * body_width / 2, 0.0)


def body_pose_feet(pose, body_height, body_length, body_width):
    """몸체 자세(dict: x y z roll pitch yaw)를 네 다리의 발끝 좌표 [FL, HL, HR, FR]로 바꿉니다."""
    r = rotation(pose["roll"], pose["pitch"], pose["yaw"])
    move = (pose["x"], pose["y"], pose["z"])
    feet = []
    for leg in range(4):
        hip = hip_position(leg, body_length, body_width)
        side_y = ports.FOOT_Y_OFFSET if leg in ports.LEFT_LEGS else -ports.FOOT_Y_OFFSET
        ground = (hip[0], hip[1] + side_y, -body_height)            # 바닥에 놓인 발끝 F
        d = [ground[i] - move[i] for i in range(3)]                  # F - T
        in_body = [sum(r[k][i] * d[k] for k in range(3)) for i in range(3)]   # Rᵀ · (F - T)
        feet.append([in_body[i] - hip[i] for i in range(3)])         # 엉덩이에서 본 발끝
    return feet


def zero_pose():
    """기본 자세 (여섯 값 모두 0)."""
    return {axis: 0 for axis in POSE_AXES}

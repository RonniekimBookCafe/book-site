# -*- coding: utf-8 -*-
"""
q01lib_body_pose_test.py  |  QUAD-01 교육용 라이브러리 · 몸체 자세 테스트 (x · y · z · roll · pitch · yaw)

시작 파일 q01_body_pose_start.py · 로봇 Book-QUAD-01-ROLL_PITCH_YAW

네 발을 바닥에 둔 채 몸체를 옮기고(x · y · z) 기울입니다(roll · pitch · yaw). 키를 한 번
누를 때마다 몸체 자세 한 값을 바꾸고, 네 다리의 발끝 좌표를 다시 계산해 서보를 움직입니다.
값과 키는 시작 파일에 있습니다.

    몸체 자세 (x, y, z, roll, pitch, yaw)
      -> body_pose/q01lib_body_pose.py        네 다리의 발끝 좌표
      -> 갈 수 있는지 확인                    도달 범위 · 관절 0~180도 (leg_common/q01lib_leg_check.py)
      -> LegMotion.run()                      IK → 서보 12개

    W · S / A · D / E · Q   몸체 x / y / z를 MOVE_STEP씩 + · -   (앞 · 뒤 / 왼쪽 · 오른쪽 / 위 · 아래)
    I · K                   pitch + · -  (머리 아래로 · 머리 위로)
    J · L                   roll  - · +  (왼쪽으로 · 오른쪽으로 기울임)
    U · O                   yaw   + · -  (왼쪽으로 · 오른쪽으로 돎)
    1                       자동 테스트: 여섯 값을 차례로 + · - 로 바꿨다 되돌리고 기본 자세로
    F1 · F2 · F3            키 안내 · 기본 자세 · 자동 테스트 멈춤 (공통, q01lib_leg_app.py)

[갈 수 없는 자세]
새 자세에서 한 다리라도 발끝이 도달 범위(25~130) 밖이거나 관절이 0도 · 180도 제한에 닿으면
서보를 움직이지 않고 이전 자세를 유지합니다. 콘솔에 어느 다리의 어느 관절인지 남기고,
로봇 화면 상태 상자의 둘째 줄에 빨강으로 알립니다(예: "HL HY 제한 · 이전 자세 유지").
머리를 들어 올리는 pitch -에서는 뒷다리의 HY가 먼저 180도에 닿습니다(기본 높이에서 약 -14도).

[로봇 화면]  이 테스트만 쓰는 화면 파일 body_pose/q01lib_body_pose_screen.py (BodyPoseScreen)
Attitude Angle 화면: 맨 위 상태 상자 · 격자 · 막대 · IMU 줄.
    상태 줄   대기 · 자동 테스트 중 · roll · 멈춤 (F3) · 키 안내 (F1)
    안내 줄   쓸 수 있는 키, 또는 갈 수 없는 자세 · 범위 끝 (빨강)
    격자      pitch(세로) · yaw(가로)에 지금 값을 십자선으로. 키 한 번(5) = 세로 2줄 · 가로 5칸
    막대      Roll · Pitch · Yaw · Horizon(x) · Side(y) · Height(z), 두 개씩 한 줄. 키 한 번(5) = 1칸
    IMU 줄    IMU(Port 1)로 잰 실제 roll · pitch · yaw (USE_IMU)
키를 누를 때마다 새로 쓰고, 키를 누르지 않아도 1초마다 다시 씁니다(on_loop).

[IMU로 확인하기]  USE_IMU가 True이면 시작할 때 기본 자세에서 IMU 영점을 잡고, 키를 누르고
IMU_LOG_DELAY_SEC 뒤에 콘솔에 IMU로 잰 기울기와 명령한 기울기를 나란히 남깁니다.
roll · pitch · yaw 키가 실제 로봇을 그 방향 · 그 크기로 기울였는지 숫자로 확인합니다.
IMU가 없거나 읽을 수 없으면 알리고 IMU 없이 계속합니다. IMU 부호는 실습 7과 같은 몸체
좌표계입니다(core/q01lib_imu.py, 센서를 14장 표대로 달았을 때).
"""

import time

from ..core import q01lib_ports as ports
from ..core.q01lib_key_events import key_label
from ..leg_common.q01lib_leg_check import check_point
from ..core import q01lib_log as L    # 콘솔 LOG 출력 (L.event · L.more · L.key …)
from ..core.q01lib_imu import BodyIMU, STILL_TIMEOUT_SEC
from .q01lib_body_pose import POSE_AXES, body_pose_feet, zero_pose
from .q01lib_body_pose_screen import BodyPoseScreen, attitude_text, help_text, keys_text, tag

# F1 키 안내 화면에 쓰는 짧은 말 (+ 방향, - 방향)
HELP_WORDS = {
    "x": ("앞", "뒤"),
    "y": ("왼쪽", "오른쪽"),
    "z": ("위", "아래"),
    "roll": ("오른쪽 아래", "왼쪽 아래"),
    "pitch": ("머리 아래", "머리 위"),
    "yaw": ("왼쪽 돎", "오른쪽 돎"),
}
# 콘솔 키 안내 · 키 입력 줄에 쓰는 영어 (+ 방향, - 방향)
AXIS_WORDS_EN = {
    "x": ("fwd", "back"),
    "y": ("left", "right"),
    "z": ("up", "down"),
    "roll": ("right down", "left down"),
    "pitch": ("nose down", "nose up"),
    "yaw": ("turn left", "turn right"),
}
UNIT_EN = {"x": "", "y": "", "z": "", "roll": " deg", "pitch": " deg", "yaw": " deg"}
MOVE_AXES = ("x", "y", "z")
TURN_AXES = ("roll", "pitch", "yaw")

IMU_SETTLE_SEC = 0.5         # 기본 자세로 선 뒤 최소로 기다리는 시간(초). 그 뒤 IMU가 멈출 때까지 기다림
IMU_LOG_DELAY_SEC = 1.0      # 키를 누른 뒤 서보가 멈출 때까지 기다렸다가 IMU 값을 콘솔에 남김(초)
ZERO_SPREAD_WARN_DEG = 1.0   # 영점을 잡는 동안 IMU가 이보다 많이 움직이면 콘솔에 알림(도)


class BodyPoseTest:
    """몸체 자세 테스트 (Book-QUAD-01-ROLL_PITCH_YAW)."""

    TITLE = "몸체 자세 테스트"
    SHORT = "몸체 자세"
    HEADER = "QUAD-01 BODY POSE  x y z roll pitch yaw   (Book-QUAD-01-ROLL_PITCH_YAW)"
    LOG_CATEGORIES = ("ACTION", "SENSOR")   # 공통 분류 밖에 이 테스트가 콘솔에 쓰는 분류 (열 맞추기)
    START_FILE = "q01_body_pose_start.py"
    USES_LEG_SELECT = False
    VALUE_NAMES = ("KEY_REPEAT_SEC", "BODY_LENGTH", "BODY_WIDTH",
                   "MOVE_STEP", "ANGLE_STEP_DEG", "POSE_MOVE_STEPS",
                   "X_RANGE", "Y_RANGE", "Z_RANGE", "ROLL_RANGE", "PITCH_RANGE", "YAW_RANGE",
                   "AUTO_MOVE", "AUTO_ANGLE_DEG", "AUTO_STEP_SEC",
                   "POSE_KEYS", "AUTO_TEST_KEY", "USE_IMU", "LOG_DETAIL")

    def __init__(self, robot, settings):
        self.robot = robot
        self.motion = robot.motion
        self.s = settings
        self.screen = BodyPoseScreen()      # 이 테스트만 쓰는 로봇 화면 (Text Screen, Port 0)
        self.pose = zero_pose()
        self.note = None            # 화면 안내 줄에 쓰는 알림 (갈 수 없는 자세 · 범위 끝)
        self.help_shown = False     # F1 키 안내 화면이 떠 있으면 True (다시 쓰기에서 덮지 않음)
        self.imu = None             # BodyIMU (USE_IMU가 True이고 IMU를 읽을 수 있을 때)
        self.imu_note = None        # IMU를 쓸 수 없을 때 화면에 쓰는 설명
        self.imu_log_at = None      # 이 시각이 지나면 IMU 값을 콘솔에 남김
        self.imu_error = None
        if settings["USE_IMU"]:
            try:
                self.imu = BodyIMU(ports.PORT_INERTIAL_SENSOR)
            except Exception as e:
                self.imu_error = e          # 시작 안내 뒤에 콘솔에 알림 (enter)
                self.imu_note = f"IMU 없음 (Port {ports.PORT_INERTIAL_SENSOR})"
        self.ranges = {"x": settings["X_RANGE"], "y": settings["Y_RANGE"], "z": settings["Z_RANGE"],
                       "roll": settings["ROLL_RANGE"], "pitch": settings["PITCH_RANGE"],
                       "yaw": settings["YAW_RANGE"]}
        for key, (axis, sign) in settings["POSE_KEYS"].items():
            if axis not in POSE_AXES or sign not in (1, -1):
                raise ValueError(f"POSE_KEYS '{key}': axis must be one of {', '.join(POSE_AXES)}, direction 1 or -1")

    # ------------------------------------------------------------
    # 키 · 화면 · 콘솔 안내
    # ------------------------------------------------------------
    def actions(self):
        """(키, 콘솔에 남길 설명, 실행할 함수, 걸린 시간을 남길지) 목록."""
        items = []
        for key, (axis, sign) in self.s["POSE_KEYS"].items():
            items.append((key, f"body {axis} {'+' if sign > 0 else '-'} ({self._direction_en(axis, sign)})",
                          lambda axis=axis, sign=sign: self.step(axis, sign), False))
        items.append((self.s["AUTO_TEST_KEY"], "auto test", self.auto_test, True))
        return items

    def repeat_keys(self):
        """누르고 있으면 KEY_REPEAT_SEC마다 다시 실행하는 키."""
        return list(self.s["POSE_KEYS"])

    @staticmethod
    def _direction_en(axis, sign):
        return AXIS_WORDS_EN[axis][0 if sign > 0 else 1]

    def _axis_keys(self):
        """축마다 [(키, 방향), ...]. 시작 파일 POSE_KEYS에 적은 순서 (예: "roll": [("J", -1), ("L", 1)])."""
        keys = {}
        for key, (axis, sign) in self.s["POSE_KEYS"].items():
            keys.setdefault(axis, []).append((key_label(key), sign))
        return keys

    def guide(self):
        """콘솔 키 안내 (영어)."""
        s = self.s
        keys = self._axis_keys()

        def item(axis):
            names = "/".join(k for k, _ in keys[axis])
            words = "/".join(AXIS_WORDS_EN[axis][0 if d > 0 else 1] for _, d in keys[axis])
            return f"{L.key(names)} {axis} {words}"

        def ranges(axes):
            return "  ".join(f"{a} {self.ranges[a][0]}..{self.ranges[a][1]}" for a in axes)
        move = [a for a in keys if a in MOVE_AXES]
        turn = [a for a in keys if a in TURN_AXES]
        return [f" Move   {'   '.join(item(a) for a in move)}",
                f"        {s['MOVE_STEP']} per key   {ranges(MOVE_AXES)}",
                f" Tilt   {item(turn[0])}   {item(turn[1])}" if len(turn) > 1 else f" Tilt   {item(turn[0])}",
                *([f"        {'   '.join(item(a) for a in turn[2:])}"] if len(turn) > 2 else []),
                f"        {s['ANGLE_STEP_DEG']} deg per key   {ranges(TURN_AXES)}",
                f" Test   {L.key(key_label(s['AUTO_TEST_KEY']))} auto test (tilt +-{s['AUTO_ANGLE_DEG']} deg, "
                f"move +-{s['AUTO_MOVE']})",
                " Frame  x fwd(+) y left(+) z up(+)  roll+ right down  pitch+ nose down"]

    def _key(self, name):
        """시작 파일의 키 이름(예: "HELP_KEY") → 화면에 쓰는 키 글자 (예: "F1")."""
        return key_label(self.s[name])

    def screen_text(self, state, info):
        """로봇 화면 글자: 상태 상자(상태 · 안내) + 격자 + 막대 + IMU 줄. 알림이 있으면 안내 대신 빨강으로."""
        if self.note:
            info = tag(f"{self.note} · 이전 자세 유지", "alert")
        return attitude_text(self.pose, state, info, self.imu_screen_value())

    def show_idle(self):
        """대기 화면 (다리 테스트 프로그램이 키를 하나 실행할 때마다 부름)."""
        self.help_shown = False
        if self.robot.interrupted:
            state = "멈춤 (자동 테스트)"
            info = keys_text([(self._key("STAND_KEY"), "기본 자세"), (self._key("AUTO_TEST_KEY"), "자동 테스트")])
        else:
            state = "대기"
            info = keys_text([(self._key("HELP_KEY"), "키 안내"), (self._key("AUTO_TEST_KEY"), "자동 테스트")])
        self.screen.show(self.screen_text(state, info))

    def show_running(self, axis):
        """자동 테스트 중 화면."""
        info = keys_text([(self._key("STOP_KEY"), "멈춤"), (self._key("STAND_KEY"), "기본 자세")])
        self.screen.show(self.screen_text(f"자동 테스트 중 · {axis}", info))

    def show_help_screen(self):
        """F1 키 안내 화면 (이 테스트의 키). 한 줄에 키 묶음 하나, 설명은 줄 끝에."""
        keys = self._axis_keys()
        lines = []
        for axis in keys:
            names = " ".join(k for k, _ in keys[axis])
            words = " · ".join(HELP_WORDS[axis][0 if d > 0 else 1] for _, d in keys[axis])
            lines.append(f" {tag(f'{names:<4}', 'key')}{axis:<6}{tag(words, 'text')}")
        auto = f"{self._key('AUTO_TEST_KEY'):<4}"
        lines.append(f" {tag(auto, 'key')}{tag('자동 테스트', 'text')}")
        lines.append(" " + keys_text([(self._key("STAND_KEY"), "기본 자세"), (self._key("STOP_KEY"), "멈춤")], "   "))
        info = tag("다른 키를 누르면 돌아감", "text")
        self.help_shown = True
        self.screen.show(help_text("키 안내", info, lines))

    def on_loop(self):
        """다리 테스트 프로그램이 키를 한 번 읽을 때마다 부름.

        키를 누르고 IMU_LOG_DELAY_SEC가 지나면 IMU 값을 콘솔에 남기고, REFRESH_SEC마다 화면을
        다시 씁니다(IMU 값 갱신). F1 키 안내 화면은 덮지 않습니다.
        """
        if self.imu_log_at is not None and time.time() >= self.imu_log_at:
            self.imu_log_at = None
            self.log_imu()
            if not self.help_shown:
                self.show_idle()
        elif not self.help_shown and self.screen.due():
            self.show_idle()

    # ------------------------------------------------------------
    # IMU (실제 기울기 확인)
    # ------------------------------------------------------------
    def _imu_failed(self, error):
        L.event("WARN", f"no IMU on port {ports.PORT_INERTIAL_SENSOR}: continuing without it")
        L.more(str(error))
        self.imu = None
        self.imu_note = f"IMU 없음 (Port {ports.PORT_INERTIAL_SENSOR})"

    def read_imu(self):
        """IMU로 잰 (roll, pitch, yaw) 도. IMU를 쓰지 않거나 읽을 수 없으면 None."""
        if self.imu is None:
            return None
        try:
            return self.imu.read()
        except Exception as e:
            self._imu_failed(e)
            return None

    def imu_screen_value(self):
        """화면 IMU 줄에 쓸 값: (roll, pitch, yaw), 설명 글자, 또는 None(USE_IMU False)."""
        values = self.read_imu()
        if values is not None:
            return values
        return self.imu_note

    def calibrate_imu(self):
        """기본 자세에서 IMU 영점을 잡습니다 (지금 기울기를 0으로)."""
        if self.imu is None:
            return
        time.sleep(IMU_SETTLE_SEC)
        try:
            zero = self.imu.calibrate()
            L.event("SENSOR", f"zero  {L.angles_text(zero)}")
            L.more(f"still after {self.imu.wait_sec:.1f} s  spread={self.imu.spread:.2f} deg")
            if not self.imu.settled:
                L.event("WARN", f"IMU not still after {STILL_TIMEOUT_SEC:g} s: robot moving")
            elif self.imu.spread > ZERO_SPREAD_WARN_DEG:
                L.event("WARN", f"IMU moved {self.imu.spread:.1f} deg while zeroing: robot not still")
        except Exception as e:
            self._imu_failed(e)

    def log_imu(self):
        """콘솔: IMU로 잰 기울기와 명령한 기울기."""
        values = self.read_imu()
        if values is None:
            return
        p = self.pose
        diff = [values[0] - p["roll"], values[1] - p["pitch"], values[2] - p["yaw"]]
        L.event("SENSOR", f"imu   {L.angles_text(values)}")
        L.more(f"cmd   roll={L.num(p['roll'])} pitch={L.num(p['pitch'])} yaw={L.num(p['yaw'])}  "
               f"diff {L.signed(diff[0], 0)} {L.signed(diff[1], 0)} {L.signed(diff[2], 0)}")

    def enter(self):
        """시작할 때: 네 다리를 기본 자세로 옮깁니다."""
        if self.imu_error is not None:
            self._imu_failed(self.imu_error)
        self.robot.stand()
        self.on_stand()
        self.calibrate_imu()

    def on_stand(self):
        """기본 자세로 옮긴 뒤: 몸체 자세 값을 모두 0으로."""
        self.pose = zero_pose()
        self.note = None
        self.log_pose()

    def before_action(self):
        """키 하나를 실행하기 전에: 지난 알림을 지웁니다."""
        self.note = None

    def after_stop(self):
        """자동 테스트를 멈춘 뒤: 보낸 각도를 맞춥니다. 몸체 자세 값은 멈춘 자세 그대로."""
        self.robot.sync_from_motion()

    # ------------------------------------------------------------
    # 몸체 자세 바꾸기
    # ------------------------------------------------------------
    def check(self, pose):
        """자세 하나를 확인합니다. (네 발끝 좌표, 문제 설명 또는 None). 서보는 움직이지 않습니다."""
        feet = body_pose_feet(pose, self.s["BODY_HEIGHT"], self.s["BODY_LENGTH"], self.s["BODY_WIDTH"])
        for leg, point in enumerate(feet):
            r = check_point(self.motion, leg, point)
            name = ports.LEG_NAMES[leg]
            if not r["ok"]:
                return feet, (f"{name} 갈 수 없음", f"{name} foot {r['reason']}")
            if r["limited"]:
                return feet, (f"{name} {'·'.join(r['limited'])} 제한",
                              f"{name} {' '.join(r['limited'])} at 0/180 deg limit")
        return feet, None

    def step(self, axis, sign, log_feet=True):
        """몸체 자세의 axis 값을 한 번(MOVE_STEP · ANGLE_STEP_DEG) 바꿉니다. 바꿨으면 True."""
        s = self.s
        size = s["MOVE_STEP"] if axis in MOVE_AXES else s["ANGLE_STEP_DEG"]
        lo, hi = self.ranges[axis]
        unit = UNIT_EN[axis]
        target = max(lo, min(hi, self.pose[axis] + sign * size))
        if target == self.pose[axis]:
            L.event("WARN", f"{axis} already at {target:g}{unit} (range {lo}..{hi})")
            self.note = f"{axis} 범위 끝"
            return False
        pose = dict(self.pose)
        pose[axis] = target
        feet, problem = self.check(pose)
        if problem:
            L.event("WARN", f"{axis} {self.pose[axis]:g} -> {target:g}{unit} not possible, pose kept")
            L.more(problem[1])
            self.note = problem[0]
            return False
        self.pose = pose
        self.move(feet)
        self.log_pose(log_feet and self.s["LOG_DETAIL"])
        if log_feet and self.imu is not None:
            self.imu_log_at = time.time() + IMU_LOG_DELAY_SEC
        return True

    def move(self, feet):
        """네 발끝을 feet로 옮깁니다 (POSE_MOVE_STEPS 단계, 1이면 바로)."""
        steps = self.s["POSE_MOVE_STEPS"]
        if steps <= 1:
            for leg in range(4):
                self.motion.points[leg] = list(feet[leg])
            self.motion.run()
        else:
            self.motion.move_to([list(p) for p in feet], steps)
        self.robot.sync_from_motion()

    def log_pose(self, log_feet=False):
        """콘솔: 몸체 자세 한 줄. log_feet이면 다리마다 발끝 좌표와 서보 각도 (LOG_DETAIL)."""
        p = self.pose
        L.event("ACTION", f"pose  x={L.num(p['x'])} y={L.num(p['y'])} z={L.num(p['z'])}  "
                          f"roll={L.num(p['roll'])} pitch={L.num(p['pitch'])} yaw={L.num(p['yaw'])} deg")
        if not log_feet:
            return
        L.more("foot       x       y        z    HX  HY  KN")
        for leg in range(4):
            x, y, z = self.motion.points[leg]
            hx, hy, kn = self.robot.leg_servo(leg)
            L.more(f"{ports.LEG_NAMES[leg]:<4} {x:7.1f} {y:7.1f} {z:8.1f}   {hx:3} {hy:3} {kn:3}")

    # ------------------------------------------------------------
    # 자동 테스트
    # ------------------------------------------------------------
    def auto_sequence(self):
        """자동 테스트의 순서: 축마다 0 → +A → 0 → -A → 0 (한 번에 한 칸씩)."""
        s = self.s
        sequence = []
        for axis in ("roll", "pitch", "yaw", "z", "x", "y"):
            size = s["ANGLE_STEP_DEG"] if axis in TURN_AXES else s["MOVE_STEP"]
            amount = s["AUTO_ANGLE_DEG"] if axis in TURN_AXES else s["AUTO_MOVE"]
            n = max(1, round(amount / size))
            for sign in (1, -1):
                sequence += [(axis, sign)] * n + [(axis, -sign)] * n
        return sequence

    def auto_test(self):
        """기본 자세에서 여섯 값을 차례로 바꿨다 되돌린 뒤 기본 자세로 돌아옵니다.

        한 칸마다 AUTO_STEP_SEC 기다립니다 (F3 멈춤 · F2 기본 자세).
        """
        L.event("TASK", "auto test: roll, pitch, yaw, z, x, y")
        if self.pose != zero_pose():
            self.robot.stand()          # 기본 자세에서 시작 (기본 자세로 돌아오며 끝나도록)
            self.on_stand()
        current = None
        for axis, sign in self.auto_sequence():
            if axis != current:
                current = axis
                L.event("TASK", f"auto test: {axis}")
            moved = self.step(axis, sign, log_feet=False)
            self.show_running(axis)
            if not moved:
                L.event("WARN", f"{axis} step skipped")
            self.robot.wait(self.s["AUTO_STEP_SEC"])
        self.robot.stand()
        self.on_stand()

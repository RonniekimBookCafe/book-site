# -*- coding: utf-8 -*-
"""
Q01_Lib/body_pose  |  몸체 자세 테스트 (q01_body_pose_start.py · Book-QUAD-01-ROLL_PITCH_YAW)

    q01lib_body_pose.py        몸체 자세 (x y z · roll pitch yaw) → 네 다리의 발끝 좌표 (계산만)
    q01lib_body_pose_test.py   BodyPoseTest: 키로 몸체 자세를 한 값씩 바꾸고, 자동 테스트
    q01lib_body_pose_screen.py BodyPoseScreen: 이 테스트만 쓰는 로봇 화면 (상태 상자 · Attitude Angle 격자 · 막대)

키를 읽는 반복 부분과 서보 · 기본 자세는 leg_common 폴더를 다리 테스트와 함께 씁니다.
로봇 화면은 함께 쓰지 않고 q01lib_body_pose_screen.py가 따로 맡습니다.
"""

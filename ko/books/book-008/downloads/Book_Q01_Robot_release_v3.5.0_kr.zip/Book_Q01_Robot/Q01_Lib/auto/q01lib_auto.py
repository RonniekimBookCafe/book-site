# -*- coding: utf-8 -*-
"""
q01lib_auto.py  |  QUAD-01 교육용 라이브러리 · 자동 동작 모드 (1·2·3번 키)

정해진 순서대로 보행 동작을 이어서 실행하는 자동 모드입니다. 각 모드는
QuadRobot의 보행 동작을 auto_mode=True, duration=초 로 부릅니다.
키가 아니라 시간으로 동작을 끝냅니다.

    1번 키  자동 모드 1 : 기본 이동 패턴
            전진 3초 → 후진 3초 → 좌회전 3초 → 우회전 3초
            → 왼쪽 측면 2초 → 오른쪽 측면 2초
    2번 키  자동 모드 2 : 높이별 주행 안정성 테스트
            표준(BODY_HEIGHT) → 낮음 69 → 포복 45 → 높음 119 → 표준, 높이마다 4초 전진
    3번 키  자동 모드 3 : 복합 동작 패턴 (4단계)
            직선 → 대각선 4방향 → 지그재그 → 대각선·360도 회전

[콘솔 LOG]  (영어, 형식은 core/q01lib_log.py)
    [  6.0] [TASK]      auto 1  basic moves  start
    [  6.0] [TASK]      1/6  forward     3.0 s
    ...
    [ 26.3] [TASK]      auto 1  done in 20.3 s
단계마다 [TASK] 한 줄을 남깁니다. 자동 모드 2는 단계마다 몸체 높이와 보폭을 함께
씁니다. 단계 사이의 기본 자세 복귀는 콘솔에 따로 남기지 않습니다.

[알아 두기]
자동 모드는 한 번 시작하면 모드가 끝날 때까지 메인 루프로 돌아가지 않습니다.
그래서 실행 중에는 다른 키를 읽지 않고, 모드가 끝난 뒤에 다시 키를 받습니다.
"""

import time

from ..walk.q01lib_gait import diagonal_pair, zigzag_pair, Phase
from ..core import q01lib_log as L    # 콘솔 LOG 출력 (L.event · L.more · L.key …)

# 자동 모드 2의 자세 높이 (표준 높이는 QuadRobot.base_height = BODY_HEIGHT)
LOW_HEIGHT = 69       # 표준보다 약 30% 낮춘 높이
CRAWL_HEIGHT = 45     # 포복 높이
HIGH_HEIGHT = 119     # 표준보다 약 20% 높인 높이

# 자동 모드 3의 대각선 이동 진폭 (x 앞뒤, y 좌우). 부호: x + 앞 / y + 왼쪽
DIAGONALS = {
    "forward_left":   (15, 10),
    "forward_right":  (15, -10),
    "backward_left":  (-15, 10),
    "backward_right": (-15, -10),
}

# 자동 모드 3의 지그재그 y(좌우) 진폭. 부호: + 왼쪽으로 휨
ZIGZAGS = {
    "forward_left_turn": 12,
    "forward_right_turn": -12,
}

# 대각선·지그재그 이동의 위상 증가량(도)
PATTERN_SPEED = 2.5


class AutoModes:
    """자동 동작 모드 1·2·3을 실행하는 클래스."""

    def __init__(self, robot):
        self.robot = robot

    @property
    def active(self) -> bool:
        """자동 모드가 실행 중이면 True."""
        return self.robot.auto_mode_active

    # ------------------------------------------------------------
    # 시작과 중지
    # ------------------------------------------------------------
    def start(self, mode):
        """자동 모드를 시작합니다. 이미 실행 중이면 중지합니다.

        :param mode: 자동 모드 번호 (1, 2, 3)
        """
        if self.robot.auto_mode_active:
            self.stop()
            return

        self.robot.auto_mode_active = True

        if mode == 1:
            self.mode_1_basic_movement()
        elif mode == 2:
            self.mode_2_height_pattern()
        elif mode == 3:
            self.mode_3_complex_pattern()
        else:
            L.event("WARN", f"unknown auto mode {mode}")
            self.robot.auto_mode_active = False

    def stop(self):
        """자동 모드를 중지하고 기본 자세로 돌아갑니다."""
        if self.robot.auto_mode_active:
            self.robot.auto_mode_active = False
            self.robot.default_position()
            L.event("TASK", "auto mode stopped -> default pose")

    # ------------------------------------------------------------
    # 콘솔
    # ------------------------------------------------------------
    @staticmethod
    def _begin(mode, name):
        """모드 시작 줄을 남기고 시작 시각을 돌려줍니다."""
        L.event("TASK", f"auto {mode}  {name}  start")
        return time.time()

    @staticmethod
    def _done(mode, start):
        L.event("TASK", f"auto {mode}  done in {time.time() - start:.1f} s")

    @staticmethod
    def _step(text):
        L.event("TASK", text)

    # ------------------------------------------------------------
    # 자동 모드 1: 기본 이동 패턴
    # ------------------------------------------------------------
    def mode_1_basic_movement(self):
        """앞으로 3초 → 뒤로 3초 → 왼쪽 회전 3초 → 오른쪽 회전 3초
        → 왼쪽 측면 2초 → 오른쪽 측면 2초
        """
        robot = self.robot
        start = self._begin(1, "basic moves")

        try:
            # 앞으로 3초 이동
            self._step("1/6  forward     3.0 s")
            robot.forward(duration=3.0, auto_mode=True, speed=2.5, stride_x=12, lift_z=6)

            if not self.active:
                return

            # 0.5초 정지
            robot.default_position()
            time.sleep(0.5)

            # 뒤로 3초 이동
            self._step("2/6  backward    3.0 s")
            robot.backward(duration=3.0, auto_mode=True)

            if not self.active:
                return

            # 0.5초 정지
            robot.default_position()
            time.sleep(0.5)

            # 왼쪽으로 3초 회전
            self._step("3/6  turn left   3.0 s")
            robot.turn_left(duration=3.0, auto_mode=True)

            if not self.active:
                return

            # 0.5초 정지
            robot.default_position()
            time.sleep(0.5)

            # 오른쪽으로 3초 회전
            self._step("4/6  turn right  3.0 s")
            robot.turn_right(duration=3.0, auto_mode=True)
            time.sleep(0.5)

            # 0.5초 정지
            robot.default_position()
            time.sleep(0.5)

            # 왼쪽 측면 이동 2초
            self._step("5/6  side left   2.0 s")
            robot.step_left(duration=2.0, auto_mode=True)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.3)

            # 오른쪽 측면 이동 2초
            self._step("6/6  side right  2.0 s")
            robot.step_right(duration=2.0, auto_mode=True)
            if not self.active:
                return

            # 기본 자세로 복귀
            robot.default_position()
            self._done(1, start)

        except Exception as e:
            L.event("ERROR", f"auto 1: {e}")
        finally:
            robot.auto_mode_active = False

    # ------------------------------------------------------------
    # 자동 모드 2: 높이별 주행 안정성 테스트
    # ------------------------------------------------------------
    def mode_2_height_pattern(self):
        """다양한 몸체 높이에서 전진해 자세 전환과 주행 안정성을 확인합니다.
        표준 높이는 BODY_HEIGHT(기본 99)를 씁니다.
        """
        robot = self.robot
        base = robot.base_height
        start = self._begin(2, "height test")

        try:
            # 1. 기본 자세 확인 (2초)
            self._step(f"1/9  stand            h={base:3g} mm  2.0 s")
            robot.height = base
            robot.default_position()
            time.sleep(2)

            if not self.active:
                return

            # 2. 표준 높이 주행 (4초)
            self._step(f"2/9  walk standard    h={base:3g} mm  4.0 s  stride 32/16")
            robot.forward(duration=4.0, auto_mode=True, speed=2.5, stride_x=32, lift_z=16)

            if not self.active:
                return

            robot.default_position()
            time.sleep(0.5)

            # 3. 자세 전환: 표준 → 낮음 (2초)
            self._step(f"3/9  height {base:3g} -> {LOW_HEIGHT:3g} mm  2.0 s")
            robot.smooth_height_transition(LOW_HEIGHT, duration=2.0)

            if not self.active:
                return

            # 4. 낮은 자세 주행 (4초)
            self._step(f"4/9  walk low         h={LOW_HEIGHT:3g} mm  4.0 s  stride 12/6")
            robot.forward(duration=4.0, auto_mode=True, speed=2, stride_x=12, lift_z=6)

            if not self.active:
                return

            robot.default_position()
            time.sleep(0.5)

            # 5. 자세 전환: 낮음 → 포복 (2초)
            self._step(f"5/9  height {LOW_HEIGHT:3g} -> {CRAWL_HEIGHT:3g} mm  2.0 s")
            robot.smooth_height_transition(CRAWL_HEIGHT, duration=2.0)

            if not self.active:
                return

            # 6. 포복 주행 (4초)
            self._step(f"6/9  walk crawl       h={CRAWL_HEIGHT:3g} mm  4.0 s  stride 12/6")
            robot.forward(duration=4.0, auto_mode=True, speed=1.5, stride_x=12, lift_z=6)

            if not self.active:
                return

            robot.default_position()
            time.sleep(0.5)

            # 7. 자세 전환: 포복 → 높음 (3초)
            self._step(f"7/9  height {CRAWL_HEIGHT:3g} -> {HIGH_HEIGHT:3g} mm  3.0 s")
            robot.smooth_height_transition(HIGH_HEIGHT, duration=3.0)

            if not self.active:
                return

            # 8. 높은 자세 주행 (4초)
            self._step(f"8/9  walk high        h={HIGH_HEIGHT:3g} mm  4.0 s  stride 12/6")
            robot.forward(duration=4.0, auto_mode=True, speed=1.5, stride_x=12, lift_z=6)

            if not self.active:
                return

            robot.default_position()
            time.sleep(0.5)

            # 9. 기본 자세 복귀 (2초)
            self._step(f"9/9  height {HIGH_HEIGHT:3g} -> {base:3g} mm  2.0 s")
            robot.smooth_height_transition(base, duration=2.0)

            if not self.active:
                return

            robot.default_position()

            self._done(2, start)

        except Exception as e:
            L.event("ERROR", f"auto 2: {e}")
            # 오류가 나면 표준 높이의 기본 자세로 복귀
            robot.height = base
            robot.default_position()
            L.event("STATE", "back to default pose")
        finally:
            robot.auto_mode_active = False

    # ------------------------------------------------------------
    # 자동 모드 3: 복합 동작 패턴
    # ------------------------------------------------------------
    def mode_3_complex_pattern(self):
        """1단계 직선(6초) → 2단계 대각선 4방향(12초) → 3단계 지그재그(16초)
        → 4단계 대각선 6초 + 360도 회전 6초. 단계 사이에 1초 대기.
        """
        robot = self.robot
        start = self._begin(3, "complex pattern")

        try:
            # 1단계: 직선 테스트 세트 (6초)
            self._step("stage 1/4  straight")

            self._step("  1.1  forward          3.0 s")
            robot.forward(duration=3.0, auto_mode=True, speed=2.5, stride_x=20, lift_z=10)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.2)

            self._step("  1.2  backward         3.0 s")
            robot.backward(duration=3.0, auto_mode=True, speed=2.5)
            if not self.active:
                return

            robot.default_position()

            time.sleep(1.0)
            if not self.active:
                return

            # 2단계: 대각선 이동 (12초)
            self._step("stage 2/4  diagonal")

            self._step("  2.1  forward-left     3.0 s")
            self._diagonal_movement("forward_left", 3.0)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.2)

            self._step("  2.2  forward-right    3.0 s")
            self._diagonal_movement("forward_right", 3.0)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.2)

            self._step("  2.3  backward-left    3.0 s")
            self._diagonal_movement("backward_left", 3.0)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.2)

            self._step("  2.4  backward-right   3.0 s")
            self._diagonal_movement("backward_right", 3.0)
            if not self.active:
                return

            robot.default_position()

            time.sleep(1.0)
            if not self.active:
                return

            # 3단계: 지그재그 테스트 (16초)
            self._step("stage 3/4  zigzag")

            zigzag_patterns = [
                ("forward_left_turn", "forward + left"),
                ("forward_right_turn", "forward + right"),
                ("forward_left_turn", "forward + left"),
                ("forward_right_turn", "forward + right"),
            ]

            for i, (pattern, description) in enumerate(zigzag_patterns):
                self._step(f"  3.{i + 1}  {description:<16} 4.0 s")
                self._zigzag_movement(pattern, 4.0)
                if not self.active:
                    return

                # 패턴 사이 짧은 정지
                robot.default_position()
                time.sleep(0.2)

            time.sleep(1.0)
            if not self.active:
                return

            # 4단계: 복합 테스트 피니시 (18초)
            self._step("stage 4/4  finish")

            self._step("  4.1  diagonal x4      6.0 s")
            self._extended_diagonal_test(6.0)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.3)

            self._step("  4.2  turn right       6.0 s")
            self._full_rotation(6.0)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.3)

            self._done(3, start)

        except Exception as e:
            L.event("ERROR", f"auto 3: {e}")
            robot.default_position()
            L.event("STATE", "back to default pose")
        finally:
            robot.auto_mode_active = False

    # ------------------------------------------------------------
    # 자동 모드 3의 보조 동작
    # ------------------------------------------------------------
    def _pattern_walk(self, duration, coords_fn):
        """duration초 동안 위상 90 → 450도를 반복하며 coords_fn의 좌표로 걷습니다."""
        robot = self.robot
        phase = Phase(90, PATTERN_SPEED, 90, 450)
        start_time = time.time()

        while time.time() - start_time < duration and self.active:
            X1, Y1, Z1, X2, Y2, Z2 = coords_fn(phase.angle)
            robot.motion.change_coordinates("forward", X1, Y1, Z1, X2, Y2, Z2)
            phase.advance()

    def _diagonal_movement(self, direction, duration):
        """대각선 이동: 전진·후진과 좌우 이동을 함께 합니다.

        :param direction: "forward_left" · "forward_right" · "backward_left" · "backward_right"
        """
        amp_x, amp_y = DIAGONALS[direction]
        self._pattern_walk(duration,
                           lambda angle: diagonal_pair(angle, amp_x, amp_y, self.robot.height))

    def _zigzag_movement(self, pattern, duration):
        """지그재그 이동: 전진하면서 한쪽으로 휩니다.

        :param pattern: "forward_left_turn" · "forward_right_turn"
        """
        amp_y = ZIGZAGS[pattern]
        self._pattern_walk(duration,
                           lambda angle: zigzag_pair(angle, amp_y, self.robot.height))

    def _extended_diagonal_test(self, duration):
        """대각선 4방향을 duration/4초씩 차례로 실행합니다."""
        pattern_duration = duration / 4
        patterns = ["forward_left", "forward_right", "backward_left", "backward_right"]

        for pattern in patterns:
            if not self.active:
                break
            self._diagonal_movement(pattern, pattern_duration)
            time.sleep(0.1)

    def _full_rotation(self, duration):
        """duration초 동안 오른쪽 회전을 0.3초씩 이어서 실행합니다."""
        start_time = time.time()

        while time.time() - start_time < duration and self.active:
            self.robot.turn_right(duration=0.3, auto_mode=True, speed=2.0)
            if not self.active:
                break


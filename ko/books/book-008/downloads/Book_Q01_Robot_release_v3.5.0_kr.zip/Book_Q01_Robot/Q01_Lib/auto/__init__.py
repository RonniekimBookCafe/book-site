# -*- coding: utf-8 -*-
"""
Q01_Lib/auto  |  자동 테스트 (q01_walk_start.py의 1·2·3번 키)

정해진 순서의 보행 동작을 시간에 맞춰 이어서 실행합니다.
"""

# -*- coding: utf-8 -*-
"""QUAD-01 WALK / LEG1-3 / BALANCE 시작 Welcome 표시만 담당합니다.

로봇 모델명은 일반 문자열로, WELCOME은 화면 둘째 줄로 고정합니다.
TextScreen 공식 속성만 이용하므로 단어별 색상 태그나 스크립트 강제 종료를 사용하지 않습니다.
"""
import time
from color import Color
from controllables import TextScreen

DEFAULT_WELCOME_SEC = 1.0
DEFAULT_START_SCREEN_SEC = 2.5
MAX_SCREEN_SEC = 60.0


def checked_duration(value, name):
    """시작 화면 유지 시간(초). 실제 RoboCo 실행 중 임의의 무한 대기 방지."""
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 <= value <= MAX_SCREEN_SEC:
        raise ValueError("{} must be between 0 and {} seconds".format(name, int(MAX_SCREEN_SEC)))
    return float(value)


def show_welcome(status_screen, model_name, seconds=DEFAULT_WELCOME_SEC):
    """TextScreen Port 0의 기존 정렬·색상 설정을 보존하고 2줄 Welcome을 표시합니다.

    정상적 순서: Welcome → 기존 시작 안내 → 메인. 종료 요청 시 불필요한 정리 대기는 없습니다.
    status_screen은 이미 준비된 StatusScreen 객체입니다.
    """
    seconds = checked_duration(seconds, "WELCOME_SEC")
    screen = status_screen.screen
    # 이후 원래 앱이 설정한 화면 스타일로 정확히 돌아옵니다.
    old = (screen.wrapping, screen.horizontal_alignment, screen.vertical_alignment,
           screen.auto_size, screen.color)
    try:
        screen.wrapping = False
        screen.horizontal_alignment = TextScreen.HorizontalAlignment.CENTER
        screen.vertical_alignment = TextScreen.VerticalAlignment.MIDDLE
        screen.auto_size = True
        screen.color = Color(0.86, 0.93, 1.00)  # ACTION Welcome과 동일한 밝은 컬러
        screen.text = "<color=#DBEDFF>{}\nWELCOME</color>".format(model_name)
        if seconds > 0:
            time.sleep(seconds)
    finally:
        (screen.wrapping, screen.horizontal_alignment, screen.vertical_alignment,
         screen.auto_size, screen.color) = old

# -*- coding: utf-8 -*-
"""
q01lib_ik.py  |  QUAD-01 교육용 라이브러리 · 역기구학 (좌표 → 관절 각도)

다리 끝(발끝)의 목표 좌표 (x, y, z)를 받아, 그 위치에 발끝을 두기 위한
관절 각도 (a, b, c)를 계산합니다. 이 계산을 역기구학(Inverse Kinematics,
IK)이라고 합니다.

    발끝 좌표 (x, y, z)
      -> coordinate_to_angle()  삼각함수로 관절 각도 계산
      -> (a, b, c)              a 엉덩이 X축(HX, roll 방향)
                                b 엉덩이 Y축(HY, pitch 방향)
                                c 무릎(KN, pitch 방향)

발끝 좌표는 다리 좌표계로 적습니다(Spot과 같은 축 방향).
    원점 : 그 다리의 엉덩이 관절
    x    : 앞 (+)
    y    : 왼쪽 (+)
    z    : 위 (+). 발끝은 엉덩이보다 아래에 있으므로 서 있을 때 z는 음수

이 파일의 함수는 RoboCo API를 쓰지 않는 순수 계산입니다. 그래서 RoboCo
밖의 Python에서도 그대로 실행해 결과를 확인할 수 있습니다.
"""

import math

from . import q01lib_ports as ports


def link_lengths(l1=None, l2=None, l3=None):
    """다리 링크 길이 (l1, l2, l3)를 돌려줍니다.

    값을 주지 않은 링크는 부를 때마다 q01lib_ports.LINK_HIP · LINK_UPPER ·
    LINK_LOWER에서 읽습니다. 그래서 q01lib_ports.py의 값을 바꾸면 IK와 FK
    계산에 바로 반영됩니다.
    """
    return (ports.LINK_HIP if l1 is None else l1,
            ports.LINK_UPPER if l2 is None else l2,
            ports.LINK_LOWER if l3 is None else l3)


def coordinate_to_angle(x, y, z, l1=None, l2=None, l3=None):
    """발끝 목표 좌표 (x, y, z)에서 관절 각도를 계산합니다(역기구학).

    :param x, y, z: 발끝 목표 좌표 (x 앞 · y 왼쪽 · z 위, 원점은 엉덩이 관절)
    :param l1, l2, l3: 다리 링크 길이. 생략하면 q01lib_ports.LINK_*
    :return: (a, b, c) 관절 각도 (도, 정수로 반올림)
    """
    l1, l2, l3 = link_lengths(l1, l2, l3)

    # 엉덩이에서 발끝까지의 아래 방향 거리 (발끝의 z는 음수이므로 부호를 바꿈)
    down = -z

    # 첫 번째 관절(a)의 각도 - x축 중심(roll 방향), y-z 평면에서 다리를 벌리고 모음
    angle_a = math.pi / 2 - math.atan2(y, down)

    # 첫 번째 링크(l1)의 아래 방향 성분과 y 성분
    x_4 = l1 * math.sin(angle_a)
    x_5 = l1 * math.cos(angle_a)

    # 두 번째 관절에서 발끝까지의 직선 거리
    l23 = math.sqrt((y - x_5) ** 2 + (down - x_4) ** 2 + x ** 2)

    # 삼각법으로 두 번째(b)와 세 번째(c) 관절 각도 계산
    w = x / l23                                         # 사인 값
    v = (l2**2 + l23**2 - l3**2) / (2 * l2 * l23)       # 코사인 법칙

    # 두 번째 관절(b) - y축 중심(pitch 방향), 다리를 앞뒤로 흔드는 회전
    angle_b = math.asin(round(w, 2)) - math.acos(round(v, 2))

    # 세 번째 관절(c) - 무릎(pitch 방향), 다리를 굽히는 회전
    angle_c = math.pi - math.acos(round((l2**2 + l3**2 - l23**2) / (2 * l3 * l2), 2))

    # 라디안 → 도
    return (
        round(math.degrees(angle_a)),
        round(math.degrees(angle_b)),
        round(math.degrees(angle_c)),
    )


def angle_to_coordinate(a, b, c, l1=None, l2=None, l3=None):
    """관절 각도 (a, b, c)에서 발끝 좌표를 계산합니다(순기구학).

    coordinate_to_angle()의 반대 계산입니다. 두 함수를 이어서 부르면 처음
    좌표로 돌아오는지(각도를 정수로 반올림한 만큼의 차이 안에서) 확인할 수
    있습니다. 각도는 coordinate_to_angle()이 돌려주는 값과 같은 기준이며,
    좌우 다리 방향 보정(q01lib_motion.py)을 하기 전의 각도입니다.

        a : 엉덩이 X축(HX), b : 엉덩이 Y축(HY, 0도 = 허벅지가 수직 아래),
        c : 무릎(KN, 0도 = 다리가 곧게 펴짐)

    :param a, b, c: 관절 각도 (도)
    :param l1, l2, l3: 다리 링크 길이. 생략하면 q01lib_ports.LINK_*
    :return: (x, y, z) 발끝 좌표 (x 앞 · y 왼쪽 · z 위, 원점은 엉덩이 관절)
    """
    l1, l2, l3 = link_lengths(l1, l2, l3)
    a = math.radians(a)
    b = math.radians(b)
    c = math.radians(c)

    # 다리 평면 안에서: 앞뒤 거리와, 엉덩이 X축 관절에서 발끝까지의 거리
    x = l3 * math.sin(b + c) + l2 * math.sin(b)
    reach = l3 * math.cos(b + c) + l2 * math.cos(b) + l1

    # 다리 평면을 엉덩이 X축(a)만큼 돌려 y(왼쪽)와 z(위)로 나눔
    down = reach * math.sin(a)
    y = reach * math.cos(a)
    return x, y, -down


def is_valid_point(point):
    """발끝 좌표가 다리가 닿을 수 있는 범위 안에 있으면 True.

    엉덩이(원점)에서 발끝까지의 거리가 REACH_MIN ~ REACH_MAX 사이인지 봅니다.
    닿을 수 없는 위치로 서보를 보내지 않기 위한 안전 검사입니다.
    """
    x, y, z = point
    length = math.sqrt(x**2 + y**2 + z**2)
    return ports.REACH_MIN <= length <= ports.REACH_MAX


def restrict_angle(angle, min_angle=ports.LOGICAL_MIN_DEG, max_angle=ports.LOGICAL_MAX_DEG):
    """각도를 서보의 논리 각도 범위(0~180도) 안으로 맞춥니다."""
    return max(min_angle, min(max_angle, angle))

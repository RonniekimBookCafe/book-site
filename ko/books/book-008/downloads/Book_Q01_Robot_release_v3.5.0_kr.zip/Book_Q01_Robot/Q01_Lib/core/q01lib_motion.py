# -*- coding: utf-8 -*-
"""
q01lib_motion.py  |  QUAD-01 교육용 라이브러리 · 발끝 좌표 → 관절 서보

네 다리의 발끝 좌표를 기억하고, 그 좌표를 관절 각도로 바꿔 서보 12개에
보냅니다. 보행·자세 동작(walk/q01lib_robot.py)은 서보 각도를 직접 정하지 않고
이 파일에 발끝 좌표만 넘깁니다.

    발끝 좌표 points[다리] = [x, y, z]   (x 앞 · y 왼쪽 · z 위, 원점은 엉덩이 관절)
      -> run()
           1. 좌표가 닿을 수 있는 범위인지 검사   (q01lib_ik.is_valid_point)
           2. 좌표 → 관절 각도 (a, b, c)          (q01lib_ik.coordinate_to_angle)
           3. 좌우 다리 방향 보정 + 0~180도 제한
           4. 서보 12개에 각도 전송               (q01lib_servo.ServoController)

[좌우 다리 방향 보정]
왼쪽 다리(FL·HL)와 오른쪽 다리(HR·FR)는 서보가 서로 마주 보게 달려
있습니다. 같은 발끝 위치를 만들기 위해 IK 각도를 다음처럼 바꿉니다.

            a (엉덩이 X축)   b (엉덩이 Y축)   c (무릎)
    왼쪽    a                90 - b           c
    오른쪽  a                90 + b           180 - c
"""

from . import q01lib_ports as ports
from .q01lib_servo import ServoController
from .q01lib_ik import coordinate_to_angle, is_valid_point, restrict_angle
from . import q01lib_log as L         # 콘솔 LOG 출력 (L.event · L.more · L.key …)


class LegMotion:
    """네 다리의 발끝 좌표를 관절 서보 움직임으로 바꾸는 클래스."""

    def __init__(self, body_height=99, servo_rpm=30):
        self.servo = ServoController()       # 서보 모터 제어 객체
        self.rpm = servo_rpm                 # run()에 속도를 따로 주지 않을 때 쓰는 서보 속도
        self.out_of_reach = False            # 지난 run()이 범위 밖 좌표로 건너뛰었는가 (콘솔 알림을 한 번만)
        self.last_error = None               # 지난 run()의 서보 오류 메시지 (같은 오류는 한 번만 남김)

        # 다리별 발끝 좌표 [x, y, z] - 시작 자세 (FL, HL, HR, FR)
        #   y : 왼쪽 다리 +, 오른쪽 다리 - (발끝을 몸통 바깥쪽으로)
        #   z : -body_height (발끝이 엉덩이보다 body_height만큼 아래)
        self.points = [
            [0, ports.FOOT_Y_OFFSET, -body_height],     # FL
            [0, ports.FOOT_Y_OFFSET, -body_height],     # HL
            [0, -ports.FOOT_Y_OFFSET, -body_height],    # HR
            [0, -ports.FOOT_Y_OFFSET, -body_height],    # FR
        ]
        # 다리별 관절 각도 [a, b, c] - run()이 마지막으로 보낸 값
        self.angles = [[90, 0, 0] for _ in range(4)]
        self.calibration_angles = ports.CALIBRATION_ANGLES

    def run(self, rpm=None):
        """지금 points의 발끝 좌표로 네 다리를 움직입니다.

        :param rpm: 서보 속도. 생략하면 self.rpm
        """
        if rpm is None:
            rpm = self.rpm

        # 1. 모든 좌표가 닿을 수 있는 범위인지 확인
        bad = [ports.LEG_NAMES[i] for i, p in enumerate(self.points) if not is_valid_point(p)]
        if bad:
            if not self.out_of_reach:
                L.event("WARN", f"foot out of reach ({' '.join(bad)}): servo command skipped")
            self.out_of_reach = True
            return
        if self.out_of_reach:
            L.event("STATE", "foot back in reach")
        self.out_of_reach = False

        try:
            # 2. 다리별 발끝 좌표 → 관절 각도
            # 3. 보정각 적용, 좌우 방향 보정, 0~180도 제한
            for i in range(4):
                self.angles[i] = self.to_servo_angles(i, coordinate_to_angle(*self.points[i]))

            # 4. 서보에 각도 전송 (다리 순서 FL, HL, HR, FR / 관절 순서 a, b, c)
            #    서보 모터 포트 순서 = [4, 3, 2, 7, 6, 5, 8, 9, 10, 11, 12, 13]
            servo_order = ports.SERVO_ORDER
            for leg in range(4):
                for axis in range(3):
                    servo_index = servo_order[leg * 3 + axis]
                    angle = self.angles[leg][axis]
                    self.servo.set_servo_angle(servo_index, angle, rpm)

        except Exception as e:
            if str(e) != self.last_error:
                L.event("ERROR", "servo command failed")
                for line in L.wrap(e):
                    L.more(line)
            self.last_error = str(e)
            return
        self.last_error = None

    def to_servo_angles(self, leg, ik_angles):
        """IK 각도 (a, b, c)를 그 다리의 서보에 보낼 논리 각도로 바꿉니다.

        보정각을 더하고, 좌우 다리 방향 보정을 한 뒤, 0~180도로 제한합니다.

        :param leg: 다리 번호 (0 FL, 1 HL, 2 HR, 3 FR)
        :param ik_angles: q01lib_ik.coordinate_to_angle()이 계산한 (a, b, c)
        :return: [HX, HY, KN] 논리 각도
        """
        a, b, c = ik_angles
        cal = self.calibration_angles[leg]
        if leg in ports.LEFT_LEGS:      # 왼쪽 다리 (0 FL, 1 HL)
            return [restrict_angle(a + cal[0]),
                    restrict_angle(90 - (b + cal[1])),
                    restrict_angle(c + cal[2])]
        else:                           # 오른쪽 다리 (2 HR, 3 FR)
            return [restrict_angle(a + cal[0]),
                    restrict_angle(90 + b + cal[1]),
                    restrict_angle(180 - (c + cal[2]))]

    def change_coordinates(self, move_order, X1, Y1, Z1, X2, Y2, Z2):
        """보행 궤적이 계산한 두 그룹의 좌표를 네 다리에 나눠 주고 움직입니다.

        트롯 보행이므로 대각선 두 다리가 같은 그룹입니다.
            그룹 1 (X1, Y1, Z1) : FL(0) · HR(2)
            그룹 2 (X2, Y2, Z2) : HL(1) · FR(3)

        X 앞뒤 · Y 좌우 · Z 위아래 (다리 좌표계).
        x에는 FOOT_X_OFFSET을, y에는 왼쪽 다리 +FOOT_Y_OFFSET · 오른쪽 다리
        -FOOT_Y_OFFSET을 더합니다. 제자리 회전(yaw)에서는 대각선 다리마다
        앞뒤·좌우 이동 방향의 부호를 바꿉니다.

        :param move_order: "turn_left" · "turn_right" · 그 밖(직진·측면 이동)
        """
        xo = ports.FOOT_X_OFFSET
        yo = ports.FOOT_Y_OFFSET
        if move_order == "turn_left":
            for i in range(2):
                self.points[2*i][0] = ((-1)**(1+i))*X1 + xo
                self.points[2*i][1] = ((-1)**(i))*Y1 + ((-1)**i)*yo
                self.points[2*i][2] = Z1
                self.points[1+2*i][0] = ((-1)**(1+i))*X2 + xo
                self.points[1+2*i][1] = ((-1)**(1+i))*Y2 + ((-1)**i)*yo
                self.points[1+2*i][2] = Z2
        elif move_order == "turn_right":
            for i in range(2):
                self.points[2*i][0] = ((-1)**(i))*X1 + xo
                self.points[2*i][1] = ((-1)**(1+i))*Y1 + ((-1)**i)*yo
                self.points[2*i][2] = Z1
                self.points[1+2*i][0] = ((-1)**(i))*X2 + xo
                self.points[1+2*i][1] = ((-1)**(i))*Y2 + ((-1)**i)*yo
                self.points[1+2*i][2] = Z2
        else:  # 전진·후진·측면 이동·대각선 이동
            for i in range(2):
                self.points[i*2][0] = X1 + xo
                self.points[i*2][1] = Y1 + ((-1)**i)*yo
                self.points[i*2][2] = Z1
                self.points[i*2+1][0] = X2 + xo
                self.points[i*2+1][1] = Y2 + ((-1)**i)*yo
                self.points[i*2+1][2] = Z2
        self.run()

    def move_to(self, target_positions, steps, rpm=None):
        """네 다리를 목표 좌표까지 steps 단계로 나눠 부드럽게 옮깁니다.

        :param target_positions: 다리별 목표 좌표 [[x, y, z] × 4]
        :param steps: 나눌 단계 수 (클수록 천천히 움직임)
        :param rpm: 서보 속도. 생략하면 self.rpm
        """
        increments = []
        for i in range(4):
            dx = (target_positions[i][0] - self.points[i][0]) / steps
            dy = (target_positions[i][1] - self.points[i][1]) / steps
            dz = (target_positions[i][2] - self.points[i][2]) / steps
            increments.append([dx, dy, dz])

        for _ in range(steps):
            for i in range(4):
                self.points[i][0] += increments[i][0]
                self.points[i][1] += increments[i][1]
                self.points[i][2] += increments[i][2]
            self.run(rpm)

# -*- coding: utf-8 -*-
"""
q01lib_log.py  |  QUAD-01 교육용 라이브러리 · 콘솔 LOG 형식 (모든 실습 공통)

콘솔 LOG는 영어로 씁니다. 한국어 책과 영어 책이 같은 실행 화면(동영상 · 캡처)을
쓰고, 영문 · 숫자만 쓰면 콘솔의 고정폭 글꼴에서 열이 맞기 때문입니다. 로봇
화면(Text Screen)과 코드 설명은 한국어 그대로입니다.

    [  3.2] [INPUT]     2    balance on/off
    [  3.2] [PARAMETER] KP=0.50  KI=1.50  KD=0.020  filter=kalman
    [  4.2] [SENSOR]    imu   roll= +1.2  pitch= +0.0  yaw= +0.0 deg
    [  4.2] [ACTION]    corr  roll= -1.7  pitch= +0.0 deg

    [  3.2]       프로그램을 시작한 뒤 지난 시간(초)
    [INPUT]       분류 (아래 CATEGORIES)
    key=value     값은 이름=값, 단위는 줄 끝에 한 번 (deg · s · mm)

[프로그램마다 열 맞추기]
프로그램은 시작할 때 configure()에 자기가 쓰는 분류만 넘깁니다. 분류 칸의 폭은
그 가운데 가장 긴 이름에 맞춥니다. 그래서 프로그램마다 내용이 시작하는 열이
다릅니다 (보행 · 균형 테스트 · 시험대 12칸, 액션 · 복합 테스트 · 몸체 자세 9칸, 관절 · IK 테스트 8칸).
한 프로그램 안에서는 모든 줄의 내용이 같은 열에서 시작합니다.

이어지는 줄(more)은 시간 · 분류 칸을 비우고 내용 열에 맞춥니다. 시작 안내(banner)는
시간 없이 =와 - 선으로 둘러쌉니다. 한 줄은 콘솔 폭에 맞춰 72자 이하로 씁니다.

[색]
COLOR가 True이면 시간 · 분류 이름 · 시작 안내 제목에 색을 입히고, WARN · ERROR는
내용까지 빨간색으로 씁니다. 키 이름(F1 · W · 1 · D/A처럼 누르는 키)은 시작 안내 · F1 키 안내 ·
[INPUT] 줄 · 다음 단계 안내(next: press 2)에서 노란색(KEY)으로 씁니다. 그래서 글자 사이에서도
어느 것이 키인지 바로 보입니다. 키 이름은 key()로 붙이고, 줄 길이는 색 태그를 뺀 글자 수
(visible_len)로 셉니다. 색은 Unity 리치 텍스트 태그(<color=#RRGGBB>…</color>)로
붙입니다. RoboCo Text Screen과 콘솔은 이 태그를 색으로 보여 줍니다. 콘솔에
<color=...> 글자가 그대로 보이면 시작 파일의 LOG_COLOR를 False로 바꿉니다. 색을 끄면 이 파일의 다른 출력은 그대로입니다.
색이 없어도 분류 이름이 남아 있으므로 색만으로 구분하지 않습니다.

모든 라이브러리 파일은 print()를 직접 부르지 않고 이 파일의 함수를 부릅니다.
콘솔 출력이 어디에서 나오는지 한곳에서 찾을 수 있게 하기 위해서입니다.

[콘솔에는 영문 · 숫자만]
log()는 영문 · 숫자 · 기호(ASCII)가 아닌 글자를 ?로 바꿔 씁니다. 코드의 LOG 문장은 모두
영어이지만, 시작 파일에 한글로 적은 값이 오류 메시지에 섞여 나오는 경우까지 막기 위해서입니다.
예상하지 못한 오류는 log_traceback()이 파일 이름 · 줄 번호 · 함수 이름만 영어로 씁니다.
Python 기본 오류 출력은 오류가 난 코드 줄을 그대로 보여 주므로, 그 줄의 한국어 주석이
콘솔에 나올 수 있기 때문입니다. 각 프로그램은 준비(시작 파일 값 확인)와 반복에서 난 오류를
모두 잡아 이 형식으로 남긴 뒤 멈춥니다.
"""

import threading
import time

# 분류 이름 (시리즈 공통 LOG 분류 + JOINT · WARN)
CATEGORIES = {
    "INPUT": "키 입력",
    "PARAMETER": "설정값 · 바꾼 값",
    "SENSOR": "센서 값 (IMU)",
    "STATE": "로봇 · 프로그램 상태 (기본 자세 · 준비 · 종료)",
    "ACTION": "실행한 동작 · 보정 · 자세 명령",
    "JOINT": "관절 서보에 보낸 각도",
    "TASK": "자동 동작 · 자동 테스트의 시작 · 단계 · 끝",
    "METRIC": "확인 결과 (IK · FK 오차 · IMU 판정 · 균형 테스트)",
    "WARN": "알림 (갈 수 없는 자세 · 설정 차이 · IMU 없음)",
    "ERROR": "예상하지 못한 오류",
}

# 색 (어두운 콘솔 배경 기준). 시리즈 Accent 색과 맞춤: INPUT Yellow · SENSOR Cyan · ACTION Orange
COLOR = True
COLORS = {
    "TIME": "#8A929C",       # 시간 · 선
    "INPUT": "#FFD91A",
    "PARAMETER": "#B39DFF",
    "SENSOR": "#20D6D9",
    "STATE": "#4ADE80",
    "ACTION": "#FF8A34",
    "JOINT": "#FFB070",
    "TASK": "#7FB2FF",
    "METRIC": "#9FD3FF",
    "WARN": "#FF5A52",
    "ERROR": "#FF5A52",
    "TITLE": "#FF8A34",      # 시작 안내 제목 (QUAD Mechanical Orange)
    "KEY": "#FFD91A",        # 키 이름 (F1 · W · 1 · D/A). INPUT과 같은 노란색: 누르는 키 = 입력
}
LOUD = ("WARN", "ERROR")     # 내용까지 색을 입히는 분류

TIME_WIDTH = 5               # [  3.2] 안의 숫자 폭
RULE_WIDTH = 60              # 시작 안내의 = · - 선 길이

# 프로그램마다의 설정 (시작 시각 · 분류 칸 폭 · 색). Book-QUAD-01-BALANCE처럼 Microcontroller 두 개의
# 스크립트가 같은 Python에서 이 파일을 함께 쓰게 되더라도 서로의 설정을 바꾸지 않도록,
# 스크립트를 실행하는 스레드마다 따로 둡니다.
_states = {}


def _state_now():
    return _states.setdefault(threading.get_ident(),
                              {"start": time.time(), "tag_width": 12, "color": COLOR})


# ------------------------------------------------------------
# 준비
# ------------------------------------------------------------
def configure(categories, color=None):
    """프로그램이 쓰는 분류로 분류 칸의 폭을 정하고, 시간을 0초부터 다시 셉니다.

    :param categories: 이 프로그램이 쓰는 분류 이름 목록 (예: ("INPUT", "STATE", "TASK"))
    :param color: True · False. None이면 COLOR 그대로
    """
    state = _state_now()
    state["tag_width"] = max(len(name) for name in categories) + 3   # "[" + 이름 + "]" + 빈칸
    if color is not None:
        state["color"] = bool(color)
    reset_clock()


def reset_clock():
    """시간 표시를 0초부터 다시 셉니다."""
    _state_now()["start"] = time.time()


def paint(text, key):
    """색을 켰으면 text에 COLORS[key] 색 태그를 붙입니다. 끈 경우와 key가 없는 경우는 그대로."""
    if not _state_now()["color"] or key not in COLORS:
        return text
    return f"<color={COLORS[key]}>{text}</color>"


def key(label, width=0):
    """키 이름에 키 색(KEY)을 붙입니다. "D/A"처럼 /로 묶은 키는 키마다 붙이고 /는 그대로 둡니다.

    :param label: 키 이름 (key_label()이 만든 글자. 예: "F1" · "W" · "D/A")
    :param width: 0보다 크면 보이는 글자 수가 width가 되도록 뒤에 빈칸 (색 태그 밖)
    """
    label = str(label)
    text = "/".join(paint(part, "KEY") if part else part for part in label.split("/"))
    return text + " " * max(0, width - len(label))


def keys(labels, sep=" "):
    """키 이름 여러 개 → 키마다 색. 예: ["U/J", "I/K"] → "U/J I/K"."""
    return sep.join(key(label) for label in labels)


def visible_len(text):
    """색 태그(<color=...> · </color>)를 뺀 글자 수. 줄 길이 · 열 맞춤에 씀."""
    import re
    return len(re.sub(r"</?color[^>]*>", "", str(text)))


# ------------------------------------------------------------
# 출력
# ------------------------------------------------------------
def log(message: str = ""):
    """콘솔에 한 줄을 남깁니다. ASCII가 아닌 글자는 ?로 바꿉니다."""
    print(str(message).encode("ascii", "replace").decode("ascii"))


def log_traceback():
    """예상하지 못한 오류의 위치를 영어로 남깁니다: 오류 종류와 메시지, 그리고 호출 순서
    (파일 이름:줄 번호 in 함수 이름). 코드 줄과 주석은 쓰지 않습니다."""
    import sys
    import traceback
    kind, error, tb = sys.exc_info()
    if kind is None:
        return
    for line in wrap(f"{kind.__name__}: {error}"):
        more(paint(line, "ERROR"))
    for frame in traceback.extract_tb(tb):
        name = frame.filename.replace("\\", "/").split("/")[-1]
        more(f"  at {name}:{frame.lineno} in {frame.name}")


def setup_failed(error, file_name):
    """시작 파일의 값으로 프로그램을 준비하다 오류가 났을 때: 영어로 알립니다.
    시작 파일의 값이 잘못된 경우(ValueError)는 메시지만, 그 밖의 오류(Port 등)는 위치도 남깁니다."""
    if isinstance(error, ValueError):
        event("ERROR", "setup failed: a value in the start file")
        for line in wrap(str(error)):
            more(paint(line, "ERROR"))
    else:
        event("ERROR", "setup failed")
        log_traceback()
    event("STATE", f"stopped. Fix {file_name}")


def wrap(text, width=72):
    """이어지는 줄(more)에 맞춰 text를 width 안으로 나눈 줄 목록."""
    import textwrap
    return textwrap.wrap(str(text), max(20, width - len(indent()))) or [""]


def event(category, text):
    """한 줄: [시간] [분류] 내용. 분류 칸은 configure()에서 정한 폭으로 맞춥니다."""
    state = _state_now()
    seconds = time.time() - state["start"]
    tag = f"[{category}]"
    pad = " " * max(1, state["tag_width"] - len(tag))
    if category in LOUD:
        text = paint(text, category)
    log(paint(f"[{seconds:{TIME_WIDTH}.1f}]", "TIME") + " " + paint(tag, category) + pad + text)


def indent():
    """이어지는 줄의 들여쓰기 (내용이 시작하는 열까지의 빈칸)."""
    return " " * (TIME_WIDTH + 3 + _state_now()["tag_width"])


def more(text):
    """앞 줄에 이어지는 줄: 시간 · 분류 칸을 비우고 내용 열에 맞춥니다."""
    log(indent() + text)


def rule(char="="):
    log(paint(char * RULE_WIDTH, "TIME"))


def banner(title, lines):
    """시작 안내 · 키 안내: = 선, 제목, - 선, 키 안내 줄, = 선."""
    rule("=")
    log(" " + paint(title, "TITLE"))
    rule("-")
    for line in lines:
        log(line)
    rule("=")


def key_lines(label, items, width=RULE_WIDTH, label_cols=6):
    """키 안내 줄: " Walk   W forward   S backward ..." 가 width를 넘으면 다음 줄로 넘깁니다.
    키 이름에는 키 색을 붙이고, 줄 길이는 보이는 글자 수로 셉니다.

    :param label: 줄 앞의 묶음 이름 (label_cols칸)
    :param items: (키 이름, 설명) 목록. 키 이름은 key_label()의 글자 (색은 여기서 붙임)
    """
    head = f" {label:<{label_cols}} "
    lines, line, empty = [], head, True
    for name, desc in items:
        part = f"{key(name)} {desc}"
        if not empty and visible_len(line) + 3 + visible_len(part) > width:
            lines.append(line)
            line, empty = " " * len(head), True
        line += ("" if empty else "   ") + part
        empty = False
    lines.append(line)
    return lines


# ------------------------------------------------------------
# 숫자 쓰기
# ------------------------------------------------------------
def signed(value, width=5, digits=1):
    """부호를 붙인 숫자. 예: +1.2, -0.3, +0.0 (-0.0을 쓰지 않음)."""
    return f"{round(value, digits) + 0.0:+{width}.{digits}f}"


def angles_text(values, names=("roll", "pitch", "yaw"), unit=" deg"):
    """(roll, pitch, yaw) → "roll= +1.2  pitch= +0.0  yaw= +0.0 deg"."""
    return "  ".join(f"{n}={signed(v)}" for n, v in zip(names, values)) + unit


def xyz_text(x, y, z, width=6):
    """발끝 좌표 → "x=  13.0  y=  10.2  z= -97.3"."""
    return f"x={x:{width}.1f}  y={y:{width}.1f}  z={z:{width}.1f}"


def num(value):
    """정수처럼 보이는 값은 그대로, 0이 아니면 부호를 붙임. 예: 0, +5, -10, +2.5"""
    return f"{value:+g}" if value else "0"

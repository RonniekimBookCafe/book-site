# -*- coding: utf-8 -*-
"""
q01lib_keys.py  |  QUAD-01 교육용 라이브러리 · 키 입력

이 로봇은 키를 "지금 눌려 있는가"로 읽습니다.

키보드 보행(q01_walk_start.py)에서는 다음과 같이 씁니다.
- 보행 키 (W·S·A·D·Q·E): 누르고 있는 동안 보행을 반복합니다. 키를 떼면
  보행 반복이 끝나고 기본 자세로 돌아갑니다.
- 자세 키 (X·Z), 자동 모드 키 (1·2·3): 누르는 순간 한 번 실행합니다.
  같은 키가 계속 눌려 있어도 ACTION_COOLDOWN_SEC 안에는 다시 실행하지
  않습니다.
- 종료 키 (0): 이완 자세로 옮긴 뒤 스크립트를 끝냅니다.

사용하는 RoboCo 공식 API
- Input.pressed(key): 그 순간 키가 눌려 있으면 ButtonState.DOWN
- Input.stream(key): 그 키를 누르고 뗀 사건의 흐름. 읽을 때마다 지난번 이후
  생긴 사건을 순서대로 돌려줍니다(누름 True, 뗌 False)

누른 순간 한 번만 실행할 동작(다리 고르기·균형 모드 전환 등)은
KeyWatcher로 읽습니다.

알아 두기: Input.pressed()는 물어본 순간의 상태만 알려 줍니다. 아주 짧게
누른 키는 두 번 물어보는 사이에 놓칠 수 있습니다. 누르고 뗀 사건을 모두
받으려면 Input.stream()을 씁니다(key_stream). 액션 동작 실습
(q01_action_start.py)은 이 방법으로 키를 읽습니다.
"""

import time

from inputs import Input, ButtonState


def is_down(key: str) -> bool:
    """key가 지금 눌려 있으면 True."""
    return Input.pressed(key) == ButtonState.DOWN


class KeyWatcher:
    """키를 누른 순간을 한 번만 알려 주는 클래스.

    pressed(key)는 키가 눌리지 않았다가 눌린 첫 순간에만 True입니다.
    계속 누르고 있으면 repeat_sec마다 다시 True가 됩니다(0이면 반복하지 않음).
    """

    def __init__(self, repeat_sec: float = 0.0):
        self.repeat_sec = repeat_sec
        self._down_since = {}       # 키별: 눌린 상태로 마지막에 True를 돌려준 시각

    def pressed(self, key: str) -> bool:
        now = time.time()
        if not is_down(key):
            self._down_since.pop(key, None)
            return False
        last = self._down_since.get(key)
        if last is None or (self.repeat_sec > 0 and now - last >= self.repeat_sec):
            self._down_since[key] = now
            return True
        return False


def key_stream(key: str):
    """key를 누르고 뗀 사건을 받는 흐름(Input.stream)을 만듭니다.

    for 문으로 읽으면 지난번에 읽은 뒤 생긴 사건이 차례로 나옵니다.
    누른 사건은 True, 뗀 사건은 False입니다. 동작이 진행되는 동안 누른 키도
    흐름에 남아 있다가 다음에 읽을 때 나옵니다.
    """
    return Input.stream(key)

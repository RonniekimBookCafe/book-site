# -*- coding: utf-8 -*-
"""
q01lib_screen.py  |  QUAD-01 교육용 라이브러리 · 상태 화면 (Text Screen, Port 0)

로봇의 Text Screen(Port 0)에 지금 상태를 한 줄로 보여 줍니다.

    - 글자 크기 자동 맞춤(auto_size) 켜기
    - 기본: 왼쪽 · 위쪽 정렬, 자동 줄바꿈
    - centered=True: 가운데 정렬, 자동 줄바꿈 끄고 코드가 정한 줄만 씀
    - 문구는 이 화면을 쓰는 프로그램(예: walk/q01lib_app.py)에 적힌 문장 그대로

사용하는 RoboCo 공식 API (TextScreen)
- text, auto_size, wrapping, horizontal_alignment, vertical_alignment
"""

from controllables import TextScreen
import re
from color import Color
from . import q01lib_ports as ports

# RoboCo TextScreen.font_color's baseline must be bright on the robot's black screen.
# Rich-text <color> labels in LEG/BALANCE/BODY_POSE retain their own accent color.
# A fixed pale white avoids the saved UI color (often black) reappearing after Welcome.
DEFAULT_TEXT_COLOR_HEX = "#F0F5FF"
DEFAULT_TEXT_COLOR = Color(240 / 255, 245 / 255, 255 / 255)  # #F0F5FF

# TextMeshPro rich-text color tags work for highlighted values, but ordinary text
# could still render black on RoboCo's dark screen. Tag only uncolored spans;
# existing per-value <color=...> and <b> markup remains unchanged.
_RICH_TAG = re.compile(r"(<color\s*=\s*[^>]+>|</color\s*>|<[^>]*>)", re.IGNORECASE)
_OPEN_COLOR = re.compile(r"<color\s*=", re.IGNORECASE)
_CLOSE_COLOR = re.compile(r"</color\s*>", re.IGNORECASE)


def ensure_readable_text(text, default_color=DEFAULT_TEXT_COLOR_HEX):
    """Make every otherwise uncolored character readable, preserving accent tags.

    Existing <color=#...> blocks stay byte-for-byte identical. Surround each
    uncolored span with an explicit pale-white TextMeshPro color tag. This is a
    rendering fix, not a change to screen text content or robot motion.
    """
    text = str(text)
    pieces = _RICH_TAG.split(text)
    depth = 0
    result = []
    for piece in pieces:
        if not piece:
            continue
        if _OPEN_COLOR.match(piece):
            depth += 1
            result.append(piece)
        elif _CLOSE_COLOR.fullmatch(piece):
            depth = max(0, depth - 1)
            result.append(piece)
        elif piece.startswith("<") and piece.endswith(">"):
            result.append(piece)  # formatting markup (e.g. <b>)
        elif depth:
            result.append(piece)  # preserve explicitly colored text
        else:
            result.append("<color={}>{}</color>".format(default_color, piece))
    return "".join(result)


class StatusScreen:
    """Text Screen 한 개에 상태 문구를 쓰는 클래스.

    centered=False (기본, 키보드 보행 · 균형 제어)
        왼쪽 · 위쪽 정렬. 글이 화면 끝에 닿으면 자동으로 줄을 바꿈(wrapping).
    centered=True (다리 테스트 · 액션 동작)
        가운데 정렬. 자동 줄바꿈을 끄고 코드가 정한 줄(show_lines)만 씀.
        글자 크기는 가장 긴 줄이 화면 폭에 맞도록 auto_size가 정함.
        자동 줄바꿈을 켜 두면 "포즈 변화"가 "포 / 즈 변화"처럼 낱말 중간에서
        끊기거나 "x 10 y / 10"처럼 값이 이름과 떨어진 줄로 나뉘기 때문입니다.
    """

    def __init__(self, centered=False, port=None, wrap=True, enforce_contrast=True):
        """port: Text Screen의 Port. 생략하면 로봇의 Port 0 (시험대 Microcontroller는 Port 6).
        wrap=False: 왼쪽 정렬이어도 자동 줄바꿈을 끄고 코드가 정한 줄만 씀 (시험대 화면)."""
        # Reference는 여기서 한 번만 만들고 계속 씁니다.
        # ACTION은 상태별 font_color를 사용하므로 enforce_contrast=False를 지정합니다.
        self.enforce_contrast = enforce_contrast
        self.screen = TextScreen(ports.PORT_TEXT_SCREEN if port is None else port)
        self.screen.color = DEFAULT_TEXT_COLOR  # Explicit readable text on black background.
        self.screen.auto_size = True
        if centered:
            self.screen.wrapping = False
            self.screen.horizontal_alignment = TextScreen.HorizontalAlignment.CENTER
            self.screen.vertical_alignment = TextScreen.VerticalAlignment.MIDDLE
        else:
            self.screen.horizontal_alignment = TextScreen.HorizontalAlignment.LEFT
            if wrap:
                self.screen.vertical_alignment = TextScreen.VerticalAlignment.TOP
            else:
                self.screen.wrapping = False
                self.screen.vertical_alignment = TextScreen.VerticalAlignment.MIDDLE

    def show(self, text: str):
        """화면에 문구를 씁니다."""
        value = str(text)
        self.screen.text = ensure_readable_text(value) if self.enforce_contrast else value

    def show_lines(self, *lines):
        """여러 줄을 한 줄씩 나눠 씁니다. 줄마다 짧게(한글 10자 안팎) 씁니다."""
        value = "\n".join(str(line) for line in lines)
        self.screen.text = ensure_readable_text(value) if self.enforce_contrast else value

# -*- coding: utf-8 -*-
"""
q01lib_servo.py  |  QUAD-01 교육용 라이브러리 · 관절 서보 제어 (ServoController)

관절 서보에 각도를 보내는 클래스입니다.

[두 가지 각도]
    논리 각도 (0 ~ 180도) : 사람이 읽기 쉬운 각도. 90도가 중립
    물리 각도 (+90 ~ -90도): ServoMotor.spin_to_degrees()가 받는 각도. 0도가 중립

    논리 0도   → 물리 +90도 (시계 방향 끝)
    논리 90도  → 물리   0도 (중립)
    논리 180도 → 물리 -90도 (반시계 방향 끝)

[각도를 보내는 순서]
set_servo_angle()은 각도를 보낼 때마다 다음 순서를 따릅니다.

    ServoMotor(port) 생성 → 논리 각도를 물리 각도로 변환
    → max_rpm = rpm → spin_to_degrees(물리 각도)

ServoMotor(port)를 만드는 데 걸리는 시간도 보행 루프 한 번의 시간에
포함됩니다. 보행 루프에는 time.sleep()이 없으므로, 이 시간이 걸음 속도
(*_GAIT_SPEED)와 서보가 목표 각도를 따라가는 정도를 함께 정합니다.
SERVO_RPM과 *_GAIT_SPEED의 기본값은 이 순서를 기준으로 맞춘 값입니다.

사용하는 RoboCo 공식 API (ServoMotor)
- ServoMotor(port): Port의 서보 Reference
- max_rpm: 회전 속도 설정 값
- spin_to_degrees(angle): 물리 각도(도)로 회전
"""

from controllables import ServoMotor
from . import q01lib_ports as ports


def setup_canonical_servos():
    """QUAD-01 Robot Family 공통 12개 서보 사양 초기화 (시험대 제외)."""
    if set(ports.SERVO_MAX_TORQUE_BY_PORT) != set(ports.SERVO_ORDER):
        raise ValueError("canonical servo torque/port mapping incomplete")
    for port in ports.SERVO_ORDER:
        servo = ServoMotor(port)
        for attr, target in (("max_rpm", ports.SERVO_RPM_DEFAULT),
                             ("max_torque", ports.SERVO_MAX_TORQUE_BY_PORT[port]),
                             ("acceleration_time", ports.SERVO_ACCELERATION_TIME)):
            current = getattr(servo, attr)
            if abs(current - target) > 0.0001 * max(1.0, abs(target)):
                setattr(servo, attr, target)
            actual = getattr(servo, attr)
            if abs(actual - target) > 0.0001 * max(1.0, abs(target)):
                raise ValueError("{} {}: expected {}, got {}".format(
                    ports.SERVO_PART_NAMES[port], attr, target, actual))


class ServoController:
    """
    서보 모터 제어 클래스 - 로봇의 각 관절을 움직이는 모터를 제어합니다.
    """
    def __init__(self):
        """서보모터 초기화 - 중심 각도만 설정"""
        self.motor = None             # 모터 객체 (아직 초기화되지 않음)
        self.center_angle = 90        # 모터의 중심 각도 (90도 = 중립 위치)

    def convert_angle(self, logical_angle):
        """논리 각도(0~180도)를 물리 각도(+90~-90도)로 바꿉니다.

        :param logical_angle: 사용자가 설정하려는 각도 (0~180도)
        :return: 변환된 물리적 각도 (-90~90도)
        """
        if logical_angle == 0:
            physical_angle = 90       # 시계 방향으로 최대 회전
        elif logical_angle == 90:
            physical_angle = 0        # 중앙 위치
        elif logical_angle == 180:
            physical_angle = -90      # 반시계 방향으로 최대 회전
        else:
            # 논리적 각도가 90도보다 작으면 시계 방향으로 회전
            if logical_angle < 90:
                physical_angle = 90 - logical_angle
            else:
                # 논리적 각도가 90도보다 크면 반시계 방향으로 회전
                physical_angle = -(logical_angle - 90)

        return physical_angle

    def set_servo_angle(self, port, logical_angle, rpm):
        """지정된 Port의 서보를 논리 각도로 보냅니다.

        :param port: 서보모터 포트 번호
        :param logical_angle: 논리적 각도 (0~180도)
        :param rpm: 모터의 회전 속도 (분당 회전수)
        """
        # 모터 초기화 (각도를 보낼 때마다 새로운 인스턴스 생성)
        self.motor = ServoMotor(port)
        # 논리적 각도를 물리적 각도로 변환
        physical_angle = self.convert_angle(logical_angle)
        # 모터 회전 속도 설정
        self.motor.max_rpm = rpm
        # 모터를 지정된 각도로 회전
        self.motor.spin_to_degrees(physical_angle)


# -*- coding: utf-8 -*-
"""
q01lib_ports.py  |  QUAD-01 4족 로봇 하드웨어 대응표 (Port · 관절 · 다리 치수)

4족 로봇의 부품이 어느 Port에 연결되어 있는지, 다리마다 어느 관절이
어느 Port인지, 역기구학(IK)에 쓰는 다리 길이와 도달 범위를 이 파일
한곳에 모았습니다. 다른 q01lib_*.py 파일과 시작 파일은 이 값만 가져다
쓰고, Port 번호를 따로 적지 않습니다.

Port 번호와 관절 이름은 RoboCo Microcontroller 화면(Port 0~13)과
관절 번호 그림(포트 구성 그림)에 맞춘 값입니다. 로봇을 직접 고쳐 만들어
배선이 달라졌을 때만 바꿉니다.

[좌표계와 회전 이름]
Boston Dynamics Spot과 같은 몸체 좌표계(오른손 좌표계)를 씁니다.

    x : 앞 (+)      roll  : x축을 중심으로 한 회전 (몸체가 좌우로 기울어짐)
    y : 왼쪽 (+)    pitch : y축을 중심으로 한 회전 (몸체가 앞뒤로 기울어짐)
    z : 위 (+)      yaw   : z축을 중심으로 한 회전 (제자리에서 방향을 바꿈)

    회전의 + 방향은 오른손 법칙을 따릅니다. 축의 + 끝에서 원점을 볼 때
    반시계 방향이 +입니다. 예를 들어 위에서 볼 때 왼쪽으로 도는 것이 +yaw입니다.

발끝 좌표는 다리 좌표계로 적습니다. 원점은 각 다리의 엉덩이 관절이고,
축 방향은 몸체 좌표계와 같습니다. 발끝은 엉덩이보다 아래에 있으므로
서 있을 때 발끝의 z는 음수입니다(예: 몸체 높이 99 → z = -99).

[관절 이름 읽는 법]
    FL_KN  =  FL(다리) + KN(관절)
    다리  FL 앞왼쪽 · HL 뒤왼쪽 · HR 뒤오른쪽 · FR 앞오른쪽
          (RoboCo 부품 이름의 FrontLeft · HindLeft · HindRight · FrontRight)
          Spot의 다리 이름(fl · fr · hl · hr, Hind = 뒷다리)과 같습니다.
          CORE-01의 4륜 로봇은 바퀴를 FL · FR · RL · RR(Rear = 뒤)로 부릅니다.
          HL = RL(뒤왼쪽), HR = RR(뒤오른쪽)로 같은 자리입니다.
    관절  HX 엉덩이 X축 (hip x) : x축을 중심으로 도는 관절 (roll 방향)
                                 다리를 몸통 바깥·안쪽으로 벌리고 모음
          HY 엉덩이 Y축 (hip y) : y축을 중심으로 도는 관절 (pitch 방향)
                                 다리를 앞뒤로 흔듦
          KN 무릎 (knee)        : y축과 나란한 축으로 도는 관절 (pitch 방향)
                                 다리를 굽히고 폄

[방향 보정에 대해]
이 로봇의 왼쪽 다리와 오른쪽 다리는 서보가 서로 마주 보게 달려 있습니다.
그래서 같은 자세를 만들 때 좌우 다리의 논리 각도가 반대가 됩니다.
이 반전은 q01lib_motion.py의 각도 변환(왼쪽: 90 - b, 오른쪽: 90 + b,
180 - c)에서 처리하며, 서보의 flipped 속성은 바꾸지 않습니다.
제공 로봇 파일의 12개 관절 서보는 flipped 설정이 모두 True입니다.
"""

# ----------------------------------------------------------------
# 1. 표시·센서 부품 Port
# ----------------------------------------------------------------
PORT_TEXT_SCREEN = 0     # Text Screen 1 (상태 문구 표시)
PORT_INERTIAL_SENSOR = 1  # Inertial Sensor 1 (몸체 자세 · 균형 테스트에서 씀)
# InertialSensor는 RoboCo(Unity) 좌표계로 값을 돌려줍니다. 부품의 x축이 오른쪽,
# y축이 위, z축이 앞입니다. 위의 Spot 좌표계(x 앞 · y 왼쪽 · z 위)와 축 이름과 부호가
# 다르므로 core/q01lib_imu.py가 rotation_axis()를 읽어 축을 바꾸고, 부호는 실제 로봇에서
# 확인합니다(euler_angles()는 각도가 약 57배로 나오므로 쓰지 않음).
# LED 1은 Port 0~13에 연결되어 있지 않으며(Port 목록 1·2쪽 기준), 이 코드에서는 쓰지 않습니다.

# ----------------------------------------------------------------
# 2. 관절 서보 Port (다리 4개 × 관절 3개 = 12개)
#    RoboCo 부품 이름: "다리번호-Port-다리이름" (예: 1-2-FrontLeft)
# ----------------------------------------------------------------
# 다리 1 · 앞왼쪽 (FrontLeft)
FL_KN = 2    # 2번 FL_KN  Front Left Knee            앞쪽 왼쪽 다리의 무릎 관절 (pitch)
FL_HY = 3    # 3번 FL_HY  Front Left Hip Y-axis      앞쪽 왼쪽 다리의 고관절 Y축 (pitch)
FL_HX = 4    # 4번 FL_HX  Front Left Hip X-axis      앞쪽 왼쪽 다리의 고관절 X축 (roll)

# 다리 2 · 뒤왼쪽 (HindLeft)
HL_KN = 5    # 5번 HL_KN  Hind Left Knee             뒤쪽 왼쪽 다리의 무릎 관절 (pitch)
HL_HY = 6    # 6번 HL_HY  Hind Left Hip Y-axis       뒤쪽 왼쪽 다리의 고관절 Y축 (pitch)
HL_HX = 7    # 7번 HL_HX  Hind Left Hip X-axis       뒤쪽 왼쪽 다리의 고관절 X축 (roll)

# 다리 3 · 뒤오른쪽 (HindRight)
HR_HX = 8    # 8번 HR_HX  Hind Right Hip X-axis      뒤쪽 오른쪽 다리의 고관절 X축 (roll)
HR_HY = 9    # 9번 HR_HY  Hind Right Hip Y-axis      뒤쪽 오른쪽 다리의 고관절 Y축 (pitch)
HR_KN = 10   # 10번 HR_KN Hind Right Knee            뒤쪽 오른쪽 다리의 무릎 관절 (pitch)

# 다리 4 · 앞오른쪽 (FrontRight)
FR_HX = 11   # 11번 FR_HX Front Right Hip X-axis     앞쪽 오른쪽 다리의 고관절 X축 (roll)
FR_HY = 12   # 12번 FR_HY Front Right Hip Y-axis     앞쪽 오른쪽 다리의 고관절 Y축 (pitch)
FR_KN = 13   # 13번 FR_KN Front Right Knee           앞쪽 오른쪽 다리의 무릎 관절 (pitch)

# ----------------------------------------------------------------
# 3. 다리 순서와 관절 순서
#    코드 안에서 다리는 아래 순서(0~3)로, 관절은 IK가 계산하는
#    (a, b, c) 순서로 다룹니다.
#      a : 엉덩이 X축 (HX)  - roll 방향, 다리를 몸통 바깥·안쪽으로 벌리고 모음
#      b : 엉덩이 Y축 (HY)  - pitch 방향, 다리를 앞뒤로 흔듦
#      c : 무릎 (KN)        - pitch 방향, 다리를 굽히고 폄
# ----------------------------------------------------------------
LEG_NAMES = ["FL", "HL", "HR", "FR"]       # 다리 0 · 1 · 2 · 3  (왼쪽 FL·HL, 오른쪽 HR·FR)
LEFT_LEGS = (0, 1)                         # 왼쪽 다리 FL · HL
RIGHT_LEGS = (2, 3)                        # 오른쪽 다리 HR · FR
FRONT_LEGS = (0, 3)                        # 앞다리 FL · FR
HIND_LEGS = (1, 2)                         # 뒷다리 HL · HR

# 다리별 (a, b, c) 관절의 Port
LEG_JOINT_PORTS = [
    (FL_HX, FL_HY, FL_KN),    # 다리 0 · FL : 4, 3, 2
    (HL_HX, HL_HY, HL_KN),    # 다리 1 · HL : 7, 6, 5
    (HR_HX, HR_HY, HR_KN),    # 다리 2 · HR : 8, 9, 10
    (FR_HX, FR_HY, FR_KN),    # 다리 3 · FR : 11, 12, 13
]

# 서보에 명령을 보내는 순서 (위 표를 펼친 것)
SERVO_ORDER = [port for leg in LEG_JOINT_PORTS for port in leg]
# = [4, 3, 2, 7, 6, 5, 8, 9, 10, 11, 12, 13]

# 트롯(trot) 보행의 대각선 짝. 같은 짝의 두 다리는 같은 궤적으로 움직입니다.
#   그룹 1 : FL(0) · HR(2)    그룹 2 : HL(1) · FR(3)
# Spot의 기본 보행(walk, trot)도 같은 대각선 짝(앞왼쪽·뒤오른쪽, 앞오른쪽·뒤왼쪽)을
# 번갈아 움직입니다.

# ----------------------------------------------------------------
# 4. 서보 각도 체계
#    논리 각도 0~180도 → 물리 각도 +90~-90도 (중립 90도 = 물리 0도)
#    ServoMotor.spin_to_degrees()에는 물리 각도를 보냅니다.
# ----------------------------------------------------------------
LOGICAL_MIN_DEG = 0         # 논리 각도 하한 (IK 결과는 이 범위로 제한)
LOGICAL_MAX_DEG = 180       # 논리 각도 상한

# 다리별 보정각 (a, b, c). 로봇마다 조금씩 다른 조립 오차를 맞출 때 씁니다.
# 제공 로봇은 모두 0입니다.
CALIBRATION_ANGLES = [
    [0, 0, 0],   # FL
    [0, 0, 0],   # HL
    [0, 0, 0],   # HR
    [0, 0, 0],   # FR
]

# ----------------------------------------------------------------
# 5. 다리 치수와 도달 범위
#    발끝 좌표(다리 좌표계: x 앞 · y 왼쪽 · z 위)와 같은 단위입니다.
# ----------------------------------------------------------------
LINK_HIP = 23        # l1 : 엉덩이 X축 관절(HX) ~ 엉덩이 Y축 관절(HY)
LINK_UPPER = 55      # l2 : 엉덩이 Y축 관절(HY) ~ 무릎(KN)
LINK_LOWER = 65      # l3 : 무릎 ~ 발끝

REACH_MIN = 25       # 엉덩이(원점)에서 발끝까지 거리의 최솟값
REACH_MAX = 130      # 엉덩이(원점)에서 발끝까지 거리의 최댓값

# ----------------------------------------------------------------
# 6. 발끝 기준 위치 오프셋
#    보행 궤적이 계산한 값에 더해지는 기본 위치입니다.
#      x : 모든 다리 +10 (발끝을 조금 앞쪽에 둠)
#      y : 왼쪽 다리 +10, 오른쪽 다리 -10 (발끝을 몸통 바깥쪽으로 벌림)
# ----------------------------------------------------------------
FOOT_X_OFFSET = 10
FOOT_Y_OFFSET = 10

# ----------------------------------------------------------------
# 7. 공통 12DOF 서보 계약: Robot Family의 모든 변형에서 동일
# 로봇 부품에 저장된 초기값과 함께 관리하며 동작 시 max_rpm은 명령별 설정이 우선합니다.
# ----------------------------------------------------------------
SERVO_RPM_DEFAULT = 50
SERVO_RPM_MIN = 0
SERVO_RPM_MAX = 1000
SERVO_ACCELERATION_TIME = 0.2
SERVO_ACCELERATION_MIN = 0.0
SERVO_ACCELERATION_MAX = 10.0
SERVO_MAX_TORQUE_BY_PORT = {
    2: 1720, 3: 13150, 4: 13150,
    5: 1720, 6: 13150, 7: 13150,
    8: 13150, 9: 13150, 10: 1720,
    11: 13150, 12: 13150, 13: 1720,
}
SERVO_PART_NAMES = {
    2: "1-2-FrontLeft", 3: "1-3-FrontLeft", 4: "1-4-FrontLeft",
    5: "2-5-HindLeft", 6: "2-6-HindLeft", 7: "2-7-HindLeft",
    8: "3-8-HindRight", 9: "3-9-HindRight", 10: "3-10-HindRight",
    11: "4-11-FrontRight", 12: "4-12-FrontRight", 13: "4-13-FrontRight",
}

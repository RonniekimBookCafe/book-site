# -*- coding: utf-8 -*-
"""
q01lib_imu.py  |  QUAD-01 교육용 라이브러리 · IMU (Inertial Sensor)

쓰는 곳: 로봇 IMU (로봇 Microcontroller Port 1) - 실습 6 몸체 자세 · 실습 7 균형 테스트
         시험대 IMU  (시험대 3axis-Microcontroller Port 5) - 실습 4 시험대 (balance_test/q01lib_platform_app.py)
두 IMU는 다른 Microcontroller의 부품이므로 BodyIMU를 하나씩 따로 만들어 씁니다. Port 번호는
Microcontroller마다 따로 매겨지므로(InertialSensor(port)는 그 스크립트를 실행하는
Microcontroller의 Port만 봄) 두 IMU가 서로 섞이지 않습니다.

Inertial Sensor가 알려 주는 회전을 이 책의 몸체 좌표계(Spot과 같음)의
roll · pitch · yaw(도)로 바꿉니다.

[무엇을 읽는가: rotation_axis()]
InertialSensor.rotation_axis()는 센서가 처음 놓였던 방향에서 지금 방향까지의 회전을
"회전축 × 회전 각도(라디안)" 하나의 Vector3로 돌려줍니다. 축의 방향이 회전축, 길이가
회전 각도입니다. 예: <0, 0, 0.05>는 센서의 z축을 중심으로 0.05 라디안(약 2.9도) 돈 것.

euler_angles()는 쓰지 않습니다. RoboCo API 소스(sensors.py · vector.py)를 보면
euler_angles()는 센서 값(도 단위의 회전 벡터)을 라디안으로 바꾸지 않은 채
Vector3.euler_angles_from_rotation_axis()(라디안을 받는 함수)에 넘깁니다. 그래서 회전
각도가 약 57.3배(180/π)로 커집니다. 0.1도 기울면 약 5.7도, 3도 기울면 약 172도로
읽히므로, 가만히 있어도 값이 몇 도씩 흔들립니다. rotation_axis()는 같은 값을 라디안으로
바르게 바꿔 돌려줍니다.

[두 좌표계]
    RoboCo(Unity) 부품 좌표계          이 책의 몸체 좌표계 (Spot)
    x 오른쪽 · y 위 · z 앞             x 앞 · y 왼쪽 · z 위
    회전 벡터 (라디안)                  roll x축 · pitch y축 · yaw z축 회전, 도, -180 ~ +180

센서의 z축이 로봇의 앞, y축이 위를 향하게 달려 있을 때, 축을
    Spot x = Unity z      Spot y = -(Unity x)      Spot z = Unity y
로 바꾼 회전 행렬에서 roll · pitch · yaw(z → y → x 순서, 로봇에서 흔히 쓰는 방식)를 꺼냅니다.
    roll  +  오른쪽이 내려감      pitch +  앞(코)이 내려감      yaw +  위에서 볼 때 반시계 방향
센서를 다르게 달았다면 시작 파일의 ROLL_SIGN · PITCH_SIGN · YAW_SIGN · SWAP_ROLL_PITCH로
맞춥니다(시험대 IMU는 IMU_ROLL_SIGN 등). 확인 방법은 README 11.3 · 14장을 봅니다.

[영점: 가만히 있을 때까지 기다린 뒤 회전을 평균]
calibrate()는 두 단계입니다.
  1. 기다리기: interval_sec마다 읽어, 바로 앞 값과의 회전 차이가 STILL_DEG(0.2도, 시작 파일의
     IMU_STILL_DEG)보다 작은
     값이 STILL_SAMPLES(5)번 이어질 때까지 기다립니다. 서보가 자리를 잡는 동안이나, 시험대와 로봇
     스크립트를 함께 시작해 시험대가 평평해지는 동안에는 영점을 잡지 않습니다. STILL_TIMEOUT_SEC(5초)가
     지나도 멈추지 않으면 그대로 진행하고 settled를 False로 남깁니다.
  2. 평균: samples번 읽은 회전을 쿼터니언(회전을 네 수로 나타낸 값)으로 바꿔 평균한 회전을
     영점으로 저장합니다. 각도 세 개를 따로 평균하지 않으므로 ±180도 경계나 축이 섞이는
     문제가 없습니다. 읽은 값이 평균에서 가장 많이 벗어난 회전 각도는 spread(도)에 남깁니다.
그 뒤 read()는 "영점 자세에서 지금 자세까지의 회전"(영점의 역회전 × 지금 회전)을 몸체
좌표계로 바꾼 값입니다. 영점에서 몸체가 기울어 있었더라도, 영점 자세의 몸체 축을 기준으로
roll · pitch · yaw를 잽니다. 오일러 각도에서 영점 각도를 빼는 방식은 영점이 0이 아닐 때 축이
섞여 틀린 값이 나올 수 있습니다.

zero는 센서가 처음 놓였던 방향에서 영점 자세까지의 회전을 roll · pitch · yaw로 나타낸 값입니다
(콘솔 [SENSOR] zero 줄). 기울기 알림과 확인에만 쓰고 계산에는 쿼터니언을 씁니다.

사용하는 RoboCo 공식 API (InertialSensor, sensors.py)
- InertialSensor(port): 이 Microcontroller의 Port에 달린 Inertial Sensor Reference. 한 번 만들어 계속 씀
- rotation_axis(): Vector3, 센서가 처음 놓인 방향에서 지금 방향까지의 회전(축 × 각도, 라디안).
  축은 센서 자신의 좌표계(x 오른쪽 · y 위 · z 앞)로 나타냄
- euler_angles() · rotation_stream() · motion_data_stream()은 쓰지 않습니다. 흐름은 읽지 않은 샘플이
  쌓일 수 있고, 이 실습은 지금 값 하나면 됩니다.
회전 계산은 Matrix4x4 대신 이 파일의 짧은 식(쿼터니언)으로 합니다. 식을 한눈에 따라갈 수 있게 하기 위해서입니다.
"""

import math
import time

from sensors import InertialSensor

STILL_DEG = 0.2            # 앞 값과 이보다 적게 달라야 "가만히 있음"으로 셈 (도, interval_sec 동안)
STILL_SAMPLES = 5          # "가만히 있음"이 이만큼 이어지면 영점을 잡기 시작
STILL_TIMEOUT_SEC = 5.0    # 이 시간 안에 멈추지 않으면 그대로 영점을 잡음 (settled = False)


def wrap_degrees(angle):
    """각도(도)를 -180 ~ +180 범위로 바꿉니다. 예: 358 → -2"""
    return (angle + 180.0) % 360.0 - 180.0


# ------------------------------------------------------------
# 쿼터니언 (w, x, y, z): 회전 하나를 네 수로 나타낸 값. 축 a(단위 벡터) 둘레로 θ 회전이면
#   w = cos(θ/2),  (x, y, z) = a × sin(θ/2)
# ------------------------------------------------------------
def quat_from_rotation_vector(v):
    """회전 벡터(축 × 각도, 라디안) → 쿼터니언."""
    x, y, z = float(v[0]), float(v[1]), float(v[2])
    angle = math.sqrt(x * x + y * y + z * z)
    if angle < 1e-12:
        return (1.0, 0.0, 0.0, 0.0)
    s = math.sin(angle / 2.0) / angle
    return (math.cos(angle / 2.0), x * s, y * s, z * s)


def quat_conj(q):
    """역회전."""
    return (q[0], -q[1], -q[2], -q[3])


def quat_mul(a, b):
    """회전 a 다음에 (a의 축 기준으로) 회전 b."""
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return (aw * bw - ax * bx - ay * by - az * bz,
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw)


def quat_angle_deg(q):
    """쿼터니언이 나타내는 회전의 크기(도, 0 ~ 180)."""
    return math.degrees(2.0 * math.acos(min(1.0, abs(q[0]))))


def quat_between_deg(a, b):
    """회전 a와 b의 차이(도)."""
    return quat_angle_deg(quat_mul(quat_conj(a), b))


def quat_mean(quats):
    """쿼터니언 평균. q와 -q는 같은 회전이므로 첫 값과 부호를 맞춘 뒤 더해 길이 1로 만듭니다."""
    ref = quats[0]
    total = [0.0, 0.0, 0.0, 0.0]
    for q in quats:
        sign = 1.0 if sum(a * b for a, b in zip(q, ref)) >= 0.0 else -1.0
        for i in range(4):
            total[i] += sign * q[i]
    norm = math.sqrt(sum(t * t for t in total))
    if norm < 1e-12:
        return ref
    return tuple(t / norm for t in total)


def spot_angles(q):
    """Unity 부품 좌표계의 쿼터니언 → Spot 몸체 좌표계 (roll, pitch, yaw) 도.

    Unity 회전 행렬 R의 행 · 열을 Spot 축으로 바꾼 뒤(Spot x = Unity z, Spot y = -Unity x,
    Spot z = Unity y) z → y → x 순서의 각도를 꺼냅니다.
        roll  = atan2(Rs[2][1], Rs[2][2])
        pitch = asin(-Rs[2][0])
        yaw   = atan2(Rs[1][0], Rs[0][0])
    """
    w, x, y, z = q
    # Unity 회전 행렬 중 필요한 칸
    r02 = 2.0 * (x * z + w * y)
    r10 = 2.0 * (x * y + w * z)
    r11 = 1.0 - 2.0 * (x * x + z * z)
    r12 = 2.0 * (y * z - w * x)
    r22 = 1.0 - 2.0 * (x * x + y * y)
    # Spot 행렬 칸 = (축 부호) × Unity 칸
    s21, s22, s20 = -r10, r11, r12
    s10, s00 = -r02, r22
    roll = math.degrees(math.atan2(s21, s22))
    pitch = math.degrees(math.asin(max(-1.0, min(1.0, -s20))))
    yaw = math.degrees(math.atan2(s10, s00))
    return roll, pitch, yaw


def up_value(q):
    """회전 q 뒤 몸체의 위쪽(Unity y축)이 처음의 위쪽과 이루는 cos 값. 바로 1, 옆 0, 뒤집힘 -1."""
    _w, x, _y, z = q
    return 1.0 - 2.0 * (x * x + z * z)


class BodyIMU:
    """Inertial Sensor 값을 몸체의 roll · pitch · yaw(도)로 읽는 클래스."""

    def __init__(self, port, roll_sign=1, pitch_sign=1, yaw_sign=1, swap_roll_pitch=False):
        # Reference는 여기서 한 번만 만들고 계속 씁니다.
        self.sensor = InertialSensor(port)
        self.roll_sign = roll_sign
        self.pitch_sign = pitch_sign
        self.yaw_sign = yaw_sign
        self.swap_roll_pitch = swap_roll_pitch
        self.zero_quat = (1.0, 0.0, 0.0, 0.0)   # 영점 회전 (센서가 처음 놓인 방향 기준)
        self.zero = (0.0, 0.0, 0.0)             # 영점을 (roll, pitch, yaw) 도로 나타낸 값 (콘솔용)
        self.spread = 0.0                       # 영점을 잡는 동안 평균에서 가장 많이 벗어난 회전(도)
        self.settled = True                     # 영점을 잡기 전에 센서가 멈췄는지
        self.wait_sec = 0.0                     # 멈추기를 기다린 시간(초)

    def read_quat(self):
        """센서가 처음 놓인 방향에서 지금 방향까지의 회전 (쿼터니언, Unity 부품 좌표계)."""
        return quat_from_rotation_vector(self.sensor.rotation_axis())

    def _apply_signs(self, angles):
        roll, pitch, yaw = angles
        if self.swap_roll_pitch:
            roll, pitch = pitch, roll
        return roll * self.roll_sign, pitch * self.pitch_sign, yaw * self.yaw_sign

    def read_raw(self):
        """영점을 빼기 전의 (roll, pitch, yaw) 도. 센서가 처음 놓인 방향 기준."""
        return self._apply_signs(spot_angles(self.read_quat()))

    def wait_still(self, interval_sec=0.05, still_deg=STILL_DEG, still_samples=STILL_SAMPLES,
                   timeout_sec=STILL_TIMEOUT_SEC):
        """앞 값과의 차이가 still_deg보다 작은 값이 still_samples번 이어질 때까지 기다립니다.

        :return: 멈췄으면 True, timeout_sec가 지나면 False
        """
        start = time.time()
        last = self.read_quat()
        count = 0
        while count < still_samples:
            if time.time() - start >= timeout_sec:
                self.wait_sec = time.time() - start
                return False
            time.sleep(interval_sec)
            now = self.read_quat()
            count = count + 1 if quat_between_deg(last, now) < still_deg else 0
            last = now
        self.wait_sec = time.time() - start
        return True

    def calibrate(self, samples=20, interval_sec=0.05, still_deg=STILL_DEG):
        """멈출 때까지 기다린 뒤 samples번 읽은 회전의 평균을 영점으로 저장합니다.

        :param still_deg: 앞 값과 이보다 적게 달라야 "가만히 있음" (도). 시작 파일의 IMU_STILL_DEG
        :return: 영점 (roll, pitch, yaw) 도. 센서가 처음 놓인 방향 기준
        """
        self.settled = self.wait_still(interval_sec, still_deg)
        quats = []
        for _ in range(max(1, samples)):
            quats.append(self.read_quat())
            time.sleep(interval_sec)
        self.zero_quat = quat_mean(quats)
        self.spread = max(quat_between_deg(self.zero_quat, q) for q in quats)
        self.zero = self._apply_signs(spot_angles(self.zero_quat))
        return self.zero

    def read(self):
        """영점 자세에서 지금 자세까지의 (roll, pitch, yaw) 도."""
        relative = quat_mul(quat_conj(self.zero_quat), self.read_quat())
        return self._apply_signs(spot_angles(relative))

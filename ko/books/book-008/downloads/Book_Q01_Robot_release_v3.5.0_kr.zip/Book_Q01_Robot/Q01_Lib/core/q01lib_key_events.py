# -*- coding: utf-8 -*-
"""
q01lib_key_events.py  |  QUAD-01 교육용 라이브러리 · 여러 키를 함께 읽기 (Input.stream)

다리 테스트 세 가지(q01_leg1 · leg2 · leg3 시작 파일)가 쓰는 키 입력 모듈입니다.
다른 실습도 가져다 쓸 수 있도록 core 폴더에 두었지만, 키보드 보행 · 액션 · 균형
실습은 이 모듈을 쓰지 않고 q01lib_keys.py(Input.pressed · key_stream)를 그대로 씁니다.

[두 가지 읽는 방법]
    Input.pressed(key)  물어본 순간 눌려 있는지. 키 이름은 글자 하나(영문자 a~z, 숫자 0~9)
                        → q01lib_keys.py (키보드 보행 · 균형 제어)
    Input.stream(key)   누르고 뗀 사건을 쌓아 두었다가 차례로 돌려줌. 글자에 더해
                        "f1" ~ "f12" 같은 키 이름도 받음 (Unity Input Manager 형식)
                        → 이 파일의 KeyEvents (다리 테스트)

F1 ~ F12처럼 이름이 두 글자 이상인 키는 Input.pressed()로 읽을 수 없으므로
Input.stream()으로 읽습니다. 사건을 쌓아 두므로 짧게 누른 키도 놓치지 않고, 동작이
진행되는 동안 누른 키는 동작이 끝난 뒤에 나옵니다.

사용하는 RoboCo 공식 API
- Input.stream(key): 그 키를 누르고 뗀 사건의 흐름 (누름 True, 뗌 False)
"""

import time

from inputs import Input


def key_label(key: str) -> str:
    """콘솔 · 화면에 쓰는 키 이름 (예: "w" → "W", "f1" → "F1")."""
    return key.upper()


class KeyEvents:
    """여러 키의 누름을 Input.stream으로 함께 읽는 클래스.

    pressed()는 지난번에 부른 뒤 눌린 키를 목록으로 돌려줍니다. 목록 순서는
    keys에 적은 순서입니다(Input.stream은 누른 시각을 알려 주지 않음).

    repeat_keys에 든 키는 누르고 있는 동안 repeat_sec마다 한 번 더 넣습니다.
    repeat_sec가 0이면 누를 때 한 번만 넣습니다.
    """

    def __init__(self, keys, repeat_keys=(), repeat_sec: float = 0.0):
        self.keys = list(dict.fromkeys(keys))           # 같은 키를 두 번 적어도 한 번만 읽음
        self.streams = {key: Input.stream(key) for key in self.keys}
        self.repeat_keys = set(repeat_keys)
        self.repeat_sec = repeat_sec
        self._held = {}             # 키별: 누르고 있는 키를 마지막으로 넣은 시각

    def pressed(self):
        """지난번에 부른 뒤 눌린 키 목록."""
        now = time.time()
        keys = []
        for key in self.keys:
            for event in self.streams[key]:
                if event:                       # 누름
                    keys.append(key)
                    self._held[key] = now
                else:                           # 뗌
                    self._held.pop(key, None)
        if self.repeat_sec > 0:
            for key, last in list(self._held.items()):
                if key in self.repeat_keys and key not in keys and now - last >= self.repeat_sec:
                    keys.append(key)
                    self._held[key] = now
        return keys

    def take(self, keys):
        """keys 가운데 지난번에 읽은 뒤 눌린 키만 읽어 목록으로 돌려줍니다.

        동작이 진행되는 동안 멈춤 키만 확인할 때 씁니다. 다른 키의 흐름은 건드리지
        않으므로, 그 키들은 동작이 끝난 뒤 pressed()에서 나옵니다.
        """
        found = []
        for key in keys:
            for event in self.streams[key]:
                if event:
                    found.append(key)
                    self._held[key] = time.time()
                else:
                    self._held.pop(key, None)
        return found

    def clear(self):
        """쌓여 있는 누름을 모두 버립니다."""
        for stream in self.streams.values():
            for _ in stream:
                pass
        self._held.clear()

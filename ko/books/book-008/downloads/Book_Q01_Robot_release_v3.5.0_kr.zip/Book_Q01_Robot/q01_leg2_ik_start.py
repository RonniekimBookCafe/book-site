# -*- coding: utf-8 -*-
"""
q01_leg2_ik_start.py  |  QUAD-01 시작 파일 · 다리 테스트 2 · IK 테스트 (발끝 좌표로 다리 움직이기)
배포 버전 3.9.7  |  공중에 매단 로봇(Book-QUAD-01-LEG2)의 Microcontroller에 연결해 실행합니다.

다리 하나를 골라 발끝 좌표를 키로 바꾸고, IK가 계산한 관절 각도와 FK로 다시
계산한 발끝 좌표를 확인합니다. 도달 범위와 관절 제한에 닿으면 콘솔과 화면에 알려 줍니다.

[키]  왼손 W S A D E Q · 오른손 I K J L U O · 사용자 지정 키
    W · S     발끝 x + · - (앞 · 뒤)
    A · D     발끝 y + · - (왼쪽 · 오른쪽)
    E · Q     발끝 z + · - (위 · 아래)
    I         발끝이 큰 원(x-z 평면, 중심 x 40 · z -80, 반지름 40)을 그림   자동
    K         고른 다리만 기본 자세
    J · L     다리 고르기 HL · HR      위에서 본 다리 배치와 같은 모양
    U · O     다리 고르기 FL · FR          U FL    O FR
                                           J HL    L HR
    F1        키 안내 (콘솔 · 로봇 화면)
    F2        네 다리 기본 자세 (원 그리기 중이면 멈춘 뒤 기본 자세)
    F3        원 그리기 멈춤 (다리는 멈춘 자리에 둠)

좌표는 Spot과 같은 다리 좌표계입니다: 원점은 엉덩이 관절, x 앞(+) · y 왼쪽(+) · z 위(+).
기본 자세의 발끝은 [0, ±10, -99]입니다. 시작할 때 네 다리를 기본 자세로 옮깁니다.
끝낼 때는 RoboCo에서 스크립트를 멈춥니다. 다리를 다른 자세로 옮기지 않고 바로 끝납니다.
콘솔 LOG는 영어로 나옵니다([시간] [분류] 내용). 읽는 법은 README 12장에 있습니다.

다리 테스트는 공중에 매단 로봇으로 세 단계로 합니다.
    1. q01_leg1_joint_start.py     관절 테스트 (각도 → 관절)
    2. q01_leg2_ik_start.py        IK 테스트 (발끝 x · y · z 좌표 → 관절 각도)  ← 이 파일
    3. q01_leg3_combined_start.py  복합 테스트 (IK 검증 + 네 다리 조합 동작, 자동)
"""

# --- 준비 코드: 이 부분은 바꾸지 않습니다 ------------------------------------
# 스크립트를 실행할 때마다 Q01_Lib 라이브러리를 새로 읽어 옵니다. 라이브러리
# 파일을 고쳤을 때 고친 내용이 바로 반영되게 하기 위해서입니다. 파일을 지우는
# 것이 아니라, RoboCo가 기억해 둔 이전 내용만 비웁니다.
import sys as _sys

_sys.dont_write_bytecode = True  # 실행할 때 임시 파일(__pycache__ 폴더)을 만들지 않음

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.leg_common.q01lib_leg_app import LegTestApp
from Book_Q01_Robot.Q01_Lib.leg2_ik.q01lib_leg2_ik import IKTest


# ========================================
# 1. CONTROL PARAMETERS  (먼저 바꿔 볼 값)
# ========================================
SERVO_RPM = 30               # 관절 서보 회전 속도 (ServoMotor.max_rpm). 최대 1000
                             # 서보 사양(최대 토크: 무릎 1720 · 엉덩이 HX·HY 13150, 가속 시간 0.2초)은 Q01_Lib/core/q01lib_ports.py 7절
BODY_HEIGHT = 99             # 기본 자세의 몸체 높이. 기본 자세의 발끝 z = -BODY_HEIGHT
START_LEG = "FL"             # 처음 고른 다리 (FL · HL · HR · FR)

STEP_MM = 10                 # 키를 한 번 누를 때 발끝이 움직이는 거리 (다리 길이와 같은 단위)
MOVE_STEPS = 1               # 한 번 움직일 때 나누는 단계 수 (1이면 목표로 바로, 클수록 천천히)
KEY_REPEAT_SEC = 0           # W·S·A·D·E·Q를 누르고 있을 때 다시 움직이는 간격(초). 0이면 누를 때 한 번만

# --- I  원 그리기 (x-z 평면) ---
# 기본값은 도달 범위 안에서 관절이 0 · 180도 제한에 3도 넘게 다가가지 않고,
# 발끝이 엉덩이보다 40 넘게 아래에 있는 가장 큰 원입니다 (x 0 ~ 80, z -120 ~ -40)
CIRCLE_CENTER_X = 40         # 원의 중심 x (앞 +)
CIRCLE_CENTER_Z = -80        # 원의 중심 z (위 +)
CIRCLE_RADIUS = 40           # 원의 반지름
CIRCLE_STEPS = 72            # 원 한 바퀴를 나누는 점의 수 (5도에 한 점)
CIRCLE_STEP_SEC = 0.08       # 점 하나마다 기다리는 시간(초). 한 바퀴 = 72 × 0.08 = 약 5.8초
CIRCLE_MOVE_STEPS = 20       # 원의 시작점으로 갈 때 · 끝나고 돌아올 때 나누는 단계 수

LOOP_SLEEP_SEC = 0.1         # 키를 한 번 읽은 뒤 쉬는 시간(초)

# --- 콘솔 LOG ---
LOG_COLOR = True             # 콘솔 LOG에 색을 입힘. 콘솔에 <color=...> 글자가 그대로 보이면 False
WELCOME_SEC = 1.0           # Book-QUAD-01-LEG2 / WELCOME 표시(초)
START_SCREEN_SEC = 1.0      # Welcome 다음의 기존 '테스트 시작/준비' 화면을 읽을 시간(초)


# ========================================
# 2. KEYS  (왼손 → 오른손 → 사용자 지정 키 순서)
# ========================================
# 왼손: 발끝 이동 방향 (x, y, z). STEP_MM을 곱해 더함
MOVE_KEYS = {
    "w": (1, 0, 0),          # 앞 (x +)
    "s": (-1, 0, 0),         # 뒤 (x -)
    "a": (0, 1, 0),          # 왼쪽 (y +)
    "d": (0, -1, 0),         # 오른쪽 (y -)
    "e": (0, 0, 1),          # 위 (z +)
    "q": (0, 0, -1),         # 아래 (z -)
}

# 오른손: 원 그리기 · 고른 다리 · 다리 고르기
CIRCLE_KEY = "i"             # 원 그리기
LEG_RESET_KEY = "k"          # 고른 다리만 기본 자세
LEG_SELECT_KEYS = {          # 위에서 본 다리 배치와 같은 모양
    "u": "FL",               # 앞왼쪽     U  O
    "o": "FR",               # 앞오른쪽
    "j": "HL",               # 뒤왼쪽     J  L
    "l": "HR",               # 뒤오른쪽
}

# 사용자 지정 키: 공통
HELP_KEY = "f1"              # 키 안내 (콘솔 · 로봇 화면)
STAND_KEY = "f2"             # 네 다리 기본 자세 (원 그리기 중이면 멈춘 뒤 기본 자세)
STOP_KEY = "f3"              # 원 그리기 멈춤 (다리는 멈춘 자리에 둠)


# ========================================
# 3. RUN  (한 번 준비하고, 스크립트를 멈출 때까지 반복)
# ========================================
def main():
    app = LegTestApp(globals(), IKTest)  # 준비: 기본 자세로 서고, 고른 다리의 IK 값을 출력
    app.run()                            # 반복: 키 읽기 → 발끝 이동 → IK · FK 출력


if __name__ == "__main__":
    main()

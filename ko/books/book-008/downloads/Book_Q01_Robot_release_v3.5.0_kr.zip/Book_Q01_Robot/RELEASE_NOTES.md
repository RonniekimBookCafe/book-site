# QUAD-01 · 변경 내용

## v3.5.0 (2026-11-08, 독자 배포 확정판)

**패키지 구성**

- 실습 가이드 폴더(`guides/`)와 `PORT_AND_AXES.md`를 뺐습니다. 실습 순서, 키 사용법, 관찰 포인트, Port · 축 표는 책 본문과 부록에서 다룹니다.
- `README.md`를 설치 · 첫 실행 · 실습 목록(모델 · 시작 파일 · 책의 장) · 콘솔 LOG · 설치 문제 해결 중심으로 다시 썼습니다.
- ZIP 맨 위에 따로 있던 표지 파일을 지우고 `Book_Q01_Robot/cover_quad-01.jpg` 하나만 둡니다.
- 도서 페이지 주소를 `https://ronniekimbooks.com/ko/books/book-008/`로 통일했습니다.

**코드 (동작 변경 없음)**

| 파일 | 고친 곳 |
|---|---|
| `q01_leg1_joint_start.py` · `q01_leg2_ik_start.py` · `q01_leg3_combined_start.py` · `q01_body_pose_start.py` | 서보 사양 주석: 「최대 토크 1720」 → 「무릎 1720 · 엉덩이 HX·HY 13150」 (`q01lib_ports.py`의 실제 값) |
| `Q01_Lib/core/q01lib_log.py` | `CATEGORIES["METRIC"]` 설명 문자열에서 삭제된 기능 이름(백덤블링)을 「균형 테스트」로 |

나머지 50개 Python 파일은 v3.4.9와 바이트 단위로 같습니다.

## 이전

- v3.4.9: 실습 코드 기준판

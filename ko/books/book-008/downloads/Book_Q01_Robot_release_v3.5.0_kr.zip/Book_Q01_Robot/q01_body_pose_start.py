# -*- coding: utf-8 -*-
"""
q01_body_pose_start.py  |  QUAD-01 시작 파일 · 몸체 자세 테스트 (x · y · z · roll · pitch · yaw)
배포 버전 3.9.7  |  바닥에 선 로봇(Book-QUAD-01-ROLL_PITCH_YAW)의 Microcontroller에 연결해 실행합니다.

네 발을 바닥에 둔 채 몸체를 옮기고 기울입니다. 키를 누를 때마다 몸체 자세 한 값을 바꾸고,
네 다리의 발끝 좌표를 다시 계산해 IK로 서보를 움직입니다.

    몸체 자세 (x, y, z, roll, pitch, yaw) → 네 발끝 좌표 → IK → 서보 12개

좌표는 Spot과 같은 몸체 좌표계입니다: x 앞(+) · y 왼쪽(+) · z 위(+).
회전의 + 방향은 오른손 법칙을 따릅니다.
    roll  +  오른쪽이 내려가고 왼쪽이 올라감   (x축 둘레)
    pitch +  머리(앞)가 내려가고 뒤가 올라감   (y축 둘레)
    yaw   +  위에서 볼 때 왼쪽(반시계)으로 돎  (z축 둘레)

[키]  왼손 W S A D E Q · 오른손 I K J L U O · 사용자 지정 키
    W · S     몸체 x + · - (앞으로 · 뒤로)
    A · D     몸체 y + · - (왼쪽으로 · 오른쪽으로)
    E · Q     몸체 z + · - (위로 · 아래로)
    I · K     pitch + · -  (머리 아래로 · 머리 위로)
    J · L     roll  - · +  (왼쪽으로 기울임 · 오른쪽으로 기울임)
    U · O     yaw   + · -  (왼쪽으로 돎 · 오른쪽으로 돎)
    1         자동 테스트: roll → pitch → yaw → z → x → y를 + · - 로 바꿨다 되돌림   자동
    F1        키 안내 (콘솔 · 로봇 화면)
    F2        기본 자세 (자세 값 모두 0). 자동 테스트 중이면 멈춘 뒤 기본 자세
    F3        자동 테스트 멈춤 (몸체는 멈춘 자세에 둠)

키 한 번은 x · y · z 5(다리 길이와 같은 단위), roll · pitch · yaw 5도입니다. 로봇 화면에서 키 한 번은
격자 세로 2줄(pitch) · 가로 5칸(yaw), 막대 1칸으로 언제나 같은 만큼 움직입니다.
격자는 pitch · yaw만 그립니다. roll과 x · y · z는 아래 막대에 나옵니다.

갈 수 없는 자세(발끝이 도달 범위 밖이거나 관절이 0 · 180도 제한에 닿는 자세)로 가는 키는
서보를 움직이지 않고, 콘솔과 로봇 화면에 어느 다리의 어느 관절인지 알려 줍니다.
끝낼 때는 RoboCo에서 스크립트를 멈춥니다. 다리를 다른 자세로 옮기지 않고 바로 끝납니다.

콘솔 LOG는 영어로 나옵니다([시간] [분류] 내용). 읽는 법은 README 12장에 있습니다.

다리 이름은 Spot과 같이 FL 앞왼쪽 · FR 앞오른쪽 · HL 뒤왼쪽 · HR 뒤오른쪽입니다.
"""

# --- 준비 코드: 이 부분은 바꾸지 않습니다 ------------------------------------
# 스크립트를 실행할 때마다 Q01_Lib 라이브러리를 새로 읽어 옵니다. 라이브러리
# 파일을 고쳤을 때 고친 내용이 바로 반영되게 하기 위해서입니다. 파일을 지우는
# 것이 아니라, RoboCo가 기억해 둔 이전 내용만 비웁니다.
import sys as _sys

_sys.dont_write_bytecode = True  # 실행할 때 임시 파일(__pycache__ 폴더)을 만들지 않음

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.leg_common.q01lib_leg_app import LegTestApp
from Book_Q01_Robot.Q01_Lib.body_pose.q01lib_body_pose_test import BodyPoseTest


# ========================================
# 1. CONTROL PARAMETERS  (먼저 바꿔 볼 값)
# ========================================
SERVO_RPM = 30               # 관절 서보 회전 속도 (ServoMotor.max_rpm). 최대 1000
                             # 서보 사양(최대 토크: 무릎 1720 · 엉덩이 HX·HY 13150, 가속 시간 0.2초)은 Q01_Lib/core/q01lib_ports.py 7절

# --- 몸체 치수 (다리 길이 23 · 55 · 65와 같은 단위) ---
BODY_HEIGHT = 99             # 기본 자세의 높이. 기본 자세의 발끝 z = -BODY_HEIGHT
BODY_LENGTH = 136            # 앞다리와 뒷다리 엉덩이 관절 사이 거리
BODY_WIDTH = 76              # 왼쪽과 오른쪽 엉덩이 관절 사이 거리

# --- 키를 한 번 누를 때 바뀌는 양 ---
MOVE_STEP = 5                # 몸체 x · y · z (다리 길이와 같은 단위)
ANGLE_STEP_DEG = 5           # 몸체 roll · pitch · yaw (도)
POSE_MOVE_STEPS = 1          # 한 번 바꿀 때 나누는 단계 수 (1이면 새 자세로 바로, 클수록 천천히)
KEY_REPEAT_SEC = 0           # 키를 누르고 있을 때 다시 바꾸는 간격(초). 0이면 누를 때 한 번만

# --- 몸체 자세의 범위 (최솟값, 최댓값) ---
# 범위 안이라도 갈 수 없는 자세는 움직이지 않습니다 (예: pitch -15에서 뒷다리 HY가 180도에 닿음)
X_RANGE = (-20, 20)          # 앞(+) · 뒤(-)
Y_RANGE = (-20, 20)          # 왼쪽(+) · 오른쪽(-)
Z_RANGE = (-40, 20)          # 위(+) · 아래(-). 몸체 높이 = BODY_HEIGHT + z
ROLL_RANGE = (-20, 20)       # 도
PITCH_RANGE = (-20, 20)      # 도
YAW_RANGE = (-20, 20)        # 도

# --- 1  자동 테스트 ---
AUTO_ANGLE_DEG = 10          # roll · pitch · yaw를 + · - 로 바꾸는 크기(도)
AUTO_MOVE = 20               # x · y · z를 + · - 로 바꾸는 크기
AUTO_STEP_SEC = 0.5          # 한 번 바꾼 뒤 기다리는 시간(초)

# --- 실제 기울기 확인 (IMU, Port 1) ---
USE_IMU = True               # True: 키를 누르고 1초 뒤 IMU로 잰 roll · pitch · yaw를 명령값과 나란히
                             # 콘솔에 남기고 로봇 화면 맨 아래 줄에 씀. IMU가 없으면 알리고 IMU 없이 계속

LOG_DETAIL = False           # True: 키를 누를 때마다 네 다리의 발끝 좌표와 서보 각도도 콘솔에 남김
LOOP_SLEEP_SEC = 0.1         # 키를 한 번 읽은 뒤 쉬는 시간(초)

# --- 콘솔 LOG ---
LOG_COLOR = True             # 콘솔 LOG에 색을 입힘. 콘솔에 <color=...> 글자가 그대로 보이면 False
WELCOME_SEC = 1.0           # Book-QUAD-01-ROLL_PITCH_YAW / WELCOME 표시(초)
START_SCREEN_SEC = 2.5      # Welcome 다음의 기존 초기 안내 화면 표시(초)


# ========================================
# 2. KEYS  (왼손 → 오른손 → 사용자 지정 키 순서)
# ========================================
# 키 → (바꿀 값, 방향 +1 · -1)
POSE_KEYS = {
    # 왼손: 몸체 옮기기
    "w": ("x", 1),           # 앞으로 (x +)
    "s": ("x", -1),          # 뒤로 (x -)
    "a": ("y", 1),           # 왼쪽으로 (y +)
    "d": ("y", -1),          # 오른쪽으로 (y -)
    "e": ("z", 1),           # 위로, 몸체가 높아짐 (z +)
    "q": ("z", -1),          # 아래로, 몸체가 낮아짐 (z -)
    # 오른손: 몸체 기울이기
    "i": ("pitch", 1),       # 머리(앞)가 내려감 (pitch +)
    "k": ("pitch", -1),      # 머리(앞)가 올라감 (pitch -)
    "j": ("roll", -1),       # 왼쪽이 내려감 (roll -)
    "l": ("roll", 1),        # 오른쪽이 내려감 (roll +)
    "u": ("yaw", 1),         # 왼쪽(반시계)으로 돎 (yaw +)
    "o": ("yaw", -1),        # 오른쪽(시계)으로 돎 (yaw -)
}

# 사용자 지정 키: 자동 테스트 · 공통
AUTO_TEST_KEY = "1"          # 자동 테스트

HELP_KEY = "f1"              # 키 안내 (콘솔 · 로봇 화면)
STAND_KEY = "f2"             # 기본 자세 (자동 테스트 중이면 멈춘 뒤 기본 자세)
STOP_KEY = "f3"              # 자동 테스트 멈춤 (몸체는 멈춘 자세에 둠)


# ========================================
# 3. RUN  (한 번 준비하고, 스크립트를 멈출 때까지 반복)
# ========================================
def main():
    app = LegTestApp(globals(), BodyPoseTest)  # 준비: 기본 자세로 서고 키 안내를 출력
    app.run()                                  # 반복: 키 읽기 → 몸체 자세 바꾸기 · 자동 테스트


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""
q01_leg3_combined_start.py  |  QUAD-01 시작 파일 · 다리 테스트 3 · 복합 테스트 (IK 검증 + 네 다리 조합 동작)
배포 버전 3.9.7  |  공중에 매단 로봇(Book-QUAD-01-LEG3)의 Microcontroller에 연결해 실행합니다.

숫자 키를 누르면 정해 둔 발끝 좌표 목록을 차례로 보내며 IK · FK · 관절 제한을
확인하고, 네 다리를 조합한 동작을 실행합니다. 테스트 좌표와 순서는
Q01_Lib/leg3_combined/q01lib_leg3_combined_tests.py에 있습니다.

[키]  왼손 W S A D E Q · 오른손 I K J L U O · 사용자 지정 키
    왼손 · 오른손   (쓰지 않음. 이 테스트는 다리를 고르지 않고 정해 둔 좌표로만 움직임)
    1 2 3     IK 검증 · FL       1 기본 이동 · 2 극단 위치 · 3 유효 범위           자동
    4 5       IK 검증 · 네 다리  4 네 다리 차례로 · 5 관절 제한                   자동
    6 7 8 9   복합 동작          6 다리 하나씩 들기 · 7 대각선 두 다리 ·          자동
                                 8 3점 지지 자세 · 9 보행 순서
    F1        키 안내 (콘솔 · 로봇 화면)
    F2        네 다리 기본 자세 (자동 테스트 중이면 멈춘 뒤 기본 자세)
    F3        자동 테스트 멈춤 (다리는 멈춘 자리에 둠)

좌표는 Spot과 같은 다리 좌표계입니다: 원점은 엉덩이 관절, x 앞(+) · y 왼쪽(+) · z 위(+).
기본 자세의 발끝은 [0, ±10, -99]입니다. 시작할 때 네 다리를 기본 자세로 옮깁니다.
끝낼 때는 RoboCo에서 스크립트를 멈춥니다. 다리를 다른 자세로 옮기지 않고 바로 끝납니다.
콘솔 LOG는 영어로 나옵니다([시간] [분류] 내용). 읽는 법은 README 12장에 있습니다.

다리 테스트는 공중에 매단 로봇으로 세 단계로 합니다.
    1. q01_leg1_joint_start.py     관절 테스트 (각도 → 관절)
    2. q01_leg2_ik_start.py        IK 테스트 (발끝 x · y · z 좌표 → 관절 각도)
    3. q01_leg3_combined_start.py  복합 테스트 (IK 검증 + 네 다리 조합 동작, 자동)  ← 이 파일
"""

# --- 준비 코드: 이 부분은 바꾸지 않습니다 ------------------------------------
# 스크립트를 실행할 때마다 Q01_Lib 라이브러리를 새로 읽어 옵니다. 라이브러리
# 파일을 고쳤을 때 고친 내용이 바로 반영되게 하기 위해서입니다. 파일을 지우는
# 것이 아니라, RoboCo가 기억해 둔 이전 내용만 비웁니다.
import sys as _sys

_sys.dont_write_bytecode = True  # 실행할 때 임시 파일(__pycache__ 폴더)을 만들지 않음

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.leg_common.q01lib_leg_app import LegTestApp
from Book_Q01_Robot.Q01_Lib.leg3_combined.q01lib_leg3_combined import CombinedTest


# ========================================
# 1. CONTROL PARAMETERS  (먼저 바꿔 볼 값)
# ========================================
SERVO_RPM = 30               # 관절 서보 회전 속도 (ServoMotor.max_rpm). 최대 1000
                             # 서보 사양(최대 토크: 무릎 1720 · 엉덩이 HX·HY 13150, 가속 시간 0.2초)은 Q01_Lib/core/q01lib_ports.py 7절
BODY_HEIGHT = 99             # 기본 자세의 몸체 높이. 기본 자세의 발끝 z = -BODY_HEIGHT

# --- 이동 ---
MOVE_ALL_STEPS = 30          # 네 다리를 함께 옮길 때 나누는 단계 수 (단계 사이 쉼 없음)
MOVE_SINGLE_STEPS = 20       # 다리 하나를 옮길 때 나누는 단계 수
MOVE_SINGLE_DELAY = 0.01     # 다리 하나를 옮길 때 단계마다 쉬는 시간(초)

# --- 테스트 사이에 기다리는 시간(초) ---
CASE_HOLD_SEC = 3            # 1 · 2: 좌표 하나를 확인한 뒤
VALIDITY_HOLD_SEC = 2        # 3: 좌표 하나를 검사한 뒤
STEP_HOLD_SEC = 2            # 4 · 5 · 6 · 7: 좌표 하나를 확인한 뒤
LEG_GAP_SEC = 2              # 4: 다리 하나를 끝내고 다음 다리로 넘어가기 전
THREE_LEG_HOLD_SEC = 3       # 8: 다리 하나를 든 채 기다리는 시간

# --- 9  보행 순서 ---
WALK_CYCLES = 2              # 반복 횟수
WALK_LIFT_Z = -70            # 다리를 든 발끝 z (기본 자세 -99보다 29 위)
WALK_STEP_X = 30             # 다리를 앞으로 옮기는 거리 (x)
WALK_HOLD_SEC = 1.0          # 단계마다 기다리는 시간(초)

LOOP_SLEEP_SEC = 0.1         # 키를 한 번 읽은 뒤 쉬는 시간(초)

# --- 콘솔 LOG ---
LOG_COLOR = True             # 콘솔 LOG에 색을 입힘. 콘솔에 <color=...> 글자가 그대로 보이면 False
WELCOME_SEC = 1.0           # Book-QUAD-01-LEG3 / WELCOME 표시(초)
START_SCREEN_SEC = 1.0      # Welcome 다음의 기존 '테스트 시작/준비' 화면을 읽을 시간(초)


# ========================================
# 2. KEYS  (왼손 → 오른손 → 사용자 지정 키 순서)
# ========================================
# 왼손 · 오른손: 쓰지 않음

# 사용자 지정 키: 자동 테스트 · 공통
TEST_KEYS = {
    "1": "fl_basic",          # FL 기본 이동
    "2": "fl_extreme",        # FL 극단 위치
    "3": "fl_validity",       # FL 유효 범위
    "4": "all_legs",          # 전체 다리 (네 다리에 1 · 2 · 3)
    "5": "joint_limits",      # 각도 제한
    "6": "lift_each",         # 개별 다리 (하나씩 들기)
    "7": "diagonal",          # 대각선 다리
    "8": "three_legs",        # 3점 지지 자세 (다리 하나씩 들기)
    "9": "walk_sequence",     # 보행 시퀀스
}

HELP_KEY = "f1"              # 키 안내 (콘솔 · 로봇 화면)
STAND_KEY = "f2"             # 네 다리 기본 자세 (자동 테스트 중이면 멈춘 뒤 기본 자세)
STOP_KEY = "f3"              # 자동 테스트 멈춤 (다리는 멈춘 자리에 둠)


# ========================================
# 3. RUN  (한 번 준비하고, 스크립트를 멈출 때까지 반복)
# ========================================
def main():
    app = LegTestApp(globals(), CombinedTest)  # 준비: 기본 자세로 서고 키 안내를 출력
    app.run()                                  # 반복: 키 읽기 → 숫자 키의 테스트 실행


if __name__ == "__main__":
    main()

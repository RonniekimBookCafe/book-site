# QUAD-01 실습 코드 | v3.5.0

**도서:** 『피지컬 AI로 배우는 RoboCo 구조와 보행 제어』  
**시리즈:** PHYSICAL AI · ROBOCO SERIES / QUAD-01 · WALK  
**저자:** 로니킴  
**도서 페이지:** https://ronniekimbooks.com/ko/books/book-008/

이 ZIP에는 책의 실습을 실행하는 Python 시작 파일 8개와 저자 교육용 라이브러리 `Q01_Lib`가 들어 있습니다. 각 실습에서 무엇을 관찰하고, 어떤 값을 바꾸어 무엇과 비교하며, 결과를 어떻게 해석하는지는 **책에서** 다룹니다. RoboCo 게임과 로봇 모델은 들어 있지 않습니다.

## 1. 준비물

| 준비물 | 구하는 곳 |
|---|---|
| RoboCo (Steam) | Steam 스토어 |
| QUAD-01 로봇 모델 7종 | Steam Workshop 구독. 주소는 도서 페이지에 있습니다 |
| 실습 코드 | 이 ZIP |
| 실습 순서 · 관찰 포인트 · 실험과 해석 · 최종 미션 | 책 |

## 2. 설치

1. RoboCo에서 **OPEN SCRIPT FOLDER**를 눌러 `Scripts` 폴더를 엽니다.
2. ZIP을 풀고 `Book_Q01_Robot` 폴더를 통째로 `Scripts` 바로 아래에 둡니다.  
   예: `…/My Games/RoboCo/<Steam 사용자명>/Scripts/Book_Q01_Robot/q01_walk_start.py`
3. 폴더 이름을 바꾸거나 `Q01_Lib`를 밖으로 옮기지 않습니다.

## 3. 첫 실행 — 걷는 4족 로봇

1. RoboCo에서 `Book-QUAD-01-WALK` 모델을 불러옵니다.
2. 로봇의 Microcontroller에서 **LOAD**를 누르고 `q01_walk_start.py`를 고른 뒤 Live Mode로 들어갑니다.
3. 콘솔에 `QUAD-01 WALK   (Book-QUAD-01-WALK)` 상자와 `[STATE] ready`가 나오는지 봅니다.
4. `W`를 누르고 있으면 앞으로 걷고, 떼면 기본 자세로 돌아옵니다. `X`는 정지 자세, `0`은 종료입니다.

여기까지 되면 설치는 정상입니다. 나머지 키와 자동 모드, 보폭과 걸음 속도를 바꾸어 비교하는 실험은 책 PART 1부터 이어집니다.

## 4. 실습 목록

| Workshop 모델 | 시작 파일 | 책에서 다루는 곳 |
|---|---|---|
| Book-QUAD-01-WALK | `q01_walk_start.py` | PART 1 (CHAPTER 01 · 03 ~ 05), PART 4 · 5 |
| Book-QUAD-01-ACTION | `q01_action_start.py` | CHAPTER 02 |
| Book-QUAD-01-LEG1 | `q01_leg1_joint_start.py` | CHAPTER 06 ~ 08 |
| Book-QUAD-01-LEG2 | `q01_leg2_ik_start.py` | CHAPTER 11 ~ 13 |
| Book-QUAD-01-LEG3 | `q01_leg3_combined_start.py` | CHAPTER 14 · 19 · 21 |
| Book-QUAD-01-ROLL_PITCH_YAW | `q01_body_pose_start.py` | CHAPTER 15 · 17 |
| Book-QUAD-01-BALANCE (로봇) | `q01_balance_test_start.py` | CHAPTER 17 (선택 실습) |
| Book-QUAD-01-BALANCE (시험대) | `q01_balance_test_platform_start.py` | CHAPTER 17 (선택 실습) |

연결할 때 지킬 것 세 가지입니다.

- **모델과 시작 파일을 짝지어 씁니다.** 콘솔 첫 상자 제목에 모델 이름이 나옵니다(예: `(Book-QUAD-01-WALK)`, BALANCE는 `QUAD-01 BALANCE TEST`). 불러온 모델과 같은지 확인합니다.
- **BALANCE에는 Microcontroller가 두 개 있습니다.** 로봇 쪽과 시험대 쪽에 위 표의 시작 파일을 **각각** LOAD합니다. 균형 제어를 켜기 전에 책 CHAPTER 17의 방향 확인을 먼저 합니다.
- **RoboCo Controls 매핑이 같은 서보를 움직이지 않게 합니다.** 매핑과 스크립트가 같은 서보를 함께 움직이면 결과를 읽을 수 없습니다.

시작 파일을 열면 맨 위의 `CONTROL PARAMETERS`와 `KEYS`에 바꿔 볼 값과 키가 모여 있습니다. 어떤 값을 언제, 얼마나 바꾸어 무엇과 비교하는지는 책의 해당 장을 따릅니다.

## 5. 콘솔 LOG 읽는 법

콘솔 LOG는 모든 실습에서 같은 형식의 영어로 나옵니다.

```text
[  3.2] [INPUT]     W    forward
[  4.2] [SENSOR]    imu   roll= +1.2  pitch= +0.0  yaw= +0.0 deg
[  5.0] [WARN]      foot out of reach (FL): servo command skipped
```

| 칸 | 뜻 |
|---|---|
| `[  3.2]` | 프로그램을 시작한 뒤 지난 시간(초) |
| `[INPUT]` 등 | 분류: `INPUT` 키 · `PARAMETER` 설정값 · `SENSOR` 센서 · `STATE` 상태 · `ACTION` 동작 · `JOINT` 관절 각도 · `TASK` 자동 테스트 · `METRIC` 결과 · `WARN` 알림 · `ERROR` 오류 |
| 나머지 | 내용. 값은 `이름=값`, 단위는 줄 끝에 한 번 |

문제가 생기면 첫 `[WARN]`·`[ERROR]` 줄과 바로 앞의 `[INPUT]` 줄부터 봅니다. 콘솔에 `<color=#8A929C>` 같은 글자가 그대로 보이면 시작 파일의 `LOG_COLOR`를 `False`로 바꿉니다.

## 6. 설치 문제 해결

| 증상 | 해결 |
|---|---|
| `ModuleNotFoundError: No module named 'Book_Q01_Robot'` | `Book_Q01_Robot` 폴더를 `Scripts` 바로 아래에 두고 이름을 바꾸지 않습니다 |
| `ModuleNotFoundError: … Q01_Lib.core` 등 | 폴더를 통째로 다시 넣습니다. 하위 폴더의 `__init__.py`를 지우지 않습니다 |
| 콘솔에 시작 상자와 `[STATE] ready`가 없음 | 모델의 Microcontroller에서 시작 파일을 다시 LOAD합니다 |
| 콘솔 첫 상자 제목의 모델 이름이 불러온 모델과 다름 | 4절 표대로 시작 파일을 바꿉니다 |
| BALANCE에서 `[시간] [분류]` 형식이 아닌 줄(한국어 줄 등)이 나옴 | 시험대 Microcontroller에 `q01_balance_test_platform_start.py`를 LOAD합니다 |
| `[ERROR] setup failed` | 다음 줄에 나온 값 이름을 시작 파일에서 고친 뒤 다시 LOAD합니다 |
| 시작 파일을 고쳤는데 그대로임 | 저장한 뒤 스크립트를 멈추고 다시 LOAD해 실행합니다 |

관절이 반대로 돌거나, 발이 미끄러지거나, 시험대가 반대로 기우는 문제의 원인과 확인 순서는 책의 해당 장과 부록에서 다룹니다.

## 7. 코드 주석에 남은 번호

시작 파일과 라이브러리의 주석·콘솔 문구에는 개발용 README의 장 번호가 남아 있습니다. 다음처럼 읽습니다.

| 코드에 적힌 번호 | 찾아볼 곳 |
|---|---|
| `README 8.1`, `README 11.1` ~ `11.3` | 책 CHAPTER 17 (기울기 시험대 · 균형 테스트) |
| `README 12장` | 이 README 5절 |
| `README 14`, `14장` | 책 부록 A (Port · 관절 · 축) |

## 8. 파일 구성

```text
Book_Q01_Robot/
├─ q01_*_start.py        시작 파일 8개 (모델의 Microcontroller에 LOAD)
├─ Q01_Lib/              저자 교육용 라이브러리 (RoboCo 공식 API가 아님)
├─ README.md             이 문서
├─ COMPATIBILITY.md      버전과 검증 상태
├─ RELEASE_NOTES.md      변경 내용
├─ RIGHTS_AND_USAGE.md   사용 및 권리 안내
├─ RELEASE_MANIFEST.json 파일 목록과 SHA-256
└─ cover_quad-01.jpg     도서 표지
```

## 9. 지원

- Workshop 모델 주소 · 정오표 · 업데이트: https://ronniekimbooks.com/ko/books/book-008/
- 문의할 때는 RoboCo 버전, 모델 이름, 시작 파일 이름, ZIP 버전(v3.5.0), 첫 `[WARN]`·`[ERROR]` 줄을 함께 적습니다.

# -*- coding: utf-8 -*-
"""
q01_balance_test_platform_start.py  |  QUAD-01 시작 파일 · 균형 테스트의 기울기 시험대
배포 버전 3.9.7  |  Book-QUAD-01-BALANCE의 시험대 Microcontroller(3axis-Microcontroller)에 연결해 실행합니다.

Book-QUAD-01-BALANCE에는 Microcontroller가 두 개 있습니다. 시작 파일도 하나씩 연결합니다.
    시험대 3axis-Microcontroller  q01_balance_test_platform_start.py   ← 이 파일 (시험대 기울이기)
    로봇 Microcontroller          q01_balance_test_start.py            로봇 균형 · 모든 키 · 콘솔 · 판정
시험대는 로봇이 균형을 잡는지 보기 위한 보조 장치입니다. 이 스크립트는 키를 따로 정하지 않고 로봇을
따라 시험대를 기울이며, 콘솔에는 알림(WARN · ERROR)만 씁니다. 시험대 각도와 결과는 로봇 콘솔에 나옵니다.

시험대 3axis-Microcontroller의 Port
    0 · 1  Roll Servo Motor 1 · 2      2 · 3  Pitch Servo Motor 1 · 2      4  Yaw Servo Motor 1
    5      3axis-Inertial Sensor 1 (시험대 IMU)  6  3axis-Text Screen 1      7  (있으면) 안내 화면
    (선택) 비어 있는 Port에 로봇 Microcontroller를 배정하면 시험대 IMU 값을 로봇에 보냄

[로봇을 따라가는 방법]
    로봇 Microcontroller의 Port에 이 시험대 Microcontroller를 배정했으면: 로봇이 보낸 시험대 각도를 따름 (메시지)
    배정하지 않았으면: 로봇과 같은 키(W S A D Q E · 1 2 3 5 6 7 · F2 F3)를 직접 읽어 같은 순서로 움직임
시험대의 키 · 테스트 순서 · 시험대 각도의 부호는 로봇 시작 파일과 README 11.1에 있습니다.

좌표와 부호는 로봇과 같은 Spot 몸체 좌표계입니다 (회전은 오른손 법칙).
    roll  +  시험대의 오른쪽이 내려감    pitch +  시험대의 앞쪽이 내려감    yaw +  왼쪽(반시계)으로 돎
시험대가 반대로 기울면 로봇의 1(방향 확인)이 아래 SERVO_SIGN 가운데 어느 것을 -1로 바꿀지 알려 줍니다.

시험대가 하는 일은 Q01_Lib/balance_test/q01lib_platform_app.py에 있습니다. 끝낼 때는 RoboCo에서 스크립트를 멈춥니다.
"""

# --- 준비 코드: 이 부분은 바꾸지 않습니다 ------------------------------------
# 스크립트를 실행할 때마다 Q01_Lib 라이브러리를 새로 읽어 옵니다. 라이브러리
# 파일을 고쳤을 때 고친 내용이 바로 반영되게 하기 위해서입니다. 파일을 지우는
# 것이 아니라, RoboCo가 기억해 둔 이전 내용만 비웁니다.
import sys as _sys

_sys.dont_write_bytecode = True  # 실행할 때 임시 파일(__pycache__ 폴더)을 만들지 않음

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.balance_test.q01lib_platform_app import PlatformApp


# ========================================
# 1. CONTROL PARAMETERS  (시험대 장치에 맞출 값)
# ========================================
# --- 시험대 서보 ---
TILT_LIMIT_DEG = 15          # 시험대 각도의 안전 한계(도). 로봇이 보낸 각도도 ±이 값 안으로 제한
# --- 시험대 서보 속도 (ServoMotor.max_rpm, rpm × 6 = 초당 도) ---
SERVO_RPM = None             # 기준 속도. None이면 시작할 때 부품 설정 값을 읽어 씀
                             # 시험대 속도 배수(기본 × 2.0)는 로봇 시작 파일의 PLATFORM_SPEED, 실행 중에는 로봇의 6 · 7

# --- 방향 맞추기 (로봇의 1 방향 확인이 알려 줄 때만 바꿈) ---
ROLL_SERVO_SIGN = 1          # 시험대 각도 → 서보 각도 부호. 시험대가 반대로 기울면 -1
PITCH_SERVO_SIGN = 1
YAW_SERVO_SIGN = -1          # 이 시험대의 Yaw 서보는 + 각도에서 오른쪽(시계)으로 돌므로 -1

# --- 시험대 IMU (Port 5): 시험대 화면에 시험대가 실제로 기운 각도를 보여 줌 ---
USE_IMU = True               # False: 시험대 IMU를 읽지 않음
IMU_ROLL_SIGN = 1            # 시험대 IMU 읽기 부호 (센서를 다르게 달았을 때)
IMU_PITCH_SIGN = 1
IMU_YAW_SIGN = 1
IMU_SWAP_ROLL_PITCH = False
ZERO_SETTLE_SEC = 1.0        # 시험대를 평평하게 한 뒤 최소로 기다리는 시간(초). 그 뒤 시험대 IMU가 멈출 때까지 기다림
CALIBRATION_SAMPLES = 20     # 시험대 IMU가 멈춘 뒤 영점을 잡을 때 읽는 횟수 (회전 평균, 0.05초 간격)
IMU_STILL_DEG = 0.2          # 0.05초 동안 이보다 적게 움직여야 "멈춤" (5번 이어지면 영점, 최대 5초 기다림)

# --- 로봇에 시험대 IMU 보내기 (선택) ---
ROBOT_MCU_PORT = None        # 로봇 Microcontroller를 배정한 이 시험대 Microcontroller의 Port. None이면 찾아봄
REPORT_SEC = 0.5             # 시험대 IMU 값을 로봇에 보내는 간격(초)

# --- 반복과 출력 ---
LOOP_SLEEP_SEC = 0.02        # 한 번 반복한 뒤 쉬는 시간(초)
SCREEN_INTERVAL_SEC = 0.2    # 시험대 화면을 다시 쓰는 간격(초)
PLATFORM_LOG = False         # True: 시험대의 명령 · 상태도 콘솔에 씀 (시험대를 따로 고칠 때만). False이면 알림만
LOG_COLOR = True             # 콘솔 LOG에 색을 입힘. 콘솔에 <color=...> 글자가 그대로 보이면 False


# ========================================
# 2. RUN  (한 번 준비하고, 스크립트를 멈출 때까지 반복)
# ========================================
def main():
    from scriptruntime import Runtime
    Runtime.require_force_close(False)  # BALANCE 시험대 MCU도 Space에서 즉시 중단
    # 준비: 시험대를 평평하게 하고, 시험대 IMU 영점을 맞춤
    app = PlatformApp(globals())
    # 반복: 로봇의 메시지(또는 같은 키) → 시험대 기울이기 → 시험대 화면 · (선택) 로봇에 시험대 IMU 보내기
    app.run()


if __name__ == "__main__":
    main()

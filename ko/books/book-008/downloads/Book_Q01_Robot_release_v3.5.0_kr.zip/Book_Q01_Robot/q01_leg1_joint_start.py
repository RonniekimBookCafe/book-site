# -*- coding: utf-8 -*-
"""
q01_leg1_joint_start.py  |  QUAD-01 시작 파일 · 다리 테스트 1 · 관절 테스트
배포 버전 3.9.7  |  공중에 매단 로봇(Book-QUAD-01-LEG1)의 Microcontroller에 연결해 실행합니다.

발끝 좌표(IK)를 쓰지 않고 관절 서보에 각도를 직접 보냅니다. 어느 Port가 어느
관절인지, 각도를 바꾸면 다리가 어느 쪽으로 도는지, 왼쪽과 오른쪽 다리의 각도가
왜 반대인지를 확인합니다.

[키]  왼손 W S A D E Q · 오른손 I K J L U O · 사용자 지정 키
    W · S     고른 다리 HY 앞 · 뒤 (엉덩이 Y축, 다리를 앞뒤로 흔듦)
    A · D     고른 다리 HX 왼쪽 · 오른쪽 (엉덩이 X축, 다리를 벌리고 모음)
    E · Q     고른 다리 KN 굽힘 · 폄 (무릎, 발이 올라감 · 내려감)
    I         (쓰지 않음)
    K         고른 다리 관절 세 개를 90도로
    J · L     다리 고르기 HL · HR      위에서 본 다리 배치와 같은 모양
    U · O     다리 고르기 FL · FR          U FL    O FR
                                           J HL    L HR
    1 2 3 4   다리 하나의 관절 테스트 (FL · HL · HR · FR, KN → HY → HX 차례로)  자동
    5         네 다리 HX 함께 벌리기                                         자동
    6         네 다리 포즈 변화 (HX → KN → HY를 1도씩 천천히)                 자동
    0         관절 영점 자세 (모든 관절 논리 90도)                            자동
    F1        키 안내 (콘솔 · 로봇 화면)
    F2        네 다리 기본 자세 (자동 테스트 중이면 멈춘 뒤 기본 자세)
    F3        자동 테스트 멈춤 (다리는 멈춘 자리에 둠)

시작할 때 로봇은 움직이지 않습니다. 0이나 F2로 자세를 먼저 맞춥니다.
끝낼 때는 RoboCo에서 스크립트를 멈춥니다. 다리를 다른 자세로 옮기지 않고 바로 끝납니다.

콘솔 LOG는 영어로 나옵니다([시간] [분류] 내용). 읽는 법은 README 12장에 있습니다.

다리 이름은 Spot과 같이 FL 앞왼쪽 · FR 앞오른쪽 · HL 뒤왼쪽 · HR 뒤오른쪽입니다
(RoboCo 부품 이름 FrontLeft · FrontRight · HindLeft · HindRight). CORE-01 4륜 로봇의
RL · RR(Rear)과 HL · HR(Hind)은 같은 자리입니다.

다리 테스트는 공중에 매단 로봇으로 세 단계로 합니다.
    1. q01_leg1_joint_start.py     관절 테스트 (각도 → 관절)               ← 이 파일
    2. q01_leg2_ik_start.py        IK 테스트 (발끝 x · y · z 좌표 → 관절 각도)
    3. q01_leg3_combined_start.py  복합 테스트 (IK 검증 + 네 다리 조합 동작, 자동)
"""

# --- 준비 코드: 이 부분은 바꾸지 않습니다 ------------------------------------
# 스크립트를 실행할 때마다 Q01_Lib 라이브러리를 새로 읽어 옵니다. 라이브러리
# 파일을 고쳤을 때 고친 내용이 바로 반영되게 하기 위해서입니다. 파일을 지우는
# 것이 아니라, RoboCo가 기억해 둔 이전 내용만 비웁니다.
import sys as _sys

_sys.dont_write_bytecode = True  # 실행할 때 임시 파일(__pycache__ 폴더)을 만들지 않음

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.leg_common.q01lib_leg_app import LegTestApp
from Book_Q01_Robot.Q01_Lib.leg1_joint.q01lib_leg1_joint import JointTest


# ========================================
# 1. CONTROL PARAMETERS  (먼저 바꿔 볼 값)
# ========================================
SERVO_RPM = 30               # 관절 서보 회전 속도 (ServoMotor.max_rpm). 최대 1000
                             # 서보 사양(최대 토크: 무릎 1720 · 엉덩이 HX·HY 13150, 가속 시간 0.2초)은 Q01_Lib/core/q01lib_ports.py 7절
BODY_HEIGHT = 99             # F2 기본 자세의 몸체 높이. 기본 자세의 발끝 z = -BODY_HEIGHT
START_LEG = "FL"             # 처음 고른 다리 (FL · HL · HR · FR)

# --- W · S · A · D · E · Q  관절 직접 조작 ---
JOINT_JOG_DEG = 10           # 키를 한 번 누를 때 관절이 도는 각도(도)
KEY_REPEAT_SEC = 0           # 누르고 있을 때 다시 움직이는 간격(초). 0이면 누를 때 한 번만

# --- 1 · 2 · 3 · 4  다리 하나의 관절 테스트 ---
# 왼쪽 다리(FL·HL) 기준 논리 각도 목록. 오른쪽 다리(HR·FR)에는 180 - 각도를 보냄
LEFT_TEST_ANGLES = {
    "KN": [0, 90, 150, 90],  # 무릎
    "HY": [0, 90, 180, 90],  # 엉덩이 Y축
    "HX": [0, 90, 135, 90],  # 엉덩이 X축
}
TEST_ORDER = ["KN", "HY", "HX"]   # 관절을 돌리는 순서
JOINT_STEP_SEC = 1           # 각도 하나를 보낸 뒤 기다리는 시간(초)

# --- 5  네 다리 HX 함께 벌리기 ---
SPREAD_LEFT_ANGLE = 0        # 왼쪽 다리 HX 각도 (오른쪽 다리는 180 - 이 값)
SPREAD_HOLD_SEC = 2          # 벌린 자세를 유지하는 시간(초)
SPREAD_RETURN_SEC = 1        # 90도로 돌아온 뒤 기다리는 시간(초)

# --- 6  네 다리 포즈 변화 ---
SWEEP_HX_DEG = 90            # HX를 돌리는 각도(1도씩). 왼쪽 90 → 1도, 오른쪽 90 → 179도
SWEEP_KN_DEG = 90            # KN을 돌리는 각도
SWEEP_HY_DEG = 45            # HY를 돌리는 각도
SWEEP_STEP_SEC = 0.01        # 1도마다 쉬는 시간(초)
SWEEP_PAUSE_SEC = 1          # HX · KN을 다 돌린 뒤 기다리는 시간(초)
SWEEP_END_PAUSE_SEC = 2      # HY를 다 돌린 뒤 기다리는 시간(초)
SWEEP_RESET_GROUP_SEC = 2    # 끝나고 관절 영점 자세로 돌아올 때 관절 묶음마다 기다리는 시간(초)

# --- 0  관절 영점 자세 ---
ZERO_GROUP_SEC = 1           # KN · HY · HX 관절 묶음마다 기다리는 시간(초)

LOOP_SLEEP_SEC = 0.1         # 키를 한 번 읽은 뒤 쉬는 시간(초)

# --- 콘솔 LOG ---
LOG_COLOR = True             # 콘솔 LOG에 색을 입힘. 콘솔에 <color=...> 글자가 그대로 보이면 False
WELCOME_SEC = 1.0           # Book-QUAD-01-LEG1 / WELCOME 표시(초)
START_SCREEN_SEC = 1.0      # Welcome 다음의 기존 '테스트 시작/준비' 화면을 읽을 시간(초)


# ========================================
# 2. KEYS  (왼손 → 오른손 → 사용자 지정 키 순서)
# ========================================
# 왼손: 관절 직접 조작. 키 → (관절, 왼쪽 다리에서 각도를 바꾸는 방향 +1 · -1)
# 오른쪽 다리는 HY · KN 방향을 반대로 보내므로, 네 다리 모두 같은 쪽으로 움직입니다.
JOG_KEYS = {
    "w": ("HY", -1),         # 다리를 앞으로 (IK 테스트에서 발끝 x +)
    "s": ("HY", 1),          # 다리를 뒤로
    "a": ("HX", -1),         # 다리를 왼쪽으로 (IK 테스트에서 발끝 y +)
    "d": ("HX", 1),          # 다리를 오른쪽으로
    "e": ("KN", 1),          # 무릎을 굽힘 → 발이 올라감 (IK 테스트에서 발끝 z +)
    "q": ("KN", -1),         # 무릎을 폄 → 발이 내려감
}

# 오른손: 고른 다리 · 다리 고르기
LEG_ZERO_KEY = "k"           # 고른 다리의 관절 세 개를 90도로
LEG_SELECT_KEYS = {          # 위에서 본 다리 배치와 같은 모양
    "u": "FL",               # 앞왼쪽     U  O
    "o": "FR",               # 앞오른쪽
    "j": "HL",               # 뒤왼쪽     J  L
    "l": "HR",               # 뒤오른쪽
}

# 사용자 지정 키: 자동 테스트 · 공통
LEG_TEST_KEYS = {            # 다리 하나의 관절 테스트
    "1": "FL",               # 앞왼쪽
    "2": "HL",               # 뒤왼쪽
    "3": "HR",               # 뒤오른쪽
    "4": "FR",               # 앞오른쪽
}
SPREAD_KEY = "5"             # 네 다리 HX 함께 벌리기
SWEEP_KEY = "6"              # 네 다리 포즈 변화
ZERO_KEY = "0"               # 관절 영점 자세

HELP_KEY = "f1"              # 키 안내 (콘솔 · 로봇 화면)
STAND_KEY = "f2"             # 네 다리 기본 자세 (자동 테스트 중이면 멈춘 뒤 기본 자세)
STOP_KEY = "f3"              # 자동 테스트 멈춤 (다리는 멈춘 자리에 둠)


# ========================================
# 3. RUN  (한 번 준비하고, 스크립트를 멈출 때까지 반복)
# ========================================
def main():
    app = LegTestApp(globals(), JointTest)  # 준비: 값과 키를 모으고 키 안내를 출력
    app.run()                               # 반복: 키 읽기 → 관절 직접 조작 · 자동 테스트


if __name__ == "__main__":
    main()

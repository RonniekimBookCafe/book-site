# -*- coding: utf-8 -*-
"""
q01_balance_test_start.py  |  QUAD-01 시작 파일 · 균형 테스트 (시험대 · IMU · PID)
배포 버전 3.9.7  |  기울기 시험대 위에 선 로봇(Book-QUAD-01-BALANCE)의 Microcontroller에 연결해 실행합니다.

Book-QUAD-01-BALANCE에는 Microcontroller가 두 개 있습니다. 시작 파일도 하나씩 연결합니다.
    로봇 Microcontroller          q01_balance_test_start.py            ← 이 파일 (모든 키 · 콘솔 · 판정)
    시험대 3axis-Microcontroller  q01_balance_test_platform_start.py   시험대 기울이기 (로봇을 따라감)
이 실습의 목적은 시험대가 기울 때 로봇이 몸체를 수평으로 유지하는지 보는 것입니다. 시험대는 보조 장치이므로
키는 모두 이 파일에서 정하고, 시험대 각도와 결과는 로봇의 콘솔 · 화면에 나옵니다.

    시험대 키 · 테스트 → 시험대 각도 → (메시지) → 시험대 Microcontroller → 시험대가 기울어짐
    로봇 IMU → 필터 → PID (roll · pitch, 목표 0도) → 보정 각도 → 몸체 자세 → 네 발끝 → IK → 서보 12개

[처음 하는 순서]  콘솔 · 로봇 화면이 다음 단계를 알려 줍니다 (next: ...)
    1   방향 확인: 시험대와 몸체를 ±15도 기울여 시험대 서보 · 로봇 IMU의 방향(부호)을 확인  자동, 약 23초
    2   균형 테스트: 균형 ON, 시험대가 TEST_POSES대로 기우는 동안 몸체 기울기를 자세마다 표로  자동, 약 25초
    3   비교 테스트: 같은 시험대 움직임을 균형 OFF → ON으로 두 번, 몸체 기울기를 나란히        자동, 약 51초
        (균형 OFF: 로봇이 시험대와 함께 기욺 / 균형 ON: PID가 몸체를 수평으로 → 균형 제어가 지운 기울기를 숫자로)
    PID를 바꾼 뒤(U J · I K · O L) 2를 다시 누르면 같은 조건에서 표를 비교할 수 있습니다.
    8   연속 흔들기: 시험대가 TEST_POSES를 2초씩 계속 되풀이. 멈추지 않고 PID 키를 눌러 차이를 바로 봄

[PID 키는 한 번에 한 단계]  KP_LEVELS · KI_LEVELS · KD_LEVELS의 다음 · 이전 값으로 크게 바뀝니다.
정밀하게 맞추기보다 "이 값을 바꾸면 로봇이 어떻게 달라지는가"를 눈으로 보기 위해 단계를 크게 벌렸습니다.
    KP 0 → 8     작으면 느리게 수평, 크면 빨리 수평 · 너무 크면 떨림
    KI 0 → 30    0이면 시험대가 기운 만큼 몸체에 남음, 크면 지나쳐서 출렁임
    KD 0 → 1     조금은 흔들림을 줄이고, 크면 IMU 잡음까지 키워 떨림
값은 바로 반영됩니다(균형 ON · 8 연속 흔들기 중에도). 1 2 3 자동 테스트 중에 누른 키는 테스트가 끝난 뒤
처리합니다(테스트 하나는 같은 값으로 재기 위해). 키를 누르면 로봇 화면에 2초(POPUP_SEC) 동안 무엇이
바뀌었고 왜 필요한지가 나왔다가 메인 화면으로 돌아옵니다.

[키]  왼손 시험대 · 오른손 PID · 사용자 지정 키
    W · S     시험대 pitch + · -  (앞쪽이 내려감 · 앞쪽이 올라감)  키 한 번에 PLATFORM_STEP_DEG(15도)
    D · A     시험대 roll  + · -  (오른쪽이 내려감 · 왼쪽이 내려감)
    Q · E     시험대 yaw   + · -  (왼쪽으로 돎 · 오른쪽으로 돎)
    U · J     KP 한 단계 위 · 아래   (P: 지금 기울기에 비례)
    I · K     KI 한 단계 위 · 아래   (I: 남은 기울기를 쌓아 보정)
    O · L     KD 한 단계 위 · 아래   (D: 빠른 변화를 누그러뜨림)
    1 2 3     방향 확인 · 균형 테스트 · 비교 테스트
    4         균형 ON / OFF (직접 해 보기)
    5         시험대 평평하게
    6 · 7     시험대 속도 - · + (PLATFORM_SPEED_STEP 0.2씩. 로봇 화면 · 콘솔 · 시험대 화면에 x2.0처럼)
    8         연속 흔들기 켜기 · 끄기 (균형 ON, PID 키 바로 반영)
    F1        키 안내 (콘솔 · 로봇 화면)
    F2        처음으로: 테스트 멈춤 · 시험대 평평 · 균형 OFF · 기본 자세 · IMU 영점
    F3        모두 멈춤: 테스트를 멈추고 시험대와 로봇을 그 자리에 둠
RoboCo 플레이 화면의 Controls 패널에 보이는 키 이름은 로봇 파일의 Controls Mapping에서 옵니다(스크립트가
바꿀 수 없음). 이 파일은 키를 직접 읽으므로 패널에 없는 키도 동작합니다. 패널 이름은 README 11.2 표대로 맞춥니다.

[좌표와 부호]  Spot과 같은 몸체 좌표계 (x 앞 · y 왼쪽 · z 위, 회전은 오른손 법칙, README 14)
    roll  +  오른쪽이 내려감        pitch +  머리(앞)가 내려감        yaw +  왼쪽(반시계)으로 돎
시험대가 roll +15이면 IMU roll이 +15가 되고, PID가 보정 roll -15를 내어 몸체를 수평으로 되돌립니다.

[시험대 연결]  로봇 파일에서 로봇 Microcontroller의 비어 있는 Port(예: 14)에 시험대 3axis-Microcontroller를
배정하면, 이 스크립트가 시험대에 시험대 각도를 메시지로 보냅니다(RoboCo MicroController.message, README 11.1).
배정하지 않으면 시험대 스크립트가 같은 키를 직접 읽어 같은 순서로 움직입니다. 이때 시험대는 이 파일의
2-1 · 2-2 값 대신 기본값을 쓰므로, 값을 바꾸려면 시험대를 연결합니다.

시작할 때 시험대를 평평하게 하고, 기본 자세로 선 뒤 IMU가 멈출 때까지 기다려(최대 5초) 영점을 잡습니다.
끝낼 때는 RoboCo에서 스크립트를 멈춥니다. 콘솔 LOG는 영어이고 읽는 법은 README 12장에 있습니다.
다리 이름은 Spot과 같이 FL 앞왼쪽 · FR 앞오른쪽 · HL 뒤왼쪽 · HR 뒤오른쪽입니다.
"""

# --- 준비 코드: 이 부분은 바꾸지 않습니다 ------------------------------------
# 스크립트를 실행할 때마다 Q01_Lib 라이브러리를 새로 읽어 옵니다. 라이브러리
# 파일을 고쳤을 때 고친 내용이 바로 반영되게 하기 위해서입니다. 파일을 지우는
# 것이 아니라, RoboCo가 기억해 둔 이전 내용만 비웁니다.
import sys as _sys

_sys.dont_write_bytecode = True  # 실행할 때 임시 파일(__pycache__ 폴더)을 만들지 않음

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.leg_common.q01lib_leg_app import LegTestApp
from Book_Q01_Robot.Q01_Lib.balance_test.q01lib_balance_test import BalanceTest


# ========================================
# 1. CONTROL PARAMETERS  (먼저 바꿔 볼 값)
# ========================================
# --- PID: 몸체 기울기(도) → 보정 각도(도). U J · I K · O L로 실행 중에 바꿀 수 있음 ---
KP = 0.5                     # P: 지금 기울기에 비례해 보정. 크면 빠르지만 떨림 (시작 값, 단계 사이 값도 됨)
KI = 1.5                     # I: 남은 기울기를 시간에 따라 쌓아 보정. 0이면 기울기가 남음
KD = 0.02                    # D: 기울기가 바뀌는 빠르기를 누그러뜨림. 크면 IMU 잡음에 흔들림
KP_LEVELS = [0, 0.25, 0.5, 1, 2, 4, 8]       # U · J 한 번에 한 칸. 작은 값부터
KI_LEVELS = [0, 0.5, 1.5, 3, 6, 15, 30]      # I · K
KD_LEVELS = [0, 0.02, 0.05, 0.1, 0.3, 1]     # O · L
MAX_CORRECTION_DEG = 18      # 몸체를 기울일 수 있는 최대 보정 각도(도). 갈 수 없는 자세이면 보정을 멈춤
BALANCE_AT_START = False     # True이면 시작하자마자 균형 모드를 켬

# --- 판정 (2 균형 테스트) ---
LEVEL_OK_DEG = 2.0           # 시험대 자세마다 끝(마지막 0.5초)의 몸체 기울기가 이 값(도) 이하이면 OK
SETTLE_DEG = 1.0             # 몸체 기울기가 이 값(도) 아래로 들어와 머문 시각을 "settle"로 씀

# --- 자세와 몸체 치수 (다리 길이 23 · 55 · 65와 같은 단위) ---
SERVO_RPM = 30               # 관절 서보 회전 속도 (ServoMotor.max_rpm). 최대 1000
BODY_HEIGHT = 99             # 기본 자세의 높이. 기본 자세의 발끝 z = -BODY_HEIGHT
BODY_LENGTH = 136            # 앞다리와 뒷다리 엉덩이 관절 사이 거리
BODY_WIDTH = 76              # 왼쪽과 오른쪽 엉덩이 관절 사이 거리
FEET_FORWARD = 10            # 기본 자세에서 네 발끝을 엉덩이보다 앞에 두는 거리. 시험대 앞이 내려갈 때(pitch +)
                             # 뒷다리가 보정할 여유가 생겨 몸체 pitch를 -18 ~ +26도까지 기울일 수 있음 (0이면 -14 ~ +26)

# --- IMU (Port 1) ---
FILTER_MODE = "칼만"          # 필터: "없음" · "칼만" · "이동 평균" · "칼만 + 이동 평균"
                             # (영어 이름 "none" · "kalman" · "moving_avg" · "kalman+avg"도 됨)
CALIBRATION_SAMPLES = 20     # IMU가 멈춘 뒤 영점을 맞출 때 읽는 횟수 (회전 평균, 0.05초 간격)
IMU_STILL_DEG = 0.2          # 0.05초 동안 이보다 적게 움직여야 "멈춤" (5번 이어지면 영점, 최대 5초 기다림).
                             # 로봇이 가만히 있는데도 "IMU not still"이 반복되면 0.5처럼 키움
ROLL_SIGN = 1                # IMU 방향 맞추기 (센서를 다르게 달았을 때만 바꿈). 1 방향 확인이 알려 줌
PITCH_SIGN = 1
YAW_SIGN = 1
SWAP_ROLL_PITCH = False

# --- 2-1. 시험대 (시험대 Microcontroller 연결) ---
PLATFORM_MCU_PORT = None     # 시험대 3axis-Microcontroller를 배정한 이 Microcontroller의 Port. None이면 찾아봄
PLATFORM_STEP_DEG = 15       # 시험대 키 한 번에 기우는 각도(도)
PLATFORM_LIMIT_DEG = 15      # 시험대 각도의 한계(도)
PLATFORM_SPEED = 2.0         # 시험대 속도 배수: 시험대 서보 속도 = 시험대 서보 부품 설정 속도 × 이 값 (1.0 = 부품 설정 속도). 0.4 ~ 4.0
PLATFORM_SPEED_STEP = 0.2    # 6 · 7 한 번에 바뀌는 시험대 속도 배수. 시험대 키 · 테스트 · 8의 시험대 움직임이 모두 이 속도

# --- 2-2. 테스트 순서 ---
CHECK_DEG = 15               # 1 방향 확인: 시험대 · 몸체를 기울이는 크기(도)
CHECK_HOLD_SEC = 2.0         # 1 방향 확인: 시험대 자세 하나를 유지하는 시간(초)
CHECK_MOVE_STEPS = 10        # 1 방향 확인: 몸체 자세로 옮길 때 나누는 단계 수
TEST_POSES = [               # 2 · 3: 차례로 기울일 시험대 자세 (roll, pitch, yaw)(도)
    (15, 0, 0), (0, 0, 0), (-15, 0, 0), (0, 0, 0),
    (0, 15, 0), (0, 0, 0), (0, -15, 0), (0, 0, 0),
]
TEST_HOLD_SEC = 3.0          # 2 · 3: 시험대 자세 하나를 유지하는 시간(초)
SWAY_HOLD_SEC = 2.0          # 8 연속 흔들기: TEST_POSES의 자세 하나를 유지하는 시간(초). 끝없이 되풀이

# --- 반복과 출력 ---
KEY_REPEAT_SEC = 0            # PID 키를 누르고 있을 때 다시 바꾸는 간격(초). 0이면 누를 때 한 단계만
LOG_INTERVAL_SEC = 1.0       # 시험대 · IMU · 보정을 확인하는 간격(초). 바뀌었을 때만 한 줄 남김. 0이면 남기지 않음
LOG_DETAIL = False           # True: PID의 P · I · D 항과 다리 높이 변화도 콘솔에 남김
LOOP_SLEEP_SEC = 0.02        # 키를 한 번 읽은 뒤 쉬는 시간(초). 균형 제어도 이 간격으로 반복

# --- 콘솔 LOG ---
LOG_COLOR = True             # 콘솔 LOG에 색을 입힘. 콘솔에 <color=...> 글자가 그대로 보이면 False
WELCOME_SEC = 1.0           # Book-QUAD-01-BALANCE / WELCOME 표시(초)
START_SCREEN_SEC = 2.5      # Welcome 다음의 기존 '테스트 시작/준비' 화면을 읽을 시간(초)

# --- 로봇 화면 ---
POPUP_SEC = 2.0              # 키를 누른 뒤 보조 화면(무엇이 바뀌었는지 · 왜 필요한지)을 보여 주는 시간(초). 0이면 안 씀


# ========================================
# 2. KEYS  (왼손 → 오른손 → 사용자 지정 키 순서)
# ========================================
# 왼손: 시험대 기울이기. 키 → (축, 방향 +1 · -1)
PLATFORM_KEYS = {
    "w": ("pitch", 1),       # 앞쪽이 내려감 (pitch +)
    "s": ("pitch", -1),      # 앞쪽이 올라감 (pitch -)
    "a": ("roll", -1),       # 왼쪽이 내려감 (roll -)
    "d": ("roll", 1),        # 오른쪽이 내려감 (roll +)
    "q": ("yaw", 1),         # 왼쪽으로 돎 (yaw +)
    "e": ("yaw", -1),        # 오른쪽으로 돎 (yaw -)
}

# 오른손: PID 값 바꾸기. 키 → (바꿀 값, 방향 +1 · -1)
GAIN_KEYS = {
    "u": ("KP", 1),          # KP +
    "j": ("KP", -1),         # KP -
    "i": ("KI", 1),          # KI +
    "k": ("KI", -1),         # KI -
    "o": ("KD", 1),          # KD +
    "l": ("KD", -1),         # KD -
}

# 사용자 지정 키 (시험대 스크립트도 연결하지 않았을 때 1 2 3 5 6 7 8 · F2 F3을 같은 뜻으로 읽음)
CHECK_KEY = "1"              # 방향 확인 (자동)
TEST_KEY = "2"               # 균형 테스트 (자동)
COMPARE_KEY = "3"            # 비교 테스트: 같은 시험대 움직임을 균형 OFF → ON으로 두 번 (자동)
BALANCE_KEY = "4"            # 균형 ON / OFF
LEVEL_KEY = "5"              # 시험대 평평하게
PLATFORM_SLOWER_KEY = "6"    # 시험대 속도 - (PLATFORM_SPEED_STEP)
PLATFORM_FASTER_KEY = "7"    # 시험대 속도 +
SWAY_KEY = "8"               # 연속 흔들기 켜기 · 끄기 (균형 ON, 시험대가 TEST_POSES를 계속 되풀이)

HELP_KEY = "f1"              # 키 안내 (콘솔 · 로봇 화면)
STAND_KEY = "f2"             # 처음으로 (시험대 평평 · 균형 OFF · 기본 자세 · IMU 영점)
STOP_KEY = "f3"              # 모두 멈춤 (테스트 · 시험대)


# ========================================
# 3. RUN  (한 번 준비하고, 스크립트를 멈출 때까지 반복)
# ========================================
def main():
    from scriptruntime import Runtime
    Runtime.require_force_close(False)  # Space: 별도 종료 대기 없이 기본 즉시 중단
    app = LegTestApp(globals(), BalanceTest)  # 준비: 시험대 평평 · 기본 자세 · IMU 영점 · 키 안내
    app.run()                                 # 반복: 키 → 시험대 · 테스트, IMU → (균형 ON이면) PID → 다리 · 화면 · 콘솔


if __name__ == "__main__":
    main()

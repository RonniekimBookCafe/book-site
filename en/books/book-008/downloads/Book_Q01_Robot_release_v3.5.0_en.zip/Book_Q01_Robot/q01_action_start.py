# -*- coding: utf-8 -*-
"""q01_action_start.

QUAD-01 starter script. Action demonstrations, animated quadruped poses, and motion patterns. Attach to the matching RoboCo microcontroller; adjust CONTROL PARAMETERS and KEYS in this file. The Q01_Lib package implements the underlying movements.
Setup: README.md. What to observe, change, and compare in each exercise: the book."""

# --- SETUP CODE: Do not edit this section -----------------------------------
# Reload Q01_Lib on every run so edits to the library are picked up.
# This clears the previously cached module references;
# no source files are deleted from disk.
import sys as _sys

_sys.dont_write_bytecode = True  # Do not create __pycache__ files on each run

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.action.q01lib_action_app import ActionApp


# ========================================
# 1. CONTROL PARAMETERS (change these values first)
# ========================================
# --- Smooth, interpolated motion ---
SMOOTH_STEPS = 30            # Interpolation steps between consecutive postures
FAST_DELAY = 0.01            # Delay between steps for the default fast motion (seconds)
SLOW_DELAY = 0.02            # Delay between steps for slow motion (seconds)
VERY_SLOW_DELAY = 0.03       # Delay between steps for very slow handstand motion (seconds)

# --- Joint-servo speed ---
DEFAULT_RPM = 30             # Normal joint-servo speed (ServoMotor.max_rpm)
FAST_RPM = 300               # Faster servo speed for planche push-ups and handstands

# --- Standing and intermediate rest poses ---
STAND_HEIGHT = 78            # Standing body height; default foot tips at [0, 0, -STAND_HEIGHT]
REST_POSITION = [55, 0, -78] # Intermediate resting foot position used by some actions; finish in Stand

# --- Hand wave (keys 1 and 2): front-right hip X joint, Port 11 ---
SERVO_NEUTRAL = 92           # Neutral hand-wave joint angle (degrees)
SERVO_UP = 120               # Upper hand-wave joint angle (degrees)
SERVO_DOWN = 60              # Lower hand-wave joint angle (degrees)
HAND_WAVES = 2               # Number of neutral-up-down-neutral hand-wave cycles

# --- Action-specific repetitions and timing ---
STRETCH_REPEAT = 4           # Number of left/right stretching repetitions (action 3)
PUSH_UP_COUNT = 4            # Push-up repetitions (action 4)
PAW_WAVE_REPEAT = 3          # Alternating front-paw wave repetitions (action 5)
PAW_WAVE_DELAY = 0.001       # Delay between front-paw wave steps (seconds)
SWIM_REPEAT = 3              # Front/back swimming stroke repetitions (action 6)
PLANCHE_HOLD_SEC = 2         # Duration of the planche pose (seconds)
HAND_STAND_HOLD_SEC = 3      # Duration of the handstand pose (seconds)

# --- Action 6: Swimming motion (v3.4.0 behavior) ---
SWIM_Z = -50                 # Front-foot height during the swimming action
SWIM_RADIUS = 80             # Front-foot arc radius in the swimming action
SWIM_ANGLE_DEG = 40          # Front-foot sweep angle during swimming (degrees)
SWIM_HIND = [-85, 10, -95]   # Initial rear-foot position in the swimming action
SWIM_KICK = [-65, 10, -92]   # Rear-foot kicking position in the swimming action
SWIM_KICKS = 2               # Number of rear-foot kicks per front-foot stroke
SWIM_STROKE_SEC = 0.8        # Time to move a front leg in one direction (seconds)
SWIM_STROKES = None          # Optional stroke count; None uses SWIM_REPEAT for compatibility
STEP_LIFT = 15              # Foot lift during return from swimming (action 6)
STEP_SEC = 0.5              # Return time per leg after swimming (seconds)

# --- Action 9: Tap dance (v3.4.0 behavior) ---
TAP_LIFT = 15               # Tap-dance foot lifting height
TAP_BEATS = 8               # Number of beats in each phase of the two-tempo tap dance
TAP_BEAT_SEC = 0.3          # Duration of one basic tap-dance beat (seconds)

# --- Action robot Text Screen timing ---
WELCOME_SEC = 1.0           # Duration of the startup model name / WELCOME screen (seconds)
DONE_SEC = 1.5              # Time to display completion before returning to the main screen

# --- Key handling ---
LOOP_SLEEP_SEC = 0.1         # Delay between main-loop input polls (seconds)
QUEUE_KEYS = True            # Queue keys pressed during an action when True; discard them when False

# --- CONSOLE LOG ---
LOG_COLOR = True             # Enable colored console logs; set False if <color=...> tags appear literally


# ========================================
# 2. KEYS (key bindings)
# ========================================
ACTION_KEYS = {              # Each key runs its action once
    "1": "hello",            # Standing wave
    "2": "sit_and_wave",     # Sit and wave
    "3": "leg_stretch",      # Leg stretch
    "4": "push_ups",         # Push-ups
    "5": "front_paw_wave",   # Alternate front-paw waves
    "6": "swim",             # Swimming motion
    "7": "planche_push_ups", # Planche push-ups
    "8": "handstand",        # Handstand
    "9": "tap_dance",       # Tap dance (v3.4.0)
    "0": "stand",            # Default standing pose
}


# ========================================
# 3. RUN (initialize once, then repeat)
# ========================================
def main():
    from scriptruntime import Runtime
    Runtime.require_force_close(False)  # Space: game-default immediate stop; no separate waiting process
    app = ActionApp(globals())   # Setup: pass the values and keys above to the robot, then stand
    app.run()                    # Loop: read key input and execute the selected action


if __name__ == "__main__":
    main()

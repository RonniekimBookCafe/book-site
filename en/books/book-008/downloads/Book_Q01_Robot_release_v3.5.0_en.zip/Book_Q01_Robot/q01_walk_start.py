# -*- coding: utf-8 -*-
"""q01_walk_start.

QUAD-01 starter script. Walk: keyboard locomotion and preset automatic movement scenarios. Attach to the matching RoboCo microcontroller; adjust CONTROL PARAMETERS and KEYS in this file. The Q01_Lib package implements the underlying movements.
Setup: README.md. What to observe, change, and compare in each exercise: the book."""

# --- SETUP CODE: Do not edit this section -----------------------------------
# Reload Q01_Lib on every run so edits to the library are picked up.
# This clears the previously cached module references;
# no source files are deleted from disk.
import sys as _sys

_sys.dont_write_bytecode = True  # Do not create __pycache__ files on each run

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.walk.q01lib_app import RobotApp


# ========================================
# 1. CONTROL PARAMETERS (change these values first)
# ========================================
# --- Servo and body posture ---
SERVO_RPM = 30               # Maximum joint-servo speed (ServoMotor.max_rpm)
BODY_HEIGHT = 99             # Default standing body height; foot-tip z = -BODY_HEIGHT
                             # (same length units as the 23/55/65 leg links). Auto mode 2 also uses this as its "standard height".
# Body-centered Spot coordinates: x forward (+), y left (+), z up (+)
#                                       roll = x rotation; pitch = y rotation; yaw = z rotation

# --- Gait phase increment (degrees/iteration): larger values walk faster ---
# Excessive phase increments can cause slipping; change one parameter at a time.
# Use phase increments that divide 360 evenly: 2.5, 3.0, 3.6, 3.75, 4.0, 4.5, 5.0.
FORWARD_GAIT_SPEED = 3.6     # Gait-phase increment per iteration for forward motion (degrees)
BACKWARD_GAIT_SPEED = 4.5    # Gait-phase increment per iteration for backward motion (degrees)
TURN_GAIT_SPEED = 3.75       # Gait-phase increment per iteration for yaw turns (degrees)
SIDE_GAIT_SPEED = 4.0        # Gait-phase increment per iteration for side steps (degrees)
GAIT_SPEED = 2.5             # Fallback gait-phase increment for automatic sequences without an override

# --- Stride (primary travel-axis amplitude, vertical foot lift) ---
#     Used when you drive with the walking keys. Auto modes use their own per-move values;
#     only moves without one (auto 1: back/turn/side; auto 3: back/360° turn) use these.
FORWARD_STRIDE = (20, 10)    # Forward stride (x amplitude, foot-lift z amplitude)
BACKWARD_STRIDE = (12, 6)    # Backward stride (x amplitude, foot-lift z amplitude)
TURN_STRIDE = (6, 8)         # Turn stride (horizontal amplitude, vertical foot lift)
SIDE_STRIDE = (15, 5)        # Lateral stride (y amplitude, vertical foot lift)

# --- CONSOLE LOG ---
LOG_COLOR = True             # Enable colored console logs; set False if <color=...> tags appear literally
WELCOME_SEC = 1.0           # Duration of the startup model name / WELCOME screen (seconds)


# ========================================
# 2. KEYS (key bindings)
# The console startup key reference is generated from these bindings.
# ========================================
WALK_KEYS = {                # Repeat while held; return to standing when released
    "w": "forward",          # Move forward (x +)
    "s": "backward",         # Move backward (x -)
    "a": "turn_left",        # Turn left in place, counterclockwise (yaw +)
    "d": "turn_right",       # Turn right in place, clockwise (yaw -)
    "q": "step_left",        # Step left (y +)
    "e": "step_right",       # Step right (y -)
}
POSE_KEYS = {                # Trigger once on keypress
    "x": "stop",             # Stop in a stable standing pose
    "z": "relax",            # Relaxed pose
}
AUTO_KEYS = {                # Start an automatic mode on keypress
    "1": 1,                  # Auto mode 1: basic locomotion pattern
    "2": 2,                  # Auto mode 2: stability test at different body heights
    "3": 3,                  # Auto mode 3: combined motion pattern
}
QUIT_KEY = "0"               # Relax the pose, then exit
ACTION_COOLDOWN_SEC = 0.5    # Cooldown between repeated pose/automatic-mode keypresses (seconds)


# ========================================
# 3. RUN (initialize once; quit with the exit key)
# ========================================
def main():
    app = RobotApp(globals())    # Setup: pass the values and keys above to the robot, then stand
    app.run()                    # Loop: read input, move, update the screen/console; press 0 to exit


if __name__ == "__main__":
    main()

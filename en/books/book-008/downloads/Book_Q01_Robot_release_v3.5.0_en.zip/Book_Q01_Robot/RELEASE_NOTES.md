# QUAD-01 | Release Notes

## v3.5.0-en (2026-11-08, final reader package)

**Package**

- Removed the `guides/` folder and `PORT_AND_AXES.md`. Exercise order, key usage, what to watch, and the port and axis tables are in the book and its appendices.
- Rewrote `README.md` around installation, the first run, the exercise list (model, start script, book chapter), the console log, and installation troubleshooting.
- Unified the book page address: `https://ronniekimbooks.com/en/books/book-008/`.
- No cover image is included in the English package.

**Code (no change to program logic)**

- Rewrote the comments in the eight start scripts from the Korean originals.
- Removed auto-generated filler sentences from library comments and docstrings.
- Restored the IMU notes in `core/q01lib_imu.py` (why `euler_angles()` is not used, frames, zeroing) and the filter notes in `balance_test/q01lib_imu_filter.py`.
- Corrected the servo-spec comment: knees 1720, hip HX/HY 13150 (`q01lib_ports.py`).

All 55 Python files have the same program structure as the Korean v3.5.0 package, ignoring string contents.

## Earlier

- v3.4.9: exercise code baseline

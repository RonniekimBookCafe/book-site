# -*- coding: utf-8 -*-
"""q01_leg3_combined_start.

QUAD-01 starter script. Leg Test 3: combined IK/FK validation and multi-leg motion sequences. Attach to the matching RoboCo microcontroller; adjust CONTROL PARAMETERS and KEYS in this file. The Q01_Lib package implements the underlying movements.
Setup: README.md. What to observe, change, and compare in each exercise: the book."""

# --- SETUP CODE: Do not edit this section -----------------------------------
# Reload Q01_Lib on every run so edits to the library are picked up.
# This clears the previously cached module references;
# no source files are deleted from disk.
import sys as _sys

_sys.dont_write_bytecode = True  # Do not create __pycache__ files on each run

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.leg_common.q01lib_leg_app import LegTestApp
from Book_Q01_Robot.Q01_Lib.leg3_combined.q01lib_leg3_combined import CombinedTest


# ========================================
# 1. CONTROL PARAMETERS (change these values first)
# ========================================
SERVO_RPM = 30               # Maximum joint-servo speed (ServoMotor.max_rpm)
                             # Servo specs (max torque: knees 1720, hips HX/HY 13150; acceleration 0.2 s): Q01_Lib/core/q01lib_ports.py, section 7
BODY_HEIGHT = 99             # Default standing body height; foot-tip z = -BODY_HEIGHT

# --- Movement interpolation ---
MOVE_ALL_STEPS = 30          # Interpolation steps when moving all four legs together
MOVE_SINGLE_STEPS = 20       # Interpolation steps when moving one leg
MOVE_SINGLE_DELAY = 0.01     # Pause between individual-leg interpolation steps (seconds)

# --- Wait times between test stages (seconds) ---
CASE_HOLD_SEC = 3            # Hold time after each target position in tests 1 and 2 (seconds)
VALIDITY_HOLD_SEC = 2        # Hold time after each workspace check in test 3 (seconds)
STEP_HOLD_SEC = 2            # Hold time after each position in tests 4–7 (seconds)
LEG_GAP_SEC = 2              # Pause between consecutive legs in test 4 (seconds)
THREE_LEG_HOLD_SEC = 3       # Hold time for each lifted-leg position in test 8 (seconds)

# --- Test 9: Walking sequence ---
WALK_CYCLES = 2              # Number of walking-sequence repetitions
WALK_LIFT_Z = -70            # Lifted-foot z coordinate (29 units above the -99 default)
WALK_STEP_X = 30             # Forward x displacement during a walking sequence
WALK_HOLD_SEC = 1.0          # Pause between walking-sequence steps (seconds)

LOOP_SLEEP_SEC = 0.1         # Delay between main-loop input polls (seconds)

# --- CONSOLE LOG ---
LOG_COLOR = True             # Enable colored console logs; set False if <color=...> tags appear literally
WELCOME_SEC = 1.0           # Duration of the startup model name / WELCOME screen (seconds)
START_SCREEN_SEC = 1.0      # Duration of the introductory status screen (seconds)


# ========================================
# 2. KEYS (left-hand, right-hand, then custom keys)
# ========================================
# Left/right-hand controls are unused

# Custom keys: automatic tests and common controls
TEST_KEYS = {
    "1": "fl_basic",          # FL: basic foot-tip movement
    "2": "fl_extreme",        # FL: near-limit positions
    "3": "fl_validity",       # FL: reachable workspace validation
    "4": "all_legs",          # All legs: run tests 1, 2, and 3
    "5": "joint_limits",      # Joint-angle limits
    "6": "lift_each",         # Lift each leg individually
    "7": "diagonal",          # Diagonal leg pairs
    "8": "three_legs",        # Three-point support pose (lift one leg at a time)
    "9": "walk_sequence",     # Walking sequence
}

HELP_KEY = "f1"              # Show keyboard help in the console and robot display
STAND_KEY = "f2"             # All four legs to stand pose (stops a running auto test first)
STOP_KEY = "f3"              # Stop the auto test (legs stay where they are)


# ========================================
# 3. RUN (initialize once; stop when the script stops)
# ========================================
def main():
    app = LegTestApp(globals(), CombinedTest)  # Startup: move to standing and print the key reference
    app.run()                                  # Loop: read keys -> run the numbered test


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""q01lib_gait: Educational library module for the QUAD-01 RoboCo series.

Gait timing, stride amplitudes, and foot trajectories."""

import math


def swing_pair(angle, amp_main, amp_lift, height):
    """Swing pair.

Parameters: angle, amp_main, amp_lift, height."""
    M1 = amp_main * math.cos(angle * math.pi / 180)
    Z1 = -(amp_lift * math.sin(angle * math.pi / 180) + height)
    M2 = amp_main * math.cos((angle + 180) * math.pi / 180)
    Z2 = -(amp_lift * math.sin((angle + 180) * math.pi / 180) + height)

    Z1 = max(Z1, -height)
    Z2 = max(Z2, -height)
    return M1, Z1, M2, Z2


def diagonal_pair(angle, amp_x, amp_y, height, amp_lift=8):
    """Diagonal pair."""
    X1 = amp_x * math.cos(angle * math.pi / 180)
    Y1 = amp_y * math.cos(angle * math.pi / 180)
    Z1 = -(amp_lift * math.sin(angle * math.pi / 180) + height)
    X2 = amp_x * math.cos((angle + 180) * math.pi / 180)
    Y2 = amp_y * math.cos((angle + 180) * math.pi / 180)
    Z2 = -(amp_lift * math.sin((angle + 180) * math.pi / 180) + height)

    Z1 = max(Z1, -height)
    Z2 = max(Z2, -height)
    return X1, Y1, Z1, X2, Y2, Z2


def zigzag_pair(angle, amp_turn_y, height, turn_factor=0.8):
    """Zigzag pair."""
    forward_x = 15 * math.cos(angle * math.pi / 180)
    forward_z = -(8 * math.sin(angle * math.pi / 180) + height)

    X1 = forward_x + 8 * math.cos(angle * math.pi / 180) * turn_factor
    Y1 = amp_turn_y * math.cos(angle * math.pi / 180) * turn_factor
    Z1 = forward_z
    X2 = 15 * math.cos((angle + 180) * math.pi / 180)
    Y2 = amp_turn_y * math.cos((angle + 180) * math.pi / 180) * turn_factor
    Z2 = -(8 * math.sin((angle + 180) * math.pi / 180) + height)

    Z1 = max(Z1, -height)
    Z2 = max(Z2, -height)
    return X1, Y1, Z1, X2, Y2, Z2


class Phase:
    """Phase."""

    def __init__(self, start, speed, low, high, reverse=False):
        self.angle = start
        self.speed = speed
        self.low = low
        self.high = high
        self.reverse = reverse

    def advance(self):
        if not self.reverse:
            self.angle += self.speed
            if self.angle > self.high:
                self.angle = self.low
        else:
            self.angle -= self.speed
            if self.angle < self.low:
                self.angle = self.high

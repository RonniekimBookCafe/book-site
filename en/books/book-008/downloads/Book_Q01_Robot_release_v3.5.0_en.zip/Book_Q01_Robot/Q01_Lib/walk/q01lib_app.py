# -*- coding: utf-8 -*-
"""q01lib_app: Educational library module for the QUAD-01 RoboCo series.

Application logic that coordinates robot configuration, keys, and screen output."""

import time

from ..core import q01lib_log as L    # Console logging helpers (L.event, L.more, L.key, etc.)
from ..core.q01lib_log import log_traceback
from ..core.q01lib_servo import setup_canonical_servos
from ..core.q01lib_keys import is_down
from ..core.q01lib_key_events import key_label
from .q01lib_robot import QuadRobot
from ..auto.q01lib_auto import AutoModes
from ..core.q01lib_screen import StatusScreen
from ..core.q01lib_welcome import show_welcome, DEFAULT_WELCOME_SEC

DEFAULTS = {
    "SERVO_RPM": 30,                 # Joint servo speed (ServoMotor.max_rpm)
    "BODY_HEIGHT": 99,
    "FORWARD_GAIT_SPEED": 3.6,       # W: forward
    "BACKWARD_GAIT_SPEED": 4.5,      # S: backward
    "TURN_GAIT_SPEED": 3.75,         # A/D: yaw rotation
    "SIDE_GAIT_SPEED": 4.0,          # Q/E: lateral motion
    "GAIT_SPEED": 2.5,
    "FORWARD_STRIDE": (20, 10),
    "BACKWARD_STRIDE": (12, 6),
    "TURN_STRIDE": (6, 8),
    "SIDE_STRIDE": (15, 5),
    # Keys
    "ACTION_COOLDOWN_SEC": 0.5,
    "WALK_KEYS": {"w": "forward", "s": "backward", "a": "turn_left",
                  "d": "turn_right", "q": "step_left", "e": "step_right"},
    "POSE_KEYS": {"x": "stop", "z": "relax"},
    "AUTO_KEYS": {"1": 1, "2": 2, "3": 3},
    "QUIT_KEY": "0",
    "LOG_COLOR": True,
    "WELCOME_SEC": DEFAULT_WELCOME_SEC,
}

LOG_CATEGORIES = ("INPUT", "PARAMETER", "STATE", "ACTION", "TASK", "WARN", "ERROR")

WALK_NAMES = {
    "forward": "forward", "backward": "backward",
    "turn_left": "turn left", "turn_right": "turn right",
    "step_left": "side left", "step_right": "side right",
}
POSE_NAMES = {"stop": "stop pose", "relax": "relax pose"}
AUTO_NAMES = {1: "basic moves", 2: "height test", 3: "complex pattern"}

_ACTION_MESSAGES = {
    "forward": 'Walking forward...',
    "backward": 'Walking backward...',
    "turn_left": 'Turning left...',
    "turn_right": 'Turning right...',
    "step_left": 'Sidestepping left...',
    "step_right": 'Sidestepping right...',
    "stop": 'Stopped — Returning to stand',
    "relax": 'Relaxing all motors',
}
_AUTO_MESSAGES = {
    1: 'Auto Mode 1: Basic Movement Pattern',
    2: 'Auto Mode 2: Height Comparison',
    3: 'Auto Mode 3: Combined Pattern',
}
_START_TEXT = 'QUAD-01 Walking · Moving to stand...'
_IDLE_TEXT = 'Ready... Press a control key'
_AUTO_RUNNING_TEXT = 'Auto Mode Running... Press any key to stop'
_QUIT_TEXT = 'Exiting program...'

_WALK_ACTIONS = ("forward", "backward", "turn_left", "turn_right", "step_left", "step_right")
_POSE_ACTIONS = ("stop", "relax")


def print_instructions(s):
    """Print instructions."""
    lines = (L.key_lines("Walk", [(key_label(k), WALK_NAMES[n]) for k, n in s["WALK_KEYS"].items()])
             + L.key_lines("Pose", [(key_label(k), POSE_NAMES[n]) for k, n in s["POSE_KEYS"].items()])
             + L.key_lines("Auto", [(key_label(k), AUTO_NAMES[m]) for k, m in s["AUTO_KEYS"].items()])
             + L.key_lines("Quit", [(key_label(s["QUIT_KEY"]), "relax and quit")]))
    lines.append(" Hold a walk key to walk; release it to stop.")
    L.banner("QUAD-01 WALK   (Book-QUAD-01-WALK)", lines)


def print_parameters(s):
    """Print parameters."""
    def pair(v):
        return f"{v[0]:g}/{v[1]:g}"
    L.event("PARAMETER", f"height={s['BODY_HEIGHT']:g} mm  servo rpm={s['SERVO_RPM']:g}")
    L.more(f"speed   fwd {s['FORWARD_GAIT_SPEED']:g}  back {s['BACKWARD_GAIT_SPEED']:g}  "
           f"turn {s['TURN_GAIT_SPEED']:g}  side {s['SIDE_GAIT_SPEED']:g}")
    L.more(f"stride  fwd {pair(s['FORWARD_STRIDE'])}  back {pair(s['BACKWARD_STRIDE'])}  "
           f"turn {pair(s['TURN_STRIDE'])}  side {pair(s['SIDE_STRIDE'])}")


class RobotApp:
    """Robot App."""

    def __init__(self, script_values: dict):
        """Init."""
        self.ready = False
        try:
            self._setup(script_values)
            self.ready = True
        except Exception as e:
            L.setup_failed(e, "q01_walk_start.py")

    def _setup(self, script_values: dict):
        s = dict(DEFAULTS)
        for name, value in script_values.items():
            if name in DEFAULTS:
                s[name] = value

        L.configure(LOG_CATEGORIES, s["LOG_COLOR"])
        walk_map = self._checked(s["WALK_KEYS"], _WALK_ACTIONS, "WALK_KEYS")
        pose_map = self._checked(s["POSE_KEYS"], _POSE_ACTIONS, "POSE_KEYS")
        auto_map = self._checked(s["AUTO_KEYS"], tuple(_AUTO_MESSAGES), "AUTO_KEYS")
        print_instructions(s)
        print_parameters(s)

        self.screen = StatusScreen()
        show_welcome(self.screen, "Book-QUAD-01-WALK", s["WELCOME_SEC"])
        self.screen.show(_START_TEXT)

        setup_canonical_servos()  # shared 12DOF contract
        self.robot = QuadRobot(servo_rpm=s["SERVO_RPM"],
                               body_height=s["BODY_HEIGHT"],
                               gait_speed=s["GAIT_SPEED"],
                               forward_gait_speed=s["FORWARD_GAIT_SPEED"],
                               backward_gait_speed=s["BACKWARD_GAIT_SPEED"],
                               turn_gait_speed=s["TURN_GAIT_SPEED"],
                               side_gait_speed=s["SIDE_GAIT_SPEED"],
                               forward_stride=s["FORWARD_STRIDE"],
                               backward_stride=s["BACKWARD_STRIDE"],
                               turn_stride=s["TURN_STRIDE"],
                               side_stride=s["SIDE_STRIDE"])
        self.auto = AutoModes(self.robot)
        L.event("STATE", f"default pose  height={s['BODY_HEIGHT']:g} mm")

        self.walk_keys = [(key, getattr(self.robot, name), _ACTION_MESSAGES[name], WALK_NAMES[name])
                          for key, name in walk_map]
        self.pose_keys = [(key, getattr(self.robot, name), _ACTION_MESSAGES[name], POSE_NAMES[name])
                          for key, name in pose_map]
        self.auto_keys = [(key, mode, _AUTO_MESSAGES[mode], f"auto {mode}  {AUTO_NAMES[mode]}")
                          for key, mode in auto_map]
        self.quit_key = s["QUIT_KEY"]
        self.action_cooldown = s["ACTION_COOLDOWN_SEC"]

        self.current_key = None
        self.last_action_time = 0
        self._quit = False


    @staticmethod
    def _checked(mapping: dict, allowed: tuple, label: str) -> list:
        """Checked."""
        for key, name in mapping.items():
            if name not in allowed:
                raise ValueError(f"{label} '{key}': unknown action '{name}'. "
                                 f"Use one of: {', '.join(map(str, allowed))}")
        return list(mapping.items())

    def running(self) -> bool:
        """Running."""
        return not self._quit

    def update(self):
        """Update."""
        action_occurred = False

        for key, action, message, name in self.walk_keys:
            if is_down(key):
                self._stop_auto_mode_if_active()
                self.screen.show(message)
                L.event("INPUT", f"{L.key(key_label(key), 4)} {name}")
                start = time.time()
                action(hold_key=key)
                L.event("ACTION", f"{name}  {time.time() - start:.1f} s -> default pose")
                self.current_key = key
                action_occurred = True
                break

        if not action_occurred:
            for key, action, message, name in self.pose_keys:
                current_time = time.time()
                if is_down(key) and current_time - self.last_action_time > self.action_cooldown:
                    self._stop_auto_mode_if_active()
                    self.screen.show(message)
                    L.event("INPUT", f"{L.key(key_label(key), 4)} {name}")
                    action()
                    self.last_action_time = current_time
                    action_occurred = True
                    break

        if not action_occurred:
            for key, mode, message, name in self.auto_keys:
                current_time = time.time()
                if is_down(key) and current_time - self.last_action_time > self.action_cooldown:
                    self.screen.show(message)
                    L.event("INPUT", f"{L.key(key_label(key), 4)} {name}")
                    self.auto.start(mode)
                    self.last_action_time = current_time
                    action_occurred = True
                    break

        if is_down(self.quit_key):
            self.screen.show(_QUIT_TEXT)
            L.event("INPUT", f"{L.key(key_label(self.quit_key), 4)} quit")
            self.safe_shutdown()
            self._quit = True
            return

        if not action_occurred:
            if self.current_key and not is_down(self.current_key):
                self.current_key = None
            self._update_idle_status()

    def run(self):
        """Run."""
        if not self.ready:
            return
        L.event("STATE", "ready")
        try:
            while self.running():
                self.update()

        except KeyboardInterrupt:
            pass  # RoboCo Space: extra shutdown flow disabled

        except Exception as e:
            L.event("ERROR", f"unexpected error: {e}")
            log_traceback()
            self._shutdown_after_error()

        finally:
            L.event("STATE", "end")

    def _stop_auto_mode_if_active(self):
        """Stop auto mode if active."""
        if self.robot.auto_mode_active:
            self.auto.stop()
            return True
        return False

    def _update_idle_status(self):
        """Update idle status."""
        if not self.robot.auto_mode_active:
            self.screen.show(_IDLE_TEXT)
        else:
            self.screen.show(_AUTO_RUNNING_TEXT)

    def _shutdown_after_error(self):
        """Shutdown after error."""
        try:
            self.safe_shutdown()
        except Exception as e:
            L.event("ERROR", f"shutdown failed: {e}")
            log_traceback()

    def safe_shutdown(self):
        """Safe shutdown."""
        L.event("STATE", "shutting down")
        if self.robot.auto_mode_active:
            self.auto.stop()
        self.robot.relax()

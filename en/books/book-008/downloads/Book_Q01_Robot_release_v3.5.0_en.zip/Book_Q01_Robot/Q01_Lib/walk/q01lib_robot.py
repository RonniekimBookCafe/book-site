# -*- coding: utf-8 -*-
"""q01lib_robot: Educational library module for the QUAD-01 RoboCo series.

Quadruped robot state, initialization, and actuator connections."""

import time

from ..core import q01lib_ports as ports
from ..core.q01lib_keys import is_down
from ..core.q01lib_motion import LegMotion
from .q01lib_gait import swing_pair, Phase
from ..core import q01lib_log as L    # Console logging helpers (L.event, L.more, L.key, etc.)

RELAX_POSITION = [55, 0, -78]

DEFAULT_POSITION_STEPS = 30     # Restore the default standing pose
STOP_STEPS = 50
RELAX_STEPS = 50                # Relaxed pose

HEIGHT_UPDATE_HZ = 20


class QuadRobot:
    """Quad Robot."""

    def __init__(self,
                 servo_rpm=30,
                 body_height=99,
                 gait_speed=2.5,
                 forward_gait_speed=3.6,
                 backward_gait_speed=4.5,
                 turn_gait_speed=3.75,
                 side_gait_speed=4.0,
                 forward_stride=(20, 10),
                 backward_stride=(12, 6),
                 turn_stride=(6, 8),
                 side_stride=(15, 5)):
        """Init."""
        self.motion = LegMotion(body_height=body_height, servo_rpm=servo_rpm)

        self.rpm = servo_rpm
        self.base_height = body_height
        self.height = body_height

        self.gait_speed = gait_speed
        self.forward_gait_speed = forward_gait_speed
        self.backward_gait_speed = backward_gait_speed # S: backward
        self.turn_gait_speed = turn_gait_speed
        self.side_gait_speed = side_gait_speed         # Q/E: lateral motion

        self.forward_stride = forward_stride
        self.backward_stride = backward_stride
        self.turn_stride = turn_stride
        self.side_stride = side_stride

        self.leg_names = ports.LEG_NAMES  # ["FL", "HL", "HR", "FR"]

        self.auto_mode_active = False

        # Return to the default standing pose at startup
        self.default_position()

    def default_positions(self):
        """Default positions."""
        h = self.base_height
        y = ports.FOOT_Y_OFFSET
        return [
            [0, y, -h],    # Front-left leg (FL)
            [0, y, -h],    # Hind-left leg (HL)
            [0, -y, -h],   # Hind-right leg (HR)
            [0, -y, -h],   # Front-right leg (FR)
        ]

    def default_position(self):
        """Default position."""
        self.motion.move_to(self.default_positions(), DEFAULT_POSITION_STEPS, self.rpm)

    def stop(self):
        """Stop."""
        h = self.height
        y = ports.FOOT_Y_OFFSET
        target_positions = [
            [10, y, -h],    # Front-left leg (FL)
            [10, y, -h],    # Hind-left leg (HL)
            [10, -y, -h],   # Hind-right leg (HR)
            [10, -y, -h],   # Front-right leg (FR)
        ]
        self.motion.move_to(target_positions, STOP_STEPS)
        L.event("STATE", f"stop pose  feet x=+10  height={h:g} mm")

    def relax(self):
        """Relax."""
        relax_positions = [list(RELAX_POSITION) for _ in range(4)]
        self.motion.move_to(relax_positions, RELAX_STEPS)
        L.event("STATE", "relax pose")

    def smooth_height_transition(self, target_height, duration):
        """Smooth height transition."""
        start_height = self.height
        start_time = time.time()
        steps = int(duration * HEIGHT_UPDATE_HZ)

        for step in range(steps + 1):
            if not self.auto_mode_active:
                return

            elapsed_time = time.time() - start_time
            if elapsed_time >= duration:
                break

            progress = step / steps
            current_height = start_height + (target_height - start_height) * progress

            self.height = current_height
            for i in range(4):
                self.motion.points[i][2] = -current_height

            self.motion.run()
            time.sleep(0.05)

        self.height = target_height
        for i in range(4):
            self.motion.points[i][2] = -target_height
        self.motion.run()

    def _speed(self, speed, auto_mode, manual_speed):
        """Speed."""
        if speed is not None:
            return speed
        return self.gait_speed if auto_mode else manual_speed

    def _walk(self, hold_key, duration, auto_mode, phase, step_fn):
        """Walk.

Parameters: hold_key, duration, auto_mode, phase, step_fn."""
        start_time = time.time() if duration else None

        while True:
            if auto_mode and duration:
                if time.time() - start_time >= duration:
                    break
                if not self.auto_mode_active:
                    break
            elif not auto_mode:
                if not is_down(hold_key):
                    break

            step_fn(phase.angle)
            phase.advance()

        if not auto_mode:
            self.default_position()

    def forward(self, duration=None, auto_mode=False, speed=None,
                stride_x=None, lift_z=None, hold_key="w"):
        """Forward."""
        speed = self._speed(speed, auto_mode, self.forward_gait_speed)
        sx = self.forward_stride[0] if stride_x is None else stride_x
        lz = self.forward_stride[1] if lift_z is None else lift_z

        def step(angle):
            X1, Z1, X2, Z2 = swing_pair(angle, sx, lz, self.height)
            self.motion.change_coordinates("forward", X1, 0, Z1, X2, 0, Z2)

        self._walk(hold_key, duration, auto_mode, Phase(90, speed, 90, 450), step)

    def backward(self, duration=None, auto_mode=False, speed=None,
                 stride_x=None, lift_z=None, hold_key="s"):
        """Backward."""
        speed = self._speed(speed, auto_mode, self.backward_gait_speed)
        sx = self.backward_stride[0] if stride_x is None else stride_x
        lz = self.backward_stride[1] if lift_z is None else lift_z

        def step(angle):
            X1, Z1, X2, Z2 = swing_pair(angle, sx, lz, self.height)
            self.motion.change_coordinates("backward", X1, 0, Z1, X2, 0, Z2)

        self._walk(hold_key, duration, auto_mode, Phase(450, speed, 90, 450, reverse=True), step)

    def _turn(self, move_order, start_angle, duration, auto_mode, speed, hold_key):
        """Turn."""
        speed = self._speed(speed, auto_mode, self.turn_gait_speed)
        sxy, lz = self.turn_stride

        def step(angle):
            X1, Z1, X2, Z2 = swing_pair(angle, sxy, lz, self.height)
            self.motion.change_coordinates(move_order, X1, X1, Z1, X2, X2, Z2)

        self._walk(hold_key, duration, auto_mode, Phase(start_angle, speed, 0, 360), step)

    def turn_left(self, duration=None, auto_mode=False, speed=None, hold_key="a"):
        """Turn left."""
        self._turn("turn_left", 0, duration, auto_mode, speed, hold_key)

    def turn_right(self, duration=None, auto_mode=False, speed=None, hold_key="d"):
        """Turn right."""
        self._turn("turn_right", 180, duration, auto_mode, speed, hold_key)

    def step_left(self, duration=None, auto_mode=False, speed=None, hold_key="q"):
        """Step left."""
        speed = self._speed(speed, auto_mode, self.side_gait_speed)
        sy, lz = self.side_stride

        def step(angle):
            Y1, Z1, Y2, Z2 = swing_pair(angle, sy, lz, self.height)
            self.motion.change_coordinates("step_left", 0, Y1, Z1, 0, Y2, Z2)

        self._walk(hold_key, duration, auto_mode, Phase(90, speed, 90, 450), step)

    def step_right(self, duration=None, auto_mode=False, speed=None, hold_key="e"):
        """Step right."""
        speed = self._speed(speed, auto_mode, self.side_gait_speed)
        sy, lz = self.side_stride

        def step(angle):
            Y1, Z1, Y2, Z2 = swing_pair(angle, sy, lz, self.height)
            self.motion.change_coordinates("step_right", 0, Y1, Z1, 0, Y2, Z2)

        self._walk(hold_key, duration, auto_mode, Phase(450, speed, 90, 450, reverse=True), step)

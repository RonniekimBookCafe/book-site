# -*- coding: utf-8 -*-
"""q01lib_body_pose_screen: Educational library module for the QUAD-01 RoboCo series.

Body posture control: x/y/z displacement and roll/pitch/yaw orientation."""

import math
import time

from controllables import TextScreen

from ..core import q01lib_ports as ports
from ..core.q01lib_screen import DEFAULT_TEXT_COLOR, ensure_readable_text

# ------------------------------------------------------------
# Display settings
# ------------------------------------------------------------
SCALE = 20
GRID_ROWS = 17
GRID_COLS = 41
BAR_LENGTH = 9
BAR_CHAR = "-"
GRID_X_AXIS = "yaw"
TITLE = "Attitude Angle"
SCREEN_LINES = GRID_ROWS + 8

AUTO_SIZE_MAX = 200
REFRESH_SEC = 1.0

SCREEN_COLOR = True
COLORS = {
    "value": "yellow",
    "zero": "red",
    "state": "#FF8A34",
    "alert": "red",
    "key": "#FFFFFF",
    "text": "#B0B7C3",
    "imu": "#20D6D9",
}


def tag(text, color_name):
    """Tag."""
    if not SCREEN_COLOR:
        return text
    return f"<color={COLORS.get(color_name, color_name)}>{text}</color>"


def keys_text(items, sep=" · "):
    """Keys text."""
    return sep.join(f"{tag(k, 'key')} {tag(d, 'text')}" for k, d in items)


def cell(value, count):
    """Cell."""
    half = (count - 1) // 2
    t = value / SCALE * half
    steps = int(math.floor(abs(t) + 0.5))
    return min(count - 1, max(0, half + (steps if t >= 0 else -steps)))


def value_to_col(value, width=GRID_COLS):
    """Value to col."""
    return cell(value, width)


def value_to_row(value, height=GRID_ROWS):
    """Value to row."""
    return height - 1 - cell(value, height)


def number(value):
    """Number."""
    return f"{value:g}" if float(value).is_integer() else f"{value:.1f}"


def slider(value, label, label_width):
    """Slider."""
    bar = [BAR_CHAR] * BAR_LENGTH
    bar[cell(value, BAR_LENGTH)] = tag("●", "value")
    return f"{tag(f'{label:<{label_width}}', 'value')}{number(value):>4} {''.join(bar)}"


SLIDER_ROWS = (
    (("roll", "Roll"), ("x", "Horizon")),
    (("pitch", "Pitch"), ("y", "Side")),
    (("yaw", "Yaw"), ("z", "Height")),
)
SLIDER_GAP = " "


def slider_lines(pose):
    """Slider lines."""
    left_w = max(len(row[0][1]) for row in SLIDER_ROWS)
    right_w = max(len(row[1][1]) for row in SLIDER_ROWS)
    return [slider(pose[lk], ll, left_w) + SLIDER_GAP + slider(pose[rk], rl, right_w)
            for (lk, ll), (rk, rl) in SLIDER_ROWS]


def grid(pitch, x_value):
    """Grid."""
    w, h = GRID_COLS, GRID_ROWS
    mid_c, mid_r = w // 2, h // 2
    row_p = value_to_row(pitch, h)
    col_x = value_to_col(x_value, w)
    g = [[" " for _ in range(w)] for _ in range(h)]

    for c in range(w):
        g[0][c] = g[h - 1][c] = "-"
    for r in range(h):
        g[r][0] = g[r][w - 1] = "|"
    g[0][0] = g[0][w - 1] = g[h - 1][0] = g[h - 1][w - 1] = "+"

    for c in range(1, w - 1):
        g[row_p][c] = "-"
    for r in range(1, h - 1):
        g[r][col_x] = "|"
    g[row_p][col_x] = "+"

    if pitch == 0:
        for c in range(1, w - 1):
            if g[mid_r][c] == " ":
                g[mid_r][c] = "-"
    if x_value == 0:
        for r in range(1, h - 1):
            if g[r][mid_c] == " ":
                g[r][mid_c] = "|"
    if pitch == 0 or x_value == 0:
        g[mid_r][mid_c] = tag("+", "zero")

    for v in (-SCALE, 0, SCALE):
        r = value_to_row(v, h)
        for i, ch in enumerate(f"{v:<3}"):
            g[r][1 + i] = ch
        c = value_to_col(v, w)
        for i, ch in enumerate(f"{v:<4}"):
            if c + i < w - 1:
                g[h - 1][c + i] = ch

    coord = f"({number(x_value)}, {number(pitch)})"
    if 0 < row_p < h - 1:
        start = min(col_x + 2, w - 1 - len(coord))
        for i, ch in enumerate(coord):
            g[row_p][start + i] = ch

    return "\n".join("".join(row) for row in g)


def box_top():
    """Box top."""
    inner = GRID_COLS - 2
    left = (inner - len(TITLE) - 2) // 2
    right = inner - len(TITLE) - 2 - left
    return "+" + "-" * left + f" {TITLE} " + "-" * right + "+"


def header(state, info=""):
    """Header."""
    return "\n".join([box_top(), f"  {tag(state, 'state')}", f"  {info}"])


def imu_line(imu):
    """Imu line."""
    if isinstance(imu, str):
        return "  " + tag(imu, "text")
    roll, pitch, yaw = (int(round(v)) + 0 for v in imu)
    return "  " + tag(f"IMU roll {roll} pitch {pitch} yaw {yaw}", "imu")


def _pad(lines):
    """Pad."""
    return lines + [""] * max(0, SCREEN_LINES - len(lines))


def attitude_text(pose, state, info="", imu=None):
    """Attitude text."""
    lines = [header(state, info), grid(pose["pitch"], pose[GRID_X_AXIS]), ""] + slider_lines(pose)
    if imu is not None:
        lines.append(imu_line(imu))
    return "\n".join(_pad("\n".join(lines).split("\n")))


def help_text(state, info, lines):
    """Help text."""
    body = [header(state, info), "+" + "-" * (GRID_COLS - 2) + "+"] + list(lines)
    return "\n".join(_pad("\n".join(body).split("\n")))


# ------------------------------------------------------------
# Robot Text Screen Reference
# ------------------------------------------------------------
class BodyPoseScreen:
    """Body Pose Screen."""

    def __init__(self):
        self.screen = TextScreen(ports.PORT_TEXT_SCREEN)
        self.screen.color = DEFAULT_TEXT_COLOR  # Background is black; labels use their own rich-text colors.
        self.screen.wrapping = False
        self.screen.auto_size = True
        self.screen.auto_size_max = AUTO_SIZE_MAX
        self.screen.horizontal_alignment = TextScreen.HorizontalAlignment.LEFT
        self.screen.vertical_alignment = TextScreen.VerticalAlignment.MIDDLE
        self.text = ""
        self.sent_at = 0.0

    def show(self, text):
        """Show."""
        self.screen.text = ensure_readable_text(text)
        self.text = text
        self.sent_at = time.time()

    def due(self):
        """Due."""
        return time.time() - self.sent_at >= REFRESH_SEC

# -*- coding: utf-8 -*-
"""__init__: Educational library package for the QUAD-01 RoboCo series.

Body posture control: x/y/z displacement and roll/pitch/yaw orientation."""

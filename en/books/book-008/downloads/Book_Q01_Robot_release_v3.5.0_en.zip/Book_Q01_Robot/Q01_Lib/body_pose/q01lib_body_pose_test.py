# -*- coding: utf-8 -*-
"""q01lib_body_pose_test: Educational library module for the QUAD-01 RoboCo series.

Body posture control: x/y/z displacement and roll/pitch/yaw orientation."""

import time

from ..core import q01lib_ports as ports
from ..core.q01lib_key_events import key_label
from ..leg_common.q01lib_leg_check import check_point
from ..core import q01lib_log as L    # Console logging helpers (L.event, L.more, L.key, etc.)
from ..core.q01lib_imu import BodyIMU, STILL_TIMEOUT_SEC
from .q01lib_body_pose import POSE_AXES, body_pose_feet, zero_pose
from .q01lib_body_pose_screen import BodyPoseScreen, attitude_text, help_text, keys_text, tag

HELP_WORDS = {
    "x": ('Forward', 'Backward'),
    "y": ('Left', 'Right'),
    "z": ('Up', 'Down'),
    "roll": ('Right down', 'Left down'),
    "pitch": ('Nose down', 'Nose up'),
    "yaw": ('Turn left', 'Turn right'),
}
AXIS_WORDS_EN = {
    "x": ("fwd", "back"),
    "y": ("left", "right"),
    "z": ("up", "down"),
    "roll": ("right down", "left down"),
    "pitch": ("nose down", "nose up"),
    "yaw": ("turn left", "turn right"),
}
UNIT_EN = {"x": "", "y": "", "z": "", "roll": " deg", "pitch": " deg", "yaw": " deg"}
MOVE_AXES = ("x", "y", "z")
TURN_AXES = ("roll", "pitch", "yaw")

IMU_SETTLE_SEC = 0.5
IMU_LOG_DELAY_SEC = 1.0
ZERO_SPREAD_WARN_DEG = 1.0


class BodyPoseTest:
    """Body Pose Test."""

    TITLE = 'Body Pose Test'
    SHORT = 'Body Pose'
    HEADER = "QUAD-01 BODY POSE  x y z roll pitch yaw   (Book-QUAD-01-ROLL_PITCH_YAW)"
    LOG_CATEGORIES = ("ACTION", "SENSOR")
    START_FILE = "q01_body_pose_start.py"
    USES_LEG_SELECT = False
    VALUE_NAMES = ("KEY_REPEAT_SEC", "BODY_LENGTH", "BODY_WIDTH",
                   "MOVE_STEP", "ANGLE_STEP_DEG", "POSE_MOVE_STEPS",
                   "X_RANGE", "Y_RANGE", "Z_RANGE", "ROLL_RANGE", "PITCH_RANGE", "YAW_RANGE",
                   "AUTO_MOVE", "AUTO_ANGLE_DEG", "AUTO_STEP_SEC",
                   "POSE_KEYS", "AUTO_TEST_KEY", "USE_IMU", "LOG_DETAIL")

    def __init__(self, robot, settings):
        self.robot = robot
        self.motion = robot.motion
        self.s = settings
        self.screen = BodyPoseScreen()
        self.pose = zero_pose()
        self.note = None
        self.help_shown = False
        self.imu = None
        self.imu_note = None
        self.imu_log_at = None
        self.imu_error = None
        if settings["USE_IMU"]:
            try:
                self.imu = BodyIMU(ports.PORT_INERTIAL_SENSOR)
            except Exception as e:
                self.imu_error = e
                self.imu_note = f"No IMU (Port {ports.PORT_INERTIAL_SENSOR})"
        self.ranges = {"x": settings["X_RANGE"], "y": settings["Y_RANGE"], "z": settings["Z_RANGE"],
                       "roll": settings["ROLL_RANGE"], "pitch": settings["PITCH_RANGE"],
                       "yaw": settings["YAW_RANGE"]}
        for key, (axis, sign) in settings["POSE_KEYS"].items():
            if axis not in POSE_AXES or sign not in (1, -1):
                raise ValueError(f"POSE_KEYS '{key}': axis must be one of {', '.join(POSE_AXES)}, direction 1 or -1")

    def actions(self):
        """Actions."""
        items = []
        for key, (axis, sign) in self.s["POSE_KEYS"].items():
            items.append((key, f"body {axis} {'+' if sign > 0 else '-'} ({self._direction_en(axis, sign)})",
                          lambda axis=axis, sign=sign: self.step(axis, sign), False))
        items.append((self.s["AUTO_TEST_KEY"], "auto test", self.auto_test, True))
        return items

    def repeat_keys(self):
        """Repeat keys."""
        return list(self.s["POSE_KEYS"])

    @staticmethod
    def _direction_en(axis, sign):
        return AXIS_WORDS_EN[axis][0 if sign > 0 else 1]

    def _axis_keys(self):
        """Axis keys."""
        keys = {}
        for key, (axis, sign) in self.s["POSE_KEYS"].items():
            keys.setdefault(axis, []).append((key_label(key), sign))
        return keys

    def guide(self):
        """Guide."""
        s = self.s
        keys = self._axis_keys()

        def item(axis):
            names = "/".join(k for k, _ in keys[axis])
            words = "/".join(AXIS_WORDS_EN[axis][0 if d > 0 else 1] for _, d in keys[axis])
            return f"{L.key(names)} {axis} {words}"

        def ranges(axes):
            return "  ".join(f"{a} {self.ranges[a][0]}..{self.ranges[a][1]}" for a in axes)
        move = [a for a in keys if a in MOVE_AXES]
        turn = [a for a in keys if a in TURN_AXES]
        return [f" Move   {'   '.join(item(a) for a in move)}",
                f"        {s['MOVE_STEP']} per key   {ranges(MOVE_AXES)}",
                f" Tilt   {item(turn[0])}   {item(turn[1])}" if len(turn) > 1 else f" Tilt   {item(turn[0])}",
                *([f"        {'   '.join(item(a) for a in turn[2:])}"] if len(turn) > 2 else []),
                f"        {s['ANGLE_STEP_DEG']} deg per key   {ranges(TURN_AXES)}",
                f" Test   {L.key(key_label(s['AUTO_TEST_KEY']))} auto test (tilt +-{s['AUTO_ANGLE_DEG']} deg, "
                f"move +-{s['AUTO_MOVE']})",
                " Frame  x fwd(+) y left(+) z up(+)  roll+ right down  pitch+ nose down"]

    def _key(self, name):
        """Key."""
        return key_label(self.s[name])

    def screen_text(self, state, info):
        """Screen text."""
        if self.note:
            info = tag(f"{self.note} · previous pose retained", "alert")
        return attitude_text(self.pose, state, info, self.imu_screen_value())

    def show_idle(self):
        """Show idle."""
        self.help_shown = False
        if self.robot.interrupted:
            state = 'Stopped (auto test)'
            info = keys_text([(self._key("STAND_KEY"), 'Stand'), (self._key("AUTO_TEST_KEY"), 'Auto Test')])
        else:
            state = 'Ready'
            info = keys_text([(self._key("HELP_KEY"), 'Key Help'), (self._key("AUTO_TEST_KEY"), 'Auto Test')])
        self.screen.show(self.screen_text(state, info))

    def show_running(self, axis):
        """Show running."""
        info = keys_text([(self._key("STOP_KEY"), 'Stopped'), (self._key("STAND_KEY"), 'Stand')])
        self.screen.show(self.screen_text(f"Auto test running · {axis}", info))

    def show_help_screen(self):
        """Show help screen."""
        keys = self._axis_keys()
        lines = []
        for axis in keys:
            names = " ".join(k for k, _ in keys[axis])
            words = " · ".join(HELP_WORDS[axis][0 if d > 0 else 1] for _, d in keys[axis])
            lines.append(f" {tag(f'{names:<4}', 'key')}{axis:<6}{tag(words, 'text')}")
        auto = f"{self._key('AUTO_TEST_KEY'):<4}"
        lines.append(f" {tag(auto, 'key')}{tag('Auto Test', 'text')}")
        lines.append(" " + keys_text([(self._key("STAND_KEY"), 'Stand'), (self._key("STOP_KEY"), 'Stopped')], "   "))
        info = tag('Press any other key to return', "text")
        self.help_shown = True
        self.screen.show(help_text('Key Help', info, lines))

    def on_loop(self):
        """On loop."""
        if self.imu_log_at is not None and time.time() >= self.imu_log_at:
            self.imu_log_at = None
            self.log_imu()
            if not self.help_shown:
                self.show_idle()
        elif not self.help_shown and self.screen.due():
            self.show_idle()

    def _imu_failed(self, error):
        L.event("WARN", f"no IMU on port {ports.PORT_INERTIAL_SENSOR}: continuing without it")
        L.more(str(error))
        self.imu = None
        self.imu_note = f"No IMU (Port {ports.PORT_INERTIAL_SENSOR})"

    def read_imu(self):
        """Read IMU."""
        if self.imu is None:
            return None
        try:
            return self.imu.read()
        except Exception as e:
            self._imu_failed(e)
            return None

    def imu_screen_value(self):
        """Imu screen value."""
        values = self.read_imu()
        if values is not None:
            return values
        return self.imu_note

    def calibrate_imu(self):
        """Calibrate IMU."""
        if self.imu is None:
            return
        time.sleep(IMU_SETTLE_SEC)
        try:
            zero = self.imu.calibrate()
            L.event("SENSOR", f"zero  {L.angles_text(zero)}")
            L.more(f"still after {self.imu.wait_sec:.1f} s  spread={self.imu.spread:.2f} deg")
            if not self.imu.settled:
                L.event("WARN", f"IMU not still after {STILL_TIMEOUT_SEC:g} s: robot moving")
            elif self.imu.spread > ZERO_SPREAD_WARN_DEG:
                L.event("WARN", f"IMU moved {self.imu.spread:.1f} deg while zeroing: robot not still")
        except Exception as e:
            self._imu_failed(e)

    def log_imu(self):
        """Log IMU."""
        values = self.read_imu()
        if values is None:
            return
        p = self.pose
        diff = [values[0] - p["roll"], values[1] - p["pitch"], values[2] - p["yaw"]]
        L.event("SENSOR", f"imu   {L.angles_text(values)}")
        L.more(f"cmd   roll={L.num(p['roll'])} pitch={L.num(p['pitch'])} yaw={L.num(p['yaw'])}  "
               f"diff {L.signed(diff[0], 0)} {L.signed(diff[1], 0)} {L.signed(diff[2], 0)}")

    def enter(self):
        """Enter."""
        if self.imu_error is not None:
            self._imu_failed(self.imu_error)
        self.robot.stand()
        self.on_stand()
        self.calibrate_imu()

    def on_stand(self):
        """On stand."""
        self.pose = zero_pose()
        self.note = None
        self.log_pose()

    def before_action(self):
        """Before action."""
        self.note = None

    def after_stop(self):
        """After stop."""
        self.robot.sync_from_motion()

    def check(self, pose):
        """Check."""
        feet = body_pose_feet(pose, self.s["BODY_HEIGHT"], self.s["BODY_LENGTH"], self.s["BODY_WIDTH"])
        for leg, point in enumerate(feet):
            r = check_point(self.motion, leg, point)
            name = ports.LEG_NAMES[leg]
            if not r["ok"]:
                return feet, (f"{name} unreachable", f"{name} foot {r['reason']}")
            if r["limited"]:
                return feet, (f"{name} {'·'.join(r['limited'])} limit",
                              f"{name} {' '.join(r['limited'])} at 0/180 deg limit")
        return feet, None

    def step(self, axis, sign, log_feet=True):
        """Step."""
        s = self.s
        size = s["MOVE_STEP"] if axis in MOVE_AXES else s["ANGLE_STEP_DEG"]
        lo, hi = self.ranges[axis]
        unit = UNIT_EN[axis]
        target = max(lo, min(hi, self.pose[axis] + sign * size))
        if target == self.pose[axis]:
            L.event("WARN", f"{axis} already at {target:g}{unit} (range {lo}..{hi})")
            self.note = f"{axis} range limit"
            return False
        pose = dict(self.pose)
        pose[axis] = target
        feet, problem = self.check(pose)
        if problem:
            L.event("WARN", f"{axis} {self.pose[axis]:g} -> {target:g}{unit} not possible, pose kept")
            L.more(problem[1])
            self.note = problem[0]
            return False
        self.pose = pose
        self.move(feet)
        self.log_pose(log_feet and self.s["LOG_DETAIL"])
        if log_feet and self.imu is not None:
            self.imu_log_at = time.time() + IMU_LOG_DELAY_SEC
        return True

    def move(self, feet):
        """Move."""
        steps = self.s["POSE_MOVE_STEPS"]
        if steps <= 1:
            for leg in range(4):
                self.motion.points[leg] = list(feet[leg])
            self.motion.run()
        else:
            self.motion.move_to([list(p) for p in feet], steps)
        self.robot.sync_from_motion()

    def log_pose(self, log_feet=False):
        """Log pose."""
        p = self.pose
        L.event("ACTION", f"pose  x={L.num(p['x'])} y={L.num(p['y'])} z={L.num(p['z'])}  "
                          f"roll={L.num(p['roll'])} pitch={L.num(p['pitch'])} yaw={L.num(p['yaw'])} deg")
        if not log_feet:
            return
        L.more("foot       x       y        z    HX  HY  KN")
        for leg in range(4):
            x, y, z = self.motion.points[leg]
            hx, hy, kn = self.robot.leg_servo(leg)
            L.more(f"{ports.LEG_NAMES[leg]:<4} {x:7.1f} {y:7.1f} {z:8.1f}   {hx:3} {hy:3} {kn:3}")

    # ------------------------------------------------------------
    # Automatic test
    # ------------------------------------------------------------
    def auto_sequence(self):
        """Auto sequence."""
        s = self.s
        sequence = []
        for axis in ("roll", "pitch", "yaw", "z", "x", "y"):
            size = s["ANGLE_STEP_DEG"] if axis in TURN_AXES else s["MOVE_STEP"]
            amount = s["AUTO_ANGLE_DEG"] if axis in TURN_AXES else s["AUTO_MOVE"]
            n = max(1, round(amount / size))
            for sign in (1, -1):
                sequence += [(axis, sign)] * n + [(axis, -sign)] * n
        return sequence

    def auto_test(self):
        """Auto test."""
        L.event("TASK", "auto test: roll, pitch, yaw, z, x, y")
        if self.pose != zero_pose():
            self.robot.stand()
            self.on_stand()
        current = None
        for axis, sign in self.auto_sequence():
            if axis != current:
                current = axis
                L.event("TASK", f"auto test: {axis}")
            moved = self.step(axis, sign, log_feet=False)
            self.show_running(axis)
            if not moved:
                L.event("WARN", f"{axis} step skipped")
            self.robot.wait(self.s["AUTO_STEP_SEC"])
        self.robot.stand()
        self.on_stand()

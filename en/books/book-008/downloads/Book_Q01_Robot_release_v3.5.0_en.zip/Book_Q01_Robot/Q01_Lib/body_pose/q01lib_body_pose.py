# -*- coding: utf-8 -*-
"""q01lib_body_pose: Educational library module for the QUAD-01 RoboCo series.

Body posture control: x/y/z displacement and roll/pitch/yaw orientation."""

import math

from ..core import q01lib_ports as ports

POSE_AXES = ("x", "y", "z", "roll", "pitch", "yaw")


def rotation(roll, pitch, yaw):
    """Rotation."""
    r, p, y = (math.radians(v) for v in (roll, pitch, yaw))
    cr, sr, cp, sp, cy, sy = math.cos(r), math.sin(r), math.cos(p), math.sin(p), math.cos(y), math.sin(y)
    rx = [[1, 0, 0], [0, cr, -sr], [0, sr, cr]]
    ry = [[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]]
    rz = [[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]]
    return _matmul(_matmul(rz, ry), rx)


def _matmul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def hip_position(leg, body_length, body_width):
    """Hip position."""
    front = 1 if leg in ports.FRONT_LEGS else -1
    left = 1 if leg in ports.LEFT_LEGS else -1
    return (front * body_length / 2, left * body_width / 2, 0.0)


def body_pose_feet(pose, body_height, body_length, body_width):
    """Body pose feet."""
    r = rotation(pose["roll"], pose["pitch"], pose["yaw"])
    move = (pose["x"], pose["y"], pose["z"])
    feet = []
    for leg in range(4):
        hip = hip_position(leg, body_length, body_width)
        side_y = ports.FOOT_Y_OFFSET if leg in ports.LEFT_LEGS else -ports.FOOT_Y_OFFSET
        ground = (hip[0], hip[1] + side_y, -body_height)
        d = [ground[i] - move[i] for i in range(3)]                  # F - T
        in_body = [sum(r[k][i] * d[k] for k in range(3)) for i in range(3)]   # Rᵀ · (F - T)
        feet.append([in_body[i] - hip[i] for i in range(3)])
    return feet


def zero_pose():
    """Zero pose."""
    return {axis: 0 for axis in POSE_AXES}

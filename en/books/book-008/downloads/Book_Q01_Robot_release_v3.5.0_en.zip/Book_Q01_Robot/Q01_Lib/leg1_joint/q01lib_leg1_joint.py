# -*- coding: utf-8 -*-
"""q01lib_leg1_joint: Educational library module for the QUAD-01 RoboCo series.

Leg Test 1: individual joint controls, limits, and servo angles."""

from ..core import q01lib_ports as ports
from ..core.q01lib_ik import restrict_angle
from ..core.q01lib_key_events import key_label
from ..leg_common.q01lib_leg_robot import PORT_NAMES
from ..leg_common import q01lib_leg_screen as scr
from ..core import q01lib_log as L    # Console logging helpers (L.event, L.more, L.key, etc.)

JOINTS = ("HX", "HY", "KN")

JOINT_PORTS = {joint: [ports.LEG_JOINT_PORTS[leg][i] for leg in range(4)]
               for i, joint in enumerate(JOINTS)}

JOG_WORDS = {("HY", -1): 'Forward', ("HY", 1): 'Backward',
             ("HX", -1): 'Left', ("HX", 1): 'Right',
             ("KN", 1): 'Bend', ("KN", -1): 'Extend'}

JOG_WORDS_EN = {("HY", -1): "forward", ("HY", 1): "back",
                ("HX", -1): "left", ("HX", 1): "right",
                ("KN", 1): "bend", ("KN", -1): "extend"}

SCREEN_TITLES = {
    "spread": 'Splay all four HX joints',
    "sweep": 'All-leg pose change',
    "zero": 'Joint zero pose',
}


def mirror(leg, angle):
    """Mirror."""
    return angle if leg in ports.LEFT_LEGS else 180 - angle


class JointTest:
    """Joint Test."""

    TITLE = 'Joint Test'
    HEADER = "QUAD-01 LEG TEST 1  JOINT   (Book-QUAD-01-LEG1)"
    LOG_CATEGORIES = ()
    SHORT = 'Joint'
    START_FILE = "q01_leg1_joint_start.py"
    USES_LEG_SELECT = True
    VALUE_NAMES = ("KEY_REPEAT_SEC", "LEFT_TEST_ANGLES", "TEST_ORDER", "JOINT_STEP_SEC", "ZERO_GROUP_SEC",
                   "SPREAD_LEFT_ANGLE", "SPREAD_HOLD_SEC", "SPREAD_RETURN_SEC",
                   "SWEEP_HX_DEG", "SWEEP_KN_DEG", "SWEEP_HY_DEG", "SWEEP_STEP_SEC",
                   "SWEEP_PAUSE_SEC", "SWEEP_END_PAUSE_SEC", "SWEEP_RESET_GROUP_SEC", "JOINT_JOG_DEG",
                   "LEG_TEST_KEYS", "SPREAD_KEY", "SWEEP_KEY", "ZERO_KEY", "JOG_KEYS", "LEG_ZERO_KEY")

    def __init__(self, robot, settings):
        self.robot = robot
        self.s = settings
        self.note = None
        for key, (joint, sign) in settings["JOG_KEYS"].items():
            if (joint, sign) not in JOG_WORDS:
                raise ValueError(f"JOG_KEYS '{key}': joint must be HX, HY or KN, direction 1 or -1")

    def actions(self):
        """Actions."""
        s = self.s
        items = []
        for key, name in s["LEG_TEST_KEYS"].items():
            leg = ports.LEG_NAMES.index(name)
            items.append((key, f"{name} joint test", lambda leg=leg: self.test_leg(leg), True))
        items.append((s["SPREAD_KEY"], "spread HX (4 legs)", self.spread, True))
        items.append((s["SWEEP_KEY"], "pose sweep (4 legs)", self.sweep, True))
        items.append((s["ZERO_KEY"], "zero pose (all joints 90 deg)", self.zero_pose, True))
        for key, (joint, sign) in s["JOG_KEYS"].items():
            items.append((key, f"{joint} {JOG_WORDS_EN[(joint, sign)]}",
                          lambda joint=joint, sign=sign: self.jog(joint, sign), False))
        items.append((s["LEG_ZERO_KEY"], "selected leg to 90 deg", self.zero_leg, False))
        return items

    def repeat_keys(self):
        """Repeat keys."""
        return list(self.s["JOG_KEYS"])

    def _jog_pairs(self):
        """Jog pairs."""
        keys = {}
        for key, (joint, sign) in self.s["JOG_KEYS"].items():
            keys[(joint, sign)] = key_label(key)
        return {joint: (keys.get((joint, a), "?"), keys.get((joint, -a), "?"))
                for joint, a in (("HY", -1), ("HX", -1), ("KN", 1))}

    def guide(self):
        """Guide."""
        s = self.s
        jog = {j: L.key("/".join(pair)) for j, pair in self._jog_pairs().items()}
        k = {name: L.key(key_label(s[name])) for name in ("LEG_ZERO_KEY", "SPREAD_KEY", "SWEEP_KEY", "ZERO_KEY")}
        legs = "  ".join(f"{L.key(key_label(key))} {n}" for key, n in s["LEG_TEST_KEYS"].items())
        return [
            f" Jog    {jog['HY']} HY fwd/back   {jog['HX']} HX left/right   {jog['KN']} KN bend/ext",
            f"        {s['JOINT_JOG_DEG']} deg per key   {k['LEG_ZERO_KEY']} selected leg to 90 deg",
            f" Test   {legs}   (KN, HY, HX of one leg)",
            f"        {k['SPREAD_KEY']} spread HX   {k['SWEEP_KEY']} pose sweep   {k['ZERO_KEY']} zero pose",
        ]

    def jog_footer(self):
        """Jog footer."""
        jog = self._jog_pairs()
        return scr.keys_line([(jog[j][0] + jog[j][1], j) for j in ("HY", "HX", "KN")])

    def idle_page(self):
        """Idle page."""
        body = [self.robot.servo_text(prefix='Input '),
                self.robot.motor_text(),
                self.robot.port_text(),
                self.robot.foot_text()]
        title = f"Joint · leg {self.robot.leg_name}"
        if self.note:
            title = f"{title} · {scr.paint(self.note, 'warn')}"
        return title, body, self.jog_footer()

    def help_lines(self, leg_keys):
        """Help lines."""
        s = self.s
        jog = self._jog_pairs()
        tests = " ".join(key_label(k) for k in s["LEG_TEST_KEYS"])
        return [scr.keys_line([(leg_keys, 'Leg'), (key_label(s["LEG_ZERO_KEY"]), '90°')]),
                scr.keys_line([(jog[j][0] + jog[j][1], j) for j in ("HY", "HX", "KN")]),
                scr.keys_line([(tests, 'Leg Test')]),
                scr.keys_line([(key_label(s["SPREAD_KEY"]), 'Splay'), (key_label(s["SWEEP_KEY"]), 'Pose'),
                               (key_label(s["ZERO_KEY"]), 'Zero')])]

    def enter(self):
        """Enter."""
        self.note = None

    def before_action(self):
        """Before action."""
        self.note = None

    def jog(self, joint, sign):
        """Jog."""
        leg = self.robot.leg
        port = ports.LEG_JOINT_PORTS[leg][JOINTS.index(joint)]
        if leg not in ports.LEFT_LEGS and joint != "HX":
            sign = -sign
        now = self.robot.angles.get(port)
        if now is None:
            L.event("STATE", f"{PORT_NAMES[port]}: no angle sent yet, starting from 90 deg")
            now = 90
        target = restrict_angle(now + sign * self.s["JOINT_JOG_DEG"])
        limited = target in (ports.LOGICAL_MIN_DEG, ports.LOGICAL_MAX_DEG)
        self.note = f"{joint} limit" if limited else None
        if target == now:
            L.event("WARN", f"{PORT_NAMES[port]} at {now} deg, limit "
                            f"{ports.LOGICAL_MIN_DEG}-{ports.LOGICAL_MAX_DEG} deg")
        else:
            self.robot.send_joint(port, target)
            self.robot.log_foot(leg)

    def motion_angle(self, logical):
        """Motion angle."""
        return self.robot.motion.servo.convert_angle(logical)

    def zero_leg(self):
        """Zero leg."""
        leg = self.robot.leg
        for port in ports.LEG_JOINT_PORTS[leg]:
            self.robot.send_joint(port, 90)
        self.robot.log_foot(leg)

    # ------------------------------------------------------------
    # Automatic test
    # ------------------------------------------------------------
    def zero_pose(self, group_sec=None):
        """Zero pose."""
        if group_sec is None:
            group_sec = self.s["ZERO_GROUP_SEC"]
        self.robot.show_running(SCREEN_TITLES["zero"], 'Set KN → HY → HX to 90° in order', 'Running')
        L.event("TASK", "zero pose: all joints to 90 deg (KN, HY, HX)")
        for i, joint in enumerate(("KN", "HY", "HX"), 1):
            joint_ports = JOINT_PORTS[joint]
            L.event("TASK", f"step {i}: {joint}  ports {' '.join(map(str, joint_ports))}")
            for port in joint_ports:
                self.robot.send_joint(port, 90)
            self.robot.show_running(SCREEN_TITLES["zero"], 'Set KN → HY → HX to 90° in order',
                                    f"{joint} {scr.paint(90, 'angle')}deg · Port {' '.join(map(str, joint_ports))}")
            self.robot.wait(group_sec)
        for leg in range(4):
            self.robot.log_foot(leg)
        L.event("TASK", "zero pose done")

    def test_leg(self, leg):
        """Test leg."""
        name = ports.LEG_NAMES[leg]
        L.event("TASK", f"{name} joint test: {' -> '.join(self.s['TEST_ORDER'])}")
        hx, hy, kn = ports.LEG_JOINT_PORTS[leg]
        joint_port = {"HX": hx, "HY": hy, "KN": kn}
        for joint in self.s["TEST_ORDER"]:
            port = joint_port[joint]
            for angle in self.s["LEFT_TEST_ANGLES"][joint]:
                sent = mirror(leg, angle)
                self.robot.send_joint(port, sent)
                self.robot.log_foot(leg)
                self.robot.show_running(f"{name} Joint Test", f"{PORT_NAMES[port]}  Port {port}",
                                        f"Input {scr.paint(sent, 'angle')}deg · motor {self.motion_angle(sent)}deg",
                                        self.robot.foot_text(leg))
                self.robot.wait(self.s["JOINT_STEP_SEC"])

    def spread(self):
        """Spread."""
        self.robot.show_running(SCREEN_TITLES["spread"], 'Running')
        L.event("TASK", "spread HX on 4 legs, then back to 90 deg")
        for leg, port in enumerate(JOINT_PORTS["HX"]):
            self.robot.send_joint(port, mirror(leg, self.s["SPREAD_LEFT_ANGLE"]))
        left = self.s["SPREAD_LEFT_ANGLE"]
        self.robot.show_running(SCREEN_TITLES["spread"],
                                f"HX left {scr.paint(left, 'angle')} · right {scr.paint(180 - left, 'angle')}")
        self.robot.wait(self.s["SPREAD_HOLD_SEC"])
        for port in JOINT_PORTS["HX"]:
            self.robot.send_joint(port, 90)
        self.robot.wait(self.s["SPREAD_RETURN_SEC"])

    def sweep(self):
        """Sweep."""
        self.robot.show_running(SCREEN_TITLES["sweep"], 'Sweep HX → KN → HY by 1° increments', 'Running')
        L.event("TASK", "pose sweep: HX, KN, HY 1 deg at a time")
        for joint, degrees in (("HX", self.s["SWEEP_HX_DEG"]),
                               ("KN", self.s["SWEEP_KN_DEG"]),
                               ("HY", self.s["SWEEP_HY_DEG"])):
            L.event("TASK", f"{joint}  left 90 -> {90 - (degrees - 1)} deg   "
                            f"right 90 -> {90 + (degrees - 1)} deg")
            for i in range(degrees):
                for leg, port in enumerate(JOINT_PORTS[joint]):
                    self.robot.send_joint(port, mirror(leg, 90 - i), log_line=False)
                self.robot.show_running(SCREEN_TITLES["sweep"], 'Sweep HX → KN → HY by 1° increments',
                                        f"{joint} left {scr.paint(90 - i, 'angle')} · "
                                        f"Right {scr.paint(90 + i, 'angle')}")
                self.robot.wait(self.s["SWEEP_STEP_SEC"])
            pause = self.s["SWEEP_END_PAUSE_SEC"] if joint == "HY" else self.s["SWEEP_PAUSE_SEC"]
            self.robot.wait(pause)
        for leg in range(4):
            self.robot.log_foot(leg)
        self.zero_pose(self.s["SWEEP_RESET_GROUP_SEC"])

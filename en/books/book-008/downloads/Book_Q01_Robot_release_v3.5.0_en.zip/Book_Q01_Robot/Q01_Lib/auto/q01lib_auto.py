# -*- coding: utf-8 -*-
"""q01lib_auto: Educational library module for the QUAD-01 RoboCo series.

Automatic scenarios, movement sequences, and recorded observations."""

import time

from ..walk.q01lib_gait import diagonal_pair, zigzag_pair, Phase
from ..core import q01lib_log as L    # Console logging helpers (L.event, L.more, L.key, etc.)

LOW_HEIGHT = 69
CRAWL_HEIGHT = 45
HIGH_HEIGHT = 119

DIAGONALS = {
    "forward_left":   (15, 10),
    "forward_right":  (15, -10),
    "backward_left":  (-15, 10),
    "backward_right": (-15, -10),
}

ZIGZAGS = {
    "forward_left_turn": 12,
    "forward_right_turn": -12,
}

PATTERN_SPEED = 2.5


class AutoModes:
    """Auto Modes."""

    def __init__(self, robot):
        self.robot = robot

    @property
    def active(self) -> bool:
        """Active."""
        return self.robot.auto_mode_active

    def start(self, mode):
        """Start.

Parameters: mode."""
        if self.robot.auto_mode_active:
            self.stop()
            return

        self.robot.auto_mode_active = True

        if mode == 1:
            self.mode_1_basic_movement()
        elif mode == 2:
            self.mode_2_height_pattern()
        elif mode == 3:
            self.mode_3_complex_pattern()
        else:
            L.event("WARN", f"unknown auto mode {mode}")
            self.robot.auto_mode_active = False

    def stop(self):
        """Stop."""
        if self.robot.auto_mode_active:
            self.robot.auto_mode_active = False
            self.robot.default_position()
            L.event("TASK", "auto mode stopped -> default pose")

    @staticmethod
    def _begin(mode, name):
        """Begin."""
        L.event("TASK", f"auto {mode}  {name}  start")
        return time.time()

    @staticmethod
    def _done(mode, start):
        L.event("TASK", f"auto {mode}  done in {time.time() - start:.1f} s")

    @staticmethod
    def _step(text):
        L.event("TASK", text)

    # ------------------------------------------------------------
    # Auto mode 1: basic locomotion pattern
    # ------------------------------------------------------------
    def mode_1_basic_movement(self):
        """Mode 1 basic movement."""
        robot = self.robot
        start = self._begin(1, "basic moves")

        try:
            self._step("1/6  forward     3.0 s")
            robot.forward(duration=3.0, auto_mode=True, speed=2.5, stride_x=12, lift_z=6)

            if not self.active:
                return

            # Stop for 0.5 seconds
            robot.default_position()
            time.sleep(0.5)

            self._step("2/6  backward    3.0 s")
            robot.backward(duration=3.0, auto_mode=True)

            if not self.active:
                return

            # Stop for 0.5 seconds
            robot.default_position()
            time.sleep(0.5)

            self._step("3/6  turn left   3.0 s")
            robot.turn_left(duration=3.0, auto_mode=True)

            if not self.active:
                return

            # Stop for 0.5 seconds
            robot.default_position()
            time.sleep(0.5)

            self._step("4/6  turn right  3.0 s")
            robot.turn_right(duration=3.0, auto_mode=True)
            time.sleep(0.5)

            # Stop for 0.5 seconds
            robot.default_position()
            time.sleep(0.5)

            self._step("5/6  side left   2.0 s")
            robot.step_left(duration=2.0, auto_mode=True)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.3)

            self._step("6/6  side right  2.0 s")
            robot.step_right(duration=2.0, auto_mode=True)
            if not self.active:
                return

            # Restore the default standing pose
            robot.default_position()
            self._done(1, start)

        except Exception as e:
            L.event("ERROR", f"auto 1: {e}")
        finally:
            robot.auto_mode_active = False

    # ------------------------------------------------------------
    # Auto mode 2: stability test at different body heights
    # ------------------------------------------------------------
    def mode_2_height_pattern(self):
        """Mode 2 height pattern."""
        robot = self.robot
        base = robot.base_height
        start = self._begin(2, "height test")

        try:
            self._step(f"1/9  stand            h={base:3g} mm  2.0 s")
            robot.height = base
            robot.default_position()
            time.sleep(2)

            if not self.active:
                return

            self._step(f"2/9  walk standard    h={base:3g} mm  4.0 s  stride 32/16")
            robot.forward(duration=4.0, auto_mode=True, speed=2.5, stride_x=32, lift_z=16)

            if not self.active:
                return

            robot.default_position()
            time.sleep(0.5)

            self._step(f"3/9  height {base:3g} -> {LOW_HEIGHT:3g} mm  2.0 s")
            robot.smooth_height_transition(LOW_HEIGHT, duration=2.0)

            if not self.active:
                return

            self._step(f"4/9  walk low         h={LOW_HEIGHT:3g} mm  4.0 s  stride 12/6")
            robot.forward(duration=4.0, auto_mode=True, speed=2, stride_x=12, lift_z=6)

            if not self.active:
                return

            robot.default_position()
            time.sleep(0.5)

            self._step(f"5/9  height {LOW_HEIGHT:3g} -> {CRAWL_HEIGHT:3g} mm  2.0 s")
            robot.smooth_height_transition(CRAWL_HEIGHT, duration=2.0)

            if not self.active:
                return

            self._step(f"6/9  walk crawl       h={CRAWL_HEIGHT:3g} mm  4.0 s  stride 12/6")
            robot.forward(duration=4.0, auto_mode=True, speed=1.5, stride_x=12, lift_z=6)

            if not self.active:
                return

            robot.default_position()
            time.sleep(0.5)

            self._step(f"7/9  height {CRAWL_HEIGHT:3g} -> {HIGH_HEIGHT:3g} mm  3.0 s")
            robot.smooth_height_transition(HIGH_HEIGHT, duration=3.0)

            if not self.active:
                return

            self._step(f"8/9  walk high        h={HIGH_HEIGHT:3g} mm  4.0 s  stride 12/6")
            robot.forward(duration=4.0, auto_mode=True, speed=1.5, stride_x=12, lift_z=6)

            if not self.active:
                return

            robot.default_position()
            time.sleep(0.5)

            self._step(f"9/9  height {HIGH_HEIGHT:3g} -> {base:3g} mm  2.0 s")
            robot.smooth_height_transition(base, duration=2.0)

            if not self.active:
                return

            robot.default_position()

            self._done(2, start)

        except Exception as e:
            L.event("ERROR", f"auto 2: {e}")
            robot.height = base
            robot.default_position()
            L.event("STATE", "back to default pose")
        finally:
            robot.auto_mode_active = False

    # ------------------------------------------------------------
    # Auto mode 3: combined motion pattern
    # ------------------------------------------------------------
    def mode_3_complex_pattern(self):
        """Mode 3 complex pattern."""
        robot = self.robot
        start = self._begin(3, "complex pattern")

        try:
            self._step("stage 1/4  straight")

            self._step("  1.1  forward          3.0 s")
            robot.forward(duration=3.0, auto_mode=True, speed=2.5, stride_x=20, lift_z=10)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.2)

            self._step("  1.2  backward         3.0 s")
            robot.backward(duration=3.0, auto_mode=True, speed=2.5)
            if not self.active:
                return

            robot.default_position()

            time.sleep(1.0)
            if not self.active:
                return

            self._step("stage 2/4  diagonal")

            self._step("  2.1  forward-left     3.0 s")
            self._diagonal_movement("forward_left", 3.0)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.2)

            self._step("  2.2  forward-right    3.0 s")
            self._diagonal_movement("forward_right", 3.0)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.2)

            self._step("  2.3  backward-left    3.0 s")
            self._diagonal_movement("backward_left", 3.0)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.2)

            self._step("  2.4  backward-right   3.0 s")
            self._diagonal_movement("backward_right", 3.0)
            if not self.active:
                return

            robot.default_position()

            time.sleep(1.0)
            if not self.active:
                return

            self._step("stage 3/4  zigzag")

            zigzag_patterns = [
                ("forward_left_turn", "forward + left"),
                ("forward_right_turn", "forward + right"),
                ("forward_left_turn", "forward + left"),
                ("forward_right_turn", "forward + right"),
            ]

            for i, (pattern, description) in enumerate(zigzag_patterns):
                self._step(f"  3.{i + 1}  {description:<16} 4.0 s")
                self._zigzag_movement(pattern, 4.0)
                if not self.active:
                    return

                robot.default_position()
                time.sleep(0.2)

            time.sleep(1.0)
            if not self.active:
                return

            self._step("stage 4/4  finish")

            self._step("  4.1  diagonal x4      6.0 s")
            self._extended_diagonal_test(6.0)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.3)

            self._step("  4.2  turn right       6.0 s")
            self._full_rotation(6.0)
            if not self.active:
                return

            robot.default_position()
            time.sleep(0.3)

            self._done(3, start)

        except Exception as e:
            L.event("ERROR", f"auto 3: {e}")
            robot.default_position()
            L.event("STATE", "back to default pose")
        finally:
            robot.auto_mode_active = False

    def _pattern_walk(self, duration, coords_fn):
        """Pattern walk."""
        robot = self.robot
        phase = Phase(90, PATTERN_SPEED, 90, 450)
        start_time = time.time()

        while time.time() - start_time < duration and self.active:
            X1, Y1, Z1, X2, Y2, Z2 = coords_fn(phase.angle)
            robot.motion.change_coordinates("forward", X1, Y1, Z1, X2, Y2, Z2)
            phase.advance()

    def _diagonal_movement(self, direction, duration):
        """Diagonal movement.

Parameters: direction."""
        amp_x, amp_y = DIAGONALS[direction]
        self._pattern_walk(duration,
                           lambda angle: diagonal_pair(angle, amp_x, amp_y, self.robot.height))

    def _zigzag_movement(self, pattern, duration):
        """Zigzag movement.

Parameters: pattern."""
        amp_y = ZIGZAGS[pattern]
        self._pattern_walk(duration,
                           lambda angle: zigzag_pair(angle, amp_y, self.robot.height))

    def _extended_diagonal_test(self, duration):
        """Extended diagonal test."""
        pattern_duration = duration / 4
        patterns = ["forward_left", "forward_right", "backward_left", "backward_right"]

        for pattern in patterns:
            if not self.active:
                break
            self._diagonal_movement(pattern, pattern_duration)
            time.sleep(0.1)

    def _full_rotation(self, duration):
        """Full rotation."""
        start_time = time.time()

        while time.time() - start_time < duration and self.active:
            self.robot.turn_right(duration=0.3, auto_mode=True, speed=2.0)
            if not self.active:
                break


# -*- coding: utf-8 -*-
"""__init__: Educational library package for the QUAD-01 RoboCo series.

Automatic scenarios, movement sequences, and recorded observations."""

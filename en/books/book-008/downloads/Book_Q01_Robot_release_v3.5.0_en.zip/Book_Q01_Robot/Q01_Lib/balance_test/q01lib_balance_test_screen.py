# -*- coding: utf-8 -*-
"""q01lib_balance_test_screen: Educational library module for the QUAD-01 RoboCo series.

Feedback balancing using IMU readings, PID control, and a tilt-test platform."""

import math
import time

from controllables import TextScreen

from ..core import q01lib_ports as ports
from ..core.q01lib_screen import DEFAULT_TEXT_COLOR, ensure_readable_text

# ------------------------------------------------------------
# Display settings
# ------------------------------------------------------------
SCALE = 10
BAR_LENGTH = 9
BAR_CHAR = "-"
BODY_LINES = 6
SCREEN_LINES = BODY_LINES + 4
RULE_CHAR = "-"
RULE_WIDTH = 22
AUTO_SIZE_MAX = 200
HELP_GROUP_COLS = 8
REFRESH_SEC = 0.2

SCREEN_COLOR = True
COLORS = {
    "state": "#FF8A34",
    "rule": "#6B7280",       # Separator line
    "label": "yellow",
    "value": "#FFFFFF",
    "out": "#20D6D9",
    "alert": "red",
    "hint": "#7CD992",
    "platform": "#FFD91A",
    "key": "#FFFFFF",
    "text": "#B0B7C3",
}


def tag(text, color_name):
    """Tag."""
    if not SCREEN_COLOR:
        return text
    if color_name == "key":
        return f"<b><color={COLORS['key']}>{text}</color></b>"
    return f"<color={COLORS.get(color_name, color_name)}>{text}</color>"


def pad_cols(text, cols):
    """Pad cols."""
    width = sum(2 if ord(ch) > 127 else 1 for ch in text)
    return text + " " * max(1, cols - width)


def keys_text(items, sep=" · "):
    """Keys text."""
    return sep.join(f"{tag(k, 'key')} {tag(d, 'text')}" for k, d in items)


def signed(value, width=0):
    """Signed."""
    return f"{round(value, 1) + 0.0:+{width}.1f}"


def cell(value, count=BAR_LENGTH):
    """Cell."""
    half = (count - 1) // 2
    t = value / SCALE * half
    steps = int(math.floor(abs(t) + 0.5))
    return min(count - 1, max(0, half + (steps if t >= 0 else -steps)))


def bar(value):
    """Bar."""
    cells = [BAR_CHAR] * BAR_LENGTH
    cells[cell(value)] = tag("●", "label")
    return "".join(cells)


def angle_line(label, value, extra_name="", extra_value=None):
    """Angle line."""
    line = f"{tag(f'{label:<6}', 'label')}{tag(signed(value, 6), 'value')}° {bar(value)}"
    if extra_value is not None:
        line += f" {tag(extra_name, 'text')} {tag(signed(extra_value, 5), 'out')}"
    return line


def platform_line(pose, speed, platform_imu=None):
    """Platform line."""
    roll, pitch, yaw = (round(v) + 0 for v in pose)
    line = (f"{tag('Platform', 'text')}  {tag(f'R {roll:+d}  P {pitch:+d}  Y {yaw:+d}', 'platform')}"
            f"  {tag('Speed', 'text')} {tag(speed, 'platform')}")
    if platform_imu is not None:
        line += f" {tag(f'(IMU {platform_imu[0]:+.1f} {platform_imu[1]:+.1f})', 'text')}"
    return line


def pid_line(kp, ki, kd, filter_mode):
    """Pid line."""
    return tag(f"PID  KP {kp:g} · KI {ki:g} · KD {kd:g} · {filter_mode}", "text")


def rule():
    """Rule."""
    return tag(RULE_CHAR * RULE_WIDTH, "rule")


def page(title, body, footer, body_lines=BODY_LINES):
    """Page.

Parameters: title, body, footer."""
    body = list(body)[:body_lines]
    body += [""] * (body_lines - len(body))
    return "\n".join([tag(title, "state"), rule(), *body, rule(), footer])


def balance_text(state, imu, extra_name, extras, platform, pid, info, footer=""):
    """Balance text.

Parameters: state, imu, extra_name, extras, platform, pid, info, footer."""
    lines = []
    if imu is None:
        lines += [tag('Cannot read IMU', "alert"), "", ""]
    else:
        for name, value, extra in zip(("Roll", "Pitch", "Yaw"), imu, extras):
            lines.append(angle_line(name, value, extra_name, extra))
    lines += [platform, pid_line(*pid), info]
    return page(state, lines, footer)


def help_text(lines, footer):
    """Help text."""
    return page('Key Help', lines, footer)


def popup_text(title, lines, footer):
    """Popup text."""
    body = [tag(*line) if isinstance(line, tuple) else tag(line, "text") for line in lines]
    return page(title, body, footer)


def start_text():
    """Start text."""
    return page('QUAD-01 Balance Test · Starting', [
        tag('Initializing...', "value"),
        tag('1. Level the platform', "text"),
        tag('2. Stand robot', "text"),
        tag('3. Calibrate IMU zero (~2 s)', "text"),
        tag('Do not touch the robot or platform', "hint"),
    ], tag('Main screen will appear shortly', "text"))


# ------------------------------------------------------------
# Robot Text Screen Reference
# ------------------------------------------------------------
class BalanceTestScreen:
    """Balance Test Screen."""

    def __init__(self):
        self.screen = TextScreen(ports.PORT_TEXT_SCREEN)
        self.screen.color = DEFAULT_TEXT_COLOR  # Background is black; labels use their own rich-text colors.
        self.screen.wrapping = False
        self.screen.auto_size = True
        self.screen.auto_size_max = AUTO_SIZE_MAX
        self.screen.horizontal_alignment = TextScreen.HorizontalAlignment.LEFT
        self.screen.vertical_alignment = TextScreen.VerticalAlignment.MIDDLE
        self.text = ""
        self.sent_at = 0.0

    def show(self, text):
        """Show."""
        self.screen.text = ensure_readable_text(text)
        self.text = text
        self.sent_at = time.time()

    def due(self):
        """Due."""
        return time.time() - self.sent_at >= REFRESH_SEC

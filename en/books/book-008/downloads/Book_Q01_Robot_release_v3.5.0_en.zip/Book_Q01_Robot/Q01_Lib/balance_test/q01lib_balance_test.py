# -*- coding: utf-8 -*-
"""q01lib_balance_test: Educational library module for the QUAD-01 RoboCo series.

Feedback balancing using IMU readings, PID control, and a tilt-test platform."""

import math
import time

from ..core import q01lib_ports as ports
from ..core.q01lib_key_events import key_label
from ..leg_common.q01lib_leg_check import check_point
from ..core import q01lib_log as L    # Console logging helpers (L.event, L.more, L.key, etc.)
from ..core.q01lib_imu import BodyIMU, STILL_TIMEOUT_SEC
from .q01lib_pid import PID
from ..body_pose.q01lib_body_pose import body_pose_feet, zero_pose
from .q01lib_imu_filter import IMUFilter, FILTER_NAMES_EN
from .q01lib_balance_test_screen import (BalanceTestScreen, balance_text, help_text, keys_text, platform_line, tag,
                                         pad_cols, popup_text, start_text, HELP_GROUP_COLS)
from .q01lib_platform_program import (AXES, LEVEL, DIRECTION_EN, PlatformPose, PlatformSpeed, ScenarioRun, scenario,
                                   settings_from, check_platform_keys, changed_from_defaults, pose_text,
                                   speed_text, PLATFORM_SPEED_MIN, PLATFORM_SPEED_MAX)
from .q01lib_platform_link import PlatformLink

GAIN_NAMES = ("KP", "KI", "KD")
GAIN_LEVEL_NAMES = {"KP": "KP_LEVELS", "KI": "KI_LEVELS", "KD": "KD_LEVELS"}
GAIN_INFO = {
    "KP": ("P", 'Current tilt', 'Higher: levels faster; too high causes oscillation', 'Lower: slower leveling; at 0, only I acts'),
    "KI": ("I", 'Accumulated tilt', 'Higher: overshoots and oscillates', 'Zero: residual body tilt remains'),
    "KD": ("D", 'Rate of tilt change', 'Small amount: reduces fast oscillation', 'Too high: amplifies IMU noise and jitter'),
}
SIGN_NAMES = {"roll": "ROLL_SIGN", "pitch": "PITCH_SIGN", "yaw": "YAW_SIGN"}
SERVO_SIGN_NAMES = {"roll": "ROLL_SERVO_SIGN", "pitch": "PITCH_SERVO_SIGN", "yaw": "YAW_SERVO_SIGN"}
IMU_SETTLE_SEC = 0.5
MAX_DT_SEC = 0.1
IMU_TEST_SAMPLES = 10
IMU_TEST_SAMPLE_SEC = 0.02
MEASURE_SEC = 0.5
CHECK_LEVEL_SEC = 1.0
NOTE_REPEAT_SEC = 3.0
LOG_CHANGE_DEG = 0.5
ZERO_SPREAD_WARN_DEG = 1.0
GUIDE_LABEL_COLS = 8
ZERO_TILT_WARN_DEG = 15.0


def check_levels(name, levels):
    """Check levels."""
    try:
        values = [float(v) for v in levels]
    except (TypeError, ValueError):
        raise ValueError(f"{name}: use a list of numbers, e.g. [0, 0.5, 1, 2]")
    if len(values) < 2 or any(v < 0 for v in values) or values != sorted(set(values)):
        raise ValueError(f"{name}: use 2 or more numbers >= 0, small to large")
    return values


def next_level(levels, value, sign):
    """Next level."""
    if sign > 0:
        bigger = [v for v in levels if v > value + 1e-9]
        return bigger[0] if bigger else None
    smaller = [v for v in levels if v < value - 1e-9]
    return smaller[-1] if smaller else None


def level_text(levels, value):
    """Level text."""
    return " ".join(f"[{v:g}]" if abs(v - value) < 1e-9 else f"{v:g}" for v in levels)


def tilt_of(roll, pitch):
    """Tilt of."""
    return math.hypot(roll, pitch)


class BalanceTest:
    """Balance Test."""

    TITLE = 'Balance Test'
    SHORT = 'Balance'
    HEADER = "QUAD-01 BALANCE TEST  tilt platform + IMU + PID"
    LOG_CATEGORIES = ("PARAMETER", "SENSOR", "ACTION", "METRIC")
    START_FILE = "q01_balance_test_start.py"
    USES_LEG_SELECT = False
    COMMON_DESC = {"STAND_KEY": "reset", "STOP_KEY": "stop all"}
    STAND_KO = 'Reset'
    SHOWS_START = True
    VALUE_NAMES = ("KEY_REPEAT_SEC", "BODY_LENGTH", "BODY_WIDTH", "FEET_FORWARD",
                   "KP", "KI", "KD", "KP_LEVELS", "KI_LEVELS", "KD_LEVELS", "MAX_CORRECTION_DEG",
                   "BALANCE_AT_START", "FILTER_MODE", "CALIBRATION_SAMPLES", "IMU_STILL_DEG", "LOG_INTERVAL_SEC",
                   "ROLL_SIGN", "PITCH_SIGN", "YAW_SIGN", "SWAP_ROLL_PITCH",
                   "PLATFORM_MCU_PORT", "PLATFORM_STEP_DEG", "PLATFORM_LIMIT_DEG",
                   "PLATFORM_SPEED", "PLATFORM_SPEED_STEP",
                   "CHECK_DEG", "CHECK_HOLD_SEC", "CHECK_MOVE_STEPS",
                   "TEST_POSES", "TEST_HOLD_SEC", "SWAY_HOLD_SEC", "LEVEL_OK_DEG", "SETTLE_DEG", "LOG_DETAIL",
                   "POPUP_SEC",
                   "PLATFORM_KEYS", "GAIN_KEYS", "CHECK_KEY", "TEST_KEY", "COMPARE_KEY", "BALANCE_KEY", "LEVEL_KEY",
                   "PLATFORM_SLOWER_KEY", "PLATFORM_FASTER_KEY", "SWAY_KEY")

    def __init__(self, robot, settings):
        self.robot = robot
        self.motion = robot.motion
        self.s = settings
        for key, (name, sign) in settings["GAIN_KEYS"].items():
            if name not in GAIN_NAMES or sign not in (1, -1):
                raise ValueError(f"GAIN_KEYS '{key}': name must be KP, KI or KD, direction 1 or -1")
        self.screen = BalanceTestScreen()
        self.screen.show(start_text())
        check_platform_keys(settings["PLATFORM_KEYS"])
        self.prog = settings_from(settings)
        self.gains = {name: float(settings[name]) for name in GAIN_NAMES}
        self.levels = {name: check_levels(GAIN_LEVEL_NAMES[name], settings[GAIN_LEVEL_NAMES[name]])
                       for name in GAIN_NAMES}
        if not settings["POPUP_SEC"] >= 0:
            raise ValueError(f"POPUP_SEC {settings['POPUP_SEC']}: use 0 or more (0 = no help screen on keys)")
        limit = settings["MAX_CORRECTION_DEG"]
        self.roll_pid = PID(self.gains["KP"], self.gains["KI"], self.gains["KD"], limit)
        self.pitch_pid = PID(self.gains["KP"], self.gains["KI"], self.gains["KD"], limit)
        self.filter = IMUFilter(settings["FILTER_MODE"])
        self.platform = PlatformPose(self.prog["PLATFORM_STEP_DEG"], self.prog["PLATFORM_LIMIT_DEG"])
        speed, step = self.prog["PLATFORM_SPEED"], self.prog["PLATFORM_SPEED_STEP"]
        if not PLATFORM_SPEED_MIN <= speed <= PLATFORM_SPEED_MAX:
            raise ValueError(f"PLATFORM_SPEED {speed}: use {PLATFORM_SPEED_MIN:g} ~ {PLATFORM_SPEED_MAX:g} "
                             f"(1.0 = servo part speed)")
        if not step > 0:
            raise ValueError(f"PLATFORM_SPEED_STEP {step}: use a value above 0")
        self.speed = PlatformSpeed(speed, step)
        try:
            self.link = PlatformLink(settings["PLATFORM_MCU_PORT"])
            self.link_error = None
        except Exception as e:
            self.link = None
            self.link_error = e

        self.imu = None
        self.imu_error = None
        try:
            self.imu = BodyIMU(ports.PORT_INERTIAL_SENSOR, roll_sign=settings["ROLL_SIGN"],
                               pitch_sign=settings["PITCH_SIGN"], yaw_sign=settings["YAW_SIGN"],
                               swap_roll_pitch=settings["SWAP_ROLL_PITCH"])
        except Exception as e:
            self.imu_error = e

        self.balance_on = False
        self.angles = (0.0, 0.0, 0.0)
        self.corrections = (0.0, 0.0)
        self.legs = None
        self.command = None
        self.running = None
        self.note = None
        self.note_logged = {}
        self.hint = None
        self.help_shown = False
        self.key_time = time.time()
        self.last_time = time.time()
        self.last_log = 0.0
        self.logged = None
        self.popup = None
        self.sway = None
        self.sway_index = None
        self.sway_seg = None
        self.sway_rows = []
        self.sway_seg_start = 0.0
        self.sway_gain_text = ""
        self.sway_last = None

    def actions(self):
        """Actions."""
        items = []
        for key, (axis, direction) in self.s["PLATFORM_KEYS"].items():
            items.append((key, f"platform {axis} {DIRECTION_EN[(axis, direction)]}",
                          lambda a=axis, d=direction: self.platform_step(a, d), False))
        for key, (name, sign) in self.s["GAIN_KEYS"].items():
            items.append((key, f"{name} {'+' if sign > 0 else '-'}",
                          lambda name=name, sign=sign: self.change_gain(name, sign), False))
        items += [(self.s["CHECK_KEY"], "direction check", self.direction_check, True),
                  (self.s["TEST_KEY"], "balance test", self.balance_test, True),
                  (self.s["COMPARE_KEY"], "compare OFF vs ON", self.compare_test, True),
                  (self.s["BALANCE_KEY"], "balance on/off", self.toggle_balance, False),
                  (self.s["LEVEL_KEY"], "platform level", self.platform_level, False),
                  (self.s["PLATFORM_SLOWER_KEY"], "platform slower", lambda: self.platform_speed(-1), False),
                  (self.s["PLATFORM_FASTER_KEY"], "platform faster", lambda: self.platform_speed(1), False),
                  (self.s["SWAY_KEY"], "sway on/off", self.toggle_sway, False)]
        return items

    def repeat_keys(self):
        """Repeat keys."""
        return list(self.s["GAIN_KEYS"])

    def _key(self, name):
        """Key."""
        return key_label(self.s[name])

    def _gain_keys(self):
        """Gain keys."""
        keys = {}
        for key, (name, sign) in self.s["GAIN_KEYS"].items():
            keys.setdefault(name, []).append((key_label(key), sign))
        return keys

    def _platform_keys(self):
        """Platform keys."""
        parts = []
        for axis in AXES:
            keys = sorted(((d, key_label(k)) for k, (a, d) in self.s["PLATFORM_KEYS"].items() if a == axis),
                          reverse=True)
            if keys:
                parts.append(f"{L.key('/'.join(k for _, k in keys))} {axis} "
                             f"{'/'.join('+' if d > 0 else '-' for d, _ in keys)}")
        return "   ".join(parts)

    def _gain_pairs(self):
        """Gain pairs."""
        return [("/".join(k for k, _ in keys), name) for name, keys in self._gain_keys().items()]

    def _pair_text(self, axis):
        """Pair text."""
        keys = sorted(((d, key_label(k)) for k, (a, d) in self.s["PLATFORM_KEYS"].items() if a == axis),
                      reverse=True)
        return "/".join(k for _, k in keys)

    def _link_text(self):
        if self.link is not None and self.link.linked:
            return f"platform link: MCU port {self.link.port}"
        return "platform link: none (same keys)"

    def _console_key(self, name):
        """Console key."""
        return L.key(self._key(name))

    def _gain_key_text(self):
        """Gain key text."""
        return L.keys("/".join(k for k, _ in keys) for keys in self._gain_keys().values())

    def common_guide(self):
        """Common guide."""
        k = self._console_key
        return f" {k('HELP_KEY')} help   {k('STAND_KEY')} reset   {k('STOP_KEY')} stop all   quit: stop the script"

    def guide(self):
        """Guide."""
        k = self._console_key

        def row(label, text):
            return f" {label:<{GUIDE_LABEL_COLS}} {text}"
        gain_keys = "   ".join(f"{L.key('/'.join(key for key, _ in keys))} {name}"
                               for name, keys in self._gain_keys().items())
        return [row("Step", f"{k('CHECK_KEY')} direction check   {k('TEST_KEY')} balance test"),
                row("", f"{k('COMPARE_KEY')} compare: same platform moves, balance OFF then ON"),
                row("", f"{k('SWAY_KEY')} sway: platform keeps tilting, PID keys work live"),
                row("Platform", self._platform_keys()),
                row("", f"{k('LEVEL_KEY')} level   {self.prog['PLATFORM_STEP_DEG']:g} deg per key, "
                        f"limit +-{self.prog['PLATFORM_LIMIT_DEG']:g}"),
                row("", f"{k('PLATFORM_SLOWER_KEY')}/{k('PLATFORM_FASTER_KEY')} speed -/+"
                        f"{self.speed.step:g}   (x1.0 = servo part speed)"),
                row("Gain", f"{gain_keys}   (one level per key)"),
                *[row("", f"{name} {level_text(self.levels[name], self.gains[name])}") for name in GAIN_NAMES],
                row("Mode", f"{k('BALANCE_KEY')} balance on/off   {self._link_text()}"),
                row("Now", self._gain_text()),
                row("", f"platform speed {speed_text(self.speed.value)}"),
                row("Log", "body = robot IMU   corr = PID correction (deg)")]

    def _gain_text(self):
        g = self.gains
        return (f"KP={g['KP']:g}  KI={g['KI']:g}  KD={g['KD']:g}  "
                f"filter={FILTER_NAMES_EN[self.filter.mode]}")

    def _gain_short(self):
        """Gain short."""
        g = self.gains
        return f"P{g['KP']:g} I{g['KI']:g} D{g['KD']:g}" if self.balance_on else "balance OFF"

    def _set_note(self, ko=None, en=None):
        """Set note."""
        self.note = ko
        if not en:
            return
        now = time.time()
        if now - self.note_logged.get(en, -NOTE_REPEAT_SEC) >= NOTE_REPEAT_SEC:
            L.event("WARN", en)
            self.note_logged[en] = now

    def _next(self, en, ko):
        """Next."""
        L.event("STATE", f"next: {en}")
        self.hint = ko

    def _pid(self):
        return (self.gains["KP"], self.gains["KI"], self.gains["KD"], self.filter.mode)

    def _platform_line(self):
        imu = self.link.platform_imu_fresh() if self.link is not None else None
        return platform_line(self.platform.pose, speed_text(self.speed.value), imu)

    def _info(self):
        """Info."""
        if self.note:
            return tag(self.note, "alert")
        if self.sway is not None and self.sway_last is not None:
            label, mx, end = self.sway_last
            return tag(f"Previous {label}: peak {mx:.1f}° · final {end:.1f}°", "hint")
        if self.hint:
            return tag(self.hint, "hint")
        return ""

    def _keys(self, *pairs):
        """Keys."""
        return keys_text([(self._key(k) if k in self.s else k, desc) for k, desc in pairs])

    def _popup_active(self):
        return self.popup is not None and time.time() < self.popup[1]

    def _popup(self, title, lines, *keys):
        """Popup."""
        if self.s["POPUP_SEC"] <= 0:
            return
        self.popup = (popup_text(title, lines, self._keys(*keys)), time.time() + self.s["POPUP_SEC"])
        self.help_shown = False
        self.screen.show(self.popup[0])

    def _main_title(self):
        balance = 'Balance ON' if self.balance_on else 'Balance OFF'
        if self.sway is not None and self.sway_seg is not None:
            pose = 'Level' if self.sway_seg.label == "level" else self.sway_seg.label
            return f"Continuous Sway · {balance} · {pose}"
        if self.robot.interrupted:
            return f"Balance Test · Stopped · {balance}"
        return f"Balance Test · {balance}"

    def _main_footer(self):
        if self.sway is not None:
            pid = " ".join("/".join(k for k, _ in keys) for keys in self._gain_keys().values())
            return self._keys(("SWAY_KEY", 'Stopped'), (pid, "PID"), ("BALANCE_KEY", 'Balance'))
        return self._keys(("HELP_KEY", 'Key Help'), ("STAND_KEY", 'Reset'), ("STOP_KEY", 'Stop All'))

    def show_idle(self):
        """Show idle."""
        self.help_shown = False
        if self._popup_active():
            self.screen.show(self.popup[0])
            return
        self.popup = None
        imu = self.angles if self.imu is not None else None
        extras = (self.corrections[0], self.corrections[1], None) if self.balance_on else (None, None, None)
        self.screen.show(balance_text(self._main_title(), imu, 'Correction', extras, self._platform_line(),
                                      self._pid(), self._info(), self._main_footer()))

    def show_running(self, state):
        """Show running."""
        if self._popup_active():
            self.screen.show(self.popup[0])
            return
        footer = self._keys(("STOP_KEY", 'Stopped'), ("STAND_KEY", 'Reset'))
        info = tag(self.note, "alert") if self.note else ""
        if self.command is not None:
            name, extras = 'Command', self.command
        elif self.balance_on:
            name, extras = 'Correction', (self.corrections[0], self.corrections[1], None)
        else:
            name, extras = "", (None, None, None)
        self.screen.show(balance_text(state, self.angles, name, extras, self._platform_line(), self._pid(),
                                      info, footer))

    def show_help_screen(self):
        """Show help screen."""
        k = self._key

        def pair(name):
            """Pair."""
            keys = sorted(((d, key_label(key)) for key, (a, d) in self.s["PLATFORM_KEYS"].items() if a == name),
                          reverse=True)
            return "/".join(key for _, key in keys)

        gains = self._gain_keys()
        rows = [
            ('Auto', [(k("CHECK_KEY"), 'Direction Check'), (k("TEST_KEY"), 'Balance Test')]),
            ("", [(k("COMPARE_KEY"), 'Compare OFF → ON'), (k("SWAY_KEY"), 'Continuous Sway')]),
            ('Platform', [(pair("pitch"), 'Front/back'), (pair("roll"), 'Left/right'), (pair("yaw"), 'Rotation')]),
            ("", [(k("LEVEL_KEY"), 'Level'),
                  (f"{k('PLATFORM_SLOWER_KEY')}/{k('PLATFORM_FASTER_KEY')}",
                   f"Speed (now {speed_text(self.speed.value)})")]),
            ('Balance', [(k("BALANCE_KEY"), "ON/OFF")]),
            ("PID", [("/".join(key for key, _ in gains[name]), name) for name in GAIN_NAMES if name in gains]),
        ]
        lines = [tag(pad_cols(group, HELP_GROUP_COLS), "label") + keys_text(items, "   ") for group, items in rows]
        self.help_shown = True
        self.popup = None
        self.screen.show(help_text(lines, self._keys(("STAND_KEY", 'Reset'), ("STOP_KEY", 'Stop All'),
                                                     ('Other key', 'Return'))))

    def enter(self):
        """Enter."""
        if self.imu_error is not None:
            self._imu_failed(self.imu_error)
        self._report_link()
        self._platform_to(LEVEL, force=True)
        self.robot.stand()
        self.on_stand()
        self.calibrate()
        if self.s["BALANCE_AT_START"]:
            self.set_balance(True)
        if self.imu is not None:
                self._next(f"press {self._console_key('CHECK_KEY')} (direction check)",
                           f"Next: {self._key('CHECK_KEY')} direction check")

    def _report_link(self):
        """Report link."""
        if self.link is not None and self.link.linked:
            L.event("STATE", f"platform link: MCU port {self.link.port}, robot sends angles")
            return
        if self.link_error is not None:
            L.event("WARN", f"platform link not available ({self.link_error})")
        L.event("STATE", "platform link: none, platform script reads keys")
        L.more("to link: README 11.1 (platform MCU on a robot port)")
        changed = changed_from_defaults(self.prog)
        if changed:
            L.event("WARN", "not linked: the platform uses default values for")
            for line in L.wrap(" ".join(changed), 50):
                L.more(line)

    def on_stand(self):
        """On stand."""
        if self.balance_on:
            L.event("STATE", "balance OFF")
        self.balance_on = False
        self.corrections = (0.0, 0.0)
        self.legs = None
        self.command = None
        self.roll_pid.reset()
        self.pitch_pid.reset()
        self.filter.reset()

    def reset(self):
        """Reset."""
        self.prepare()
        self.calibrate()

    def prepare(self):
        """Prepare."""
        self.running = None
        self._end_sway()
        self._platform_to(LEVEL, force=True)
        L.event("ACTION", "platform level")
        self.robot.stand()
        self.on_stand()

    def _start_time(self):
        """Start time."""
        if self.link is not None and self.link.linked:
            return time.time()
        return self.key_time

    def stop_idle(self):
        """Stop idle."""
        if self.sway is not None:
            self._end_sway()
            self._platform_to(self.platform.pose, force=True)
            L.event("STATE", f"platform held at {pose_text(self.platform.pose)}, "
                             f"balance {'ON' if self.balance_on else 'OFF'}")
            return
        L.event("STATE", f"nothing running; platform held at {pose_text(self.platform.pose)}")

    def before_action(self):
        """Before action."""
        self.note = None
        self.popup = None
        self.key_time = time.time()

    def after_stop(self):
        """After stop."""
        self.running = None
        self.robot.sync_from_motion()
        self.command = None
        self.filter.reset()
        self._platform_to(self.platform.pose, force=True)
        L.event("STATE", f"platform held at {pose_text(self.platform.pose)}, "
                         f"balance {'ON' if self.balance_on else 'OFF'}")

    def on_loop(self):
        """On loop."""
        now = time.time()
        if self.sway is not None:
            self._sway_step(now)
        self._control_step(now)
        if self.sway is not None and self.sway_seg is not None:
            self.sway_rows.append((now - self.sway_seg_start,) + tuple(self.angles))
        interval = self.s["LOG_INTERVAL_SEC"]
        if interval and now - self.last_log >= interval:
            self.last_log = now
            self.log_state()
        if not self.help_shown and self.screen.due():
            self.show_idle()

    def _control_step(self, now):
        """Control step."""
        dt = min(MAX_DT_SEC, max(0.0, now - self.last_time))
        self.last_time = now
        angles = self.read_imu()
        if angles is not None:
            self.angles = angles
            if self.balance_on:
                self.balance_step(angles, dt)
        if self.link is not None:
            self.link.poll()

    # ------------------------------------------------------------
    # Platform
    # ------------------------------------------------------------
    def _platform_to(self, pose, force=False):
        """Platform to."""
        self.platform.set(pose)
        if self.link is not None:
            self.link.send(self.platform.pose, self.speed.value, force=force)

    def platform_step(self, axis, direction):
        """Platform step."""
        self._end_sway()
        if not self.platform.step_axis(axis, direction):
            L.event("STATE", f"platform {axis} at limit {self.platform.pose[AXES.index(axis)]:+.0f} deg")
            return
        self._platform_to(self.platform.pose)
        p = self.platform.pose
        L.event("ACTION", f"platform roll={p[0]:+.0f}  pitch={p[1]:+.0f}  yaw={p[2]:+.0f} deg")
        self.logged = None

    def platform_level(self):
        """Platform level."""
        self._end_sway()
        self._platform_to(LEVEL)
        L.event("ACTION", "platform level")
        self.logged = None
        self._popup('Platform Level', [
            'Return platform to (0, 0, 0) deg',
            'Why: restart from level after a tilt',
            'Balance ON: body tilts in the opposite direction',
            '        then settles back toward level',
            ('Per platform keypress '
             f"{self.prog['PLATFORM_STEP_DEG']:g}deg · limit ±{self.prog['PLATFORM_LIMIT_DEG']:g}deg", "platform"),
        ], (self._pair_text("pitch"), 'Front/back'), (self._pair_text("roll"), 'Left/right'), (self._pair_text("yaw"), 'Rotation'))

    def platform_speed(self, sign):
        """Platform speed."""
        old = self.speed.value
        changed = self.speed.change(sign)
        if not changed:
            limit = "min" if sign < 0 else "max"
            L.event("STATE", f"platform speed at {limit} {speed_text(old)}")
        else:
            self._platform_to(self.platform.pose, force=True)
            L.event("PARAMETER", f"platform speed {speed_text(old)} -> {speed_text(self.speed.value)}")
        new = speed_text(self.speed.value)
        title = f"Platform speed {speed_text(old)} → {new}" if changed else \
            f"Platform speed {new} ({'Minimum speed' if sign < 0 else 'Maximum speed'})"
        self._popup(title, [
            'Servo speed = component speed × multiplier',
            'Faster: abrupt tilt; larger peak',
            'Slower: easier PID response; smaller peak',
            (f"Per step {self.speed.step:g} · range {speed_text(PLATFORM_SPEED_MIN)} ~ {speed_text(PLATFORM_SPEED_MAX)}", "platform"),
            'Applies to platform keys and tests 1, 2, 3, 8',
            ('Compare peak tilt in Balance Test 2', "hint"),
        ], ("PLATFORM_SLOWER_KEY", 'Slower'), ("PLATFORM_FASTER_KEY", 'Faster'), ("TEST_KEY", 'Balance Test'))

    # ------------------------------------------------------------
    # IMU
    # ------------------------------------------------------------
    def _imu_failed(self, error):
        L.event("WARN", f"no IMU on port {ports.PORT_INERTIAL_SENSOR}: balance and tests off")
        L.more(str(error))
        self.imu = None
        self.balance_on = False
        self.note = f"No IMU (Port {ports.PORT_INERTIAL_SENSOR})"

    def _need_imu(self):
        if self.imu is None:
            self.note = f"No IMU (Port {ports.PORT_INERTIAL_SENSOR})"
            L.event("WARN", "no IMU: cannot run this")
            return False
        return True

    def read_imu(self):
        """Read IMU."""
        if self.imu is None:
            return None
        try:
            return self.filter.update(self.imu.read())
        except Exception as e:
            self._imu_failed(e)
            return None

    def read_imu_average(self):
        """Read IMU average."""
        total = [0.0, 0.0, 0.0]
        for _ in range(IMU_TEST_SAMPLES):
            for i, value in enumerate(self.imu.read()):
                total[i] += value
            time.sleep(IMU_TEST_SAMPLE_SEC)
        return tuple(t / IMU_TEST_SAMPLES for t in total)

    def calibrate(self):
        """Calibrate."""
        if self.imu is None:
            return
        time.sleep(IMU_SETTLE_SEC)
        L.event("STATE", "IMU zero: keep the robot and the platform still")
        try:
            zero = self.imu.calibrate(self.s["CALIBRATION_SAMPLES"], still_deg=self.s["IMU_STILL_DEG"])
        except Exception as e:
            self._imu_failed(e)
            return
        self.filter.reset()
        self.angles = (0.0, 0.0, 0.0)
        self.logged = None
        L.event("SENSOR", f"zero  {L.angles_text(zero)}")
        L.more(f"still after {self.imu.wait_sec:.1f} s  spread={self.imu.spread:.2f} deg")
        again = f"press {self._console_key('STAND_KEY')} (reset) again"
        if not self.imu.settled:
            L.event("WARN", f"IMU not still after {STILL_TIMEOUT_SEC:g} s "
                            f"(IMU_STILL_DEG={self.s['IMU_STILL_DEG']:g})")
            L.more(f"keep the robot still and {again}")
        elif self.imu.spread > ZERO_SPREAD_WARN_DEG:
            L.event("WARN", f"IMU moved {self.imu.spread:.1f} deg while zeroing")
            L.more(f"keep the robot still and {again}")
        if any(ZERO_TILT_WARN_DEG < abs(v) < 180.0 - ZERO_TILT_WARN_DEG for v in zero[:2]):
            L.event("WARN", "large tilt at zero: is the platform level?")
            L.more(f"level the platform and {again}")

    def toggle_balance(self):
        """Toggle balance."""
        self.set_balance(not self.balance_on)
        p = self.platform.pose
        now = f"Platform now R {p[0]:+.0f} · P {p[1]:+.0f} · Y {p[2]:+.0f}"
        if self.balance_on:
            self._popup('Balance OFF → ON', [
                'IMU → PID → leg height → level body',
                'Target: body roll 0°, pitch 0°',
                'Correction: tilt body opposite the platform',
                'Why: see the feedback difference by toggling',
                (now, "platform"),
                ('Use platform keys to test tilt; 8 for continuous sway', "hint"),
            ], ("BALANCE_KEY", "OFF"), (self._pair_text("roll"), 'Platform'), ("SWAY_KEY", 'Sway'))
        elif self.imu is not None:
            self._popup('Balance ON → OFF', [
                'Stop PID and return to standing pose',
                'Body tilts with the platform',
                'Roll / Pitch follow platform tilt',
                'Why: compare against no balance control',
                (now, "platform"),
                ('Turn ON again: body returns toward level', "hint"),
            ], ("BALANCE_KEY", "ON"), (self._pair_text("roll"), 'Platform'), ("SWAY_KEY", 'Sway'))

    def set_balance(self, on):
        """Set balance."""
        if on and not self._need_imu():
            return
        if on:
            self.roll_pid.reset()
            self.pitch_pid.reset()
            self.filter.reset()
            self.balance_on = True
            self.last_time = time.time()
            self.note_logged = {}
            L.event("STATE", "balance ON  target roll=0 pitch=0 deg")
            L.event("PARAMETER", self._gain_text())
        else:
            self.balance_on = False
            L.event("STATE", "balance OFF -> stand pose")
            self.robot.stand()
            self.on_stand()
        self.logged = None

    def change_gain(self, name, sign):
        """Change gain."""
        levels = self.levels[name]
        old = self.gains[name]
        new = next_level(levels, old, sign)
        if new is None:
            L.event("STATE", f"{name} at {'max' if sign > 0 else 'min'} {old:g}")
            new = old
        else:
            self.gains[name] = new
            for pid in (self.roll_pid, self.pitch_pid):
                pid.set_gains(**{name.lower(): new})
            L.event("PARAMETER", f"{name} {old:g} -> {new:g}  (level {levels.index(new) + 1}/{len(levels)})")
        self._gain_popup(name, old, new, sign)

    def _gain_popup(self, name, old, new, sign):
        """Gain popup."""
        letter, formula, big, small = GAIN_INFO[name]
        if new != old:
            title = f"{name} {old:g} → {new:g}"
        else:
            title = f"{name} {new:g} ({'Highest level' if sign > 0 else 'Lowest level'})"
        if not self.balance_on:
            state = ('Balance OFF: press 4 to see feedback', "alert")
        else:
            state = (f"Current correction roll {self.corrections[0]:+.1f} · pitch {self.corrections[1]:+.1f}", "out")
        tip = ('Compare peak and final tilt in sway logs', "hint") if self.sway is not None else \
            ('8 Continuous Sway: compare without stopping', "hint")
        up, down = (next((k for k, s in self._gain_keys().get(name, []) if s == d), "?") for d in (1, -1))
        self._popup(title, [
            f"{letter} = {name} × {formula}",
            big,
            small,
            (f"level {level_text(self.levels[name], new)}", "platform"),
            state,
            tip,
        ], (up, 'Increase'), (down, 'Decrease'), ("BALANCE_KEY", 'Balance'), ("SWAY_KEY", 'Sway'))

    def toggle_sway(self):
        """Toggle sway."""
        if self.sway is not None:
            self._end_sway()
            self._platform_to(LEVEL)
            L.event("ACTION", "platform level")
            self._popup('8 Continuous Sway OFF', [
                'Level the platform',
                'Current PID gains remain unchanged',
                (f"Current KP {self.gains['KP']:g} · KI {self.gains['KI']:g} · KD {self.gains['KD']:g}", "platform"),
                'Record good gains in start-script KP / KI / KD',
                ('Repeat Balance Test 2 under the same conditions', "hint"),
            ], ("SWAY_KEY", 'Turn back ON'), ("TEST_KEY", 'Balance Test'))
            return
        if not self._need_imu():
            return
        if self.robot.interrupted:
            L.event("STATE", "moving to stand pose before sway")
            self.prepare()
        t0 = self._start_time()
        if not self.balance_on:
            self.set_balance(True)
        self.sway = ScenarioRun("sway", scenario("sway", self.prog), t0, loop=True)
        self.sway_index = None
        self.sway_seg = None
        self.sway_last = None
        hold = self.prog["SWAY_HOLD_SEC"]
        n = len(self.prog["TEST_POSES"])
        L.event("TASK", f"sway: {n} platform poses, {hold:g} s each, repeating")
        L.more("per pose: max/end tilt and PID (* = changed)")
        L.more(f"PID keys work live. Stop: {L.keys([self._key(k) for k in ('SWAY_KEY', 'STOP_KEY', 'STAND_KEY')])}")
        self._popup('8 Continuous Sway ON', [
            f"Platform {n}poses {hold:g}seconds each, repeated continuously",
            'Balance ON · PID keys take effect immediately',
            'Why: compare values while motion continues',
            'Bottom row: previous pose peak and final tilt',
            ('Console [METRIC] sway: results for each pose', "hint"),
            ('Stop: 8, F3, F2, 5, or platform keys', "text"),
        ], *self._gain_pairs(), ("SWAY_KEY", 'Stopped'))

    def _sway_step(self, now):
        """Sway step."""
        i, seg = self.sway.at(now)
        if i == self.sway_index:
            return
        if self.sway_seg is not None:
            self._sway_report()
        self.sway_index = i
        self.sway_seg = seg
        self.sway_rows = []
        self.sway_seg_start = now
        self.sway_gain_text = self._gain_short()
        self._platform_to(seg.pose)
        self.logged = None

    def _sway_report(self):
        """Sway report."""
        stats = self._segment_stats(self.sway_rows, self.prog["SWAY_HOLD_SEC"])
        if stats is None:
            return
        mx, end = stats[0], stats[1]
        label = self.sway_seg.label
        self.sway_last = ('Level' if label == "level" else label, mx, end)
        gains = self.sway_gain_text if self.sway_gain_text == self._gain_short() else f"{self.sway_gain_text} *"
        L.event("METRIC", f"sway {label:<9} max {mx:4.1f} end {end:4.1f}  {gains}")

    def _end_sway(self):
        """End sway."""
        if self.sway is None:
            return
        self.sway = None
        self.sway_seg = None
        self.sway_last = None
        L.event("TASK", "sway stopped")

    def pose_feet(self, roll=0.0, pitch=0.0, yaw=0.0):
        """Pose feet."""
        pose = zero_pose()
        pose["x"] = -self.s["FEET_FORWARD"]
        pose["roll"], pose["pitch"], pose["yaw"] = roll, pitch, yaw
        feet = body_pose_feet(pose, self.s["BODY_HEIGHT"], self.s["BODY_LENGTH"], self.s["BODY_WIDTH"])
        for leg, point in enumerate(feet):
            r = check_point(self.motion, leg, point)
            name = ports.LEG_NAMES[leg]
            if not r["ok"]:
                return feet, (f"{name} unreachable", f"{name} foot {r['reason']}")
            if r["limited"]:
                return feet, (f"{name} {'·'.join(r['limited'])} limit",
                              f"{name} {' '.join(r['limited'])} at 0/180 deg limit")
        return feet, None

    def balance_step(self, angles, dt):
        """Balance step."""
        roll, pitch, _ = angles
        saved = (self.roll_pid.integral, self.pitch_pid.integral)
        roll_c = self.roll_pid.update(roll, dt)
        pitch_c = self.pitch_pid.update(pitch, dt)
        feet, problem = self.pose_feet(roll_c, pitch_c)
        if problem:
            self.roll_pid.integral, self.pitch_pid.integral = saved
            self._set_note(f"{problem[0]} · correction held", f"{problem[1]}: correction held")
            return
        limit = self.s["MAX_CORRECTION_DEG"]
        at_limit = [name for name, c in (("roll", roll_c), ("pitch", pitch_c)) if abs(c) >= limit - 1e-6]
        if at_limit:
            self._set_note(f"{' · '.join(at_limit)} correction limit {limit}deg",
                           f"{'+'.join(at_limit)} correction at max {limit:g} deg")
        else:
            self._set_note()
        for leg in range(4):
            self.motion.points[leg] = list(feet[leg])
        self.motion.run()
        self.robot.sync_from_motion()
        self.corrections = (roll_c, pitch_c)
        self.legs = self.leg_changes(feet)

    def leg_changes(self, feet):
        """Leg changes."""
        h = self.s["BODY_HEIGHT"]
        length = [-feet[leg][2] - h for leg in range(4)]

        def mean(legs):
            return sum(length[leg] for leg in legs) / len(legs)
        return (mean(ports.FRONT_LEGS), mean(ports.HIND_LEGS), mean(ports.LEFT_LEGS), mean(ports.RIGHT_LEGS))

    def _state_text(self):
        """State text."""
        p = self.platform.pose
        a = self.angles
        text = f"platform {p[0]:+3.0f} {p[1]:+3.0f}  body {L.signed(a[0])} {L.signed(a[1])}"
        if self.balance_on:
            text += f"  corr {L.signed(self.corrections[0])} {L.signed(self.corrections[1])}"
        return text

    def log_state(self):
        """Log state."""
        if self.imu is None:
            return
        values = tuple(self.angles[:2]) + (tuple(self.corrections) if self.balance_on else (0.0, 0.0))
        if self.logged is not None and self.logged[0] == self.platform.pose \
                and max(abs(a - b) for a, b in zip(values, self.logged[1])) < LOG_CHANGE_DEG:
            return
        self.logged = (self.platform.pose, values)
        L.event("SENSOR", self._state_text())
        if not self.balance_on:
            return
        if not self.s["LOG_DETAIL"]:
            return
        for axis, pid in (("roll", self.roll_pid), ("pitch", self.pitch_pid)):
            L.more(f"PID {axis:<5} P={L.signed(pid.p)}  I={L.signed(pid.i)}  D={L.signed(pid.d)}")
        if self.legs is not None:
            f, b, left, right = self.legs
            L.more(f"legs  front={L.signed(f)} hind={L.signed(b)} left={L.signed(left)} right={L.signed(right)}")

    def _segment_stats(self, rows, hold):
        """Segment stats."""
        if not rows:
            return None
        tilts = [(t, tilt_of(r, p)) for t, r, p, _ in rows]
        end_rows = [row for row in rows if row[0] >= hold - MEASURE_SEC] or rows[-1:]
        end = tuple(sum(row[k] for row in end_rows) / len(end_rows) for k in (1, 2, 3))
        over = [t for t, tilt in tilts if tilt > self.s["SETTLE_DEG"]]
        if not over:
            settle = 0.0
        else:
            after = [t for t, _ in tilts if t > max(over)]
            settle = after[0] if after else None
        return max(v for _, v in tilts), tilt_of(end[0], end[1]), end, settle

    def direction_check(self):
        """Direction check."""
        if not self._need_imu():
            return
        self._end_sway()
        t0 = self._start_time()
        deg = self.prog["CHECK_DEG"]
        hold = self.prog["CHECK_HOLD_SEC"]
        self._popup(f"1 Direction Check · approx. {round(hold * 10.5 + 2)}s", [
            f"Platform ±{deg:g}deg: does robot IMU follow the same sign?",
            f"Body ±{deg:g}deg: does IMU agree with the command?",
            'Why: a reversed sign makes balance worse',
            'Run with balance OFF (platform, then body)',
            ('Results: see console direction check result', "hint"),
            ('All three axes OK → proceed to Balance Test 2', "text"),
        ], ("STOP_KEY", 'Stopped'), ("STAND_KEY", 'Reset'))
        if self.balance_on:
            self.set_balance(False)
        self.running = "check"
        run = ScenarioRun("check", scenario("check", self.prog), t0)
        L.event("TASK", f"direction check 1/2: platform +-{deg:g} deg, balance OFF")
        L.event("METRIC", f"{'platform':<12}  {'imu roll':>9}  {'pitch':>5}  {'yaw':>5}  {'diff':>5}")
        segs = run.segments

        def on_segment(i, seg):
            if i > 0:
                self._check_line(segs[i - 1], samples_ref.get(i - 1), hold, platform_results)

        platform_results = {}
        samples_ref = {}
        samples = self._run_collect(run, on_segment, 'Direction Check', samples_ref)
        last = len(segs) - 2
        self._check_line(segs[last], samples.get(last), hold, platform_results)

        self.robot.wait(CHECK_LEVEL_SEC)
        L.event("TASK", f"direction check 2/2: body +-{deg:g} deg, platform level")
        L.event("METRIC", f"{'body':<12}  {'imu roll':>9}  {'pitch':>5}  {'yaw':>5}  {'diff':>5}")
        body_results = self._body_check(deg)
        self.running = None
        self._check_result(platform_results, body_results, deg)

    def _run_collect(self, run, on_segment, label, store):
        """Run collect."""
        samples = store
        index = None
        while True:
            now = time.time()
            i, seg = run.at(now)
            if i is None:
                break
            if i != index:
                index = i
                self._platform_to(seg.pose)
                on_segment(i, seg)
            self._control_step(now)
            samples.setdefault(i, []).append((now - run.t0 - seg.start,) + tuple(self.angles))
            if self.screen.due():
                self.show_running(self._progress(run, i, seg, label))
            self.robot.check_stop()
            time.sleep(self.s["LOOP_SLEEP_SEC"])
        self._platform_to(LEVEL)
        return samples

    @staticmethod
    def _progress(run, i, seg, label):
        """Progress."""
        if seg.phase in ("lead", "gap"):
            return f"{label} Prepare · level platform"
        same = [s for s in run.segments if s.phase == seg.phase]
        done = sum(1 for s in run.segments[:i + 1] if s.phase == seg.phase)
        phase = f" {seg.phase.upper()}" if seg.phase in ("off", "on") and run.name == "compare" else ""
        pose = 'Level' if seg.label == "level" else seg.label
        return f"{label}{phase} {done}/{len(same)} · platform {pose}"

    def _check_line(self, seg, rows, hold, results):
        """Check line."""
        stats = self._segment_stats(rows or [], hold)
        if stats is None:
            return
        end = stats[2]
        axis = next(a for a, v in zip(AXES, seg.pose) if v != 0)
        i = AXES.index(axis)
        sign = 1 if seg.pose[i] > 0 else -1
        results[(axis, sign)] = end
        L.more(f"{seg.label:<12}  {L.signed(end[0], 9)}  {L.signed(end[1])}  {L.signed(end[2])}  "
               f"{L.signed(end[i] - seg.pose[i])}")

    def _body_check(self, deg):
        """Body check."""
        s = self.s
        level_feet, _ = self.pose_feet()
        results = {}
        for axis in AXES:
            for sign in (1, -1):
                target = {a: 0.0 for a in AXES}
                target[axis] = sign * deg
                feet, problem = self.pose_feet(**target)
                label = f"{axis} {sign * deg:+g}"
                if problem:
                    L.more(f"{label:<12}  skipped: {problem[1]}")
                    continue
                self.command = tuple(target[a] for a in AXES)
                self.show_running(f"Direction Check · body {label}")
                self.motion.move_to([list(p) for p in feet], s["CHECK_MOVE_STEPS"])
                self.robot.sync_from_motion()
                self.robot.wait(self.prog["CHECK_HOLD_SEC"] / 2)
                measured = self.read_imu_average()
                results[(axis, sign)] = measured
                diff = measured[AXES.index(axis)] - target[axis]
                L.more(f"{label:<12}  {L.signed(measured[0], 9)}  {L.signed(measured[1])}  "
                       f"{L.signed(measured[2])}  {L.signed(diff)}")
                self.angles = measured
                self.show_running(f"Direction Check · body {label}")
                self.command = (0.0, 0.0, 0.0)
                self.motion.move_to([list(p) for p in level_feet], s["CHECK_MOVE_STEPS"])
                self.robot.sync_from_motion()
                self.robot.wait(self.prog["CHECK_HOLD_SEC"] / 4)
        self.command = None
        self.robot.stand()
        self.filter.reset()
        return results

    @staticmethod
    def judge(axis, results, deg):
        """Judge."""
        i = AXES.index(axis)
        got = [(sign, results[(axis, sign)]) for sign in (1, -1) if (axis, sign) in results]
        if not got:
            return "SKIP", ""
        own = [sign * m[i] for sign, m in got]
        other = [max(abs(m[j]) for j in range(3) if j != i) for _, m in got]
        half = deg / 2
        values = " / ".join(L.signed(m[i], 0) for _, m in got)
        if all(abs(m[i]) < half for _, m in got) and all(o >= half for o in other):
            return "OTHER", values
        if all(v >= half for v in own):
            return "OK", values
        if all(v <= -half for v in own):
            return "REVERSED", values
        if all(abs(m[i]) < half for _, m in got):
            return "NONE", values
        return "UNCLEAR", values

    def _check_result(self, platform_results, body_results, deg):
        """Check result."""
        L.event("METRIC", "direction check result  (platform servo / robot IMU)")
        all_ok = True
        for axis in AXES:
            platform, pv = self.judge(axis, platform_results, deg)
            body, bv = self.judge(axis, body_results, deg)
            sign_name = SIGN_NAMES[axis]
            servo_name = SERVO_SIGN_NAMES[axis]
            fix = []
            if body == "OK" and platform == "OK":
                text = "OK"
            elif body == "OTHER":
                text, fix = "robot IMU axes swapped", ["SWAP_ROLL_PITCH = True (this file)"]
            elif body == "NONE":
                text, fix = "robot IMU did not change", [f"check IMU port 1, then {self._console_key('STAND_KEY')} reset"]
            elif platform == "NONE":
                text, fix = "platform did not move", ["platform script running? (README 11.1)"]
            elif platform == "OTHER":
                text, fix = "platform moved another axis", ["check platform servo ports (README 8.1)"]
            elif body == "OK" and platform == "REVERSED":
                text, fix = "platform servo reversed", [f"platform start file {servo_name} = -1"]
            elif body == "REVERSED" and platform == "REVERSED":
                text, fix = "robot IMU reversed", [f"{sign_name} = -1 (this file)"]
            elif body == "REVERSED" and platform == "OK":
                text, fix = "robot IMU and platform servo reversed", [f"{sign_name} = -1 (this file)",
                                                                   f"platform start file {servo_name} = -1"]
            elif "SKIP" in (body, platform):
                text = "not checked (pose unreachable)"
            else:
                text = f"unclear: run {self._console_key('CHECK_KEY')} again"
            if text != "OK":
                all_ok = False
            L.more(f"{axis:<6}{text}")
            for line in fix:
                L.more(f"      -> {line}")
            L.more(f"      platform {pv or '-'}   body {bv or '-'}")
        if all_ok:
            self._next(f"press {self._console_key('TEST_KEY')} (balance test)",
                       f"Next: {self._key('TEST_KEY')} Balance Test")
        else:
            self._next("fix the values above, run again, then press "
                       f"{self._console_key('CHECK_KEY')}", f"After fixing direction, rerun {self._key('CHECK_KEY')}")

    def balance_test(self):
        """Balance test."""
        if not self._need_imu():
            return
        self._end_sway()
        t0 = self._start_time()
        self.running = "test"
        n = len(self.prog["TEST_POSES"])
        hold_sec = self.prog["TEST_HOLD_SEC"]
        g = self.gains
        self._popup(f"2 Balance Test · approx. {round(1 + n * hold_sec)}s", [
            f"Balance ON · platform {n}poses {hold_sec:g}seconds each",
            'Per pose: peak, final tilt, settling time',
            'Why: compare PID changes under identical conditions',
            (f"Current KP {g['KP']:g} · KI {g['KI']:g} · KD {g['KD']:g}", "platform"),
            ('Result: console table; balance test n/8 OK', "hint"),
            ('Change one value, repeat 2, compare tables', "text"),
        ], ("STOP_KEY", 'Stopped'), ("STAND_KEY", 'Reset'))
        run = ScenarioRun("test", scenario("test", self.prog), t0)
        if not self.balance_on:
            self.set_balance(True)
        hold = self.prog["TEST_HOLD_SEC"]
        L.event("TASK", f"balance test: {len(self.prog['TEST_POSES'])} platform poses, "
                        f"{hold:g} s each")
        L.event("METRIC", f"{'#':>2} {'platform':<14} {'max':>5} {'end':>5} {'settle':>7}  result")
        segs = run.segments
        results = []
        store = {}

        def report(i):
            seg = segs[i]
            if seg.phase != "on":
                return
            stats = self._segment_stats(store.get(i, []), hold)
            if stats is None:
                return
            results.append((seg, stats))
            self._result_line(len(results), seg, stats)

        def on_segment(i, seg):
            if i > 0:
                report(i - 1)

        self._run_collect(run, on_segment, 'Balance Test', store)
        report(len(segs) - 2)
        self.running = None
        self._test_summary(results)
        self._next(f"press {self._console_key('COMPARE_KEY')} (compare), or change PID and press "
                   f"{self._console_key('TEST_KEY')}",
                   f"Next: {self._key('COMPARE_KEY')} compare · change PID and {self._key('TEST_KEY')}")

    def _result_line(self, n, seg, stats):
        mx, end, _, settle = stats
        ok = "OK" if end <= self.s["LEVEL_OK_DEG"] else "TILTED"
        st = "-" if settle is None else f"{settle:.1f} s"
        L.more(f"{n:>2} {seg.label:<14} {mx:5.1f} {end:5.1f} {st:>7}  {ok}")

    def _test_summary(self, results):
        if not results:
            return
        n_ok = sum(1 for _, st in results if st[1] <= self.s["LEVEL_OK_DEG"])
        worst = max(st[0] for _, st in results)
        mean_end = sum(st[1] for _, st in results) / len(results)
        settles = [st[3] for _, st in results if st[3] is not None]
        L.event("METRIC", f"balance test {n_ok}/{len(results)} OK  "
                          f"(end tilt <= {self.s['LEVEL_OK_DEG']:g} deg)")
        L.more(f"worst max {worst:.1f} deg   mean end {mean_end:.1f} deg")
        if settles:
            L.more(f"mean settle {sum(settles) / len(settles):.1f} s  "
                   f"(tilt <= {self.s['SETTLE_DEG']:g} deg)")
        L.more(self._gain_text())

    def compare_test(self):
        """Compare test."""
        if not self._need_imu():
            return
        self._end_sway()
        t0 = self._start_time()
        self.running = "compare"
        n = len(self.prog["TEST_POSES"])
        hold_sec = self.prog["TEST_HOLD_SEC"]
        self._popup(f"3 Comparison · approx. {round(1 + 2 * n * hold_sec + 2)}s", [
            'Repeat the same platform motion twice',
            'Balance OFF first, then Balance ON',
            'OFF: body follows platform tilt',
            'ON: PID levels the body',
            'Why: quantify the tilt removed by feedback',
            ('Result: console mean OFF → ON', "hint"),
        ], ("STOP_KEY", 'Stopped'), ("STAND_KEY", 'Reset'))
        run = ScenarioRun("compare", scenario("compare", self.prog), t0)
        if self.balance_on:
            self.set_balance(False)
        hold = self.prog["TEST_HOLD_SEC"]
        L.event("TASK", "compare: same platform poses, balance OFF then ON")
        segs = run.segments
        ends = {"off": [], "on": []}
        store = {}

        def report(i):
            seg = segs[i]
            if seg.phase not in ends:
                return
            stats = self._segment_stats(store.get(i, []), hold)
            if stats is not None:
                ends[seg.phase].append((seg, stats))

        def on_segment(i, seg):
            if i > 0:
                report(i - 1)
            if seg.phase in ("lead", "off") and self.balance_on:
                self.set_balance(False)
            elif seg.phase in ("gap", "on") and not self.balance_on:
                L.event("TASK", "compare: balance ON pass")
                self.set_balance(True)

        self._run_collect(run, on_segment, 'Compare', store)
        report(len(segs) - 2)
        self.running = None
        L.event("METRIC", "compare: body tilt at the end of each pose (deg)")
        L.more(f"{'platform':<14} {'OFF':>6} {'ON':>6}  less tilt")
        off_sum = on_sum = 0.0
        for (seg, off), (_, on) in zip(ends["off"], ends["on"]):
            off_sum += off[1]
            on_sum += on[1]
            less = f"{(1 - on[1] / off[1]) * 100:5.0f}%" if off[1] >= 1.0 else "    -"
            L.more(f"{seg.label:<14} {off[1]:6.1f} {on[1]:6.1f}  {less}")
        count = len(ends["on"])
        if count:
            L.more(f"mean OFF {off_sum / count:.1f} deg -> ON {on_sum / count:.1f} deg")
        L.more(self._gain_text())
        self._next(f"change PID ({self._gain_key_text()}) and press {self._console_key('TEST_KEY')}",
                   f"Next: change PID and {self._key('TEST_KEY')}")

# -*- coding: utf-8 -*-
"""q01lib_platform_program: Educational library module for the QUAD-01 RoboCo series.

Tilt-platform servo control and microcontroller messaging."""

AXES = ("roll", "pitch", "yaw")
LEVEL = (0.0, 0.0, 0.0)

LEAD_SEC = 1.0
GAP_SEC = 2.0

DEFAULTS = {
    "PLATFORM_STEP_DEG": 15,
    "PLATFORM_LIMIT_DEG": 15,
    "CHECK_DEG": 15,
    "CHECK_HOLD_SEC": 2.0,
    "TEST_POSES": [(15, 0, 0), (0, 0, 0), (-15, 0, 0), (0, 0, 0),
                   (0, 15, 0), (0, 0, 0), (0, -15, 0), (0, 0, 0)],
    "TEST_HOLD_SEC": 3.0,
    "SWAY_HOLD_SEC": 2.0,
    "PLATFORM_KEYS": {"w": ("pitch", 1), "s": ("pitch", -1), "a": ("roll", -1),
                   "d": ("roll", 1), "q": ("yaw", 1), "e": ("yaw", -1)},
    "CHECK_KEY": "1",
    "TEST_KEY": "2",
    "COMPARE_KEY": "3",
    "LEVEL_KEY": "5",
    "SWAY_KEY": "8",
    "PLATFORM_SPEED": 2.0,
    "PLATFORM_SPEED_STEP": 0.2,
    "PLATFORM_SLOWER_KEY": "6",
    "PLATFORM_FASTER_KEY": "7",
    "STAND_KEY": "f2",
    "STOP_KEY": "f3",
}

PLATFORM_SPEED_MIN = 0.4
PLATFORM_SPEED_MAX = 4.0

DIRECTION_EN = {
    ("roll", 1): "right down", ("roll", -1): "left down",
    ("pitch", 1): "front down", ("pitch", -1): "front up",
    ("yaw", 1): "turn left", ("yaw", -1): "turn right",
}
DIRECTION_KO = {
    ("roll", 1): 'Right side down', ("roll", -1): 'Left side down',
    ("pitch", 1): 'Front down', ("pitch", -1): 'Front up',
    ("yaw", 1): 'Turn left', ("yaw", -1): 'Turn right',
}


def settings_from(values):
    """Settings from."""
    s = dict(DEFAULTS)
    for name in DEFAULTS:
        if name in values:
            s[name] = values[name]
    return s


def check_platform_keys(platform_keys):
    """Check platform keys."""
    for key, item in platform_keys.items():
        if not (isinstance(item, (tuple, list)) and len(item) == 2
                and item[0] in AXES and item[1] in (1, -1)):
            raise ValueError(f"PLATFORM_KEYS '{key}': use (\"roll\" | \"pitch\" | \"yaw\", 1 | -1)")


def changed_from_defaults(s):
    """Changed from defaults."""
    return [name for name in DEFAULTS if s.get(name) != DEFAULTS[name]]


def pose_text(pose):
    """Pose text."""
    parts = [f"{axis} {round(v):+d}" for axis, v in zip(AXES, pose) if round(v) != 0]
    return " ".join(parts) if parts else "level"


class PlatformPose:
    """Platform Pose."""

    def __init__(self, step_deg, limit_deg):
        self.step = step_deg
        self.limit = limit_deg
        self.pose = LEVEL

    def clamp(self, value):
        return max(-self.limit, min(self.limit, value))

    def set(self, pose):
        """Set."""
        new = tuple(float(self.clamp(v)) for v in pose)
        changed = new != self.pose
        self.pose = new
        return changed

    def step_axis(self, axis, direction):
        """Step axis."""
        pose = list(self.pose)
        i = AXES.index(axis)
        pose[i] = self.clamp(pose[i] + direction * self.step)
        return self.set(pose)


class PlatformSpeed:
    """Platform Speed."""

    def __init__(self, value, step):
        self.step = step
        self.value = self.clamp(value)

    @staticmethod
    def clamp(value):
        return round(max(PLATFORM_SPEED_MIN, min(PLATFORM_SPEED_MAX, float(value))), 2)

    def set(self, value):
        """Set."""
        new = self.clamp(value)
        changed = new != self.value
        self.value = new
        return changed

    def change(self, sign):
        """Change."""
        return self.set(self.value + sign * self.step)


def speed_text(value):
    """Speed text."""
    return f"x{value:.1f}" if abs(value * 10 - round(value * 10)) < 1e-6 else f"x{value:.2f}"


class Segment:
    """Segment."""

    def __init__(self, start, end, pose, phase):
        self.start = start
        self.end = end
        self.pose = tuple(float(v) for v in pose)
        self.phase = phase           # "check" · "lead" · "off" · "gap" · "on" · "end"
        self.label = pose_text(self.pose)


def scenario(name, s):
    """Scenario."""
    segments = []
    t = 0.0

    def add(pose, hold, phase):
        nonlocal t
        segments.append(Segment(t, t + hold, pose, phase))
        t += hold

    if name == "check":
        deg = s["CHECK_DEG"]
        for i, axis in enumerate(AXES):
            for sign in (1, -1):
                pose = [0.0, 0.0, 0.0]
                pose[i] = sign * deg
                add(pose, s["CHECK_HOLD_SEC"], "check")
    elif name == "test":
        add(LEVEL, LEAD_SEC, "lead")
        for pose in s["TEST_POSES"]:
            add(pose, s["TEST_HOLD_SEC"], "on")
    elif name == "sway":
        for pose in s["TEST_POSES"]:
            add(pose, s["SWAY_HOLD_SEC"], "sway")
    elif name == "compare":
        add(LEVEL, LEAD_SEC, "lead")
        for pose in s["TEST_POSES"]:
            add(pose, s["TEST_HOLD_SEC"], "off")
        add(LEVEL, GAP_SEC, "gap")
        for pose in s["TEST_POSES"]:
            add(pose, s["TEST_HOLD_SEC"], "on")
    else:
        raise ValueError(f"unknown scenario {name}")
    segments.append(Segment(t, t, LEVEL, "end"))
    return segments


class ScenarioRun:
    """Scenario Run."""

    def __init__(self, name, segments, t0, loop=False):
        self.name = name
        self.segments = segments
        self.t0 = t0
        self.loop = loop
        self.period = segments[-1].start
        self.end_time = t0 + self.period

    def at(self, now):
        t = now - self.t0
        if self.loop and self.period > 0:
            lap, t = divmod(max(0.0, t), self.period)
            for i, seg in enumerate(self.segments[:-1]):
                if t < seg.end:
                    return int(lap) * (len(self.segments) - 1) + i, seg
            return int(lap + 1) * (len(self.segments) - 1), self.segments[0]
        for i, seg in enumerate(self.segments[:-1]):
            if t < seg.end:
                return i, seg
        return None, None

    def done(self, now):
        return not self.loop and now >= self.end_time

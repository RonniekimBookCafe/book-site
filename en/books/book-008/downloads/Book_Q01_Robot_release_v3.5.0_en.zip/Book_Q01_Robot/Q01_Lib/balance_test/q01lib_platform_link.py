# -*- coding: utf-8 -*-
"""q01lib_platform_link: Educational library module for the QUAD-01 RoboCo series.

Tilt-platform servo control and microcontroller messaging."""

import time

from ports import Port
from controllables import MicroController
from scriptruntime import Runtime

HEARTBEAT_SEC = 1.0


def find_mcu_port(port=None):
    """Find mcu port."""
    candidates = [port] if port is not None else Port.ports()
    for p in candidates:
        try:
            if Port.port_type(p) is MicroController:
                return p
        except Exception:
            pass
    return None


def pose_message(kind, pose, speed=None):
    """Pose message."""
    text = f"{kind} " + " ".join(f"{round(float(v), 1) + 0.0:.1f}" for v in pose)
    return text if speed is None else f"{text} {float(speed):.2f}"


def parse_message(text):
    """Parse message."""
    parts = str(text).split()
    if len(parts) not in (4, 5) or parts[0] not in ("P", "I"):
        return None, None, None
    try:
        values = [float(v) for v in parts[1:]]
    except ValueError:
        return None, None, None
    return parts[0], tuple(values[:3]), (values[3] if len(values) == 4 else None)


class Inbox:
    """Inbox."""

    def __init__(self):
        try:
            self.stream = Runtime.message_stream()
        except Exception:
            self.stream = None

    def read(self):
        """Read."""
        if self.stream is None:
            return []
        out = []
        for text in self.stream:
            kind, pose, speed = parse_message(text)
            if kind:
                out.append((kind, pose, speed))
        return out


class PlatformLink:
    """Platform Link."""

    def __init__(self, port=None):
        self.port = find_mcu_port(port)
        self.mcu = MicroController(self.port) if self.port is not None else None
        self.inbox = Inbox()
        self.pose = None
        self.speed = None
        self.sent_at = 0.0
        self.platform_imu = None
        self.imu_at = 0.0
        self.error = None

    @property
    def linked(self):
        return self.mcu is not None and self.error is None

    def send(self, pose, speed, force=False):
        """Send."""
        now = time.time()
        pose = tuple(float(v) for v in pose)
        if not self.linked:
            self.pose, self.speed = pose, speed
            return
        if force or pose != self.pose or speed != self.speed or now - self.sent_at >= HEARTBEAT_SEC:
            try:
                self.mcu.message(pose_message("P", pose, speed))
            except Exception as e:
                self.error = e
                return
            self.pose, self.speed = pose, speed
            self.sent_at = now

    def poll(self):
        """Poll."""
        for kind, pose, _ in self.inbox.read():
            if kind == "I":
                self.platform_imu = pose
                self.imu_at = time.time()
        if self.pose is not None:
            self.send(self.pose, self.speed)

    def platform_imu_fresh(self, max_age=2.0):
        """Platform IMU fresh."""
        if self.platform_imu is None or time.time() - self.imu_at > max_age:
            return None
        return self.platform_imu

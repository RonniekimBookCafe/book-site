# -*- coding: utf-8 -*-
"""q01lib_pid: Educational library module for the QUAD-01 RoboCo series.

PID error correction: proportional, integral, and derivative gains."""


class PID:
    """PID."""

    def __init__(self, kp, ki, kd, output_limit):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.output_limit = output_limit
        self.reset()

    def reset(self):
        """Reset."""
        self.integral = 0.0
        self.last_error = None
        self.p = self.i = self.d = 0.0

    def set_gains(self, kp=None, ki=None, kd=None):
        """Set gains."""
        if kp is not None:
            self.kp = kp
        if kd is not None:
            self.kd = kd
        if ki is not None:
            if ki == 0 or self.ki == 0:
                self.integral = 0.0
            else:
                self.integral *= self.ki / ki
            self.ki = ki

    def update(self, measured, dt, target=0.0):
        """Update.

Parameters: measured, dt, target."""
        error = target - measured
        limit = self.output_limit

        self.p = self.kp * error

        if self.ki == 0:
            self.integral = 0.0
        else:
            self.integral += error * dt
        self.i = self.ki * self.integral
        if self.i > limit or self.i < -limit:
            self.i = max(-limit, min(limit, self.i))
            self.integral = self.i / self.ki

        if self.last_error is None or dt <= 0:
            self.d = 0.0
        else:
            self.d = self.kd * (error - self.last_error) / dt
        self.last_error = error

        output = self.p + self.i + self.d
        return max(-limit, min(limit, output))

# -*- coding: utf-8 -*-
"""q01lib_platform_app: Educational library module for the QUAD-01 RoboCo series.

Tilt-platform servo control and microcontroller messaging."""

import time

from ports import Port
from controllables import TextScreen, MicroController

from ..core import q01lib_log as L    # Console logging helpers (L.event, L.more, L.key, etc.)
from ..core.q01lib_log import log_traceback
from ..core.q01lib_key_events import KeyEvents
from ..core.q01lib_imu import BodyIMU, STILL_TIMEOUT_SEC
from ..core.q01lib_screen import StatusScreen
from .q01lib_platform import (PlatformAxes, AXES, PLATFORM_IMU_PORT, PLATFORM_SCREEN_PORT,
                              PLATFORM_GUIDE_SCREEN_PORT, SERVO_RPM_MAX)
from .q01lib_platform_program import (DEFAULTS as PROGRAM, LEVEL, DIRECTION_KO, PlatformPose, PlatformSpeed,
                                   ScenarioRun, scenario, speed_text)
from .q01lib_platform_link import Inbox, find_mcu_port, pose_message
from .q01lib_balance_test_screen import page, tag, keys_text

START_FILE = "q01_balance_test_platform_start.py"

DEFAULTS = {
    "TILT_LIMIT_DEG": 15,
    "SERVO_RPM": None,
    "ROLL_SERVO_SIGN": 1,
    "PITCH_SERVO_SIGN": 1,
    "YAW_SERVO_SIGN": -1,
    "USE_IMU": True,
    "IMU_ROLL_SIGN": 1,
    "IMU_PITCH_SIGN": 1,
    "IMU_YAW_SIGN": 1,
    "IMU_SWAP_ROLL_PITCH": False,
    "ZERO_SETTLE_SEC": 1.0,
    "CALIBRATION_SAMPLES": 20,
    "IMU_STILL_DEG": 0.2,
    "ROBOT_MCU_PORT": None,
    "REPORT_SEC": 0.5,
    "LOOP_SLEEP_SEC": 0.02,
    "SCREEN_INTERVAL_SEC": 0.2,
    "PLATFORM_LOG": False,
    "LOG_COLOR": True,
}

LOG_CATEGORIES = ("PARAMETER", "STATE", "ACTION", "WARN", "ERROR")
ZERO_SPREAD_WARN_DEG = 1.0
SCENARIO_KO = {"check": 'Direction Check', "test": 'Balance Test', "compare": 'Compare', "sway": 'Continuous Sway'}
SCREEN_BODY_LINES = 3
GUIDE_BODY_LINES = 5


def _deg(value):
    """Deg."""
    return f"{round(value) + 0:+3d}"


class PlatformApp:
    """Platform App."""

    def __init__(self, script_values: dict):
        """Init."""
        self.ready = False
        try:
            self._setup(script_values)
            self.ready = True
        except Exception as e:
            L.setup_failed(e, START_FILE)

    def log(self, category, text):
        """Log."""
        if self.s["PLATFORM_LOG"] or category in ("WARN", "ERROR"):
            L.event(category, f"platform {text}")

    def _setup(self, script_values: dict):
        s = dict(DEFAULTS)
        for name, value in script_values.items():
            if name in DEFAULTS:
                s[name] = value
        self.s = s
        L.configure(LOG_CATEGORIES, s["LOG_COLOR"])
        self.screen = StatusScreen(port=PLATFORM_SCREEN_PORT, wrap=False)
        self.screen.show(page('Tilt Platform · Starting', [
            tag('Initializing...', "value"),
            tag('1. Level platform → 2. Calibrate platform IMU', "text"),
            tag('Do not touch the platform', "hint"),
        ], tag('Run the robot start script too', "text"), SCREEN_BODY_LINES))
        unknown = [name for name in script_values if name.isupper() and name not in DEFAULTS]
        if unknown:
            L.event("WARN", "unknown names in the start file (check spelling)")
            for name in unknown:
                L.more(name)

        if s["SERVO_RPM"] is not None and not 0 < s["SERVO_RPM"] <= SERVO_RPM_MAX:
            raise ValueError(f"SERVO_RPM {s['SERVO_RPM']}: use None or a value above 0 and up to {SERVO_RPM_MAX}")
        self.axes = PlatformAxes(s["TILT_LIMIT_DEG"], s["ROLL_SERVO_SIGN"], s["PITCH_SERVO_SIGN"],
                                 s["YAW_SERVO_SIGN"], s["SERVO_RPM"])
        if self.axes.read_error is not None:
            self.log("WARN", "cannot read the servo speed: part setting kept")
            L.more(str(self.axes.read_error))
        self.speed = PlatformSpeed(PROGRAM["PLATFORM_SPEED"], PROGRAM["PLATFORM_SPEED_STEP"])
        self.apply_speed()
        self.axes.set(0, 0, 0)

        self.show_guide_screen()

        self.inbox = Inbox()
        robot_port = find_mcu_port(s["ROBOT_MCU_PORT"])
        self.robot_mcu = MicroController(robot_port) if robot_port is not None else None
        self.linked = False
        self.last_report = 0.0

        prog = PROGRAM
        self.prog = prog
        self.target = PlatformPose(prog["PLATFORM_STEP_DEG"], prog["PLATFORM_LIMIT_DEG"])
        self.key_actions = {}
        for key, (axis, direction) in prog["PLATFORM_KEYS"].items():
            self.key_actions[key] = ("step", axis, direction)
        self.key_actions[prog["PLATFORM_SLOWER_KEY"]] = ("speed", -1)
        self.key_actions[prog["PLATFORM_FASTER_KEY"]] = ("speed", 1)
        self.key_actions[prog["CHECK_KEY"]] = ("run", "check")
        self.key_actions[prog["TEST_KEY"]] = ("run", "test")
        self.key_actions[prog["COMPARE_KEY"]] = ("run", "compare")
        self.key_actions[prog["LEVEL_KEY"]] = ("level",)
        self.key_actions[prog["STAND_KEY"]] = ("level",)
        self.key_actions[prog["STOP_KEY"]] = ("stop",)
        self.key_actions[prog["SWAY_KEY"]] = ("sway",)
        self.keys = KeyEvents(list(self.key_actions))
        self.run_state = None
        self.sway = None
        self.sway_index = None
        self.run_index = None

        self.imu = None
        self.measured = None
        if s["USE_IMU"]:
            try:
                self.imu = BodyIMU(PLATFORM_IMU_PORT, roll_sign=s["IMU_ROLL_SIGN"],
                                   pitch_sign=s["IMU_PITCH_SIGN"], yaw_sign=s["IMU_YAW_SIGN"],
                                   swap_roll_pitch=s["IMU_SWAP_ROLL_PITCH"])
                time.sleep(s["ZERO_SETTLE_SEC"])
                zero = self.imu.calibrate(s["CALIBRATION_SAMPLES"], still_deg=s["IMU_STILL_DEG"])
                self.log("STATE", f"zero {L.angles_text(zero)}")
                if not self.imu.settled:
                    self.log("WARN", f"IMU not still after {STILL_TIMEOUT_SEC:g} s "
                                     f"(IMU_STILL_DEG={s['IMU_STILL_DEG']:g})")
                elif self.imu.spread > ZERO_SPREAD_WARN_DEG:
                    self.log("WARN", f"IMU moved {self.imu.spread:.1f} deg while zeroing")
                self.measured = (0.0, 0.0, 0.0)
            except Exception as e:
                self.imu = None
                self.log("WARN", f"no IMU on port {PLATFORM_IMU_PORT} (the platform still tilts)")
                L.more(str(e))
        self.last_screen = 0.0
        self.log("STATE", "ready  robot MCU port: "
                          f"{robot_port if robot_port is not None else 'none'}")

    def _guide_port(self):
        """Guide port."""
        candidates = [PLATFORM_GUIDE_SCREEN_PORT] + [p for p in self._ports() if p != PLATFORM_GUIDE_SCREEN_PORT]
        for port in candidates:
            if port == PLATFORM_SCREEN_PORT:
                continue
            try:
                if Port.assigned(port) and Port.port_type(port) is TextScreen:
                    return port
            except Exception:
                pass
        return None

    @staticmethod
    def _ports():
        try:
            return list(Port.ports())
        except Exception:
            return []

    def show_guide_screen(self):
        """Show guide screen."""
        port = self._guide_port()
        if port is None:
            return
        guide = StatusScreen(port=port, wrap=False)
        keys = PROGRAM["PLATFORM_KEYS"]

        def pair(axis):
            plus = next((k for k, (a, d) in keys.items() if a == axis and d > 0), "?").upper()
            minus = next((k for k, (a, d) in keys.items() if a == axis and d < 0), "?").upper()
            return (f"{tag(f'{plus}/{minus}', 'key')}  {tag(axis, 'label')} "
                    f"{tag(DIRECTION_KO[(axis, 1)] + ' / ' + DIRECTION_KO[(axis, -1)], 'text')}")
        p = PROGRAM
        body = [pair("pitch"), pair("roll"), pair("yaw"),
                keys_text([(p["LEVEL_KEY"], 'Level'), (f"{p['PLATFORM_SLOWER_KEY']}/{p['PLATFORM_FASTER_KEY']}", 'Speed'),
                           (p["SWAY_KEY"], 'Continuous Sway')], "   "),
                keys_text([(p["CHECK_KEY"], 'Direction Check'), (p["TEST_KEY"], 'Balance Test'),
                           (p["COMPARE_KEY"], 'Compare')], "   ")]
        guide.show(page('Tilt Platform · Key Help', body,
                        tag('Robot reads keys · ', "text") + keys_text([("F2", 'Reset'), ("F3", 'Stop All')]),
                        GUIDE_BODY_LINES))
        self.log("STATE", f"guide screen on port {port}")

    def update_screen(self, now):
        """Update screen."""
        if now - self.last_screen < self.s["SCREEN_INTERVAL_SEC"]:
            return
        self.last_screen = now
        a = self.axes.angles
        if self.imu is not None:
            self.measured = self.imu.read()
        body = []
        for i, axis in enumerate(AXES):
            imu = tag('No IMU', "text") if self.measured is None else \
                tag(f"IMU {self.measured[i]:+5.1f}°", "out")
            body.append(f"{tag(f'{axis.capitalize():<6}', 'label')}{tag(_deg(a[axis]) + '°', 'value')}   {imu}")
        if self.linked:
            mode = 'Robot Messages'
        elif self.sway is not None:
            mode = f"Keys · {SCENARIO_KO['sway']}"
        elif self.run_state is not None:
            mode = f"Keys · {SCENARIO_KO[self.run_state.name]}"
        else:
            mode = 'Keys'
        rpms = self.axes.rpm
        rpm = "" if rpms is None else f"  (servo {rpms[0]:.1f} rpm)"
        footer = f"{tag('Speed', 'text')} {tag(speed_text(self.speed.value), 'platform')}{tag(rpm, 'text')}"
        self.screen.show(page(f"Tilt Platform · source: {mode}", body, footer, SCREEN_BODY_LINES))

    def apply_speed(self):
        """Apply speed."""
        self.axes.set_speed(self.axes.speeds(ratio=self.speed.value))
        if self.axes.rpm is not None:
            self.log("PARAMETER", f"speed {speed_text(self.speed.value)}  "
                                  f"servo rpm {self.axes.base_rpm[0]:.1f} -> {self.axes.rpm[0]:.1f}")

    def apply(self, pose):
        """Apply."""
        if self.target.set(pose):
            self._send_servos()

    def _send_servos(self):
        roll, pitch, yaw = self.axes.set(*self.target.pose)
        self.log("ACTION", f"cmd  roll={_deg(roll)}  pitch={_deg(pitch)}  yaw={_deg(yaw)} deg")

    def read_messages(self):
        """Read messages."""
        for kind, pose, speed in self.inbox.read():
            if kind != "P":
                continue
            if not self.linked:
                self.linked = True
                self.run_state = None
                self.sway = None
                self.log("STATE", "robot link: following robot messages")
            if speed is not None and self.speed.set(speed):
                self.apply_speed()
            self.apply(pose)

    def read_keys(self, now):
        """Read keys."""
        if self.run_state is not None:
            keys = self.keys.take([self.prog["STAND_KEY"], self.prog["STOP_KEY"]])
        else:
            keys = self.keys.pressed()
        for key in keys:
            action = self.key_actions[key]
            if action[0] == "stop":
                self.run_state = None
                self.sway = None
            elif action[0] == "level":
                self.run_state = None
                self.sway = None
                self.apply(LEVEL)
            elif action[0] == "run":
                self.sway = None
                self.run_state = ScenarioRun(action[1], scenario(action[1], self.prog), now)
                self.run_index = None
            elif action[0] == "sway":
                if self.sway is not None:
                    self.sway = None
                    self.apply(LEVEL)
                else:
                    self.sway = ScenarioRun("sway", scenario("sway", self.prog), now, loop=True)
                    self.sway_index = None
            elif action[0] == "step":
                self.sway = None
                if self.target.step_axis(action[1], action[2]):
                    self._send_servos()
            elif action[0] == "speed":
                if self.speed.change(action[1]):
                    self.apply_speed()
        if self.sway is not None:
            i, seg = self.sway.at(now)
            if i != self.sway_index:
                self.sway_index = i
                self.apply(seg.pose)
        if self.run_state is not None:
            i, seg = self.run_state.at(now)
            if i is None:
                self.run_state = None
                self.apply(LEVEL)
            elif i != self.run_index:
                self.run_index = i
                self.apply(seg.pose)

    def report(self, now):
        """Report."""
        if self.robot_mcu is None or self.measured is None or now - self.last_report < self.s["REPORT_SEC"]:
            return
        self.last_report = now
        try:
            self.robot_mcu.message(pose_message("I", self.measured))
        except Exception as e:
            self.robot_mcu = None
            self.log("WARN", f"cannot send to the robot MCU ({e})")

    def update(self):
        now = time.time()
        self.read_messages()
        if self.linked:
            self.keys.clear()
        else:
            self.read_keys(now)
        self.update_screen(now)
        self.report(now)
        time.sleep(self.s["LOOP_SLEEP_SEC"])

    def run(self):
        """Run."""
        if not self.ready:
            return
        try:
            from scriptruntime import Runtime
            while not Runtime.quitting():
                self.update()
        except KeyboardInterrupt:
            pass
        except Exception as e:
            L.event("ERROR", f"platform: unexpected error: {e}")
            log_traceback()
            try:
                self.axes.set(0, 0, 0)
            except Exception:
                pass

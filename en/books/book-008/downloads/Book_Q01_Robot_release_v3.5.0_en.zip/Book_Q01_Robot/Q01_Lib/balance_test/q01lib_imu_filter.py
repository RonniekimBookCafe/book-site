# -*- coding: utf-8 -*-
"""q01lib_imu_filter: QUAD-01 educational library - IMU filters (Kalman, moving average).

IMU values jitter even when the robot is still. The balance test smooths them before PID.
    SimpleKalmanFilter:  estimate = previous + K x (new - previous), K between 0 and 1
    MovingAverageFilter: mean of the last window_size values (smoother but slower)
IMUFilter applies them to roll / pitch / yaw according to FILTER_MODES.
Pure calculation; no RoboCo API.
"""

# Filter mode: name -> (use Kalman, use moving average)
FILTER_MODES = {
    'None': (False, False),
    'Kalman': (True, False),
    'Moving Average': (False, True),
    'Kalman + Moving Average': (True, True),
}

# Names written to the console
FILTER_NAMES_EN = {'None': "none", 'Kalman': "kalman", 'Moving Average': "moving_avg", 'Kalman + Moving Average': "kalman+avg"}

KALMAN_ROLL_PITCH = (1.0, 1.0, 0.01)
KALMAN_YAW = (2.0, 2.0, 0.01)
MOVING_AVERAGE_WINDOW = 5
ZERO_THRESHOLD = 0.01        # Values smaller than this (deg) become 0


class MovingAverageFilter:
    """Moving Average Filter."""

    def __init__(self, window_size=MOVING_AVERAGE_WINDOW):
        self.window_size = window_size
        self.values = []

    def update(self, value):
        self.values.append(value)
        if len(self.values) > self.window_size:
            self.values.pop(0)
        return sum(self.values) / len(self.values)


class SimpleKalmanFilter:
    """Simple Kalman Filter."""

    def __init__(self, mea_e, est_e, q):
        """Init.

Parameters: mea_e, est_e, q."""
        self.mea_e = mea_e
        self.est_e = est_e
        self.q = q
        self.last_estimate = 0.0

    def update(self, measurement):
        gain = self.est_e / (self.est_e + self.mea_e)
        estimate = self.last_estimate + gain * (measurement - self.last_estimate)
        self.est_e = (1.0 - gain) * self.est_e + abs(self.last_estimate - estimate) * self.q
        self.last_estimate = estimate
        return estimate


class IMUFilter:
    """IMUFilter."""

    def __init__(self, mode='Kalman'):
        mode = {en: ko for ko, en in FILTER_NAMES_EN.items()}.get(mode, mode)
        if mode not in FILTER_MODES:
            raise ValueError(f"FILTER_MODE: unknown filter. Use one of {', '.join(FILTER_NAMES_EN.values())}")
        self.mode = mode
        self.reset()

    def reset(self):
        """Reset."""
        self.kalman = [SimpleKalmanFilter(*KALMAN_ROLL_PITCH), SimpleKalmanFilter(*KALMAN_ROLL_PITCH),
                       SimpleKalmanFilter(*KALMAN_YAW)]
        self.average = [MovingAverageFilter() for _ in range(3)]
        self.fresh = True

    def next_mode(self):
        """Next mode."""
        names = list(FILTER_MODES)
        self.mode = names[(names.index(self.mode) + 1) % len(names)]
        self.reset()
        return self.mode

    def update(self, values):
        """Update."""
        use_kalman, use_average = FILTER_MODES[self.mode]
        if self.fresh:
            for kalman, value in zip(self.kalman, values):
                kalman.last_estimate = value
            self.fresh = False
        out = []
        for i, value in enumerate(values):
            if use_kalman:
                value = self.kalman[i].update(value)
            if use_average:
                value = self.average[i].update(value)
            out.append(0.0 if abs(value) < ZERO_THRESHOLD else value)
        return tuple(out)

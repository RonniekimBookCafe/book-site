# -*- coding: utf-8 -*-
"""q01lib_platform: Educational library module for the QUAD-01 RoboCo series.

Tilt-platform servo control and microcontroller messaging."""

from controllables import ServoMotor

PLATFORM_ROLL_SERVO_PORTS = (0, 1)
PLATFORM_PITCH_SERVO_PORTS = (2, 3)
PLATFORM_YAW_SERVO_PORT = 4
PLATFORM_IMU_PORT = 5
PLATFORM_SCREEN_PORT = 6
PLATFORM_GUIDE_SCREEN_PORT = 7

AXES = ("roll", "pitch", "yaw")
SERVO_RPM_MAX = 1000


class PlatformAxes:
    """Platform Axes."""

    def __init__(self, limit_deg, roll_sign=1, pitch_sign=1, yaw_sign=-1, servo_rpm=None):
        """Init.

Parameters: limit_deg, roll_sign, servo_rpm."""
        self.limit = limit_deg
        self.signs = {"roll": roll_sign, "pitch": pitch_sign, "yaw": yaw_sign}
        self.roll_servos = tuple(ServoMotor(port) for port in PLATFORM_ROLL_SERVO_PORTS)
        self.pitch_servos = tuple(ServoMotor(port) for port in PLATFORM_PITCH_SERVO_PORTS)
        self.yaw_servo = ServoMotor(PLATFORM_YAW_SERVO_PORT)
        self.servos = self.roll_servos + self.pitch_servos + (self.yaw_servo,)
        self.read_error = None
        if servo_rpm is not None:
            self.base_rpm = [float(servo_rpm)] * len(self.servos)
        else:
            try:
                self.base_rpm = [float(servo.max_rpm) for servo in self.servos]
            except Exception as e:
                self.base_rpm = None
                self.read_error = e
        self.rpm = None
        self.angles = {"roll": 0.0, "pitch": 0.0, "yaw": 0.0}

    def speeds(self, ratio=1.0):
        """Speeds."""
        if self.base_rpm is None:
            return None
        return [min(SERVO_RPM_MAX, r * ratio) for r in self.base_rpm]

    def set_speed(self, rpms):
        """Set speed."""
        if rpms is None or rpms == self.rpm:
            return
        for servo, rpm in zip(self.servos, rpms):
            servo.max_rpm = rpm
        self.rpm = list(rpms)

    def clamp(self, angle):
        return max(-self.limit, min(self.limit, angle))

    def set(self, roll, pitch, yaw):
        """Set."""
        roll, pitch, yaw = self.clamp(roll), self.clamp(pitch), self.clamp(yaw)
        a = self.signs["roll"] * roll
        self.roll_servos[0].spin_to_degrees(a)
        self.roll_servos[1].spin_to_degrees(-a)
        a = self.signs["pitch"] * pitch
        self.pitch_servos[0].spin_to_degrees(-a)
        self.pitch_servos[1].spin_to_degrees(a)
        self.yaw_servo.spin_to_degrees(self.signs["yaw"] * yaw)
        self.angles = {"roll": roll, "pitch": pitch, "yaw": yaw}
        return roll, pitch, yaw

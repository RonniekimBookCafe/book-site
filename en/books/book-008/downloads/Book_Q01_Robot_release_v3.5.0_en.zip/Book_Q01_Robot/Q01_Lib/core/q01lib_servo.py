# -*- coding: utf-8 -*-
"""q01lib_servo: Educational library module for the QUAD-01 RoboCo series.

Servo movement commands and joint position constraints."""

from controllables import ServoMotor
from . import q01lib_ports as ports


def setup_canonical_servos():
    """Setup canonical servos."""
    if set(ports.SERVO_MAX_TORQUE_BY_PORT) != set(ports.SERVO_ORDER):
        raise ValueError("canonical servo torque/port mapping incomplete")
    for port in ports.SERVO_ORDER:
        servo = ServoMotor(port)
        for attr, target in (("max_rpm", ports.SERVO_RPM_DEFAULT),
                             ("max_torque", ports.SERVO_MAX_TORQUE_BY_PORT[port]),
                             ("acceleration_time", ports.SERVO_ACCELERATION_TIME)):
            current = getattr(servo, attr)
            if abs(current - target) > 0.0001 * max(1.0, abs(target)):
                setattr(servo, attr, target)
            actual = getattr(servo, attr)
            if abs(actual - target) > 0.0001 * max(1.0, abs(target)):
                raise ValueError("{} {}: expected {}, got {}".format(
                    ports.SERVO_PART_NAMES[port], attr, target, actual))


class ServoController:
    """Servo Controller."""
    def __init__(self):
        """Init."""
        self.motor = None
        self.center_angle = 90

    def convert_angle(self, logical_angle):
        """Convert angle.

Parameters: logical_angle."""
        if logical_angle == 0:
            physical_angle = 90
        elif logical_angle == 90:
            physical_angle = 0
        elif logical_angle == 180:
            physical_angle = -90
        else:
            if logical_angle < 90:
                physical_angle = 90 - logical_angle
            else:
                physical_angle = -(logical_angle - 90)

        return physical_angle

    def set_servo_angle(self, port, logical_angle, rpm):
        """Set servo angle.

Parameters: port, logical_angle, rpm."""
        self.motor = ServoMotor(port)
        physical_angle = self.convert_angle(logical_angle)
        self.motor.max_rpm = rpm
        self.motor.spin_to_degrees(physical_angle)


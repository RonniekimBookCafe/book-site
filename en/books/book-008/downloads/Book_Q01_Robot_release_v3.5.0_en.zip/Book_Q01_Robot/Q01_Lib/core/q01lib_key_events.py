# -*- coding: utf-8 -*-
"""q01lib_key_events: Educational library module for the QUAD-01 RoboCo series.

Robot control."""

import time

from inputs import Input


def key_label(key: str) -> str:
    """Key label."""
    return key.upper()


class KeyEvents:
    """Key Events."""

    def __init__(self, keys, repeat_keys=(), repeat_sec: float = 0.0):
        self.keys = list(dict.fromkeys(keys))
        self.streams = {key: Input.stream(key) for key in self.keys}
        self.repeat_keys = set(repeat_keys)
        self.repeat_sec = repeat_sec
        self._held = {}

    def pressed(self):
        """Pressed."""
        now = time.time()
        keys = []
        for key in self.keys:
            for event in self.streams[key]:
                if event:
                    keys.append(key)
                    self._held[key] = now
                else:
                    self._held.pop(key, None)
        if self.repeat_sec > 0:
            for key, last in list(self._held.items()):
                if key in self.repeat_keys and key not in keys and now - last >= self.repeat_sec:
                    keys.append(key)
                    self._held[key] = now
        return keys

    def take(self, keys):
        """Take."""
        found = []
        for key in keys:
            for event in self.streams[key]:
                if event:
                    found.append(key)
                    self._held[key] = time.time()
                else:
                    self._held.pop(key, None)
        return found

    def clear(self):
        """Clear."""
        for stream in self.streams.values():
            for _ in stream:
                pass
        self._held.clear()

# -*- coding: utf-8 -*-
"""q01lib_ports: Educational library module for the QUAD-01 RoboCo series.

Explicit microcontroller port-to-servo assignments."""

# ----------------------------------------------------------------
# 1. Display and sensor ports
# ----------------------------------------------------------------
PORT_TEXT_SCREEN = 0     # Text Screen 1: robot status display
PORT_INERTIAL_SENSOR = 1  # Inertial Sensor 1: body posture and balance experiments
# The RoboCo InertialSensor returns values in Unity coordinates. Local x points right,
# y points up, and z points forward; Spot body coordinates use x forward, y left, z up.
# core/q01lib_imu.py reads rotation_axis() and remaps axes. Confirm signs on the robot.
# Do not use euler_angles() here: its angles are approximately 57 times too large.
# LED 1 is not mapped to Ports 0–13 and is not used by this package.

# ----------------------------------------------------------------
# 2. Joint-servo ports: 4 legs × 3 joints = 12 servos
# RoboCo part names: "leg-number-port-leg-name" (e.g., 1-2-FrontLeft)
# ----------------------------------------------------------------
# Leg 1: front left (FrontLeft)
FL_KN = 2    # Port 2: front-left knee joint (pitch)
FL_HY = 3    # Port 3: front-left hip Y-axis joint (pitch)
FL_HX = 4    # Port 4: front-left hip X-axis joint (roll)

# Leg 2: hind left (HindLeft)
HL_KN = 5    # Port 5: hind-left knee joint (pitch)
HL_HY = 6    # Port 6: hind-left hip Y-axis joint (pitch)
HL_HX = 7    # Port 7: hind-left hip X-axis joint (roll)

# Leg 3: hind right (HindRight)
HR_HX = 8    # Port 8: hind-right hip X-axis joint (roll)
HR_HY = 9    # Port 9: hind-right hip Y-axis joint (pitch)
HR_KN = 10   # Port 10: hind-right knee joint (pitch)

# Leg 4: front right (FrontRight)
FR_HX = 11   # Port 11: front-right hip X-axis joint (roll)
FR_HY = 12   # Port 12: front-right hip Y-axis joint (pitch)
FR_KN = 13   # Port 13: front-right knee joint (pitch)

# ----------------------------------------------------------------
# 3. Leg and joint ordering
# Leg indices 0–3 follow the order below. Joints use the IK output order
# (a, b, c) for each leg.
# a = hip X (HX): roll; moves the leg outward and inward from the body
# b = hip Y (HY): pitch; swings the leg forward and backward
# c = knee (KN): pitch; flexes and extends the leg
# ----------------------------------------------------------------
LEG_NAMES = ["FL", "HL", "HR", "FR"]       # Leg indices 0–3: FL, HL on the left; HR, FR on the right
LEFT_LEGS = (0, 1)                         # Left legs: FL and HL
RIGHT_LEGS = (2, 3)                        # Right legs: HR and FR
FRONT_LEGS = (0, 3)                        # Front legs: FL and FR
HIND_LEGS = (1, 2)                         # Hind legs: HL and HR

# Port assignments for joints (a, b, c) of each leg
LEG_JOINT_PORTS = [
    (FL_HX, FL_HY, FL_KN),    # Leg 0, FL: Ports 4, 3, 2
    (HL_HX, HL_HY, HL_KN),    # Leg 1, HL: Ports 7, 6, 5
    (HR_HX, HR_HY, HR_KN),    # Leg 2, HR: Ports 8, 9, 10
    (FR_HX, FR_HY, FR_KN),    # Leg 3, FR: Ports 11, 12, 13
]

# Order in which servo commands are sent (flattened port table)
SERVO_ORDER = [port for leg in LEG_JOINT_PORTS for port in leg]
# = [4, 3, 2, 7, 6, 5, 8, 9, 10, 11, 12, 13]

# Diagonal leg pairs for trot gait. Both legs in a pair follow the same trajectory.
# Group 1: FL (0) + HR (2); Group 2: HL (1) + FR (3)
# The standard Spot-style walk and trot also alternate the diagonal pairs
# (front-left/hind-right and front-right/hind-left).

# ----------------------------------------------------------------
# 4. Servo-angle convention
# Logical angles 0°–180° map to physical +90° to -90° (90° logical = 0° physical).
# Pass physical angles to ServoMotor.spin_to_degrees().
# ----------------------------------------------------------------
LOGICAL_MIN_DEG = 0         # Minimum logical angle; clamp IK results to this range
LOGICAL_MAX_DEG = 180       # Maximum logical angle

# Per-leg calibration offsets (a, b, c) compensate for mechanical alignment differences.
# All offsets are zero for the provided robot models.
CALIBRATION_ANGLES = [
    [0, 0, 0],   # FL
    [0, 0, 0],   # HL
    [0, 0, 0],   # HR
    [0, 0, 0],   # FR
]

# ----------------------------------------------------------------
# 5. Link geometry and reach limits
# Lengths use the same units as foot coordinates (leg axes: x forward, y left, z up).
# ----------------------------------------------------------------
LINK_HIP = 23        # l1: from hip X joint (HX) to hip Y joint (HY)
LINK_UPPER = 55      # l2: from hip Y joint (HY) to knee joint (KN)
LINK_LOWER = 65      # l3: from knee to foot tip

REACH_MIN = 25       # Minimum hip-origin-to-foot-tip distance
REACH_MAX = 130      # Maximum hip-origin-to-foot-tip distance

# ----------------------------------------------------------------
# 6. Default foot-tip position offsets
# Offsets are added to the computed gait trajectories.
# x: +10 for all legs (move feet slightly forward)
# y: +10 left legs, -10 right legs (spread feet outward)
# ----------------------------------------------------------------
FOOT_X_OFFSET = 10
FOOT_Y_OFFSET = 10

# ----------------------------------------------------------------
# 7. Shared 12-DOF servo contract: identical across all robot variants
# Track the RoboCo component defaults; per-command max_rpm settings take precedence.
# ----------------------------------------------------------------
SERVO_RPM_DEFAULT = 50
SERVO_RPM_MIN = 0
SERVO_RPM_MAX = 1000
SERVO_ACCELERATION_TIME = 0.2
SERVO_ACCELERATION_MIN = 0.0
SERVO_ACCELERATION_MAX = 10.0
SERVO_MAX_TORQUE_BY_PORT = {
    2: 1720, 3: 13150, 4: 13150,
    5: 1720, 6: 13150, 7: 13150,
    8: 13150, 9: 13150, 10: 1720,
    11: 13150, 12: 13150, 13: 1720,
}
SERVO_PART_NAMES = {
    2: "1-2-FrontLeft", 3: "1-3-FrontLeft", 4: "1-4-FrontLeft",
    5: "2-5-HindLeft", 6: "2-6-HindLeft", 7: "2-7-HindLeft",
    8: "3-8-HindRight", 9: "3-9-HindRight", 10: "3-10-HindRight",
    11: "4-11-FrontRight", 12: "4-12-FrontRight", 13: "4-13-FrontRight",
}

# -*- coding: utf-8 -*-
"""q01lib_imu: QUAD-01 educational library - IMU (Inertial Sensor).

Used by the robot IMU (robot Microcontroller Port 1; body pose and balance test) and the
platform IMU (platform 3axis-Microcontroller Port 5). Each script creates its own BodyIMU.

Converts the Inertial Sensor rotation into roll / pitch / yaw (degrees) in the book's
body frame (Spot style): x forward, y left, z up.

What is read: rotation_axis()
    The rotation from the sensor's starting orientation to now, as one Vector3
    (axis x angle, radians).

Why euler_angles() is not used
    In the RoboCo API source, euler_angles() passes a rotation vector in degrees to a
    function that expects radians, so angles come out about 57.3x (180/pi) too large.
    rotation_axis() returns the same rotation correctly in radians.

Frames
    Unity part frame: x right, y up, z forward
    Body frame:       Spot x = Unity z, Spot y = -(Unity x), Spot z = Unity y
    roll + right side down, pitch + nose down, yaw + counterclockwise seen from above
    If the sensor is mounted differently, use ROLL_SIGN / PITCH_SIGN / YAW_SIGN /
    SWAP_ROLL_PITCH in the start file (IMU_ROLL_SIGN etc. for the platform).

Zero
    calibrate() waits until consecutive readings differ by less than STILL_DEG
    STILL_SAMPLES times in a row (up to STILL_TIMEOUT_SEC), then averages the rotation as
    quaternions and stores it as zero. read() returns the rotation from that zero pose.
"""

import math
import time

from sensors import InertialSensor

STILL_DEG = 0.2            # "Still" if a reading differs from the previous one by less than this (deg)
STILL_SAMPLES = 5          # ... this many times in a row
STILL_TIMEOUT_SEC = 5.0    # Give up waiting after this (s); settled is then False


def wrap_degrees(angle):
    """Wrap degrees."""
    return (angle + 180.0) % 360.0 - 180.0


# ------------------------------------------------------------
#   w = cos(θ/2),  (x, y, z) = a × sin(θ/2)
# ------------------------------------------------------------
def quat_from_rotation_vector(v):
    """Quat from rotation vector."""
    x, y, z = float(v[0]), float(v[1]), float(v[2])
    angle = math.sqrt(x * x + y * y + z * z)
    if angle < 1e-12:
        return (1.0, 0.0, 0.0, 0.0)
    s = math.sin(angle / 2.0) / angle
    return (math.cos(angle / 2.0), x * s, y * s, z * s)


def quat_conj(q):
    """Quat conj."""
    return (q[0], -q[1], -q[2], -q[3])


def quat_mul(a, b):
    """Quat mul."""
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return (aw * bw - ax * bx - ay * by - az * bz,
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw)


def quat_angle_deg(q):
    """Quat angle deg."""
    return math.degrees(2.0 * math.acos(min(1.0, abs(q[0]))))


def quat_between_deg(a, b):
    """Quat between deg."""
    return quat_angle_deg(quat_mul(quat_conj(a), b))


def quat_mean(quats):
    """Quat mean."""
    ref = quats[0]
    total = [0.0, 0.0, 0.0, 0.0]
    for q in quats:
        sign = 1.0 if sum(a * b for a, b in zip(q, ref)) >= 0.0 else -1.0
        for i in range(4):
            total[i] += sign * q[i]
    norm = math.sqrt(sum(t * t for t in total))
    if norm < 1e-12:
        return ref
    return tuple(t / norm for t in total)


def spot_angles(q):
    """Spot angles."""
    w, x, y, z = q
    r02 = 2.0 * (x * z + w * y)
    r10 = 2.0 * (x * y + w * z)
    r11 = 1.0 - 2.0 * (x * x + z * z)
    r12 = 2.0 * (y * z - w * x)
    r22 = 1.0 - 2.0 * (x * x + y * y)
    s21, s22, s20 = -r10, r11, r12
    s10, s00 = -r02, r22
    roll = math.degrees(math.atan2(s21, s22))
    pitch = math.degrees(math.asin(max(-1.0, min(1.0, -s20))))
    yaw = math.degrees(math.atan2(s10, s00))
    return roll, pitch, yaw


def up_value(q):
    """Up value."""
    _w, x, _y, z = q
    return 1.0 - 2.0 * (x * x + z * z)


class BodyIMU:
    """Body IMU."""

    def __init__(self, port, roll_sign=1, pitch_sign=1, yaw_sign=1, swap_roll_pitch=False):
        self.sensor = InertialSensor(port)
        self.roll_sign = roll_sign
        self.pitch_sign = pitch_sign
        self.yaw_sign = yaw_sign
        self.swap_roll_pitch = swap_roll_pitch
        self.zero_quat = (1.0, 0.0, 0.0, 0.0)
        self.zero = (0.0, 0.0, 0.0)
        self.spread = 0.0
        self.settled = True
        self.wait_sec = 0.0

    def read_quat(self):
        """Read quat."""
        return quat_from_rotation_vector(self.sensor.rotation_axis())

    def _apply_signs(self, angles):
        roll, pitch, yaw = angles
        if self.swap_roll_pitch:
            roll, pitch = pitch, roll
        return roll * self.roll_sign, pitch * self.pitch_sign, yaw * self.yaw_sign

    def read_raw(self):
        """Read raw."""
        return self._apply_signs(spot_angles(self.read_quat()))

    def wait_still(self, interval_sec=0.05, still_deg=STILL_DEG, still_samples=STILL_SAMPLES,
                   timeout_sec=STILL_TIMEOUT_SEC):
        """Wait still."""
        start = time.time()
        last = self.read_quat()
        count = 0
        while count < still_samples:
            if time.time() - start >= timeout_sec:
                self.wait_sec = time.time() - start
                return False
            time.sleep(interval_sec)
            now = self.read_quat()
            count = count + 1 if quat_between_deg(last, now) < still_deg else 0
            last = now
        self.wait_sec = time.time() - start
        return True

    def calibrate(self, samples=20, interval_sec=0.05, still_deg=STILL_DEG):
        """Calibrate.

Parameters: still_deg."""
        self.settled = self.wait_still(interval_sec, still_deg)
        quats = []
        for _ in range(max(1, samples)):
            quats.append(self.read_quat())
            time.sleep(interval_sec)
        self.zero_quat = quat_mean(quats)
        self.spread = max(quat_between_deg(self.zero_quat, q) for q in quats)
        self.zero = self._apply_signs(spot_angles(self.zero_quat))
        return self.zero

    def read(self):
        """Read."""
        relative = quat_mul(quat_conj(self.zero_quat), self.read_quat())
        return self._apply_signs(spot_angles(relative))

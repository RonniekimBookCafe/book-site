# -*- coding: utf-8 -*-
"""q01lib_welcome: Educational library module for the QUAD-01 RoboCo series.

Welcome screen text and timed startup display."""
import time
from color import Color
from controllables import TextScreen

DEFAULT_WELCOME_SEC = 1.0
DEFAULT_START_SCREEN_SEC = 2.5
MAX_SCREEN_SEC = 60.0


def checked_duration(value, name):
    """Checked duration."""
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 <= value <= MAX_SCREEN_SEC:
        raise ValueError("{} must be between 0 and {} seconds".format(name, int(MAX_SCREEN_SEC)))
    return float(value)


def show_welcome(status_screen, model_name, seconds=DEFAULT_WELCOME_SEC):
    """Show welcome."""
    seconds = checked_duration(seconds, "WELCOME_SEC")
    screen = status_screen.screen
    old = (screen.wrapping, screen.horizontal_alignment, screen.vertical_alignment,
           screen.auto_size, screen.color)
    try:
        screen.wrapping = False
        screen.horizontal_alignment = TextScreen.HorizontalAlignment.CENTER
        screen.vertical_alignment = TextScreen.VerticalAlignment.MIDDLE
        screen.auto_size = True
        screen.color = Color(0.86, 0.93, 1.00)
        screen.text = "<color=#DBEDFF>{}\nWELCOME</color>".format(model_name)
        if seconds > 0:
            time.sleep(seconds)
    finally:
        (screen.wrapping, screen.horizontal_alignment, screen.vertical_alignment,
         screen.auto_size, screen.color) = old

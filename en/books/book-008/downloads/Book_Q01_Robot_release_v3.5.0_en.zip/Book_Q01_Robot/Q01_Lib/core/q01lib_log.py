# -*- coding: utf-8 -*-
"""q01lib_log: Educational library module for the QUAD-01 RoboCo series.

Structured console logging and error reporting."""

import threading
import time

CATEGORIES = {
    "INPUT": 'Keyboard input',
    "PARAMETER": 'Settings and parameter changes',
    "SENSOR": 'Sensor readings (IMU)',
    "STATE": 'Robot/program state (stand, ready, exit)',
    "ACTION": 'Actions, corrections, and pose commands',
    "JOINT": 'Angles sent to joint servos',
    "TASK": 'Automatic test start, stages, and completion',
    "METRIC": 'Validation (IK/FK error, IMU and action checks)',
    "WARN": 'Warnings (unreachable pose, setup mismatch, missing IMU)',
    "ERROR": 'Unexpected error',
}

COLOR = True
COLORS = {
    "TIME": "#8A929C",
    "INPUT": "#FFD91A",
    "PARAMETER": "#B39DFF",
    "SENSOR": "#20D6D9",
    "STATE": "#4ADE80",
    "ACTION": "#FF8A34",
    "JOINT": "#FFB070",
    "TASK": "#7FB2FF",
    "METRIC": "#9FD3FF",
    "WARN": "#FF5A52",
    "ERROR": "#FF5A52",
    "TITLE": "#FF8A34",
    "KEY": "#FFD91A",
}
LOUD = ("WARN", "ERROR")

TIME_WIDTH = 5
RULE_WIDTH = 60

_states = {}


def _state_now():
    return _states.setdefault(threading.get_ident(),
                              {"start": time.time(), "tag_width": 12, "color": COLOR})


def configure(categories, color=None):
    """Configure.

Parameters: categories, color."""
    state = _state_now()
    state["tag_width"] = max(len(name) for name in categories) + 3
    if color is not None:
        state["color"] = bool(color)
    reset_clock()


def reset_clock():
    """Reset clock."""
    _state_now()["start"] = time.time()


def paint(text, key):
    """Paint."""
    if not _state_now()["color"] or key not in COLORS:
        return text
    return f"<color={COLORS[key]}>{text}</color>"


def key(label, width=0):
    """Key.

Parameters: label, width."""
    label = str(label)
    text = "/".join(paint(part, "KEY") if part else part for part in label.split("/"))
    return text + " " * max(0, width - len(label))


def keys(labels, sep=" "):
    """Keys."""
    return sep.join(key(label) for label in labels)


def visible_len(text):
    """Visible len."""
    import re
    return len(re.sub(r"</?color[^>]*>", "", str(text)))


def log(message: str = ""):
    """Log."""
    print(str(message).encode("ascii", "replace").decode("ascii"))


def log_traceback():
    """Log traceback."""
    import sys
    import traceback
    kind, error, tb = sys.exc_info()
    if kind is None:
        return
    for line in wrap(f"{kind.__name__}: {error}"):
        more(paint(line, "ERROR"))
    for frame in traceback.extract_tb(tb):
        name = frame.filename.replace("\\", "/").split("/")[-1]
        more(f"  at {name}:{frame.lineno} in {frame.name}")


def setup_failed(error, file_name):
    """Setup failed."""
    if isinstance(error, ValueError):
        event("ERROR", "setup failed: a value in the start file")
        for line in wrap(str(error)):
            more(paint(line, "ERROR"))
    else:
        event("ERROR", "setup failed")
        log_traceback()
    event("STATE", f"stopped. Fix {file_name}")


def wrap(text, width=72):
    """Wrap."""
    import textwrap
    return textwrap.wrap(str(text), max(20, width - len(indent()))) or [""]


def event(category, text):
    """Event."""
    state = _state_now()
    seconds = time.time() - state["start"]
    tag = f"[{category}]"
    pad = " " * max(1, state["tag_width"] - len(tag))
    if category in LOUD:
        text = paint(text, category)
    log(paint(f"[{seconds:{TIME_WIDTH}.1f}]", "TIME") + " " + paint(tag, category) + pad + text)


def indent():
    """Indent."""
    return " " * (TIME_WIDTH + 3 + _state_now()["tag_width"])


def more(text):
    """More."""
    log(indent() + text)


def rule(char="="):
    log(paint(char * RULE_WIDTH, "TIME"))


def banner(title, lines):
    """Banner."""
    rule("=")
    log(" " + paint(title, "TITLE"))
    rule("-")
    for line in lines:
        log(line)
    rule("=")


def key_lines(label, items, width=RULE_WIDTH, label_cols=6):
    """Key lines.

Parameters: label, items."""
    head = f" {label:<{label_cols}} "
    lines, line, empty = [], head, True
    for name, desc in items:
        part = f"{key(name)} {desc}"
        if not empty and visible_len(line) + 3 + visible_len(part) > width:
            lines.append(line)
            line, empty = " " * len(head), True
        line += ("" if empty else "   ") + part
        empty = False
    lines.append(line)
    return lines


def signed(value, width=5, digits=1):
    """Signed."""
    return f"{round(value, digits) + 0.0:+{width}.{digits}f}"


def angles_text(values, names=("roll", "pitch", "yaw"), unit=" deg"):
    """(roll, pitch, yaw) → "roll= +1.2  pitch= +0.0  yaw= +0.0 deg"."""
    return "  ".join(f"{n}={signed(v)}" for n, v in zip(names, values)) + unit


def xyz_text(x, y, z, width=6):
    """Xyz text."""
    return f"x={x:{width}.1f}  y={y:{width}.1f}  z={z:{width}.1f}"


def num(value):
    """Num."""
    return f"{value:+g}" if value else "0"

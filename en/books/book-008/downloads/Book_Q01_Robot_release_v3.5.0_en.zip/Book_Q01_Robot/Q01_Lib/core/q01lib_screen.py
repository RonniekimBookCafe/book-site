# -*- coding: utf-8 -*-
"""q01lib_screen: Educational library module for the QUAD-01 RoboCo series.

Robot text-display rendering and formatted status pages."""

from controllables import TextScreen
import re
from color import Color
from . import q01lib_ports as ports

# RoboCo TextScreen.font_color's baseline must be bright on the robot's black screen.
# Rich-text <color> labels in LEG/BALANCE/BODY_POSE retain their own accent color.
# A fixed pale white avoids the saved UI color (often black) reappearing after Welcome.
DEFAULT_TEXT_COLOR_HEX = "#F0F5FF"
DEFAULT_TEXT_COLOR = Color(240 / 255, 245 / 255, 255 / 255)  # #F0F5FF

# TextMeshPro rich-text color tags work for highlighted values, but ordinary text
# could still render black on RoboCo's dark screen. Tag only uncolored spans;
# existing per-value <color=...> and <b> markup remains unchanged.
_RICH_TAG = re.compile(r"(<color\s*=\s*[^>]+>|</color\s*>|<[^>]*>)", re.IGNORECASE)
_OPEN_COLOR = re.compile(r"<color\s*=", re.IGNORECASE)
_CLOSE_COLOR = re.compile(r"</color\s*>", re.IGNORECASE)


def ensure_readable_text(text, default_color=DEFAULT_TEXT_COLOR_HEX):
    """Make every otherwise uncolored character readable, preserving accent tags.

    Existing <color=#...> blocks stay byte-for-byte identical. Surround each
    uncolored span with an explicit pale-white TextMeshPro color tag. This is a
    rendering fix, not a change to screen text content or robot motion.
    """
    text = str(text)
    pieces = _RICH_TAG.split(text)
    depth = 0
    result = []
    for piece in pieces:
        if not piece:
            continue
        if _OPEN_COLOR.match(piece):
            depth += 1
            result.append(piece)
        elif _CLOSE_COLOR.fullmatch(piece):
            depth = max(0, depth - 1)
            result.append(piece)
        elif piece.startswith("<") and piece.endswith(">"):
            result.append(piece)  # formatting markup (e.g. <b>)
        elif depth:
            result.append(piece)  # preserve explicitly colored text
        else:
            result.append("<color={}>{}</color>".format(default_color, piece))
    return "".join(result)


class StatusScreen:
    """Status Screen."""

    def __init__(self, centered=False, port=None, wrap=True, enforce_contrast=True):
        """Init."""
        self.enforce_contrast = enforce_contrast
        self.screen = TextScreen(ports.PORT_TEXT_SCREEN if port is None else port)
        self.screen.color = DEFAULT_TEXT_COLOR  # Explicit readable text on black background.
        self.screen.auto_size = True
        if centered:
            self.screen.wrapping = False
            self.screen.horizontal_alignment = TextScreen.HorizontalAlignment.CENTER
            self.screen.vertical_alignment = TextScreen.VerticalAlignment.MIDDLE
        else:
            self.screen.horizontal_alignment = TextScreen.HorizontalAlignment.LEFT
            if wrap:
                self.screen.vertical_alignment = TextScreen.VerticalAlignment.TOP
            else:
                self.screen.wrapping = False
                self.screen.vertical_alignment = TextScreen.VerticalAlignment.MIDDLE

    def show(self, text: str):
        """Show."""
        value = str(text)
        self.screen.text = ensure_readable_text(value) if self.enforce_contrast else value

    def show_lines(self, *lines):
        """Show lines."""
        value = "\n".join(str(line) for line in lines)
        self.screen.text = ensure_readable_text(value) if self.enforce_contrast else value

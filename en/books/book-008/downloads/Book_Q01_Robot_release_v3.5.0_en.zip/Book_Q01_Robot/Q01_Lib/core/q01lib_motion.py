# -*- coding: utf-8 -*-
"""q01lib_motion: Educational library module for the QUAD-01 RoboCo series.

Interpolated joint movement and coordinated feet trajectories."""

from . import q01lib_ports as ports
from .q01lib_servo import ServoController
from .q01lib_ik import coordinate_to_angle, is_valid_point, restrict_angle
from . import q01lib_log as L         # Console logging helpers (L.event, L.more, L.key, etc.)


class LegMotion:
    """Leg Motion."""

    def __init__(self, body_height=99, servo_rpm=30):
        self.servo = ServoController()
        self.rpm = servo_rpm
        self.out_of_reach = False
        self.last_error = None

        self.points = [
            [0, ports.FOOT_Y_OFFSET, -body_height],     # FL
            [0, ports.FOOT_Y_OFFSET, -body_height],     # HL
            [0, -ports.FOOT_Y_OFFSET, -body_height],    # HR
            [0, -ports.FOOT_Y_OFFSET, -body_height],    # FR
        ]
        self.angles = [[90, 0, 0] for _ in range(4)]
        self.calibration_angles = ports.CALIBRATION_ANGLES

    def run(self, rpm=None):
        """Run.

Parameters: rpm."""
        if rpm is None:
            rpm = self.rpm

        bad = [ports.LEG_NAMES[i] for i, p in enumerate(self.points) if not is_valid_point(p)]
        if bad:
            if not self.out_of_reach:
                L.event("WARN", f"foot out of reach ({' '.join(bad)}): servo command skipped")
            self.out_of_reach = True
            return
        if self.out_of_reach:
            L.event("STATE", "foot back in reach")
        self.out_of_reach = False

        try:
            for i in range(4):
                self.angles[i] = self.to_servo_angles(i, coordinate_to_angle(*self.points[i]))

            servo_order = ports.SERVO_ORDER
            for leg in range(4):
                for axis in range(3):
                    servo_index = servo_order[leg * 3 + axis]
                    angle = self.angles[leg][axis]
                    self.servo.set_servo_angle(servo_index, angle, rpm)

        except Exception as e:
            if str(e) != self.last_error:
                L.event("ERROR", "servo command failed")
                for line in L.wrap(e):
                    L.more(line)
            self.last_error = str(e)
            return
        self.last_error = None

    def to_servo_angles(self, leg, ik_angles):
        """To servo angles.

Parameters: leg, ik_angles."""
        a, b, c = ik_angles
        cal = self.calibration_angles[leg]
        if leg in ports.LEFT_LEGS:
            return [restrict_angle(a + cal[0]),
                    restrict_angle(90 - (b + cal[1])),
                    restrict_angle(c + cal[2])]
        else:
            return [restrict_angle(a + cal[0]),
                    restrict_angle(90 + b + cal[1]),
                    restrict_angle(180 - (c + cal[2]))]

    def change_coordinates(self, move_order, X1, Y1, Z1, X2, Y2, Z2):
        """Change coordinates.

Parameters: move_order."""
        xo = ports.FOOT_X_OFFSET
        yo = ports.FOOT_Y_OFFSET
        if move_order == "turn_left":
            for i in range(2):
                self.points[2*i][0] = ((-1)**(1+i))*X1 + xo
                self.points[2*i][1] = ((-1)**(i))*Y1 + ((-1)**i)*yo
                self.points[2*i][2] = Z1
                self.points[1+2*i][0] = ((-1)**(1+i))*X2 + xo
                self.points[1+2*i][1] = ((-1)**(1+i))*Y2 + ((-1)**i)*yo
                self.points[1+2*i][2] = Z2
        elif move_order == "turn_right":
            for i in range(2):
                self.points[2*i][0] = ((-1)**(i))*X1 + xo
                self.points[2*i][1] = ((-1)**(1+i))*Y1 + ((-1)**i)*yo
                self.points[2*i][2] = Z1
                self.points[1+2*i][0] = ((-1)**(i))*X2 + xo
                self.points[1+2*i][1] = ((-1)**(i))*Y2 + ((-1)**i)*yo
                self.points[1+2*i][2] = Z2
        else:
            for i in range(2):
                self.points[i*2][0] = X1 + xo
                self.points[i*2][1] = Y1 + ((-1)**i)*yo
                self.points[i*2][2] = Z1
                self.points[i*2+1][0] = X2 + xo
                self.points[i*2+1][1] = Y2 + ((-1)**i)*yo
                self.points[i*2+1][2] = Z2
        self.run()

    def move_to(self, target_positions, steps, rpm=None):
        """Move to.

Parameters: target_positions, steps, rpm."""
        increments = []
        for i in range(4):
            dx = (target_positions[i][0] - self.points[i][0]) / steps
            dy = (target_positions[i][1] - self.points[i][1]) / steps
            dz = (target_positions[i][2] - self.points[i][2]) / steps
            increments.append([dx, dy, dz])

        for _ in range(steps):
            for i in range(4):
                self.points[i][0] += increments[i][0]
                self.points[i][1] += increments[i][1]
                self.points[i][2] += increments[i][2]
            self.run(rpm)

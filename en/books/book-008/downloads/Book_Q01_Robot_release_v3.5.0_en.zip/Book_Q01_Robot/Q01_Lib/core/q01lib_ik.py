# -*- coding: utf-8 -*-
"""q01lib_ik: Educational library module for the QUAD-01 RoboCo series.

Inverse kinematics for quadruped leg joint targets."""

import math

from . import q01lib_ports as ports


def link_lengths(l1=None, l2=None, l3=None):
    """Link lengths."""
    return (ports.LINK_HIP if l1 is None else l1,
            ports.LINK_UPPER if l2 is None else l2,
            ports.LINK_LOWER if l3 is None else l3)


def coordinate_to_angle(x, y, z, l1=None, l2=None, l3=None):
    """Coordinate to angle.

Parameters: x, l1."""
    l1, l2, l3 = link_lengths(l1, l2, l3)

    down = -z

    angle_a = math.pi / 2 - math.atan2(y, down)

    x_4 = l1 * math.sin(angle_a)
    x_5 = l1 * math.cos(angle_a)

    l23 = math.sqrt((y - x_5) ** 2 + (down - x_4) ** 2 + x ** 2)

    w = x / l23
    v = (l2**2 + l23**2 - l3**2) / (2 * l2 * l23)

    angle_b = math.asin(round(w, 2)) - math.acos(round(v, 2))

    angle_c = math.pi - math.acos(round((l2**2 + l3**2 - l23**2) / (2 * l3 * l2), 2))

    return (
        round(math.degrees(angle_a)),
        round(math.degrees(angle_b)),
        round(math.degrees(angle_c)),
    )


def angle_to_coordinate(a, b, c, l1=None, l2=None, l3=None):
    """Angle to coordinate.

Parameters: a, l1."""
    l1, l2, l3 = link_lengths(l1, l2, l3)
    a = math.radians(a)
    b = math.radians(b)
    c = math.radians(c)

    x = l3 * math.sin(b + c) + l2 * math.sin(b)
    reach = l3 * math.cos(b + c) + l2 * math.cos(b) + l1

    down = reach * math.sin(a)
    y = reach * math.cos(a)
    return x, y, -down


def is_valid_point(point):
    """Is valid point."""
    x, y, z = point
    length = math.sqrt(x**2 + y**2 + z**2)
    return ports.REACH_MIN <= length <= ports.REACH_MAX


def restrict_angle(angle, min_angle=ports.LOGICAL_MIN_DEG, max_angle=ports.LOGICAL_MAX_DEG):
    """Restrict angle."""
    return max(min_angle, min(max_angle, angle))

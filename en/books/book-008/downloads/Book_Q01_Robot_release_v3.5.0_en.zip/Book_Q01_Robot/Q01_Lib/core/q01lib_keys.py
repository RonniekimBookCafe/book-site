# -*- coding: utf-8 -*-
"""q01lib_keys: Educational library module for the QUAD-01 RoboCo series.

Keyboard event mappings and key-name representations."""

import time

from inputs import Input, ButtonState


def is_down(key: str) -> bool:
    """Is down."""
    return Input.pressed(key) == ButtonState.DOWN


class KeyWatcher:
    """Key Watcher."""

    def __init__(self, repeat_sec: float = 0.0):
        self.repeat_sec = repeat_sec
        self._down_since = {}

    def pressed(self, key: str) -> bool:
        now = time.time()
        if not is_down(key):
            self._down_since.pop(key, None)
            return False
        last = self._down_since.get(key)
        if last is None or (self.repeat_sec > 0 and now - last >= self.repeat_sec):
            self._down_since[key] = now
            return True
        return False


def key_stream(key: str):
    """Key stream."""
    return Input.stream(key)

# -*- coding: utf-8 -*-
"""q01lib_actions: Educational library module for the QUAD-01 RoboCo series.

Action demonstrations, animated quadruped poses, and motion patterns."""
import math
import time
from ..core import q01lib_ports as ports
from ..core.q01lib_ik import is_valid_point, coordinate_to_angle
from ..walk.q01lib_gait import swing_pair

ACTION_NAMES = {
    "stand": 'Stand', "hello": 'Standing Wave', "sit_and_wave": 'Sit and Wave',
    "leg_stretch": 'Leg Stretch', "push_ups": 'Push-ups',
    "front_paw_wave": 'Alternating Front-Paw Wave', "swim": 'Swimming Motion',
    "planche_push_ups": 'Planche Push-ups', "handstand": 'Handstand',
    "tap_dance": 'Tap Dance',
}
LOG_NAMES = {
    "stand": "stand", "hello": "hello", "sit_and_wave": "sit and wave",
    "leg_stretch": "leg stretch", "push_ups": "push-ups",
    "front_paw_wave": "front paw wave", "swim": "swim",
    "planche_push_ups": "planche push-ups", "handstand": "handstand",
    "tap_dance": "tap dance",
}
LEVELS = {
    "stand": 0, "hello": 1, "sit_and_wave": 1, "leg_stretch": 1,
    "push_ups": 2, "front_paw_wave": 2, "swim": 2,
    "planche_push_ups": 3, "handstand": 3, "tap_dance": 3,
}

class Actions:
    """Nine active ACTION movement methods only."""

    def __init__(self, motion, settings):
        """settings: ACTION Reader Script parameters."""
        self.motion = motion
        self.servo = motion.servo
        self.s = settings

    def _smooth_move_to(self, target_positions, steps=None, delay=None, rpm=None):
        """Smooth move to.

Parameters: target_positions, steps, delay, rpm."""
        if steps is None:
            steps = self.s["SMOOTH_STEPS"]
        if delay is None:
            delay = self.s["FAST_DELAY"]
        if rpm is None:
            rpm = self.s["DEFAULT_RPM"]

        points = self.motion.points
        increments = []
        for i in range(4):
            dx = (target_positions[i][0] - points[i][0]) / steps
            dy = (target_positions[i][1] - points[i][1]) / steps
            dz = (target_positions[i][2] - points[i][2]) / steps
            increments.append([dx, dy, dz])

        for _ in range(steps):
            for i in range(4):
                points[i][0] += increments[i][0]
                points[i][1] += increments[i][1]
                points[i][2] += increments[i][2]
            self.motion.run(rpm)
            time.sleep(delay)

    def _move_single_leg(self, leg_index, target_position, steps=None, delay=None, rpm=None):
        """Move single leg.

Parameters: leg_index, target_position."""
        if steps is None:
            steps = self.s["SMOOTH_STEPS"]
        if delay is None:
            delay = self.s["FAST_DELAY"]
        if rpm is None:
            rpm = self.s["DEFAULT_RPM"]

        point = self.motion.points[leg_index]
        increments = [(target_position[j] - point[j]) / steps for j in range(3)]

        for _ in range(steps):
            for j in range(3):
                point[j] += increments[j]
            self.motion.run(rpm)
            time.sleep(delay)

    def _wave_servo(self, port, start_angle, end_angle, delay=None, rpm=None):
        """Wave servo.

Parameters: port, start_angle, delay, rpm."""
        if delay is None:
            delay = self.s["FAST_DELAY"]
        if rpm is None:
            rpm = self.s["DEFAULT_RPM"]

        step = 1 if end_angle > start_angle else -1
        for angle in range(start_angle, end_angle + step, step):
            self.servo.set_servo_angle(port, angle, rpm)
            time.sleep(delay)

    def _wave_hand(self):
        """Wave hand."""
        port = ports.FR_HX
        neutral = self.s["SERVO_NEUTRAL"]
        up = self.s["SERVO_UP"]
        down = self.s["SERVO_DOWN"]
        for _ in range(self.s["HAND_WAVES"]):
            self._wave_servo(port, neutral, up)
            self._wave_servo(port, up, down)
            self._wave_servo(port, down, neutral)

    def _return_to_rest(self, delay=None):
        """Return to rest."""
        rest_positions = [list(self.s["REST_POSITION"]) for _ in range(4)]
        self._smooth_move_to(rest_positions, delay=delay or self.s["SLOW_DELAY"])

    def _snap_to(self, positions, rpm):
        """Snap to.

Parameters: positions."""
        for leg, target in positions.items():
            self.motion.points[leg] = list(target)
        self.motion.run(rpm)

    def stand(self):
        """Stand."""
        stand = [0, 0, -self.s["STAND_HEIGHT"]]
        target_positions = [list(stand) for _ in range(4)]
        self._smooth_move_to(target_positions)

    def hello(self):
        """Hello."""
        greeting_pose = [
            [0, -30, -99],
            [10, 0, -99],
            [10, 0, -99],
            [0, 0, -99],
        ]
        self._smooth_move_to(greeting_pose, delay=self.s["SLOW_DELAY"])

        self._move_single_leg(3, [80, 0, -23])

        self._wave_hand()

        final_pose = [[0, 0, -100] for _ in range(4)]
        self._smooth_move_to(final_pose, delay=self.s["SLOW_DELAY"])

    def sit_and_wave(self):
        """Sit and wave."""
        sitting_pose = [
            [-20, -40, -120],
            [50, 0, -105],
            [50, 0, -105],
            [0, 0, -120],
        ]
        self._smooth_move_to(sitting_pose, delay=self.s["SLOW_DELAY"])

        self._move_single_leg(3, [80, 0, -23])

        self._wave_hand()

        self._return_to_rest()

    def leg_stretch(self):
        """Leg stretch."""
        start_pose = [
            [0, 0, -50],
            [-100, 0, -23],
            [-100, 0, -23],
            [0, 0, -50],
        ]
        self._smooth_move_to(start_pose)

        stretch_pose = [
            [80, 0, -80],
            [-30, 0, -120],
            [-30, 0, -120],
            [80, 0, -80],
        ]
        self._smooth_move_to(stretch_pose, delay=self.s["SLOW_DELAY"])

        left_pose = [
            [80, -30, -80],
            [-30, 30, -120],
            [-30, 30, -120],
            [80, -30, -80],
        ]
        right_pose = [
            [80, 30, -80],
            [-30, -30, -120],
            [-30, -30, -120],
            [80, 30, -80],
        ]
        for _ in range(self.s["STRETCH_REPEAT"]):
            self._smooth_move_to(left_pose, delay=self.s["SLOW_DELAY"])
            self._smooth_move_to(right_pose, delay=self.s["SLOW_DELAY"])

        self._return_to_rest()

    def push_ups(self):
        """Push ups."""
        start_pose = [
            [0, 0, -50],
            [-100, 0, -23],
            [-100, 0, -23],
            [0, 0, -50],
        ]
        self._smooth_move_to(start_pose)

        rpm = self.s["DEFAULT_RPM"]
        delay = self.s["FAST_DELAY"]
        points = self.motion.points
        for _ in range(self.s["PUSH_UP_COUNT"]):
            for height in range(50, 120):
                points[0][2] = -height
                points[3][2] = -height
                self.motion.run(rpm)
                time.sleep(delay)
            for height in range(120, 50, -1):
                points[0][2] = -height
                points[3][2] = -height
                self.motion.run(rpm)
                time.sleep(delay)

        self._return_to_rest()

    def front_paw_wave(self):
        """Front paw wave."""
        start_pose = [
            [-20, -20, -120],
            [50, 0, -105],
            [50, 0, -105],
            [-20, 20, -120],
        ]
        self._smooth_move_to(start_pose, delay=self.s["SLOW_DELAY"])

        paw_delay = self.s["PAW_WAVE_DELAY"]
        for _ in range(self.s["PAW_WAVE_REPEAT"]):
            self._move_single_leg(3, [100, 10, -40], delay=paw_delay)
            self._move_single_leg(3, [-20, 20, -120], delay=paw_delay)
            self._move_single_leg(0, [100, -10, -40], delay=paw_delay)
            self._move_single_leg(0, [-20, -20, -120], delay=paw_delay)

        self._return_to_rest(delay=self.s["SLOW_DELAY"])

    # ----------------------------------------------------------------
    # v3.4.0 action-only helpers. No other robot calls them.
    # ----------------------------------------------------------------
    def _v340_move(self, targets, sec, rpm=None):
        """Smooth cosine blend in 0.02 second intervals. None means hold leg."""
        rpm = self.s["DEFAULT_RPM"] if rpm is None else rpm
        points = self.motion.points
        start = [pt[:] for pt in points]
        goal = [start[i] if pos is None else list(pos) for i, pos in enumerate(targets)]
        steps = max(1, round(sec / 0.02))
        for step in range(1, steps + 1):
            k = (1.0 - math.cos(math.pi * step / steps)) / 2.0
            for leg in range(4):
                for axis in range(3):
                    points[leg][axis] = start[leg][axis] + (goal[leg][axis] - start[leg][axis]) * k
            self.motion.run(rpm)
            time.sleep(0.02)

    def _v340_in_range(self, leg, point):
        """IK point and joint-range guard inherited from v3.4.0."""
        if not is_valid_point(point):
            return False
        try:
            angle = self.motion.to_servo_angles(leg, coordinate_to_angle(*point))
        except ValueError:
            return False
        return all(ports.LOGICAL_MIN_DEG < v < ports.LOGICAL_MAX_DEG for v in angle)

    def _v340_step_to(self, targets):
        """Restore feet one at a time, FL/FR/HL/HR."""
        for leg in (0, 3, 1, 2):
            first = self.motion.points[leg][:]
            goal = list(targets[leg])
            if max(abs(a-b) for a,b in zip(first, goal)) < 1.0:
                continue
            lift = self.s["STEP_LIFT"]
            while True:
                midpoint = [(first[0]+goal[0])/2.0, goal[1],
                            max(first[2],goal[2])+lift]
                if lift <= 0 or self._v340_in_range(leg, midpoint):
                    break
                lift -= 5
            for pt in (midpoint,goal):
                targets_for_all = [None] * 4
                targets_for_all[leg] = pt
                self._v340_move(targets_for_all, self.s["STEP_SEC"]/2.0)

    def _v340_stand_by_steps(self):
        """Equalize foot heights and step into stand after swim."""
        height = self.s["STAND_HEIGHT"]
        levels = []
        for leg, pt in enumerate(self.motion.points):
            new = [pt[0],pt[1],-height]
            levels.append(new if self._v340_in_range(leg,new) else None)
        self._v340_move(levels,0.6)
        self._v340_step_to([[0,0,-height] for _ in range(4)])

    def swim(self):
        """Key6: v3.4.0 front arc + out-of-phase hind kick + careful return."""
        s = self.s
        z = s["SWIM_Z"]
        def both(point):
            x,y,zz = point
            return [[x,y,zz],[x,y,zz],[x,-y,zz],[x,-y,zz]]
        def arm(phi_deg):
            phi=math.radians(phi_deg)
            return [s["SWIM_RADIUS"]*math.sin(phi),
                    s["SWIM_RADIUS"]*math.cos(phi)+ports.LINK_HIP,z]
        def kick(k):
            a,b=s["SWIM_HIND"],s["SWIM_KICK"]
            hl=[a[i]+(b[i]-a[i])*k for i in range(3)]
            hr=[a[i]+(b[i]-a[i])*(1-k) for i in range(3)]
            return hl,[hr[0],-hr[1],hr[2]]
        top=s["SWIM_ANGLE_DEG"]
        hind=both(s["SWIM_HIND"])
        self._v340_step_to([self.motion.points[0],hind[1],hind[2],self.motion.points[3]])
        front=both(arm(top))
        self._v340_move([front[0],None,None,front[3]],1.0)
        steps=max(4,round(s["SWIM_STROKE_SEC"]/0.02))
        repeats=s["SWIM_REPEAT"] if s["SWIM_STROKES"] is None else s["SWIM_STROKES"]
        for _ in range(repeats):
            for sign in (-1,1):
                for step in range(1,steps+1):
                    k=(1.0-math.cos(math.pi*step/steps))/2.0
                    phi=-sign*top+sign*2*top*k
                    front_left=arm(phi)
                    kick_k=(1.0-math.cos(2.0*math.pi*s["SWIM_KICKS"]*step/steps))/2.0
                    hl,hr=kick(kick_k)
                    front_right=[front_left[0],-front_left[1],front_left[2]]
                    self._snap_to({i:p for i,p in enumerate((front_left,hl,hr,front_right))},s["DEFAULT_RPM"])
                    time.sleep(0.02)
        tuck=both([0,30,z])
        self._v340_move([tuck[0],None,None,tuck[3]],0.6)
        self._v340_stand_by_steps()

    def tap_dance(self):
        """Key9: v3.4.0 alternating trot diagonal foot lift, two tempos."""
        s=self.s
        self.stand()
        base=[[0,0,-s["STAND_HEIGHT"]] for _ in range(4)]
        height=s["STAND_HEIGHT"]
        for beat_sec in (s["TAP_BEAT_SEC"],s["TAP_BEAT_SEC"]/2.0):
            steps=max(4,round(2.0*beat_sec/0.02))
            for _ in range(max(1,s["TAP_BEATS"]//2)):
                for step in range(1,steps+1):
                    angle=360.0*step/steps
                    _,z1,_,z2=swing_pair(angle,0,s["TAP_LIFT"],height)
                    lift={0:z1+height,2:z1+height,1:z2+height,3:z2+height}
                    feet=[[pt[0],pt[1],pt[2]+lift[i]] for i,pt in enumerate(base)]
                    self._snap_to({i:pt for i,pt in enumerate(feet)},s["DEFAULT_RPM"])
                    time.sleep(0.02)
        self.stand()

    def planche_push_ups(self):
        """Planche push ups."""
        fast = self.s["FAST_RPM"]

        start_pose = [
            [-60, 0, -90],
            [0, 0, -100],
            [0, 0, -100],
            [-60, 0, -90],
        ]
        self._smooth_move_to(start_pose, rpm=fast)
        time.sleep(0.5)

        planche_pose = [
            [-60, 0, -90],
            [-105, 0, 0],
            [-105, 0, 0],
            [-60, 0, -90],
        ]
        self._smooth_move_to(planche_pose, rpm=fast)
        time.sleep(self.s["PLANCHE_HOLD_SEC"])

        extended_pose = [
            [90, 0, -10],
            [0, 0, -90],
            [0, 0, -90],
            [90, 0, -10],
        ]
        self._smooth_move_to(extended_pose, rpm=fast, delay=self.s["SLOW_DELAY"])
        time.sleep(0.5)

        self.stand()

    def handstand(self):
        """Handstand."""
        fast = self.s["FAST_RPM"]

        start_pose = [
            [-60, 0, -90],
            [0, 0, -100],
            [0, 0, -100],
            [-60, 0, -90],
        ]
        self._smooth_move_to(start_pose, rpm=fast)
        time.sleep(0.5)

        planche_pose = [
            [-60, 0, -90],
            [-105, 0, 0],
            [-105, 0, 0],
            [-60, 0, -90],
        ]
        self._smooth_move_to(planche_pose, rpm=fast)
        time.sleep(self.s["PLANCHE_HOLD_SEC"])

        handstand_pose = [
            [0, 0, -90],
            self.motion.points[1][:],
            self.motion.points[2][:],
            [0, 0, -90],
        ]
        self._smooth_move_to(handstand_pose, rpm=fast, delay=self.s["VERY_SLOW_DELAY"])
        time.sleep(self.s["HAND_STAND_HOLD_SEC"])

        folded_pose = [
            [-20, 0, -50],
            [-40, 0, -20],
            [-40, 0, -20],
            [-20, 0, -50],
        ]
        self._smooth_move_to(folded_pose, rpm=fast)
        time.sleep(1.5)

        self.stand()


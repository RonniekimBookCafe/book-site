# -*- coding: utf-8 -*-
"""q01lib_leg2_ik: Educational library module for the QUAD-01 RoboCo series.

Leg Test 2: foot Cartesian coordinates, inverse kinematics (IK), and forward kinematics (FK)."""

import math

from ..core import q01lib_ports as ports
from ..core.q01lib_ik import coordinate_to_angle, angle_to_coordinate, is_valid_point
from ..core.q01lib_key_events import key_label
from ..leg_common import q01lib_leg_screen as scr
from ..core import q01lib_log as L    # Console logging helpers (L.event, L.more, L.key, etc.)

AXES = ("x", "y", "z")


class IKTest:
    """IKTest."""

    TITLE = 'IK Test'
    HEADER = "QUAD-01 LEG TEST 2  IK   (Book-QUAD-01-LEG2)"
    LOG_CATEGORIES = ()
    SHORT = "IK"
    START_FILE = "q01_leg2_ik_start.py"
    USES_LEG_SELECT = True
    VALUE_NAMES = ("KEY_REPEAT_SEC", "STEP_MM", "MOVE_STEPS",
                   "CIRCLE_CENTER_X", "CIRCLE_CENTER_Z", "CIRCLE_RADIUS", "CIRCLE_STEPS",
                   "CIRCLE_STEP_SEC", "CIRCLE_MOVE_STEPS",
                   "MOVE_KEYS", "CIRCLE_KEY", "LEG_RESET_KEY")

    def __init__(self, robot, settings):
        self.robot = robot
        self.motion = robot.motion
        self.s = settings
        self.last = None

    def actions(self):
        """Actions."""
        s = self.s
        items = []
        for key, direction in s["MOVE_KEYS"].items():
            items.append((key, f"foot {self._direction_text(direction)}",
                          lambda direction=direction: self.move_foot(direction), False))
        items.append((s["CIRCLE_KEY"], "draw a circle with the foot", self.circle, True))
        items.append((s["LEG_RESET_KEY"], "selected leg to stand pose", self.reset_leg, False))
        return items

    def repeat_keys(self):
        """Repeat keys."""
        return list(self.s["MOVE_KEYS"])

    @staticmethod
    def _direction_text(direction):
        """(1, 0, 0) → "x +" """
        return " ".join(f"{axis} {'+' if d > 0 else '-'}" for axis, d in zip(AXES, direction) if d)

    def _move_pairs(self):
        """Move pairs."""
        keys = {}
        for key, direction in self.s["MOVE_KEYS"].items():
            for axis, d in zip(AXES, direction):
                if d:
                    keys[(axis, d > 0)] = key_label(key)
        return {axis: (keys.get((axis, True), "?"), keys.get((axis, False), "?")) for axis in AXES}

    def guide(self):
        """Guide."""
        s = self.s
        mv = {axis: L.key("/".join(pair)) for axis, pair in self._move_pairs().items()}
        return [
            f" Foot   {mv['x']} x fwd/back   {mv['y']} y left/right   {mv['z']} z up/down",
            f"        {s['STEP_MM']} per key   {L.key(key_label(s['LEG_RESET_KEY']))} selected leg to stand",
            f" Test   {L.key(key_label(s['CIRCLE_KEY']))} circle (x-z, center x={s['CIRCLE_CENTER_X']} "
            f"z={s['CIRCLE_CENTER_Z']}, r={s['CIRCLE_RADIUS']})",
            " Frame  origin at hip  x fwd(+)  y left(+)  z up(+)",
        ]

    def value_lines(self):
        """Value lines."""
        x, y, z = self.motion.points[self.robot.leg]
        lines = [scr.xyz(round(x), round(y), round(z), 'Target ')]
        last = self.last
        if last is None or last["ik"] is None:
            lines += ["IK -", self.robot.servo_text(prefix='Servo '), scr.paint('Unreachable target', "warn")]
            return lines
        a, b, c = last["ik"]
        lines += [f"IK a {a}  b {b}  c {c}",
                  scr.joints(last["servo"], "angle", 'Servo ')]
        if last["problem"]:
            lines.append(f"Distance {last['reach']:.0f}  {scr.paint('Joint limit reached', 'warn')}")
        else:
            error = f"{last['error']:.1f}"
            lines.append(f"Distance {last['reach']:.0f}  FK error {scr.paint(error, 'ok')}")
        return lines

    def idle_page(self):
        """Idle page."""
        mv = self._move_pairs()
        footer = scr.keys_line([(mv[a][0] + mv[a][1], a) for a in AXES])
        return f"IK · leg {self.robot.leg_name}", self.value_lines(), footer

    def help_lines(self, leg_keys):
        """Help lines."""
        s = self.s
        mv = self._move_pairs()
        return [scr.keys_line([(leg_keys, 'Leg')]),
                scr.keys_line([(mv["x"][0] + mv["x"][1], 'Forward/back x'), (mv["y"][0] + mv["y"][1], 'Left/right y')]),
                scr.keys_line([(mv["z"][0] + mv["z"][1], 'Up/down z'), (key_label(s["CIRCLE_KEY"]), 'Circle')]),
                scr.keys_line([(key_label(s["LEG_RESET_KEY"]), 'Reset selected leg')])]

    def enter(self):
        """Enter."""
        self.robot.stand()
        self.report()

    def on_leg_selected(self):
        self.report()

    def on_stand(self):
        self.report()

    def after_stop(self):
        """After stop."""
        self.robot.sync_from_motion()
        self.report()

    def solve(self, leg, point):
        """Solve."""
        if not is_valid_point(point):
            return None, None, f"reach outside {ports.REACH_MIN}-{ports.REACH_MAX}"
        try:
            ik = coordinate_to_angle(*point)
        except ValueError:
            return None, None, "no IK solution for the leg lengths"
        servo = self.motion.to_servo_angles(leg, ik)
        if any(v <= ports.LOGICAL_MIN_DEG or v >= ports.LOGICAL_MAX_DEG for v in servo):
            return ik, servo, f"joint at {ports.LOGICAL_MIN_DEG}-{ports.LOGICAL_MAX_DEG} deg limit"
        return ik, servo, None

    def report(self):
        """Report."""
        leg = self.robot.leg
        name = self.robot.leg_name
        x, y, z = self.motion.points[leg]
        ik, servo, problem = self.solve(leg, [x, y, z])
        hx, hy, kn = ports.LEG_JOINT_PORTS[leg]
        L.event("STATE", f"{name} foot target  {L.xyz_text(x, y, z)}")
        if ik is None:
            L.event("WARN", problem)
            self.last = None
            return
        fx, fy, fz = angle_to_coordinate(*ik)
        L.more(f"IK     a={ik[0]:3}  b={ik[1]:4}  c={ik[2]:3}")
        L.more(f"servo  HX={servo[0]:3}  HY={servo[1]:3}  KN={servo[2]:3}  (ports {hx} {hy} {kn})")
        L.more(f"FK     {L.xyz_text(fx, fy, fz)}")
        if problem:
            L.event("WARN", problem)
        self.last = self.measure()

    def measure(self):
        """Measure."""
        leg = self.robot.leg
        x, y, z = self.motion.points[leg]
        ik, servo, problem = self.solve(leg, [x, y, z])
        if ik is None:
            return None
        fx, fy, fz = angle_to_coordinate(*ik)
        return {"ik": ik, "servo": servo, "problem": problem,
                "reach": math.sqrt(x * x + y * y + z * z),
                "error": math.sqrt((fx - x) ** 2 + (fy - y) ** 2 + (fz - z) ** 2)}

    def move_foot(self, direction):
        """Move foot."""
        leg = self.robot.leg
        step = self.s["STEP_MM"]
        target = [c + d * step for c, d in zip(self.motion.points[leg], direction)]
        ik, servo, problem = self.solve(leg, target)
        if ik is None:
            L.event("WARN", f"{self.robot.leg_name} cannot reach ({target[0]:.0f}, {target[1]:.0f}, "
                            f"{target[2]:.0f}), foot kept")
            L.more(problem)
            return
        positions = [list(p) for p in self.motion.points]
        positions[leg] = target
        self.motion.move_to(positions, self.s["MOVE_STEPS"])
        self.robot.sync_from_motion()
        self.report()

    def circle(self):
        """Circle."""
        s = self.s
        leg = self.robot.leg
        name = self.robot.leg_name
        y = self.robot.stand_positions()[leg][1]
        cx, cz, r, n = s["CIRCLE_CENTER_X"], s["CIRCLE_CENTER_Z"], s["CIRCLE_RADIUS"], s["CIRCLE_STEPS"]
        path = [[cx + r * math.cos(2 * math.pi * k / n), y,
                 cz + r * math.sin(2 * math.pi * k / n)] for k in range(n + 1)]
        ranges = [[180, 0], [180, 0], [180, 0]]
        for p in path:
            ik, servo, problem = self.solve(leg, p)
            if problem:
                L.event("WARN", f"{name} circle point ({p[0]:.0f}, {p[1]:.0f}, {p[2]:.0f}), circle skipped")
                L.more(problem)
                return
            for i, v in enumerate(servo):
                ranges[i] = [min(ranges[i][0], v), max(ranges[i][1], v)]
        L.event("TASK", f"{name} circle  x={cx} z={cz} r={r}  {n} points  ~{n * s['CIRCLE_STEP_SEC']:.1f} s")
        L.more(f"servo range  HX {ranges[0][0]}-{ranges[0][1]}  HY {ranges[1][0]}-{ranges[1][1]}  "
               f"KN {ranges[2][0]}-{ranges[2][1]}")
        self._glide(leg, path[0])
        for p in path[1:]:
            self._step_to(leg, p)
        self._glide(leg, self.robot.stand_positions()[leg])
        self.robot.sync_from_motion()
        self.report()

    def _glide(self, leg, target):
        """Glide."""
        steps = max(1, self.s["CIRCLE_MOVE_STEPS"])
        start = list(self.motion.points[leg])
        for i in range(1, steps + 1):
            self._step_to(leg, [a + (b - a) * i / steps for a, b in zip(start, target)])

    def _step_to(self, leg, point):
        """Step to."""
        self.motion.points[leg] = list(point)
        self.motion.run()
        self.robot.sync_from_motion()
        self.last = self.measure()
        self.robot.show_running(f"IK · leg {self.robot.leg_name} circle", *self.value_lines())
        self.robot.wait(self.s["CIRCLE_STEP_SEC"])

    def reset_leg(self):
        """Reset leg."""
        positions = [list(p) for p in self.motion.points]
        positions[self.robot.leg] = self.robot.stand_positions()[self.robot.leg]
        self.motion.move_to(positions, self.s["MOVE_STEPS"])
        self.robot.sync_from_motion()
        self.report()

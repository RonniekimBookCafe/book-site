# -*- coding: utf-8 -*-
"""__init__: Educational library package for the QUAD-01 RoboCo series."""

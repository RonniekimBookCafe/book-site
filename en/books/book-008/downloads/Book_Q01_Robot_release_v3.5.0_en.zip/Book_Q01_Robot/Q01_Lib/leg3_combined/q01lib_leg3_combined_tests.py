# -*- coding: utf-8 -*-
"""q01lib_leg3_combined_tests: Educational library module for the QUAD-01 RoboCo series.

Leg Test 3: combined IK/FK validation and multi-leg motion sequences."""

import time

from ..core import q01lib_ports as ports
from ..leg_common.q01lib_leg_check import check_point, side_word, side_word_en
from ..core import q01lib_log as L    # Console logging helpers (L.event, L.more, L.key, etc.)

NAME_WIDTH = 13
TARGET_WIDTH = 16


def default_y(leg):
    """Default y."""
    return ports.FOOT_Y_OFFSET if leg in ports.LEFT_LEGS else -ports.FOOT_Y_OFFSET


class LegCombinedTests:
    """Leg Combined Tests."""

    def __init__(self, motion, settings, on_case=None, wait=None, on_result=None, on_pose=None):
        """Init."""
        self.motion = motion
        self.s = settings
        self.rpm = settings["SERVO_RPM"]
        self.names = ports.LEG_NAMES
        self.on_case = on_case
        self.wait = wait if wait is not None else time.sleep
        self.on_result = on_result
        self.on_pose = on_pose

    def case(self, label, leg=None, pos=None):
        """Case."""
        if self.on_case is not None:
            self.on_case(label.split(" (")[0], leg, pos)

    def result(self, leg, pos, r):
        """Result."""
        if self.on_result is not None:
            self.on_result(leg, pos, r)

    def stand_positions(self):
        h = self.s["BODY_HEIGHT"]
        return [[0, default_y(leg), -h] for leg in range(4)]

    def default_position(self):
        """Default position."""
        self.move_all(self.stand_positions(), show=False)
        L.event("STATE", "stand pose")

    def move_all(self, targets, show=True):
        """Move all."""
        self.motion.move_to([list(t) for t in targets], self.s["MOVE_ALL_STEPS"], self.rpm)
        if show and self.on_pose is not None:
            self.on_pose()

    def move_one(self, leg, target):
        """Move one."""
        steps = self.s["MOVE_SINGLE_STEPS"]
        point = self.motion.points[leg]
        start = list(point)
        delta = [(t - c) / steps for t, c in zip(target, start)]
        for _ in range(steps):
            for j in range(3):
                point[j] += delta[j]
            self.motion.run(self.rpm)
            self.wait(self.s["MOVE_SINGLE_DELAY"])

    def snapshot(self):
        return [list(p) for p in self.motion.points]

    def report(self, leg, en, pos):
        """Report."""
        r = check_point(self.motion, leg, pos)
        self.result(leg, pos, r)
        L.event("TASK", f"{ports.LEG_NAMES[leg]} {en:<18} {self.fmt(pos)}")
        if not r["ok"]:
            L.event("WARN", f"invalid: {r['reason']}")
            return False
        a, b, c = r["ik"]
        hx, hy, kn = r["servo"]
        fx, fy, fz = r["fk"]
        L.more(f"IK     a={a:3}  b={b:4}  c={c:4}")
        L.more(f"servo  HX={hx:3}  HY={hy:3}  KN={kn:3}")
        L.more(f"FK     {L.xyz_text(fx, fy, fz)}   err={r['error']:.1f}")
        if r["limited"]:
            L.event("WARN", f"{' '.join(r['limited'])} at 0/180 deg limit: foot misses the target")
        return True

    @staticmethod
    def table_head(title):
        """Table head."""
        L.event("METRIC", f"{title:<{NAME_WIDTH}} {'target':<{TARGET_WIDTH}} HX  HY  KN  err limit")

    def report_short(self, leg, en, pos):
        """Report short."""
        r = check_point(self.motion, leg, pos)
        self.result(leg, pos, r)
        head = f"{en:<{NAME_WIDTH}} {self.fmt(pos):<{TARGET_WIDTH}}"
        if not r["ok"]:
            L.more(f"{head}invalid  reach={r['reach']:.1f}")
            return False
        hx, hy, kn = r["servo"]
        L.more(f"{head}{hx:3} {hy:3} {kn:3} {r['error']:4.1f} {' '.join(r['limited'])}".rstrip())
        return True

    @staticmethod
    def fmt(pos):
        return "[" + ", ".join(f"{v:g}" if isinstance(v, (int, float)) else str(v) for v in pos) + "]"

    def fl_basic(self):
        """Fl basic."""
        original = list(self.motion.points[0])
        cases = [
            ('Stand', "stand", [0, 10, -99]),
            ('Forward (x +30)', "fwd  x+30", [30, 10, -99]),
            ('Backward (x -30)', "back x-30", [-30, 10, -99]),
            ('Up (z -70, foot lifted)', "up   z-70", [0, 10, -70]),
            ('Down (z -120, leg extended)', "down z-120", [0, 10, -120]),
            ('y +20 (outward)', "y+20 out", [0, 30, -99]),
            ('y -20 (inward)', "y-20 in", [0, -10, -99]),
        ]
        for name, en, pos in cases:
            self.case(f"FL {name}", 0, pos)
            self.move_one(0, pos)
            self.report(0, en, pos)
            self.wait(self.s["CASE_HOLD_SEC"])
        self.move_one(0, original)

    def fl_extreme(self):
        """Fl extreme."""
        original = list(self.motion.points[0])
        cases = [
            ('Forward + Up', "fwd+up", [50, 10, -70]),
            ('Backward + Up', "back+up", [-50, 10, -70]),
            ('Forward + Down', "fwd+down", [50, 10, -120]),
            ('Up + Outward', "up+outward", [0, 40, -50]),
            ('Forward + Up + Outward', "fwd+up+outward", [40, 30, -60]),
        ]
        for name, en, pos in cases:
            self.case(f"FL {name}", 0, pos)
            if check_point(self.motion, 0, pos)["ok"]:
                self.move_one(0, pos)
            self.report(0, en, pos)
            self.wait(self.s["CASE_HOLD_SEC"])
        self.move_one(0, original)

    def fl_validity(self):
        """Fl validity."""
        L.event("TASK", f"reach check only ({ports.REACH_MIN}-{ports.REACH_MAX}), servos not moved")
        original = list(self.motion.points[0])
        cases = [
            ('Too high', "too high", [0, 10, -20]),
            ('Too low', "too low", [0, 10, -140]),
            ('Too far forward', "too far fwd", [100, 10, -99]),
            ('Combined limit exceeded', "mixed over", [70, 50, -70]),
        ]
        L.event("METRIC", f"{'case':<{NAME_WIDTH}} {'target':<{TARGET_WIDTH}} reach  result")
        for name, en, pos in cases:
            self.case(f"FL {name}", 0, pos)
            r = check_point(self.motion, 0, pos)
            self.result(0, pos, r)
            L.more(f"{en:<{NAME_WIDTH}} {self.fmt(pos):<{TARGET_WIDTH}}{r['reach']:5.1f}  "
                   f"{'valid' if r['ok'] else 'invalid'}")
            if r["ok"]:
                limit = " ".join(r["limited"]) or "none"
                L.event("WARN", f"unexpectedly valid: err={r['error']:.1f}  limit={limit}")
            self.wait(self.s["VALIDITY_HOLD_SEC"])
        self.move_one(0, original)

    def all_legs(self):
        """All legs."""
        for leg, name in enumerate(self.names):
            original = list(self.motion.points[leg])
            self._basic(leg, name)
            self._extreme(leg, name)
            self._validity(leg, name)
            self.move_one(leg, original)
            L.event("STATE", f"{name} back to start")
            self.wait(self.s["LEG_GAP_SEC"])
        self.default_position()

    def _basic(self, leg, name):
        self.table_head(f"{name} basic")
        y = default_y(leg)
        cases = [
            ('Basic', "stand", [0, y, -99]),
            ('Forward', "fwd", [30, y, -99]),
            ('Backward', "back", [-30, y, -99]),
            ('Up', "up", [0, y, -70]),
            ('Down', "down", [0, y, -120]),
            (f"y +20 ({side_word(leg, 1)})", f"y+20 {side_word_en(leg, 1)}", [0, y + 20, -99]),
            (f"y -20 ({side_word(leg, -1)})", f"y-20 {side_word_en(leg, -1)}", [0, y - 20, -99]),
        ]
        for case_name, en, pos in cases:
            self.case(f"{name} {case_name}", leg, pos)
            self.move_one(leg, pos)
            self.report_short(leg, en, pos)
            self.wait(self.s["STEP_HOLD_SEC"])

    def _extreme(self, leg, name):
        self.table_head(f"{name} extreme")
        y = default_y(leg)
        cases = [
            ('Forward + Up', "fwd+up", [50, y, -70]),
            ('Backward + Up', "back+up", [-50, y, -70]),
            ('Forward + Down', "fwd+down", [50, y, -120]),
            (f"Up + y +30 ({side_word(leg, 1)})", f"up y+30 {side_word_en(leg, 1)}", [0, y + 30, -50]),
            (f"Combined y +20 ({side_word(leg, 1)})", f"mix y+20 {side_word_en(leg, 1)}", [40, y + 20, -60]),
        ]
        for case_name, en, pos in cases:
            self.case(f"{name} {case_name}", leg, pos)
            if check_point(self.motion, leg, pos)["ok"]:
                self.move_one(leg, pos)
            self.report_short(leg, en, pos)
            self.wait(self.s["STEP_HOLD_SEC"])

    def _validity(self, leg, name):
        L.event("METRIC", f"{name + ' reach':<{NAME_WIDTH}} {'target':<{TARGET_WIDTH}} reach  result")
        y = default_y(leg)
        cases = [
            ('Too high', "too high", [0, y, -20]),
            ('Too low', "too low", [0, y, -140]),
            ('Too far forward', "too far fwd", [100, y, -99]),
            ('Combined limit exceeded', "mixed over", [70, y + 40, -70]),
        ]
        for case_name, en, pos in cases:
            self.case(f"{name} {case_name}", leg, pos)
            r = check_point(self.motion, leg, pos)
            self.result(leg, pos, r)
            L.more(f"{en:<{NAME_WIDTH}} {self.fmt(pos):<{TARGET_WIDTH}}{r['reach']:5.1f}  "
                   f"{'valid' if r['ok'] else 'invalid'}")
            self.wait(self.s["STEP_HOLD_SEC"])

    def lift_each(self):
        """Lift each."""
        originals = self.snapshot()
        for leg, name in enumerate(self.names):
            self.table_head(f"{name} lift")
            y = default_y(leg)
            for label, en, pos in (('Lift', "lift", [0, y, -70]), ('Forward', "fwd", [30, y, -70]),
                                   ('Backward', "back", [-30, y, -70])):
                self.case(f"{name} {label}", leg, pos)
                self.move_one(leg, pos)
                self.report_short(leg, en, pos)
                self.wait(self.s["STEP_HOLD_SEC"])
            self.move_one(leg, originals[leg])
            L.event("STATE", f"{name} back to start")
            self.wait(self.s["STEP_HOLD_SEC"])

    def diagonal(self):
        """Diagonal."""
        originals = self.snapshot()
        hold = self.s["STEP_HOLD_SEC"]
        for title, legs in (("FL + HR", (0, 2)), ("FR + HL", (3, 1))):
            self.case(title)
            target = [list(p) for p in originals]
            for leg in legs:
                target[leg] = [0, default_y(leg), -70]
            self.move_all(target)
            L.event("ACTION", f"{title}  lift (z=-70)")
            self.wait(hold)
            for leg in legs:
                target[leg] = [30, default_y(leg), -70]
            self.move_all(target)
            L.event("ACTION", f"{title}  forward (x=+30)")
            self.wait(hold)
            self.move_all(originals)
            L.event("ACTION", f"{title}  back to start")
            if title == "FL + HR":
                self.wait(hold)

    def joint_limits(self):
        """Joint limits."""
        originals = self.snapshot()
        for leg, name in enumerate(self.names):
            self.table_head(f"{name} limits")
            y = default_y(leg)
            cases = [
                ('HX side 1 (y -30, z -130)', "HX y-30", [0, y - 30, -130]),
                ('HX side 2 (y +30, z -130)', "HX y+30", [0, y + 30, -130]),
                ('Fold leg (z -50)', "fold z-50", [0, y, -50]),
                ('Extend leg (z -130)', "extend z-130", [0, y, -130]),
                ('Reach forward (x +50, z -90)', "fwd x+50", [50, y, -90]),
                ('Reach backward (x -50, z -90)', "back x-50", [-50, y, -90]),
            ]
            for case_name, en, pos in cases:
                self.case(f"{name} {case_name}", leg, pos)
                if check_point(self.motion, leg, pos)["ok"]:
                    self.move_one(leg, pos)
                self.report_short(leg, en, pos)
                self.wait(self.s["STEP_HOLD_SEC"])
            self.move_one(leg, originals[leg])
            self.wait(self.s["STEP_HOLD_SEC"])

    def three_legs(self):
        """Three legs."""
        originals = self.snapshot()
        for leg, name in enumerate(self.names):
            self.case(f"{name} lift")
            target = [list(p) for p in originals]
            target[leg] = [0, default_y(leg), -70]
            self.move_all(target)
            L.event("ACTION", f"{name} lifted, 3 legs on stand pose")
            self.wait(self.s["THREE_LEG_HOLD_SEC"])
        self.move_all(originals)
        L.event("ACTION", "all legs back to start")

    def walk_sequence(self):
        """Walk sequence."""
        originals = self.snapshot()
        h, lift, stride = self.s["BODY_HEIGHT"], self.s["WALK_LIFT_Z"], self.s["WALK_STEP_X"]
        hold = self.s["WALK_HOLD_SEC"]
        yl, yr = ports.FOOT_Y_OFFSET, -ports.FOOT_Y_OFFSET
        for cycle in range(self.s["WALK_CYCLES"]):
            L.event("TASK", f"cycle {cycle + 1}/{self.s['WALK_CYCLES']}")
            steps = [
                ('1. Lift FL+HR', "1 FL+HR lift", [[0, yl, lift], list(originals[1]), [0, yr, lift], list(originals[3])]),
                ('2. Move FL+HR forward', "2 FL+HR forward",
                 [[stride, yl, lift], list(originals[1]), [stride, yr, lift], list(originals[3])]),
                ('3. Lower FL+HR', "3 FL+HR down",
                 [[stride, yl, -h], list(originals[1]), [stride, yr, -h], list(originals[3])]),
                ('4. Lift FR+HL', "4 FR+HL lift", [[stride, yl, -h], [0, yl, lift], [stride, yr, -h], [0, yr, lift]]),
                ('5. Move FR+HL forward', "5 FR+HL forward",
                 [[stride, yl, -h], [stride, yl, lift], [stride, yr, -h], [stride, yr, lift]]),
                ('6. Lower FR+HL', "6 FR+HL down",
                 [[stride, yl, -h], [stride, yl, -h], [stride, yr, -h], [stride, yr, -h]]),
                ('7. Move body forward', "7 body forward (all feet back)",
                 [[0, yl, -h], [0, yl, -h], [0, yr, -h], [0, yr, -h]]),
            ]
            for label, en, target in steps:
                self.case(label)
                self.move_all(target)
                L.event("ACTION", en)
                self.wait(hold)
        self.move_all(originals)
        L.event("ACTION", "all legs back to start")

# -*- coding: utf-8 -*-
"""q01lib_leg3_combined: Educational library module for the QUAD-01 RoboCo series.

Leg Test 3: combined IK/FK validation and multi-leg motion sequences."""

from ..core import q01lib_ports as ports
from ..core.q01lib_key_events import key_label
from ..core import q01lib_log as L    # Console logging helpers (L.event, L.more, L.key, etc.)
from ..leg_common.q01lib_leg_check import check_point
from ..leg_common import q01lib_leg_screen as scr
from .q01lib_leg3_combined_tests import LegCombinedTests

TESTS = {
    "fl_basic": ('FL Basic Movement', 'Basic', 'IK Check · FL', "FL basic"),
    "fl_extreme": ('FL Extreme Targets', 'Extreme', 'IK Check · FL', "FL extreme"),
    "fl_validity": ('FL Valid Workspace', 'Valid', 'IK Check · FL', "FL reach"),
    "all_legs": ('All Legs', 'All', 'IK Check · All Legs', "all legs"),
    "joint_limits": ('Joint Angle Limit', 'Joint Angle Limit', 'IK Check · All Legs', "joint limits"),
    "lift_each": ('Individual Leg', 'Individual', 'Combined Action', "lift each"),
    "diagonal": ('Diagonal Pair', 'Diagonal', 'Combined Action', "diagonal"),
    "three_legs": ('Three-Point Support Pose', 'Three-Point Support', 'Combined Action', "3-leg support"),
    "walk_sequence": ('Gait Sequence', 'Walking', 'Combined Action', "walk sequence"),
}
GROUPS = ('IK Check · FL', 'IK Check · All Legs', 'Combined Action')
GROUP_EN = {'IK Check · FL': "IK FL", 'IK Check · All Legs': "IK 4 legs", 'Combined Action': "Combined"}
GROUP_SHORT = {'IK Check · FL': 'FL IK Check', 'IK Check · All Legs': 'All-Leg IK Check',
               'Combined Action': 'Combined Action'}


class CombinedTest:
    """Combined Test."""

    TITLE = 'Combined Test'
    HEADER = "QUAD-01 LEG TEST 3  COMBINED   (Book-QUAD-01-LEG3)"
    LOG_CATEGORIES = ("ACTION", "METRIC")
    SHORT = 'Combined'
    START_FILE = "q01_leg3_combined_start.py"
    USES_LEG_SELECT = False
    VALUE_NAMES = ("MOVE_ALL_STEPS", "MOVE_SINGLE_STEPS", "MOVE_SINGLE_DELAY", "CASE_HOLD_SEC",
                   "VALIDITY_HOLD_SEC", "STEP_HOLD_SEC", "LEG_GAP_SEC", "THREE_LEG_HOLD_SEC",
                   "WALK_CYCLES", "WALK_LIFT_Z", "WALK_STEP_X", "WALK_HOLD_SEC", "TEST_KEYS")

    def __init__(self, robot, settings):
        self.robot = robot
        self.s = settings
        for key, name in settings["TEST_KEYS"].items():
            if name not in TESTS:
                raise ValueError(f"TEST_KEYS '{key}': unknown test '{name}'. "
                                 f"Use one of: {', '.join(TESTS)}")
        self.title = ""
        self.label = ""
        self.tests = LegCombinedTests(robot.motion, settings, on_case=self.show_case, wait=robot.wait,
                                      on_result=self.show_result, on_pose=self.show_pose)

    def actions(self):
        """Actions."""
        return [(key, TESTS[name][3], lambda name=name: self.perform(name), True)
                for key, name in self.s["TEST_KEYS"].items()]

    def repeat_keys(self):
        """Repeat keys."""
        return []

    def _keys_in(self, group):
        return [key_label(k) for k, n in self.s["TEST_KEYS"].items() if TESTS[n][2] == group]

    def guide(self):
        """Guide."""
        lines = []
        for group in GROUPS:
            items = [f"{L.key(key_label(k))} {TESTS[n][3]}"
                     for k, n in self.s["TEST_KEYS"].items() if TESTS[n][2] == group]
            label = GROUP_EN[group]
            while items:
                row = items.pop(0)
                while items and L.visible_len(row) + 3 + L.visible_len(items[0]) <= 48:
                    row += "   " + items.pop(0)
                lines.append(f" {label:<10} {row}")
                label = ""
        lines.append(" Frame      origin at hip  x fwd(+)  y left(+)  z up(+)")
        lines.append("            stand [0, +-10, -99]")
        return lines

    def idle_page(self):
        """Idle page."""
        body = []
        for group in GROUPS:
            keys = self._keys_in(group)
            if keys:
                body.append(scr.keys_line([(" ".join(keys), GROUP_SHORT[group])]))
        footer = scr.keys_line([(key_label(self.s["HELP_KEY"]), 'Key Help'),
                                (key_label(self.s["STAND_KEY"]), 'Stand')], " · ")
        return 'Combined Test', body, footer

    def help_lines(self, leg_keys=None):
        """Help lines."""
        lines = []
        for group in GROUPS:
            pairs = [(key_label(k), TESTS[n][1])
                     for k, n in self.s["TEST_KEYS"].items() if TESTS[n][2] == group]
            if not pairs:
                continue
            if len("  ".join(f"{k} {d}" for k, d in pairs)) <= 18:
                lines.append(scr.keys_line(pairs))
            else:
                for i in range(0, len(pairs), 2):
                    lines.append(scr.keys_line(pairs[i:i + 2]))
        return lines

    def enter(self):
        """Enter."""
        self.tests.default_position()
        self.robot.sync_from_motion()

    def after_stop(self):
        """After stop."""
        self.robot.sync_from_motion()

    def show_case(self, label, leg=None, pos=None):
        """Show case."""
        self.label = label
        if pos is not None:
            self.show_result(leg, pos, check_point(self.robot.motion, leg, pos))
        else:
            self.show_pose()

    def show_result(self, leg, pos, r):
        """Show result."""
        x, y, z = pos
        body = [self.label, scr.xyz(f"{x:g}", f"{y:g}", f"{z:g}", f"{ports.LEG_NAMES[leg]} ")]
        if not r["ok"]:
            body += [scr.joints((None, None, None)), f"Distance {r['reach']:.0f} · {scr.paint('Unreachable', 'warn')}"]
        else:
            body.append(scr.joints(r["servo"], "angle"))
            error = f"{r['error']:.1f}"
            if r["limited"]:
                body.append(f"FK error {scr.paint(error, 'warn')} · "
                            f"{scr.paint('·'.join(r['limited']) + ' limit', 'warn')}")
            else:
                body.append(f"FK error {scr.paint(error, 'ok')}")
        self.robot.show_running(self.title, *body)

    def show_pose(self):
        """Show pose."""
        if not self.title:
            return
        p = {name: self.robot.motion.points[i] for i, name in enumerate(ports.LEG_NAMES)}

        def xz(name):
            return f"{name} ({scr.paint(round(p[name][0]), 'coord')}, {scr.paint(round(p[name][2]), 'coord')})"
        self.robot.show_running(self.title, self.label, 'Foot (x, z)',
                                f"{xz('FL')}  {xz('FR')}", f"{xz('HL')}  {xz('HR')}")

    def perform(self, name):
        self.title = TESTS[name][0]
        self.label = 'Running'
        try:
            getattr(self.tests, name)()
        finally:
            self.title = ""
            self.robot.sync_from_motion()

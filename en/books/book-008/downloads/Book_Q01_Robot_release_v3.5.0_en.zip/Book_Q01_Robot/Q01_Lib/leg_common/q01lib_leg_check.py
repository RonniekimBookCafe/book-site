# -*- coding: utf-8 -*-
"""q01lib_leg_check: Educational library module for the QUAD-01 RoboCo series."""

import math

from ..core import q01lib_ports as ports
from ..core.q01lib_ik import coordinate_to_angle, angle_to_coordinate, is_valid_point

JOINT_NAMES = ("HX", "HY", "KN")


def servo_to_ik(leg, servo):
    """Servo to IK."""
    hx, hy, kn = servo
    cal = ports.CALIBRATION_ANGLES[leg]
    if leg in ports.LEFT_LEGS:
        return hx - cal[0], (90 - hy) - cal[1], kn - cal[2]
    return hx - cal[0], (hy - 90) - cal[1], (180 - kn) - cal[2]


def foot_from_servo(leg, servo):
    """Foot from servo."""
    return angle_to_coordinate(*servo_to_ik(leg, servo))


def check_point(motion, leg, point):
    """Check point.

Parameters: motion, leg, point."""
    result = {"ok": False, "reason": None, "reach": math.sqrt(sum(v * v for v in point)),
              "ik": None, "servo": None, "limited": [], "fk": None, "error": None}
    if not is_valid_point(point):
        result["reason"] = f"reach {result['reach']:.1f} outside {ports.REACH_MIN}-{ports.REACH_MAX}"
        return result
    try:
        ik = coordinate_to_angle(*point)
    except ValueError:
        result["reason"] = "no IK solution for the leg lengths"
        return result
    servo = motion.to_servo_angles(leg, ik)
    fk = foot_from_servo(leg, servo)
    result.update(ok=True, ik=ik, servo=servo, fk=fk,
                  limited=[n for n, v in zip(JOINT_NAMES, servo)
                           if v <= ports.LOGICAL_MIN_DEG or v >= ports.LOGICAL_MAX_DEG],
                  error=math.sqrt(sum((f - t) ** 2 for f, t in zip(fk, point))))
    return result


def side_word(leg, dy):
    """Side word."""
    if dy == 0:
        return ""
    outward = (dy > 0) == (leg in ports.LEFT_LEGS)
    return 'Outward' if outward else 'Inward'


def side_word_en(leg, dy):
    """Side word en."""
    if dy == 0:
        return ""
    return "out" if (dy > 0) == (leg in ports.LEFT_LEGS) else "in"

# -*- coding: utf-8 -*-
"""q01lib_leg_screen: Educational library module for the QUAD-01 RoboCo series.

Robot text-display rendering and formatted status pages."""

SCREEN_COLOR = True
COLORS = {
    "title": "#FF8A34",
    "coord": "#20D6D9",
    "angle": "#FFD91A",
    "ok": "#4ADE80",
    "warn": "#FF5A52",
    "key": "#FFFFFF",
    "rule": "#6B7280",       # Separator line
    "hint": "#B0B7C3",
}
RULE_CHAR = "-"
RULE_WIDTH = 18
BODY_LINES = 4


def paint(text, kind):
    """Paint."""
    text = str(text)
    if not SCREEN_COLOR:
        return text
    if kind == "key":
        return f"<b><color={COLORS['key']}>{text}</color></b>"
    return f"<color={COLORS[kind]}>{text}</color>"


def value(v, kind):
    """Value."""
    if v is None or v == "-":
        return "-"
    if kind is None:
        return str(v)
    return paint(v, kind)


def joints(values, kind="angle", prefix=""):
    """Joints."""
    hx, hy, kn = values
    return f"{prefix}HX {value(hx, kind)}  HY {value(hy, kind)}  KN {value(kn, kind)}"


def xyz(x, y, z, prefix=""):
    """Xyz."""
    return f"{prefix}x {value(x, 'coord')}  y {value(y, 'coord')}  z {value(z, 'coord')}"


def keys_line(pairs, sep="  "):
    """Keys line."""
    return sep.join(f"{paint(k, 'key')} {paint(desc, 'hint')}" for k, desc in pairs)


def rule():
    """Rule."""
    return paint(RULE_CHAR * RULE_WIDTH, "rule")


def page(title, body, footer):
    """Page."""
    body = list(body)
    body += [""] * (BODY_LINES - len(body))
    return [paint(title, "title"), rule(), *body, rule(), footer]

# -*- coding: utf-8 -*-
"""q01lib_leg_app: Educational library module for the QUAD-01 RoboCo series.

Application logic that coordinates robot configuration, keys, and screen output."""

import time

from ..core import q01lib_ports as ports
from ..core.q01lib_key_events import KeyEvents, key_label
from ..core.q01lib_log import log_traceback
from ..core.q01lib_welcome import (show_welcome, checked_duration,
                                    DEFAULT_WELCOME_SEC, DEFAULT_START_SCREEN_SEC)
from .q01lib_leg_robot import LegTestRobot, TestStopped
from . import q01lib_leg_screen as scr
from ..core import q01lib_log as L    # Console logging helpers (L.event, L.more, L.key, etc.)

COMMON_NAMES = ("SERVO_RPM", "BODY_HEIGHT", "LOOP_SLEEP_SEC", "HELP_KEY", "STAND_KEY", "STOP_KEY")
LEG_SELECT_NAMES = ("START_LEG", "LEG_SELECT_KEYS")
OPTIONAL_NAMES = ("LOG_COLOR", "WELCOME_SEC", "START_SCREEN_SEC")
COMMON_LOG_CATEGORIES = ("INPUT", "STATE", "JOINT", "TASK", "WARN", "ERROR")


def check_names(values, names, file_name):
    """Check names."""
    unknown = [name for name in values if name not in names and name not in OPTIONAL_NAMES]
    if unknown:
        L.event("WARN", "unknown names in the start file (check spelling)")
        for name in unknown:
            L.more(name)
    missing = [n for n in names if n not in values]
    if missing:
        raise ValueError(f"{file_name}: missing {', '.join(missing)} (check spelling)")


WELCOME_MODELS = {
    "q01_leg1_joint_start.py": "Book-QUAD-01-LEG1",
    "q01_leg2_ik_start.py": "Book-QUAD-01-LEG2",
    "q01_leg3_combined_start.py": "Book-QUAD-01-LEG3",
    "q01_body_pose_start.py": "Book-QUAD-01-ROLL_PITCH_YAW",
    "q01_balance_test_start.py": "Book-QUAD-01-BALANCE",
}


class LegTestApp:
    """Leg Test App."""

    def __init__(self, script_values: dict, test_class):
        """Init."""
        self.ready = False
        try:
            self._setup(script_values, test_class)
            self.ready = True
        except Exception as e:
            L.setup_failed(e, test_class.START_FILE)

    def _setup(self, script_values: dict, test_class):
        values = {name: value for name, value in script_values.items() if name.isupper()}
        L.configure(COMMON_LOG_CATEGORIES + test_class.LOG_CATEGORIES, values.get("LOG_COLOR"))
        names = COMMON_NAMES + (LEG_SELECT_NAMES if test_class.USES_LEG_SELECT else ()) + test_class.VALUE_NAMES
        check_names(values, names, test_class.START_FILE)
        self.s = values
        self.robot = LegTestRobot(values)
        model_name = WELCOME_MODELS.get(test_class.START_FILE)
        if model_name:
            show_welcome(self.robot.screen, model_name,
                         values.get("WELCOME_SEC", DEFAULT_WELCOME_SEC))
        if not getattr(test_class, "SHOWS_START", False):
            self.robot.show_page(f"{test_class.TITLE} · start",
                                 [scr.paint('Initializing...', "hint"), 'Move to standing pose'],
                                 scr.paint('Please wait', "hint"))
        self.test = test_class(self.robot, values)
        if model_name:
            intro_sec = checked_duration(values.get("START_SCREEN_SEC", DEFAULT_START_SCREEN_SEC),
                                         "START_SCREEN_SEC")
            if intro_sec:
                time.sleep(intro_sec)

        if len({values["HELP_KEY"], values["STAND_KEY"], values["STOP_KEY"]}) < 3:
            raise ValueError("HELP_KEY, STAND_KEY and STOP_KEY share a key: "
                             "give each key one action")

        desc = getattr(test_class, "COMMON_DESC", {})
        common = {values["HELP_KEY"]: ("help", self.show_help, False),
                  values["STAND_KEY"]: (desc.get("STAND_KEY", "stand pose"), self.stand, False),
                  values["STOP_KEY"]: (desc.get("STOP_KEY", "stop test"), self.stop_idle, False)}
        leg_select = {}
        if test_class.USES_LEG_SELECT:
            leg_select = {key: (f"select leg {name}", lambda name=name: self.select_leg(name), False)
                          for key, name in values["LEG_SELECT_KEYS"].items()}
            for name in values["LEG_SELECT_KEYS"].values():
                if name not in ports.LEG_NAMES:
                    raise ValueError(f"LEG_SELECT_KEYS '{name}': use one of FL, HL, HR, FR")
        test_keys = [(key, (desc, func, timed)) for key, desc, func, timed in self.test.actions()]

        self.table = {}
        entries = ([(k, v, "common keys") for k, v in common.items()] +
                   [(k, v, "LEG_SELECT_KEYS") for k, v in leg_select.items()] +
                   [(k, v, "test keys") for k, v in test_keys])
        owner = {}
        for key, item, group in entries:
            if key in self.table:
                raise ValueError(f"key {key_label(key)} is used twice: {owner[key]} ({self.table[key][0]}) "
                                 f"and {group} ({item[0]}). Give each key one action")
            self.table[key] = item
            owner[key] = group

        all_keys = [k for k, _ in test_keys] + list(leg_select) + list(common)
        self.keys = KeyEvents(all_keys, self.test.repeat_keys(), values.get("KEY_REPEAT_SEC", 0))

        self._help_on_screen = False
        self.stop_keys = [values["STOP_KEY"], values["STAND_KEY"]]
        self.robot.stop_check = self._stop_pressed
        stand_ko = getattr(test_class, "STAND_KO", 'Stand')
        self.robot.running_footer = scr.keys_line([(key_label(values["STOP_KEY"]), 'Stopped'),
                                                   (key_label(values["STAND_KEY"]), stand_ko)], " · ")

        self.print_guide()
        self.robot.check_servo_spec()
        self.test.enter()
        self.keys.clear()
        self.show_idle()

    def print_guide(self):
        """Print guide."""
        s = self.s
        test = self.test
        if hasattr(test, "common_guide"):
            lines = [test.common_guide()]
        else:
            lines = [f" {L.key(key_label(s['HELP_KEY']))} help   {L.key(key_label(s['STAND_KEY']))} stand   "
                     f"{L.key(key_label(s['STOP_KEY']))} stop test   quit: stop the script"]
        if test.USES_LEG_SELECT:
            legs = "  ".join(f"{L.key(key_label(k))} {name}" for k, name in s["LEG_SELECT_KEYS"].items())
            lines.append(f" Leg    {legs}   (now {self.robot.leg_name})")
        lines += test.guide()
        L.banner(test.HEADER, lines)

    def show_idle(self):
        """Show idle."""
        if hasattr(self.test, "show_idle"):
            self.test.show_idle()
        else:
            self.robot.show_page(*self.test.idle_page())

    def show_help(self):
        """Show help."""
        s = self.s
        self.print_guide()
        leg_keys = " ".join(key_label(k) for k in s.get("LEG_SELECT_KEYS", {}))
        if hasattr(self.test, "show_help_screen"):
            self.test.show_help_screen()
        else:
            footer = scr.keys_line([(key_label(s["STAND_KEY"]), 'Stand'), (key_label(s["STOP_KEY"]), 'Stopped')],
                                   " · ")
            self.robot.show_page(f"{self.test.SHORT} key help", self.test.help_lines(leg_keys), footer)
        self._help_on_screen = True

    def stand(self):
        """Stand."""
        if hasattr(self.test, "reset"):
            self.test.reset()
            return
        self.robot.stand()
        if hasattr(self.test, "on_stand"):
            self.test.on_stand()

    def stop_idle(self):
        """Stop idle."""
        if hasattr(self.test, "stop_idle"):
            self.test.stop_idle()
            return
        L.event("STATE", "no auto test running")

    def _stop_pressed(self):
        """Stop pressed."""
        pressed = self.keys.take(self.stop_keys)
        if self.s["STAND_KEY"] in pressed:
            return self.s["STAND_KEY"]
        return pressed[0] if pressed else None

    def after_stop(self, key, start):
        """After stop."""
        L.event("TASK", f"stopped by {L.key(key_label(key))} after {time.time() - start:.1f} s")
        self.keys.clear()
        if hasattr(self.test, "after_stop"):
            self.test.after_stop()
        if key == self.s["STAND_KEY"]:
            self.stand()
        else:
            self.robot.interrupted = True
            stand_desc = getattr(self.test, "COMMON_DESC", {}).get("STAND_KEY", "stand")
            L.event("STATE", f"legs held; next test starts from stand "
                             f"({L.key(key_label(self.s['STAND_KEY']))}: {stand_desc})")

    def select_leg(self, name):
        self.robot.leg = ports.LEG_NAMES.index(name)
        if hasattr(self.test, "on_leg_selected"):
            self.test.on_leg_selected()

    def handle(self, key):
        """Handle."""
        desc, func, timed = self.table[key]
        L.event("INPUT", f"{L.key(key_label(key), 4)} {desc}")
        if hasattr(self.test, "before_action"):
            self.test.before_action()
        self._help_on_screen = False
        start = time.time()
        try:
            if timed and self.robot.interrupted:
                L.event("STATE", "moving to stand pose before the test")
                if hasattr(self.test, "prepare"):
                    self.test.prepare()
                else:
                    self.stand()
            func()
            if timed:
                L.event("TASK", f"done in {time.time() - start:.1f} s")
        except TestStopped as stop:
            self.after_stop(stop.key, start)
        if not self._help_on_screen:
            self.show_idle()

    def update(self):
        for key in self.keys.pressed():
            self.handle(key)
        if hasattr(self.test, "on_loop"):
            self.test.on_loop()
        time.sleep(self.s["LOOP_SLEEP_SEC"])

    def run(self):
        """Run."""
        if not self.ready:
            return
        L.event("STATE", "ready")
        try:
            if getattr(self.test, "START_FILE", "") == "q01_balance_test_start.py":
                from scriptruntime import Runtime
                while not Runtime.quitting():
                    self.update()
            else:
                while True:
                    self.update()
        except KeyboardInterrupt:
            pass
        except Exception as e:
            L.event("ERROR", f"unexpected error: {e}")
            log_traceback()

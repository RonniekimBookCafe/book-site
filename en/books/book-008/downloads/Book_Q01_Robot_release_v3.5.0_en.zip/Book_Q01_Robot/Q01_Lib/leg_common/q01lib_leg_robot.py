# -*- coding: utf-8 -*-
"""q01lib_leg_robot: Educational library module for the QUAD-01 RoboCo series.

Quadruped robot state, initialization, and actuator connections."""

import time

from controllables import ServoMotor

from ..core import q01lib_ports as ports
from ..core.q01lib_servo import setup_canonical_servos
from ..core.q01lib_motion import LegMotion
from ..core.q01lib_screen import StatusScreen
from .q01lib_leg_check import foot_from_servo
from . import q01lib_leg_screen as scr
from ..core import q01lib_log as L    # Console logging helpers (L.event, L.more, L.key, etc.)

STAND_STEPS = 30
STOP_CHECK_SEC = 0.05


class TestStopped(Exception):
    """Test Stopped."""

    def __init__(self, key):
        super().__init__(key)
        self.key = key

PORT_NAMES = {}
for _leg, _name in enumerate(ports.LEG_NAMES):
    for _joint, _port in zip(("HX", "HY", "KN"), ports.LEG_JOINT_PORTS[_leg]):
        PORT_NAMES[_port] = f"{_name}_{_joint}"


def joint_list_text(joints):
    """Joint list text."""
    legs = [n for n in ports.LEG_NAMES if any(j.startswith(n + "_") for j in joints)]
    kinds = [k for k in ("HX", "HY", "KN") if any(j.endswith("_" + k) for j in joints)]
    if len(joints) == len(legs) * len(kinds):
        return f"{' '.join(kinds)} on {' '.join(legs)}"
    return " ".join(joints)


class LegTestRobot:
    """Leg Test Robot."""

    def __init__(self, settings):
        self.s = settings
        setup_canonical_servos()  # shared 12DOF motor contract
        start_leg = settings.get("START_LEG", ports.LEG_NAMES[0])
        if start_leg not in ports.LEG_NAMES:
            raise ValueError(f"START_LEG '{start_leg}': use one of FL, HL, HR, FR")
        self.rpm = settings["SERVO_RPM"]
        if not 0 < self.rpm <= ports.SERVO_RPM_MAX:
            raise ValueError(f"SERVO_RPM {self.rpm}: use a value above 0 and up to {ports.SERVO_RPM_MAX}")
        self.height = settings["BODY_HEIGHT"]
        self.feet_forward = settings.get("FEET_FORWARD", 0)
        self._screen = None
        self.motion = LegMotion(body_height=self.height, servo_rpm=self.rpm)
        self.angles = {}
        self.leg = ports.LEG_NAMES.index(start_leg)
        self.stop_check = None
        self.running_footer = ""
        self.interrupted = False

    def check_stop(self):
        """Check stop."""
        if self.stop_check is not None:
            key = self.stop_check()
            if key:
                raise TestStopped(key)

    def wait(self, seconds):
        """Wait."""
        remaining = seconds
        while remaining > 0:
            step = min(STOP_CHECK_SEC, remaining)
            time.sleep(step)
            remaining -= step
            self.check_stop()
        if seconds <= 0:
            self.check_stop()

    @property
    def screen(self):
        """Screen."""
        if self._screen is None:
            self._screen = StatusScreen(centered=True)
        return self._screen

    def show_page(self, title, body, footer):
        """Show page."""
        self.screen.show_lines(*scr.page(title, body, footer))

    def show_running(self, title, *body):
        """Show running."""
        self.show_page(title, body, self.running_footer)

    def check_servo_spec(self):
        """Check servo spec."""
        try:
            values = {port: {name: getattr(ServoMotor(port), name)
                             for name in ("max_torque", "acceleration_time")}
                      for port in ports.SERVO_ORDER}
        except Exception as e:
            L.event("WARN", f"cannot read servo settings ({e})")
            return
        L.event("STATE", f"servo action rpm={self.rpm:g}  default={ports.SERVO_RPM_DEFAULT:g}  "
                         f"accel={ports.SERVO_ACCELERATION_TIME:g} s")
        for port, value in values.items():
            expected = {"max_torque": ports.SERVO_MAX_TORQUE_BY_PORT[port],
                        "acceleration_time": ports.SERVO_ACCELERATION_TIME}
            for name, target in expected.items():
                if abs(value[name] - target) > 0.01 * max(1.0, abs(target)):
                    L.event("WARN", f"{ports.SERVO_PART_NAMES[port]} {name}={value[name]:g}, "
                                    f"expected {target:g}")

    @property
    def leg_name(self):
        return ports.LEG_NAMES[self.leg]

    def leg_servo(self, leg=None):
        """Leg servo."""
        leg = self.leg if leg is None else leg
        return [self.angles.get(p) for p in ports.LEG_JOINT_PORTS[leg]]

    def servo_text(self, leg=None, prefix=""):
        """Servo text."""
        return scr.joints(self.leg_servo(leg), "angle", prefix)

    def motor_text(self, leg=None):
        """Motor text."""
        values = [None if v is None else self.motion.servo.convert_angle(v) for v in self.leg_servo(leg)]
        return scr.joints(values, None, 'Motor ')

    def port_text(self, leg=None):
        """Port text."""
        return scr.joints(ports.LEG_JOINT_PORTS[self.leg if leg is None else leg], None, "Port ")

    def foot_text(self, leg=None):
        """Foot text."""
        leg = self.leg if leg is None else leg
        servo = self.leg_servo(leg)
        if None in servo:
            return scr.xyz(None, None, None, 'Foot ')
        x, y, z = (round(v) + 0 for v in foot_from_servo(leg, servo))
        return scr.xyz(x, y, z, 'Foot ')

    def send_joint(self, port, logical_angle, log_line=True):
        """Send joint."""
        old = self.angles.get(port)
        self.motion.servo.set_servo_angle(port, logical_angle, self.rpm)
        self.angles[port] = logical_angle
        if log_line:
            physical = self.motion.servo.convert_angle(logical_angle)
            before = "" if old is None else f"{old:3} -> "
            L.event("JOINT", f"{PORT_NAMES[port]:<5} port={port:<2}  in={before}{logical_angle:3} deg  "
                             f"motor={physical:3} deg")

    def log_foot(self, leg):
        """Log foot."""
        servo = self.leg_servo(leg)
        if None in servo:
            return
        x, y, z = (v + 0.0 for v in foot_from_servo(leg, servo))
        L.event("STATE", f"{ports.LEG_NAMES[leg]} foot (FK)  {L.xyz_text(x, y, z)}")

    def sync_from_motion(self):
        """Sync from motion."""
        for leg in range(4):
            for axis, port in enumerate(ports.LEG_JOINT_PORTS[leg]):
                self.angles[port] = self.motion.angles[leg][axis]

    def stand_positions(self):
        """Stand positions."""
        x = self.feet_forward
        y = ports.FOOT_Y_OFFSET
        h = self.height
        return [[x, y, -h], [x, y, -h], [x, -y, -h], [x, -y, -h]]

    def stand(self):
        """Stand."""
        self.motion.move_to(self.stand_positions(), STAND_STEPS)
        self.sync_from_motion()
        self.interrupted = False
        L.event("STATE", "stand pose")

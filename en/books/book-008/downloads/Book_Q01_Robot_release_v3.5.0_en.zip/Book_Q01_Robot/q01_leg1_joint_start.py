# -*- coding: utf-8 -*-
"""q01_leg1_joint_start.

QUAD-01 starter script. Leg Test 1: individual joint controls, limits, and servo angles. Attach to the matching RoboCo microcontroller; adjust CONTROL PARAMETERS and KEYS in this file. The Q01_Lib package implements the underlying movements.
Setup: README.md. What to observe, change, and compare in each exercise: the book."""

# --- SETUP CODE: Do not edit this section -----------------------------------
# Reload Q01_Lib on every run so edits to the library are picked up.
# This clears the previously cached module references;
# no source files are deleted from disk.
import sys as _sys

_sys.dont_write_bytecode = True  # Do not create __pycache__ files on each run

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.leg_common.q01lib_leg_app import LegTestApp
from Book_Q01_Robot.Q01_Lib.leg1_joint.q01lib_leg1_joint import JointTest


# ========================================
# 1. CONTROL PARAMETERS (change these values first)
# ========================================
SERVO_RPM = 30               # Maximum joint-servo speed (ServoMotor.max_rpm)
                             # Servo specs (max torque: knees 1720, hips HX/HY 13150; acceleration 0.2 s): Q01_Lib/core/q01lib_ports.py, section 7
BODY_HEIGHT = 99             # Default standing body height; foot-tip z = -BODY_HEIGHT
START_LEG = "FL"             # Initially selected leg (FL, HL, HR, FR)

# --- W/S/A/D/E/Q: Direct joint controls ---
JOINT_JOG_DEG = 10           # Joint-angle increment per manual keypress (degrees)
KEY_REPEAT_SEC = 0           # Key-hold repeat interval (seconds); 0 means once per press

# --- Keys 1–4: Individual-leg joint tests ---
# Logical angles are defined for left legs (FL/HL); right legs (HR/FR) receive 180° minus the angle.
LEFT_TEST_ANGLES = {
    "KN": [0, 90, 150, 90],  # Knee joint
    "HY": [0, 90, 180, 90],  # Hip Y joint
    "HX": [0, 90, 135, 90],  # Hip X joint
}
TEST_ORDER = ["KN", "HY", "HX"]   # Order in which joints are exercised in each test
JOINT_STEP_SEC = 1           # Wait time after each joint angle command (seconds)

# --- Key 5: Spread the HX joints on all four legs ---
SPREAD_LEFT_ANGLE = 0        # Left-leg HX spread angle; right legs use 180° minus this angle
SPREAD_HOLD_SEC = 2          # Hold time at the spread pose (seconds)
SPREAD_RETURN_SEC = 1        # Delay after returning to a 90° joint angle (seconds)

# --- Key 6: Four-leg pose sweep ---
SWEEP_HX_DEG = 90            # HX sweep range in one-degree increments
SWEEP_KN_DEG = 90            # Knee joint sweep range (degrees)
SWEEP_HY_DEG = 45            # Hip Y-axis sweep range (degrees)
SWEEP_STEP_SEC = 0.01        # Pause after each one-degree sweep step (seconds)
SWEEP_PAUSE_SEC = 1          # Pause after completing the HX and knee sweeps (seconds)
SWEEP_END_PAUSE_SEC = 2      # Pause after completing the HY sweep (seconds)
SWEEP_RESET_GROUP_SEC = 2    # Pause per joint group when returning to joint zero (seconds)

# --- Key 0: Joint zero pose ---
ZERO_GROUP_SEC = 1           # Pause between joint groups during zero-pose reset (seconds)

LOOP_SLEEP_SEC = 0.1         # Delay between main-loop input polls (seconds)

# --- CONSOLE LOG ---
LOG_COLOR = True             # Enable colored console logs; set False if <color=...> tags appear literally
WELCOME_SEC = 1.0           # Duration of the startup model name / WELCOME screen (seconds)
START_SCREEN_SEC = 1.0      # Duration of the introductory status screen (seconds)


# ========================================
# 2. KEYS (left-hand, right-hand, then custom keys)
# ========================================
# Left hand: direct joint control. Key -> (joint, direction of the angle change on a LEFT leg, +1/-1)
# Right legs get the opposite HY/KN direction, so all four legs move the same way.
JOG_KEYS = {
    "w": ("HY", -1),         # Move the leg forward (foot-tip x + in IK test)
    "s": ("HY", 1),          # Move the leg backward
    "a": ("HX", -1),         # Move the leg left (foot-tip y + in IK test)
    "d": ("HX", 1),          # Move the leg right
    "e": ("KN", 1),          # Bend the knee; lift the foot tip (z + in IK test)
    "q": ("KN", -1),         # Extend the knee; lower the foot tip
}

# Right hand: selected leg / leg selection
LEG_ZERO_KEY = "k"           # Reset the three joints of the selected leg to 90°
LEG_SELECT_KEYS = {          # Same layout as the legs seen from above
    "u": "FL",               # Front-left leg (U/O on the diagram)
    "o": "FR",               # Front-right leg
    "j": "HL",               # Hind-left leg (J/L on the diagram)
    "l": "HR",               # Hind-right leg
}

# Custom keys: automatic tests and common controls
LEG_TEST_KEYS = {            # Joint test for one leg
    "1": "FL",               # Front left
    "2": "HL",               # Hind left
    "3": "HR",               # Hind-right leg
    "4": "FR",               # Front-right leg
}
SPREAD_KEY = "5"             # Spread the HX joints on all four legs
SWEEP_KEY = "6"              # Run the coordinated four-leg pose sweep
ZERO_KEY = "0"               # Return to the joint zero pose

HELP_KEY = "f1"              # Show keyboard help in the console and robot display
STAND_KEY = "f2"             # All four legs to stand pose (stops a running auto test first)
STOP_KEY = "f3"              # Stop the auto test (legs stay where they are)


# ========================================
# 3. RUN (initialize once; stop when the script stops)
# ========================================
def main():
    app = LegTestApp(globals(), JointTest)  # Setup: collect values and keys, print the key guide
    app.run()                               # Loop: read keys -> direct joint control / auto tests


if __name__ == "__main__":
    main()

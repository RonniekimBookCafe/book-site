# -*- coding: utf-8 -*-
"""q01_body_pose_start.

QUAD-01 starter script. Body posture control: x/y/z displacement and roll/pitch/yaw orientation. Attach to the matching RoboCo microcontroller; adjust CONTROL PARAMETERS and KEYS in this file. The Q01_Lib package implements the underlying movements.
Setup: README.md. What to observe, change, and compare in each exercise: the book."""

# --- SETUP CODE: Do not edit this section -----------------------------------
# Reload Q01_Lib on every run so edits to the library are picked up.
# This clears the previously cached module references;
# no source files are deleted from disk.
import sys as _sys

_sys.dont_write_bytecode = True  # Do not create __pycache__ files on each run

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.leg_common.q01lib_leg_app import LegTestApp
from Book_Q01_Robot.Q01_Lib.body_pose.q01lib_body_pose_test import BodyPoseTest


# ========================================
# 1. CONTROL PARAMETERS (change these values first)
# ========================================
SERVO_RPM = 30               # Maximum joint-servo speed (ServoMotor.max_rpm)
                             # Servo specs (max torque: knees 1720, hips HX/HY 13150; acceleration 0.2 s): Q01_Lib/core/q01lib_ports.py, section 7

# --- Body dimensions (same length units as the 23/55/65 leg links) ---
BODY_HEIGHT = 99             # Default standing body height; foot-tip z = -BODY_HEIGHT
BODY_LENGTH = 136            # Distance between the front and hind hip-joint axes
BODY_WIDTH = 76              # Distance between the left and right hip-joint axes

# --- Increment applied per keypress ---
MOVE_STEP = 5                # Body x/y/z translation per keypress (leg-length units)
ANGLE_STEP_DEG = 5           # Body roll/pitch/yaw angle increment per keypress (degrees)
POSE_MOVE_STEPS = 1          # Interpolation steps per posture adjustment; 1 moves directly
KEY_REPEAT_SEC = 0           # Key-hold repeat interval (seconds); 0 means once per press

# --- Allowed body-pose ranges (minimum, maximum) ---
# An in-range pose may still be unreachable; e.g., rear-leg HY reaches 180° at pitch -15°.
X_RANGE = (-20, 20)          # Body translation range along x: forward (+), backward (-)
Y_RANGE = (-20, 20)          # Body translation range along y: left (+), right (-)
Z_RANGE = (-40, 20)          # Body translation range along z: up (+), down (-)
ROLL_RANGE = (-20, 20)       # Body roll-angle limits (degrees)
PITCH_RANGE = (-20, 20)      # Body pitch-angle limits (degrees)
YAW_RANGE = (-20, 20)        # Body yaw-angle limits (degrees)

# --- 1: Automatic body-pose test ---
AUTO_ANGLE_DEG = 10          # Positive/negative roll, pitch, and yaw amplitude in automatic test
AUTO_MOVE = 20               # Positive/negative body x/y/z displacement in automatic test
AUTO_STEP_SEC = 0.5          # Pause after each automatic movement step (seconds)

# --- Verify measured orientation using the robot IMU (Port 1) ---
USE_IMU = True               # True: 1 s after each key, log IMU roll/pitch/yaw next to the command
                             #   and show it on the bottom line of the robot screen. Without an IMU, warns and continues

LOG_DETAIL = False           # Print detailed foot, joint, PID, or leg-height diagnostics when enabled
LOOP_SLEEP_SEC = 0.1         # Delay between main-loop input polls (seconds)

# --- CONSOLE LOG ---
LOG_COLOR = True             # Enable colored console logs; set False if <color=...> tags appear literally
WELCOME_SEC = 1.0           # Duration of the startup model name / WELCOME screen (seconds)
START_SCREEN_SEC = 2.5      # Duration of the introductory status screen (seconds)


# ========================================
# 2. KEYS (left-hand, right-hand, then custom keys)
# ========================================
# Key -> (value to change, direction +1/-1)
POSE_KEYS = {
    # Left hand: move the body
    "w": ("x", 1),           # Forward (x +)
    "s": ("x", -1),          # Backward (x -)
    "a": ("y", 1),           # Left (y +)
    "d": ("y", -1),          # Right (y -)
    "e": ("z", 1),           # Up; body rises (z +)
    "q": ("z", -1),          # Down; body lowers (z -)
    # Right hand: tilt and turn the body
    "i": ("pitch", 1),       # Front of body tilts down (pitch +)
    "k": ("pitch", -1),      # Front of body tilts up (pitch -)
    "j": ("roll", -1),       # Left side tilts down (roll -)
    "l": ("roll", 1),        # Right side tilts down (roll +)
    "u": ("yaw", 1),         # Turn left, counterclockwise (yaw +)
    "o": ("yaw", -1),        # Turn right, clockwise (yaw -)
}

# Custom keys: automatic tests and common controls
AUTO_TEST_KEY = "1"          # Automatic test

HELP_KEY = "f1"              # Show keyboard help in the console and robot display
STAND_KEY = "f2"             # Stand pose (stops a running auto test first)
STOP_KEY = "f3"              # Stop the auto test (body stays in the stopped pose)


# ========================================
# 3. RUN (initialize once; stop when the script stops)
# ========================================
def main():
    app = LegTestApp(globals(), BodyPoseTest)  # Startup: move to standing and print the key reference
    app.run()                                  # Loop: read keys -> change body pose / auto test


if __name__ == "__main__":
    main()

# QUAD-01 | Rights and Use

This package supports the exercises in *Learning Physical AI with RoboCo: Robot Structure and Gait Control*.

- `Q01_Lib` and the start scripts are teaching code written by the author. They are not the official RoboCo Python API.
- The RoboCo name, game, logo, and in-game assets belong to their owners. This package includes no RoboCo game license and does not imply endorsement by or affiliation with the RoboCo developer.
- The book's explanations, figures, and tables are in the book and are not part of this package.
- Terms for redistributing, modifying, commercial use, and classroom use of the code and documents are on the book page. This notice does not grant an open-source license.

Book page: https://ronniekimbooks.com/en/books/book-008/

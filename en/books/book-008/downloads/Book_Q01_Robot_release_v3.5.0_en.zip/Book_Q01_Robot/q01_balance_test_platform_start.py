# -*- coding: utf-8 -*-
"""q01_balance_test_platform_start.

QUAD-01 starter script. Feedback balancing using IMU readings, PID control, and a tilt-test platform. Attach to the matching RoboCo microcontroller; adjust CONTROL PARAMETERS and KEYS in this file. The Q01_Lib package implements the underlying movements. The BALANCE configuration requires separate robot and platform microcontroller scripts.
Setup: README.md. What to observe, change, and compare in each exercise: the book."""

# --- SETUP CODE: Do not edit this section -----------------------------------
# Reload Q01_Lib on every run so edits to the library are picked up.
# This clears the previously cached module references;
# no source files are deleted from disk.
import sys as _sys

_sys.dont_write_bytecode = True  # Do not create __pycache__ files on each run

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.balance_test.q01lib_platform_app import PlatformApp


# ========================================
# 1. CONTROL PARAMETERS  (values to match the platform hardware)
# ========================================
# --- Tilt-platform servos ---
TILT_LIMIT_DEG = 15          # Safety limit of the platform tilt (degrees); clamps robot commands
# --- Platform servo speed (ServoMotor.max_rpm; RPM × 6 = degrees/second) ---
SERVO_RPM = None             # Reference speed. None = read the part's own setting at startup
                             # Speed multiplier (default x2.0) = PLATFORM_SPEED in the robot start file; change it live with the robot's 6/7

# --- Rotation-sign calibration: change only after direction check (key 1) ---
ROLL_SERVO_SIGN = 1          # Platform roll servo direction; use -1 if the tilt is reversed
PITCH_SERVO_SIGN = 1
YAW_SERVO_SIGN = -1          # This platform's yaw servo turns right (clockwise) for a + angle, so -1

# --- Platform IMU (Port 5): display the measured platform orientation ---
USE_IMU = True               # False: do not read the platform IMU
IMU_ROLL_SIGN = 1            # Platform IMU roll-direction sign, depending on mounting orientation
IMU_PITCH_SIGN = 1
IMU_YAW_SIGN = 1
IMU_SWAP_ROLL_PITCH = False
ZERO_SETTLE_SEC = 1.0        # Minimum level-platform settling time before IMU zero calibration
CALIBRATION_SAMPLES = 20     # IMU samples averaged during zero calibration after motion settles
IMU_STILL_DEG = 0.2          # Maximum IMU movement over 0.05s to count as still (degrees)

# --- Optional platform IMU reporting to the robot ---
ROBOT_MCU_PORT = None        # Platform MCU port assigned to the robot MCU; None auto-detects
REPORT_SEC = 0.5             # Interval for sending platform IMU readings to the robot (seconds)

# --- Loop timing and output ---
LOOP_SLEEP_SEC = 0.02        # Delay between main-loop input polls (seconds)
SCREEN_INTERVAL_SEC = 0.2    # Update period for the platform display (seconds)
PLATFORM_LOG = False         # When True, log platform commands and state; otherwise show alerts only
LOG_COLOR = True             # Enable colored console logs; set False if <color=...> tags appear literally


# ========================================
# 2. RUN  (initialize once, repeat until the script stops)
# ========================================
def main():
    from scriptruntime import Runtime
    Runtime.require_force_close(False)  # The BALANCE platform MCU also stops at once on Space
    # Setup: level the platform and zero the platform IMU
    app = PlatformApp(globals())
    # Loop: robot messages (or the same keys) -> tilt platform -> platform screen, (optional) send platform IMU to robot
    app.run()


if __name__ == "__main__":
    main()

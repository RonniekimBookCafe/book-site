# QUAD-01 Exercise Code | v3.5.0

**Book:** *Learning Physical AI with RoboCo: Robot Structure and Gait Control*  
**Series:** PHYSICAL AI · ROBOCO SERIES / QUAD-01 · WALK  
**Author:** Ronnie Kim  
**Book page:** https://ronniekimbooks.com/en/books/book-008/

This ZIP contains the eight Python start scripts and the author's teaching library, `Q01_Lib`, used in the book's exercises. What to watch in each exercise, which values to change, what to compare, and how to read the results are covered **in the book**. The RoboCo game and the robot models are not included.

## 1. What you need

| Item | Where to get it |
|---|---|
| RoboCo | Steam |
| The seven QUAD-01 robot models | Subscribe on Steam Workshop. Links are on the book page |
| Exercise code | This ZIP |
| Exercise order, what to watch, experiments, and the final mission | The book |

## 2. Install

1. In RoboCo, click **OPEN SCRIPT FOLDER** to open your `Scripts` folder.
2. Unzip this file and place the whole `Book_Q01_Robot` folder directly inside `Scripts`.  
   Example: `…/My Games/RoboCo/<Steam user name>/Scripts/Book_Q01_Robot/q01_walk_start.py`
3. Do not rename the folder or move `Q01_Lib` out of it.

## 3. First run: a walking quadruped

1. In RoboCo, load the `Book-QUAD-01-WALK` model.
2. On the robot's Microcontroller, click **LOAD**, choose `q01_walk_start.py`, and enter Live Mode.
3. Check that the console shows the `QUAD-01 WALK   (Book-QUAD-01-WALK)` box and `[STATE] ready`.
4. Hold `W` to walk forward; release it to return to the stand pose. `X` is the stop pose and `0` exits.

If this works, your installation is correct. The other keys, the automatic modes, and the experiments that change stride and gait speed start in Part 1 of the book.

## 4. Exercises

| Workshop model | Start script | Where the book covers it |
|---|---|---|
| Book-QUAD-01-WALK | `q01_walk_start.py` | Part 1 (Chapters 1, 3–5), Parts 4 and 5 |
| Book-QUAD-01-ACTION | `q01_action_start.py` | Chapter 2 |
| Book-QUAD-01-LEG1 | `q01_leg1_joint_start.py` | Chapters 6–8 |
| Book-QUAD-01-LEG2 | `q01_leg2_ik_start.py` | Chapters 11–13 |
| Book-QUAD-01-LEG3 | `q01_leg3_combined_start.py` | Chapters 14, 19, and 21 |
| Book-QUAD-01-ROLL_PITCH_YAW | `q01_body_pose_start.py` | Chapters 15 and 17 |
| Book-QUAD-01-BALANCE (robot) | `q01_balance_test_start.py` | Chapter 17 (optional exercise) |
| Book-QUAD-01-BALANCE (platform) | `q01_balance_test_platform_start.py` | Chapter 17 (optional exercise) |

Three rules when connecting:

- **Pair each model with its start script.** The first console box shows the model name (for example, `(Book-QUAD-01-WALK)`; BALANCE shows `QUAD-01 BALANCE TEST`). Check that it matches the model you loaded.
- **BALANCE has two Microcontrollers.** LOAD the robot script and the platform script from the table **separately**, one on each. Before turning on balance control, run the direction check in Chapter 17.
- **Do not let RoboCo Controls mappings drive the same servos.** If a mapping and the script move the same servo, the results cannot be read.

Each start script begins with `CONTROL PARAMETERS` and `KEYS`, where the values and keys you can change are grouped. Which value to change, when, by how much, and what to compare it with follow the matching chapter of the book.

## 5. Reading the console log

Every exercise writes the same English log format.

```text
[  3.2] [INPUT]     W    forward
[  4.2] [SENSOR]    imu   roll= +1.2  pitch= +0.0  yaw= +0.0 deg
[  5.0] [WARN]      foot out of reach (FL): servo command skipped
```

| Field | Meaning |
|---|---|
| `[  3.2]` | Seconds since the program started |
| `[INPUT]` etc. | Category: `INPUT` key · `PARAMETER` setting · `SENSOR` sensor · `STATE` state · `ACTION` motion · `JOINT` joint angle · `TASK` automatic test · `METRIC` result · `WARN` warning · `ERROR` error |
| The rest | Message. Values are `name=value`, with the unit once at the end |

When something goes wrong, start with the first `[WARN]` or `[ERROR]` line and the `[INPUT]` line just before it. If the console shows text such as `<color=#8A929C>`, set `LOG_COLOR = False` in the start script.

## 6. Installation troubleshooting

| Symptom | Fix |
|---|---|
| `ModuleNotFoundError: No module named 'Book_Q01_Robot'` | Put `Book_Q01_Robot` directly inside `Scripts` and keep its name |
| `ModuleNotFoundError: … Q01_Lib.core` or similar | Copy the whole folder again. Do not delete the `__init__.py` files in subfolders |
| No start box and no `[STATE] ready` in the console | LOAD the start script again on the model's Microcontroller |
| The model name in the first console box differs from the loaded model | Switch to the start script listed in section 4 |
| In BALANCE, a line without the `[time] [category]` prefix appears | LOAD `q01_balance_test_platform_start.py` on the platform Microcontroller |
| `[ERROR] setup failed` | Fix the value named on the next line in the start script, then LOAD again |
| An edit to a start script has no effect | Save, stop the script, then LOAD and run it again |

Causes and check order for joints turning the wrong way, feet slipping, or the platform tilting backward are covered in the matching chapters and appendices of the book.

## 7. Section numbers left in the code

Comments and some console messages still refer to sections of the development README. Read them as follows.

| Number in the code | Where to look |
|---|---|
| `README 8.1`, `README 11.1`–`11.3` | Chapter 17 of the book (tilt platform and balance test) |
| `README Chapter 12` | Section 5 of this README |
| `README 14`, `Chapter 14` | Appendix A of the book (ports, joints, axes) |

## 8. Files

```text
Book_Q01_Robot/
├─ q01_*_start.py        8 start scripts (LOAD on the model's Microcontroller)
├─ Q01_Lib/              Author's teaching library (not the official RoboCo API)
├─ README.md             This file
├─ COMPATIBILITY.md      Version and verification status
├─ RELEASE_NOTES.md      Changes
├─ RIGHTS_AND_USAGE.md   Rights and permitted use
└─ RELEASE_MANIFEST.json File list with SHA-256
```

## 9. Support

- Workshop model links, errata, and updates: https://ronniekimbooks.com/en/books/book-008/
- When you ask for help, include your RoboCo version, model name, start script, ZIP version (v3.5.0-en), and the first `[WARN]` or `[ERROR]` line.

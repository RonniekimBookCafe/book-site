# -*- coding: utf-8 -*-
"""q01_leg2_ik_start.

QUAD-01 starter script. Leg Test 2: foot Cartesian coordinates, inverse kinematics (IK), and forward kinematics (FK). Attach to the matching RoboCo microcontroller; adjust CONTROL PARAMETERS and KEYS in this file. The Q01_Lib package implements the underlying movements.
Setup: README.md. What to observe, change, and compare in each exercise: the book."""

# --- SETUP CODE: Do not edit this section -----------------------------------
# Reload Q01_Lib on every run so edits to the library are picked up.
# This clears the previously cached module references;
# no source files are deleted from disk.
import sys as _sys

_sys.dont_write_bytecode = True  # Do not create __pycache__ files on each run

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.leg_common.q01lib_leg_app import LegTestApp
from Book_Q01_Robot.Q01_Lib.leg2_ik.q01lib_leg2_ik import IKTest


# ========================================
# 1. CONTROL PARAMETERS (change these values first)
# ========================================
SERVO_RPM = 30               # Maximum joint-servo speed (ServoMotor.max_rpm)
                             # Servo specs (max torque: knees 1720, hips HX/HY 13150; acceleration 0.2 s): Q01_Lib/core/q01lib_ports.py, section 7
BODY_HEIGHT = 99             # Default standing body height; foot-tip z = -BODY_HEIGHT
START_LEG = "FL"             # Initially selected leg (FL, HL, HR, FR)

STEP_MM = 10                 # Foot-tip displacement per keypress (same units as the leg lengths)
MOVE_STEPS = 1               # Interpolation steps per foot-tip move; 1 moves directly
KEY_REPEAT_SEC = 0           # Key-hold repeat interval (seconds); 0 means once per press

# --- I: Draw a foot-tip circle in the x-z plane ---
# The default circle stays within reach, at least 3° from joint limits (0°/180°),
# with the foot at least 40 units below the hip (x 0–80, z -120 to -40).
CIRCLE_CENTER_X = 40         # Circle center along x (forward is positive)
CIRCLE_CENTER_Z = -80        # Circle center along z (up is positive)
CIRCLE_RADIUS = 40           # Radius of the foot-tip circle
CIRCLE_STEPS = 72            # Samples in one full circle (72 points = 5° increments)
CIRCLE_STEP_SEC = 0.08       # Pause per circle point (seconds)
CIRCLE_MOVE_STEPS = 20       # Interpolation steps when entering and exiting the circle

LOOP_SLEEP_SEC = 0.1         # Delay between main-loop input polls (seconds)

# --- CONSOLE LOG ---
LOG_COLOR = True             # Enable colored console logs; set False if <color=...> tags appear literally
WELCOME_SEC = 1.0           # Duration of the startup model name / WELCOME screen (seconds)
START_SCREEN_SEC = 1.0      # Duration of the introductory status screen (seconds)


# ========================================
# 2. KEYS (left-hand, right-hand, then custom keys)
# ========================================
# Left hand: foot-tip move direction (x, y, z), multiplied by STEP_MM
MOVE_KEYS = {
    "w": (1, 0, 0),          # Forward (x +)
    "s": (-1, 0, 0),         # Backward (x -)
    "a": (0, 1, 0),          # Left (y +)
    "d": (0, -1, 0),         # Right (y -)
    "e": (0, 0, 1),          # Up (z +)
    "q": (0, 0, -1),         # Down (z -)
}

# Right hand: draw circle / reset selected leg / select leg
CIRCLE_KEY = "i"             # Draw a circle with the selected foot tip
LEG_RESET_KEY = "k"          # Reset the selected leg to the default position
LEG_SELECT_KEYS = {          # Same layout as the legs seen from above
    "u": "FL",               # Front-left leg (U/O on the diagram)
    "o": "FR",               # Front-right leg
    "j": "HL",               # Hind-left leg (J/L on the diagram)
    "l": "HR",               # Hind-right leg
}

# Custom keys: common controls
HELP_KEY = "f1"              # Show keyboard help in the console and robot display
STAND_KEY = "f2"             # All four legs to stand pose (stops the circle first if running)
STOP_KEY = "f3"              # Stop the circle (legs stay where they are)


# ========================================
# 3. RUN (initialize once; stop when the script stops)
# ========================================
def main():
    app = LegTestApp(globals(), IKTest)  # Startup: stand and report IK data for the selected leg
    app.run()                            # Loop: read keys, move the foot tip, and report IK/FK results


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""q01_balance_test_start.

QUAD-01 starter script. Feedback balancing using IMU readings, PID control, and a tilt-test platform. Attach to the matching RoboCo microcontroller; adjust CONTROL PARAMETERS and KEYS in this file. The Q01_Lib package implements the underlying movements. The BALANCE configuration requires separate robot and platform microcontroller scripts.
Setup: README.md. What to observe, change, and compare in each exercise: the book."""

# --- SETUP CODE: Do not edit this section -----------------------------------
# Reload Q01_Lib on every run so edits to the library are picked up.
# This clears the previously cached module references;
# no source files are deleted from disk.
import sys as _sys

_sys.dont_write_bytecode = True  # Do not create __pycache__ files on each run

for _mod_name in list(_sys.modules.keys()):
    if _mod_name == "Book_Q01_Robot" or _mod_name.startswith("Book_Q01_Robot."):
        del _sys.modules[_mod_name]

from Book_Q01_Robot.Q01_Lib.leg_common.q01lib_leg_app import LegTestApp
from Book_Q01_Robot.Q01_Lib.balance_test.q01lib_balance_test import BalanceTest


# ========================================
# 1. CONTROL PARAMETERS (change these values first)
# ========================================
# --- PID maps body tilt (degrees) to correction angle (degrees); tune P/I/D with U/J, I/K, O/L ---
KP = 0.5                     # Proportional correction for current tilt; excessive gain may oscillate
KI = 1.5                     # Integral correction for persistent tilt over time
KD = 0.02                    # Derivative damping of tilt changes; excessive gain amplifies IMU noise
KP_LEVELS = [0, 0.25, 0.5, 1, 2, 4, 8]       # Selectable proportional gains, ascending; U/J step one level
KI_LEVELS = [0, 0.5, 1.5, 3, 6, 15, 30]      # I · K
KD_LEVELS = [0, 0.02, 0.05, 0.1, 0.3, 1]     # O · L
MAX_CORRECTION_DEG = 18      # Maximum body tilt used for correction; stop at unreachable poses
BALANCE_AT_START = False     # Enable feedback balancing immediately after startup when True

# --- Pass/fail thresholds for balance test 2 ---
LEVEL_OK_DEG = 2.0           # Final body-tilt threshold for a pass at each test pose (degrees)
SETTLE_DEG = 1.0             # Tilt threshold for recording settling time (degrees)

# --- Body geometry and pose (same length units as 23/55/65 leg links) ---
SERVO_RPM = 30               # Maximum joint-servo speed (ServoMotor.max_rpm)
BODY_HEIGHT = 99             # Default standing body height; foot-tip z = -BODY_HEIGHT
BODY_LENGTH = 136            # Distance between the front and hind hip-joint axes
BODY_WIDTH = 76              # Distance between the left and right hip-joint axes
FEET_FORWARD = 10            # Distance the four feet sit ahead of the hips in the stand pose. When the platform front drops (pitch +),
                             # the hind legs have room to correct: body pitch -18 to +26 deg (with 0: -14 to +26)

# --- IMU (Port 1) ---
FILTER_MODE = 'Kalman'          # Filter: 'None', 'Kalman', 'Moving Average', 'Kalman + Moving Average'
                             # (the console names "none", "kalman", "moving_avg", "kalman+avg" also work)
CALIBRATION_SAMPLES = 20     # IMU samples averaged during zero calibration after motion settles
IMU_STILL_DEG = 0.2          # "Still" = moves less than this in 0.05 s (5 in a row -> zero; waits up to 5 s)
                             # If "IMU not still" repeats while nothing is moving, raise it (e.g., 0.5)
ROLL_SIGN = 1                # Robot IMU roll sign; update only after direction verification
PITCH_SIGN = 1
YAW_SIGN = 1
SWAP_ROLL_PITCH = False

# --- 2-1. Tilt-platform MCU connection ---
PLATFORM_MCU_PORT = None     # Robot MCU port assigned to the platform MCU; None auto-detects
PLATFORM_STEP_DEG = 15       # Platform tilt increment per keypress (degrees)
PLATFORM_LIMIT_DEG = 15      # Maximum allowed platform tilt (degrees)
PLATFORM_SPEED = 2.0         # Platform servo speed multiplier relative to the component setting
PLATFORM_SPEED_STEP = 0.2    # Multiplier adjustment per speed-control keypress

# --- 2-2. Experiment sequence ---
CHECK_DEG = 15               # Platform/body tilt magnitude in direction-check test (degrees)
CHECK_HOLD_SEC = 2.0         # Platform pose hold time during direction check (seconds)
CHECK_MOVE_STEPS = 10        # Interpolation steps for body movement during direction check
TEST_POSES = [               # Successive platform roll/pitch/yaw test poses (degrees)
    (15, 0, 0), (0, 0, 0), (-15, 0, 0), (0, 0, 0),
    (0, 15, 0), (0, 0, 0), (0, -15, 0), (0, 0, 0),
]
TEST_HOLD_SEC = 3.0          # Hold time for each platform test pose (seconds)
SWAY_HOLD_SEC = 2.0          # Hold time per pose in continuously repeated sway testing

# --- Loop timing and output ---
KEY_REPEAT_SEC = 0            # Key-hold repeat interval (seconds); 0 means once per press
LOG_INTERVAL_SEC = 1.0       # Console state logging interval (seconds); 0 disables periodic logs
LOG_DETAIL = False           # Print detailed foot, joint, PID, or leg-height diagnostics when enabled
LOOP_SLEEP_SEC = 0.02        # Delay between main-loop input polls (seconds)

# --- CONSOLE LOG ---
LOG_COLOR = True             # Enable colored console logs; set False if <color=...> tags appear literally
WELCOME_SEC = 1.0           # Duration of the startup model name / WELCOME screen (seconds)
START_SCREEN_SEC = 2.5      # Duration of the introductory status screen (seconds)

# --- Robot Text Screen ---
POPUP_SEC = 2.0              # Duration of key feedback popups (seconds); 0 disables them


# ========================================
# 2. KEYS (left-hand, right-hand, then custom keys)
# ========================================
# Left hand: tilt the platform. Key -> (axis, direction +1/-1)
PLATFORM_KEYS = {
    "w": ("pitch", 1),       # Front tilts down (pitch +)
    "s": ("pitch", -1),      # Front tilts up (pitch -)
    "a": ("roll", -1),       # Left side tilts down (roll -)
    "d": ("roll", 1),        # Right side tilts down (roll +)
    "q": ("yaw", 1),         # Rotate left (yaw +)
    "e": ("yaw", -1),        # Rotate right (yaw -)
}

# Right hand: change PID gains. Key -> (gain, direction +1/-1)
GAIN_KEYS = {
    "u": ("KP", 1),          # KP +
    "j": ("KP", -1),         # KP -
    "i": ("KI", 1),          # KI +
    "k": ("KI", -1),         # KI -
    "o": ("KD", 1),          # KD +
    "l": ("KD", -1),         # KD -
}

# Custom keys (an unlinked platform script also reads 1 2 3 5 6 7 8 and F2 F3 the same way)
CHECK_KEY = "1"              # Run the automated direction check
TEST_KEY = "2"               # Run the automated balance test
COMPARE_KEY = "3"            # Compare the same platform motion with balance OFF and ON
BALANCE_KEY = "4"            # Toggle feedback balance control on/off
LEVEL_KEY = "5"              # Return the test platform to level
PLATFORM_SLOWER_KEY = "6"    # Decrease the platform servo speed multiplier
PLATFORM_FASTER_KEY = "7"    # Increase the platform servo speed multiplier
SWAY_KEY = "8"               # Toggle continuously repeated platform swaying

HELP_KEY = "f1"              # Show keyboard help in the console and robot display
STAND_KEY = "f2"             # Reset: level platform, balance OFF, stand pose, IMU zero
STOP_KEY = "f3"              # Stop all: tests and platform


# ========================================
# 3. RUN (initialize once; stop when the script stops)
# ========================================
def main():
    from scriptruntime import Runtime
    Runtime.require_force_close(False)  # Space stops the script at once; no extra shutdown wait
    app = LegTestApp(globals(), BalanceTest)  # Setup: level platform, stand, IMU zero, key guide
    app.run()                                 # Loop: keys -> platform/tests; IMU -> PID (if ON) -> legs, screen, console


if __name__ == "__main__":
    main()

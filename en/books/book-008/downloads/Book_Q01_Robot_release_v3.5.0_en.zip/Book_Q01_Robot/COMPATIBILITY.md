# QUAD-01 | Version and Verification Status

| Item | Status |
|---|---|
| Book | *Learning Physical AI with RoboCo: Robot Structure and Gait Control* · QUAD-01 |
| Reader ZIP | `Book_Q01_Robot_release_v3.5.0_en.zip` |
| Package version | v3.5.0-en (final, 2026-11-08) |
| Python code base | v3.4.9. Same program logic as the Korean v3.5.0 package; comments, docstrings, and on-screen text are in English |
| RoboCo game build | **Recorded on the book page after testing** |
| RoboCo Python API | Written against the 0.3.1 documentation. Re-check against your game version |
| Workshop model IDs | **Listed on the book page** (models are not in this ZIP) |
| Python syntax, ZIP structure, file hashes | Checked |
| Live Mode, walking, IMU, platform, English screen layout | **Results recorded on the book page after in-game testing** |

The `v3.4.3`, `v3.9.7`, and `v3.4.9` labels at the top of the start scripts are per-file development history. The package version is v3.5.0-en.

If a game update changes behavior, the tested build and any fixed files will be posted on the book page. Compatibility and success rates are not guaranteed until the scripts have been run on the same RoboCo build.
